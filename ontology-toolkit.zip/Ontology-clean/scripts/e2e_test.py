"""端到端测试：上传文档 → 构建本体 → 查询"""

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import select, text
from backend.db import engine, async_session
from backend.ontology.models import Base, Object, Link, ObjectType
from backend.ontology.crud import ensure_default_types
from backend.document.pipeline import process_document


async def main():
    # 1. 重建表
    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)

    async with async_session() as session:
        await ensure_default_types(session)

        # 2. 处理九峰公司介绍
        test_file = "/Users/fred/Documents/cc_Projects/Taishan/一期库/九峰/raw/九峰_公司产品/九峰_公司介绍_20250520_v1_方铭.docx"

        print("=== 端到端测试 ===\n")
        print(f"处理文档: {os.path.basename(test_file)}")

        result = await process_document(test_file, session)
        print(f"\n结果:")
        print(f"  文档ID: {result['document_id']}")
        print(f"  实体数: {result['objects_count']}")
        print(f"  关系数: {result['links_count']}")

        print(f"\n实体列表:")
        for obj in result["objects"]:
            print(f"  [{obj['type']}] {obj['name']}")

        # 3. 查询统计（用 join 避免 lazy load）
        from sqlalchemy.orm import selectinload
        obj_count = (await session.execute(
            select(Object).options(selectinload(Object.type))
        )).scalars().all()
        link_count = (await session.execute(select(Link))).scalars().all()

        print(f"\n=== 数据库统计 ===")
        print(f"  总实体: {len(obj_count)}")
        print(f"  总关系: {len(link_count)}")

        # 按类型统计
        type_counts = {}
        for o in obj_count:
            type_name = o.type.name if o.type else "?"
            type_counts[type_name] = type_counts.get(type_name, 0) + 1

        print(f"\n按类型:")
        for t, c in sorted(type_counts.items()):
            print(f"  {t}: {c}")

        # 4. 验收标准
        print(f"\n=== 验收 ===")
        print(f"  实体数 > 10: {'✅' if len(obj_count) > 10 else '❌'} ({len(obj_count)})")
        print(f"  关系数 > 5: {'✅' if len(link_count) > 5 else '❌'} ({len(link_count)})")

    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
