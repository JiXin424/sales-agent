import { useState } from 'react';
import { Tabs, Input, Button, Card, Spin, Empty } from 'antd';
import {
  FileSearchOutlined,
  WarningOutlined,
  SwapOutlined,
  FileDoneOutlined,
} from '@ant-design/icons';
import { coachPrep, coachObjection, coachComparison, coachReview } from '../services/api';

interface TabResult {
  loading: boolean;
  content: string | null;
}

const initialResult = (): TabResult => ({ loading: false, content: null });

export default function CoachPage() {
  const [inputs, setInputs] = useState({ prep: '', objection: '', comparison: '', review: '' });
  const [results, setResults] = useState({
    prep: initialResult(),
    objection: initialResult(),
    comparison: initialResult(),
    review: initialResult(),
  });

  const setResult = (key: keyof typeof results, val: Partial<TabResult>) => {
    setResults((prev) => ({ ...prev, [key]: { ...prev[key], ...val } }));
  };

  const handleAction = async (
    key: keyof typeof inputs,
    apiFn: (v: string) => Promise<{ data: unknown }>,
    field?: string
  ) => {
    const val = inputs[key].trim();
    if (!val) return;
    setResult(key, { loading: true, content: null });
    try {
      const res = await apiFn(val);
      const data = res.data as Record<string, unknown>;
      setResult(key, {
        loading: false,
        content: (data[field || 'result'] || data['answer'] || JSON.stringify(data, null, 2)) as string,
      });
    } catch {
      setResult(key, { loading: false, content: '发生了错误，请重试。' });
    }
  };

  const renderTab = (
    key: keyof typeof inputs,
    placeholder: string,
    isTextarea: boolean,
    btnLabel: string,
    apiFn: (v: string) => Promise<{ data: unknown }>,
    field?: string
  ) => (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {isTextarea ? (
          <Input.TextArea
            rows={4}
            placeholder={placeholder}
            value={inputs[key]}
            onChange={(e) => setInputs((prev) => ({ ...prev, [key]: e.target.value }))}
          />
        ) : (
          <Input
            placeholder={placeholder}
            value={inputs[key]}
            onChange={(e) => setInputs((prev) => ({ ...prev, [key]: e.target.value }))}
            onPressEnter={() => handleAction(key, apiFn, field)}
          />
        )}
        <Button type="primary" onClick={() => handleAction(key, apiFn, field)} loading={results[key].loading}>
          {btnLabel}
        </Button>
      </div>
      {results[key].loading && <Spin style={{ display: 'block', margin: '40px auto' }} />}
      {!results[key].loading && results[key].content && (
        <Card size="small" style={{ whiteSpace: 'pre-wrap', marginTop: 8 }}>
          {results[key].content}
        </Card>
      )}
      {!results[key].loading && !results[key].content && (
        <Empty description="输入主题后点击按钮" style={{ marginTop: 40 }} />
      )}
    </div>
  );

  return (
    <div style={{ maxWidth: 900 }}>
      <h2 style={{ color: '#e6edf3', marginBottom: 24 }}>销售教练</h2>
      <Tabs
        items={[
          {
            key: 'prep',
            label: (
              <span>
                <FileSearchOutlined /> 拜访准备
              </span>
            ),
            children: renderTab('prep', '输入客户或商机名称...', false, '生成方案', coachPrep),
          },
          {
            key: 'objection',
            label: (
              <span>
                <WarningOutlined /> 异议处理
              </span>
            ),
            children: renderTab('objection', '描述客户异议...', false, '处理', coachObjection),
          },
          {
            key: 'comparison',
            label: (
              <span>
                <SwapOutlined /> 竞品分析
              </span>
            ),
            children: renderTab('comparison', '输入竞品名称...', false, '对比', coachComparison),
          },
          {
            key: 'review',
            label: (
              <span>
                <FileDoneOutlined /> 访后复盘
              </span>
            ),
            children: renderTab('review', '粘贴拜访记录...', true, '分析', coachReview, 'visit_notes'),
          },
        ]}
      />
    </div>
  );
}
