#!/usr/bin/env python3
"""从 scenarios_10_sales_coaching.md 补建销售场景实体

为什么这么做：
synonyms.json 里 scenario_synonyms 的 15 个 standard（价格异议、初次拜访...），
在本体里没有 name 完全相同的实体，导致 Layer 2 同义词命中拿到 standard 后
找不到对应实体，core_entities 经常为空。

补建策略：
- 用 scenarios_10_sales_coaching.md 的 10 个销售教练场景作为内容源
- name 直接用 synonym standard 词（"价格异议"），保证 L2 命中后能 name 匹配
- 同时保留 md 里的完整场景名作为 alias
- description / pain_points / typical_objections 从 md 引导问题提炼
- related_principles 按场景内容关联到本体已有 principle

写入 influence_ontology_cleaned.json 的 scenarios 列表（先备份 .bak3）。
"""

import json
import shutil
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CLEANED = BASE_DIR / "influence_ontology_cleaned.json"
BACKUP = BASE_DIR / "influence_ontology_cleaned.json.bak3"

# 10 个新场景：name = synonym standard，alias = md 里的完整名
# content 从 scenarios_10_sales_coaching.md 提炼
NEW_SCENARIOS = [
    {
        "id": "scenario-initial-visit",
        "name": "初次拜访",
        "alias": "大客户初次拜访",
        "category": "通用销售",
        "difficulty": "高",
        "description": (
            "第一次拜访客户时的典型场景。客户时间紧张、对销售有戒备心理，"
            "需要快速建立信任、应对'见多了'式的拒绝、把模糊的'再联系'转化为明确的下一步承诺。"
        ),
        "pain_points": [
            "客户时间紧张，没耐心听完介绍",
            "客户戒备心理强，'你们这类销售我见多了'",
            "'再联系'式敷衍，无法推进到下一步"
        ],
        "related_principles": ["喜好原理", "互惠原理", "承诺和一致原理"],
        "typical_objections": [
            "不需要",
            "已经有供应商了",
            "发资料给我看看",
            "再联系吧"
        ],
    },
    {
        "id": "scenario-price-objection",
        "name": "价格异议",
        "alias": "价格异议处理",
        "category": "通用销售",
        "difficulty": "高",
        "description": (
            "客户嫌贵的应对场景。客户说'比竞品贵 30%'、'预算不够'、'能不能便宜'时，"
            "需要在不降价的前提下让客户理解价值差异，改变参照系从'比谁便宜'转向'值多少钱'，"
            "用拒绝—后撤术处理折扣要求以维护价格体系。"
        ),
        "pain_points": [
            "客户拿竞品价格做锚定，要求降价",
            "预算约束真实存在，硬塞价值客户听不进",
            "客户习惯性砍价，试探底线"
        ],
        "related_principles": ["对比原理", "互惠原理", "稀缺原理"],
        "typical_objections": [
            "比竞品贵 30%",
            "预算只有这么多",
            "能不能便宜点",
            "别人家更便宜"
        ],
    },
    {
        "id": "scenario-stakeholder-mapping",
        "name": "多方决策梳理",
        "alias": "多方决策人梳理",
        "category": "ToB 销售",
        "difficulty": "极高",
        "description": (
            "ToB 多方决策场景。客户内部决策链复杂（采购/IT/业务/财务），"
            "需要识别真正的决策者、把中间联系人培养成内部盟友、"
            "让不同角色的决策者都感受到价值并获得支持。"
        ),
        "pain_points": [
            "决策链复杂，找错联系人浪费时间",
            "中间人不愿引荐决策者",
            "不同角色关心点不同，难以同时满足"
        ],
        "related_principles": ["喜好原理", "社会认同原理", "权威原理"],
        "typical_objections": [
            "我不是决策人",
            "需要内部讨论",
            "业务部门没空",
            "IT 那边有顾虑"
        ],
    },
    {
        "id": "scenario-competitor-displacement",
        "name": "竞品对比",
        "alias": "替换在用竞品",
        "category": "ToB 销售",
        "difficulty": "高",
        "description": (
            "客户已用竞品的替换场景。客户有稳定运行的竞品系统、长期合作的供应商，"
            "需要找到切入点、不攻击对手的前提下发现未被满足的需求、"
            "用低成本试点降低客户的换供应商风险感知。"
        ),
        "pain_points": [
            "客户对现有供应商满意度高，没动力换",
            "更换成本和风险客户不愿承担",
            "现有合同未到期，没有窗口"
        ],
        "related_principles": ["对比原理", "互惠原理", "稀缺原理"],
        "typical_objections": [
            "我们用现在的不挺好的",
            "换供应商太麻烦",
            "等合同到期再说",
            "你们能比现在的强多少"
        ],
    },
    {
        "id": "scenario-rfp-response",
        "name": "招标响应",
        "alias": "招标书响应策略",
        "category": "ToB 销售",
        "difficulty": "高",
        "description": (
            "客户发 RFP（招标书）的响应场景。参数明显偏向竞品、技术评分落后时，"
            "需要差异化响应避免参数比拼、通过商务条款和风险评估扭转局面、"
            "用锚定效应重新定义价格坐标系。"
        ),
        "pain_points": [
            "招标书参数偏向竞品，技术分落后",
            "价格被压制，难以维持利润",
            "客户只看分数不听价值"
        ],
        "related_principles": ["对比原理", "权威原理", "社会认同原理"],
        "typical_objections": [
            "你们价格最高",
            "技术评分不占优",
            "参数对不上"
        ],
    },
    {
        "id": "scenario-internal-champion",
        "name": "培养内部支持者",
        "alias": "培养内部支持者",
        "category": "ToB 销售",
        "difficulty": "中",
        "description": (
            "客户内部有人认可方案但影响力不够的场景。需要把支持者升级为内部倡导者、"
            "让他在关键决策会议上主动发声、降低他向上管理的风险感知。"
        ),
        "pain_points": [
            "支持者人微言轻，影响不了决策",
            "支持者怕向上管理失败影响自己前途",
            "支持者不知道怎么内部推动"
        ],
        "related_principles": ["喜好原理", "承诺和一致原理", "社会认同原理"],
        "typical_objections": [
            "我说了不算",
            "我不想冒头",
            "领导不会听的"
        ],
    },
    {
        "id": "scenario-deal-closing",
        "name": "推进成交",
        "alias": "商务谈判收尾",
        "category": "通用销售",
        "difficulty": "高",
        "description": (
            "签约前的最后冲刺场景。客户突然提额外要求、要求先试用再付款、"
            "陷入'不满足这个条件就不签'的僵局时，需要用条件交换维护利润、"
            "用承诺和一致原理破局。"
        ),
        "pain_points": [
            "签约前客户临时加要求",
            "客户要求先试用再付款，现金流压力",
            "谈判僵局，客户下最后通牒"
        ],
        "related_principles": ["承诺和一致原理", "互惠原理", "稀缺原理"],
        "typical_objections": [
            "再加个保修/培训",
            "先试用再付款",
            "不满足这个条件就不签"
        ],
    },
    {
        "id": "scenario-dormant-revival",
        "name": "客户拖延",
        "alias": "唤醒沉睡客户",
        "category": "通用销售",
        "difficulty": "中",
        "description": (
            "客户搁置项目、长期拖延的场景。客户搁置半年没动静、说'预算被砍'、"
            "一直拖延决策时，需要重新激活、用时间窗口制造紧迫感、放大拖延成本推动决策。"
        ),
        "pain_points": [
            "项目搁置，无人推进",
            "客户用'预算被砍'推脱",
            "长期跟进后仍然拖延"
        ],
        "related_principles": ["稀缺原理", "承诺和一致原理", "对比原理"],
        "typical_objections": [
            "项目暂时搁置",
            "预算被砍了",
            "再等等吧",
            "今年不一定能定"
        ],
    },
    {
        "id": "scenario-upsell-existing",
        "name": "老客户",
        "alias": "存量客户扩Scope",
        "category": "通用销售",
        "difficulty": "中",
        "description": (
            "老客户增购扩模块的场景。客户只用基础模块、说'现有功能够用'、"
            "总部压降本指标时，需要让客户意识到未使用功能的隐性价值、"
            "在不降价的前提下推动增购。"
        ),
        "pain_points": [
            "客户用基础模块就够了，没动力扩",
            "客户总部压降本，扩购预算紧",
            "客户感知不到高级模块的价值"
        ],
        "related_principles": ["对比原理", "社会认同原理", "稀缺原理"],
        "typical_objections": [
            "现有功能够用",
            "预算在收紧",
            "高级模块太贵",
            "暂时不需要"
        ],
    },
    {
        "id": "scenario-loss-recovery",
        "name": "丢单",
        "alias": "丢单后挽回关系",
        "category": "通用销售",
        "difficulty": "高",
        "description": (
            "丢单后维护关系的场景。客户选了竞品、说'服务太差'流失、"
            "拒绝沟通时，需要为下一次机会埋伏笔、承认问题并证明改进、"
            "通过提供价值重新建立连接。也覆盖成交后的关系维护。"
        ),
        "pain_points": [
            "丢单后客户拒绝沟通",
            "客户因服务问题流失",
            "缺乏下一次合作的机会点"
        ],
        "related_principles": ["互惠原理", "喜好原理", "社会认同原理"],
        "typical_objections": [
            "已经选了别家",
            "你们服务太差",
            "暂时不需要联系",
            "以后再说"
        ],
    },
]

# 把"关系维护"作为丢单的关联 standard，单独补一个轻量场景
EXTRA_SCENARIOS = [
    {
        "id": "scenario-relationship-maintenance",
        "name": "关系维护",
        "alias": "客户长期关系经营",
        "category": "通用销售",
        "difficulty": "中",
        "description": (
            "成交后/未成交客户的长期关系维护。包括定期跟进、价值持续输出、"
            "节日/关键节点触达、把单次交易转化为长期合作伙伴关系。"
        ),
        "pain_points": [
            "成交后客户流失",
            "缺乏持续触达的理由",
            "关系淡出后无法重新激活"
        ],
        "related_principles": ["喜好原理", "互惠原理", "联盟原理"],
        "typical_objections": [
            "暂时不需要",
            "我们换了负责人",
            "以后有需要再联系"
        ],
    },
    {
        "id": "scenario-trust-building",
        "name": "建立信任",
        "alias": "信任建立",
        "category": "通用销售",
        "difficulty": "高",
        "description": (
            "销售早期建立信任的场景。客户对销售有戒备、对产品/公司不熟悉时，"
            "需要通过提供价值、展示专业、引入权威背书、利用相似性等方式降低戒备、"
            "建立可信赖的顾问形象。"
        ),
        "pain_points": [
            "客户对销售戒备心强",
            "缺乏信任基础，难以推进",
            "客户不认可销售专业度"
        ],
        "related_principles": ["喜好原理", "权威原理", "互惠原理"],
        "typical_objections": [
            "我不认识你",
            "你怎么证明",
            "我为什么要信你"
        ],
    },
    {
        "id": "scenario-urgency-creation",
        "name": "制造紧迫感",
        "alias": "紧迫感营造",
        "category": "通用销售",
        "difficulty": "中",
        "description": (
            "推动客户尽快决策的场景。客户犹豫不决、缺乏行动力时，"
            "需要用稀缺原理（数量有限/时间有限）、潜在损失放大、竞争氛围等方式，"
            "让客户感到'现在不决定就亏了'。"
        ),
        "pain_points": [
            "客户没有决策紧迫感",
            "客户觉得'以后再说也行'",
            "缺乏制造稀缺的合理理由"
        ],
        "related_principles": ["稀缺原理", "对比原理", "社会认同原理"],
        "typical_objections": [
            "不着急",
            "再考虑考虑",
            "下个季度再说"
        ],
    },
    {
        "id": "scenario-cold-customer",
        "name": "冷漠客户",
        "alias": "冷漠客户激活",
        "category": "通用销售",
        "difficulty": "高",
        "description": (
            "客户冷淡、没兴趣、不回应的场景。客户以'没时间'、'不需要'推脱时，"
            "需要重新唤起兴趣、用反向问题/痛点刺激/第三方案例打破冷漠。"
        ),
        "pain_points": [
            "客户回复冷淡甚至不回",
            "客户明确表示'不需要'",
            "客户对销售套路免疫"
        ],
        "related_principles": ["喜好原理", "社会认同原理", "稀缺原理"],
        "typical_objections": [
            "没时间",
            "不需要",
            "不感兴趣",
            "别再联系了"
        ],
    },
    {
        "id": "scenario-hesitation",
        "name": "客户犹豫",
        "alias": "客户犹豫处理",
        "category": "通用销售",
        "difficulty": "中",
        "description": (
            "客户拿不定主意的场景。客户在多个方案间纠结、被内部不同意见影响、"
            "担心决策错误时，需要帮客户理清决策标准、用小承诺推进、"
            "提供安全感降低决策风险。"
        ),
        "pain_points": [
            "客户在多个方案间反复",
            "客户内部意见不统一",
            "客户担心决策失误"
        ],
        "related_principles": ["承诺和一致原理", "社会认同原理", "权威原理"],
        "typical_objections": [
            "再想想",
            "内部还没统一",
            "怕选错"
        ],
    },
    {
        "id": "scenario-rejection-handling",
        "name": "拒绝",
        "alias": "拒绝处理",
        "category": "通用销售",
        "difficulty": "高",
        "description": (
            "客户直接拒绝的场景。客户说'不要'、'不需要'、'没兴趣'时，"
            "需要识别拒绝的真实原因（價格/价值/信任/时机）、用反向问题挖掘需求、"
            "把拒绝转化为继续对话的契机。"
        ),
        "pain_points": [
            "客户直接拒绝，无对话空间",
            "拒绝理由不真实，难以对症下药",
            "拒绝后无法二次接触"
        ],
        "related_principles": ["互惠原理", "喜好原理", "承诺和一致原理"],
        "typical_objections": [
            "不要",
            "不需要",
            "没兴趣",
            "已经买过类似的"
        ],
    },
]


def main():
    if not CLEANED.exists():
        raise SystemExit(f"找不到 cleaned.json: {CLEANED}")

    with open(CLEANED, 'r', encoding='utf-8') as f:
        ont = json.load(f)

    existing_ids = {s.get('id') for s in ont.get('scenarios', [])}
    existing_names = {s.get('name') for s in ont.get('scenarios', [])}

    all_new = NEW_SCENARIOS + EXTRA_SCENARIOS
    added = 0
    skipped = 0
    for sc in all_new:
        if sc['id'] in existing_ids or sc['name'] in existing_names:
            print(f"  跳过（已存在）: {sc['name']}")
            skipped += 1
            continue
        sc['type'] = 'scenario'
        ont['scenarios'].append(sc)
        added += 1

    # 同步补 relations：每个新场景 → 关联 principle
    # 找 principle id 映射
    principle_name_to_id = {}
    for p in ont.get('principles', []):
        n = p.get('name')
        if n:
            principle_name_to_id[n] = p.get('id')

    relation_added = 0
    existing_relations = {(r.get('from_id'), r.get('to_id'), r.get('relation_type'))
                          for r in ont.get('relations', [])}
    for sc in all_new:
        sid = sc.get('id')
        for pname in sc.get('related_principles', []):
            pid = principle_name_to_id.get(pname)
            if not pid:
                continue
            key = (sid, pid, 'applies')
            if key in existing_relations:
                continue
            ont['relations'].append({
                'from_id': pid,
                'to_id': sid,
                'relation_type': 'applies',
                'description': f"{pname}适用于{sc['name']}场景"
            })
            existing_relations.add(key)
            relation_added += 1

    if not BACKUP.exists():
        shutil.copy2(CLEANED, BACKUP)
        print(f"备份: {BACKUP}")
    else:
        print(f"备份已存在（不覆盖）: {BACKUP}")

    with open(CLEANED, 'w', encoding='utf-8') as f:
        json.dump(ont, f, ensure_ascii=False, indent=2)

    print(f"\n新增 scenario 实体: {added} 个")
    print(f"跳过（已存在）: {skipped} 个")
    print(f"新增 applies 关系: {relation_added} 条")
    print(f"当前 scenarios 总数: {len(ont['scenarios'])}")
    print(f"当前 relations 总数: {len(ont['relations'])}")


if __name__ == '__main__':
    main()
