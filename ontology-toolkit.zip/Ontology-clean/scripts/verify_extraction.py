"""V5: 实体抽取 Prompt Baseline — 用 DeepSeek 从 Markdown 抽取实体"""

import asyncio
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
from openai import AsyncOpenAI

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))

def build_prompt(content: str) -> str:
    return f"""你是一个销售知识本体抽取专家。从以下文档中抽取所有销售相关的实体和关系。

请按以下 JSON 格式输出：

{{
  "objects": [
    {{"type": "Company|Product|Competitor|Feature|Scenario|Pricing|Certification|CustomerSegment", "name": "实体名称", "properties": {{"key": "value"}}}}
  ],
  "relations": [
    {{"source": "源实体名", "target": "目标实体名", "type": "produces|competes_with|targets|includes|priced_at|certified_for|solves"}}
  ]
}}

只抽取文档中明确提到的信息，不要推测。每个实体必须有 type 和 name。

文档内容：
---
{content}
---

请输出 JSON："""


async def main():
    test_output_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "test_output",
    )

    # 直接读 AFC2md 生成的 Markdown（保存在源文件旁边）
    md_path = "/Users/fred/Documents/cc_Projects/Taishan/一期库/九峰/raw/九峰_公司产品/九峰_公司介绍_20250520_v1_方铭.md"
    if not os.path.exists(md_path):
        print("❌ 未找到 Markdown 文件，请先运行 V4")
        return

    md_file = os.path.basename(md_path)
    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()

    print(f"V5: 实体抽取 Baseline")
    print(f"输入文件: {md_file} ({len(content)} 字符)\n")

    # 截取前 4000 字符（避免超长）
    content = content[:4000]

    client = AsyncOpenAI(
        api_key=os.getenv("DEEPSEEK_API_KEY"),
        base_url=os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
    )

    print("调用 DeepSeek V4 Pro 抽取实体...")
    resp = await client.chat.completions.create(
        model="deepseek-v4-pro",
        messages=[{"role": "user", "content": build_prompt(content)}],
        max_tokens=8000,
        response_format={"type": "json_object"},
    )

    msg = resp.choices[0].message
    result_text = msg.content

    # DeepSeek thinking mode: content 可能在 reasoning_content
    if not result_text and hasattr(msg, "reasoning_content") and msg.reasoning_content:
        print("  ⚠️ 主 content 为空，thinking mode 可能消耗了 token")
        print(f"  reasoning_content (前200字): {msg.reasoning_content[:200]}")

    print(f"Tokens: {resp.usage.prompt_tokens}in / {resp.usage.completion_tokens}out")

    try:
        result = json.loads(result_text)
        objects = result.get("objects", [])
        relations = result.get("relations", [])

        print(f"抽取结果:")
        print(f"  实体数: {len(objects)}")
        for obj in objects[:10]:
            print(f"    [{obj.get('type', '?')}] {obj.get('name', '?')}")
        if len(objects) > 10:
            print(f"    ... 还有 {len(objects) - 10} 个")

        print(f"\n  关系数: {len(relations)}")
        for rel in relations[:10]:
            print(f"    {rel.get('source')} --[{rel.get('type')}]--> {rel.get('target')}")
        if len(relations) > 10:
            print(f"    ... 还有 {len(relations) - 10} 个")

        # 保存结果
        out_path = os.path.join(test_output_dir, "extraction_baseline.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"\n结果已保存: {out_path}")

    except json.JSONDecodeError:
        print(f"❌ JSON 解析失败，原始输出:\n{result_text[:500]}")

    print("\n✅ 实体抽取 Baseline 验证完成")


if __name__ == "__main__":
    asyncio.run(main())
