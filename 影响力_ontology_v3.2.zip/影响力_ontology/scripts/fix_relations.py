#!/usr/bin/env python3
"""修复 influence_ontology.json 中的关系引用问题。"""

import json
import os
import re

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JSON_PATH = os.path.join(BASE_DIR, "influence_ontology.json")

ENTITY_KEYS = [
    "principles", "concepts", "terms", "cases", "experiments",
    "persons", "reasoning_chains", "tactics", "action_steps",
    "scripts", "scenarios"
]


def normalize(s):
    if not s:
        return ""
    s = re.sub(r'[\s\-—（）()\[\]【】]', '', str(s))
    return s.lower()


def main():
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Build id -> entity and name -> id maps
    all_ids = set()
    name_to_id = {}
    for key in ENTITY_KEYS:
        for item in data.get(key, []):
            item_id = item.get("id")
            if item_id:
                all_ids.add(item_id)
                name_to_id[normalize(item_id)] = item_id
            name = item.get("name", "")
            if name:
                norm = normalize(name)
                if norm and norm not in name_to_id:
                    name_to_id[norm] = item_id
                # Also store without common suffixes
                norm2 = normalize(name.replace("原理", "").replace("原则", "").replace("效应", ""))
                if norm2 and norm2 not in name_to_id:
                    name_to_id[norm2] = item_id

    fixed = []
    removed = []
    for r in data.get("relations", []):
        fid = r.get("from_id")
        tid = r.get("to_id")
        rt = r.get("relation_type", "")

        if isinstance(fid, list):
            fid = fid[0] if fid else None
        if isinstance(tid, list):
            tid = tid[0] if tid else None

        # Try to fix ids by name lookup
        if fid and fid not in all_ids:
            fid = name_to_id.get(normalize(fid), fid)
        if tid and tid not in all_ids:
            tid = name_to_id.get(normalize(tid), tid)

        # Normalize relation_type
        rt_norm = rt
        if rt in ["principle_illustrated_by", "tactic_based_on", "tactic_applies_to",
                  "concept_related_to", "reasoning_derives", "case_uses_experiment",
                  "experiment_conducted_by", "person_proposes", "applies", "experiment_supports"]:
            rt_norm = rt
        elif "应用" in rt or "运用" in rt or "采用" in rt or "使用" in rt or "实施" in rt or "利用" in rt:
            rt_norm = "applies"
        elif "体现" in rt or "说明" in rt or "illustrated" in rt:
            rt_norm = "principle_illustrated_by"
        elif "验证" in rt or "支持" in rt or "证明" in rt:
            rt_norm = "experiment_supports"
        elif "提出" in rt or "首创" in rt or "创立" in rt:
            rt_norm = "person_proposes"
        elif "实验" in rt and ("conducted" in rt or "进行" in rt or "做" in rt):
            rt_norm = "experiment_conducted_by"
        elif "适用" in rt or "条件" in rt:
            rt_norm = "applies"
        elif "遭遇" in rt or "陷入" in rt:
            rt_norm = "related_to"
        elif "研究" in rt or "调查" in rt:
            rt_norm = "studies"
        elif "进行" in rt:
            rt_norm = "related_to"
        else:
            rt_norm = "related_to"

        if fid in all_ids and tid in all_ids:
            new_r = dict(r)
            new_r["from_id"] = fid
            new_r["to_id"] = tid
            new_r["relation_type"] = rt_norm
            fixed.append(new_r)
        else:
            removed.append({"relation": r, "from_id": fid, "to_id": tid})

    data["relations"] = fixed

    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"Fixed relations: {len(fixed)}")
    print(f"Removed relations: {len(removed)}")
    if removed:
        print("Sample removed:")
        for r in removed[:5]:
            print(" ", r)


if __name__ == "__main__":
    main()
