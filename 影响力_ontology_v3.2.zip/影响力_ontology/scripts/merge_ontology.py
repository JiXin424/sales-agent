#!/usr/bin/env python3
"""合并各章节抽取结果，按 name 去重，生成统一 ontology 文件。"""

import json
import os
import re
from collections import defaultdict

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DIR = os.path.join(BASE_DIR, "raw")
OUT_JSON = os.path.join(BASE_DIR, "influence_ontology.json")
OUT_MD = os.path.join(BASE_DIR, "主体文件-影响力.md")

ENTITY_KEYS = [
    "principles", "concepts", "terms", "cases", "experiments",
    "persons", "reasoning_chains", "tactics", "action_steps",
    "scripts", "scenarios"
]


def load_all_raw():
    all_data = defaultdict(list)
    for fname in sorted(os.listdir(RAW_DIR)):
        if not fname.endswith(".json"):
            continue
        path = os.path.join(RAW_DIR, fname)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for key in ENTITY_KEYS + ["relations"]:
            all_data[key].extend(data.get(key, []))
    return all_data


def normalize_name(name):
    if not name:
        return ""
    s = str(name)
    s = re.sub(r'[\s\-—（）()\[\]【】]', '', s)
    s = s.replace('原理', '').replace('原则', '').replace('效应', '')
    return s.lower()


def pick_better(a, b, key):
    """从两个字典中选择更完整的值。"""
    va = a.get(key)
    vb = b.get(key)
    if not va and not vb:
        return None
    if not va:
        return vb
    if not vb:
        return va
    # Prefer longer strings, more items in lists
    la = len(va) if isinstance(va, (str, list)) else 1
    lb = len(vb) if isinstance(vb, (str, list)) else 1
    return va if la >= lb else vb


def deduplicate_by_name(items, key_fields=None):
    """按 name 去重，支持包含关系合并，合并字段。"""
    # Filter out items without name
    items = [i for i in items if i.get("name")]
    # Sort by normalized name length descending
    items_sorted = sorted(items, key=lambda x: len(normalize_name(x.get("name", ""))), reverse=True)

    groups = []
    for item in items_sorted:
        norm = normalize_name(item.get("name", ""))
        merged = False
        for g in groups:
            g_norm = g["_norm"]
            # Merge if one contains the other and they share significant overlap
            if (g_norm in norm or norm in g_norm) and len(set(g_norm) & set(norm)) >= min(len(g_norm), len(norm)) * 0.5:
                g["items"].append(item)
                merged = True
                break
        if not merged:
            groups.append({"_norm": norm, "items": [item]})

    result = []
    for g in groups:
        group = g["items"]
        # Pick base with most complete info
        base = max(group, key=lambda x: sum(len(str(v)) for v in x.values() if v))
        merged = dict(base)
        for other in group:
            if other is base:
                continue
            for k, v in other.items():
                if k in ("id", "name"):
                    continue
                if v and not merged.get(k):
                    merged[k] = v
                elif v and isinstance(v, str) and isinstance(merged.get(k), str):
                    if len(str(v)) > len(merged[k]):
                        merged[k] = v
                elif v and isinstance(v, list) and isinstance(merged.get(k), list):
                    merged[k] = list(set(merged[k] + v))
        result.append(merged)
    return result


def deduplicate_by_id(items):
    seen = {}
    for item in items:
        item_id = item.get("id")
        if not item_id:
            continue
        if item_id in seen:
            for k, v in item.items():
                if v and not seen[item_id].get(k):
                    seen[item_id][k] = v
        else:
            seen[item_id] = dict(item)
    return list(seen.values())


def build_id_mapping(merged):
    """基于 name 构建从旧 id 到新 id 的映射。"""
    name_to_id = {}
    for key in ENTITY_KEYS:
        for item in merged[key]:
            name = item.get("name", "")
            norm = normalize_name(name)
            if norm and norm not in name_to_id:
                name_to_id[norm] = item.get("id", "")
    return name_to_id


def map_relation_id(raw_id, name_to_id, all_items_by_id):
    """尝试把旧的 relation id 映射到去重后的 id。"""
    if not raw_id:
        return raw_id
    # First try direct id match
    if raw_id in all_items_by_id:
        return raw_id
    # Then try name-based mapping
    # Find any item whose old id was raw_id
    for key in ENTITY_KEYS:
        for item in all_items_by_id[key].values():
            if item.get("_old_ids") and raw_id in item["_old_ids"]:
                return item.get("id", raw_id)
    return raw_id


def merge_and_dedup(all_data):
    merged = {}

    # Name-based dedup for semantic layer
    merged["principles"] = deduplicate_by_name(all_data.get("principles", []))
    merged["concepts"] = deduplicate_by_name(all_data.get("concepts", []))
    merged["terms"] = deduplicate_by_name(all_data.get("terms", []))
    merged["scenarios"] = deduplicate_by_name(all_data.get("scenarios", []))

    # ID-based dedup for others
    merged["cases"] = deduplicate_by_id(all_data.get("cases", []))
    merged["experiments"] = deduplicate_by_id(all_data.get("experiments", []))
    merged["persons"] = deduplicate_by_name(all_data.get("persons", []))
    merged["reasoning_chains"] = deduplicate_by_id(all_data.get("reasoning_chains", []))
    merged["tactics"] = deduplicate_by_id(all_data.get("tactics", []))
    merged["action_steps"] = deduplicate_by_id(all_data.get("action_steps", []))
    merged["scripts"] = deduplicate_by_id(all_data.get("scripts", []))

    # Build old id -> new id mapping
    # Tag items with old ids before dedup
    all_items_by_id = defaultdict(dict)
    for key in ENTITY_KEYS:
        for item in all_data.get(key, []):
            item_id = item.get("id")
            if item_id:
                all_items_by_id[key][item_id] = item

    # For name-deduped items, track old ids
    for key in ["principles", "concepts", "terms", "scenarios", "persons"]:
        name_groups = defaultdict(list)
        for item in all_data.get(key, []):
            name_groups[normalize_name(item.get("name", ""))].append(item)
        for item in merged[key]:
            norm = normalize_name(item.get("name", ""))
            old_ids = [i.get("id") for i in name_groups.get(norm, []) if i.get("id")]
            item["_old_ids"] = list(set(old_ids))

    # Map relations
    name_to_id = {}
    for key in ENTITY_KEYS:
        for item in merged[key]:
            norm = normalize_name(item.get("name", ""))
            if norm and norm not in name_to_id:
                name_to_id[norm] = item.get("id", "")

    rels = all_data.get("relations", [])
    seen_rels = set()
    unique_rels = []
    for r in rels:
        rt = r.get("relation_type")
        if isinstance(rt, list):
            rt = tuple(rt)
        fid = r.get("from_id")
        if isinstance(fid, list):
            fid = tuple(fid)
        tid = r.get("to_id")
        if isinstance(tid, list):
            tid = tuple(tid)

        # Try to map ids
        for old_id, item in all_items_by_id.get("principles", {}).items():
            if old_id == fid:
                fid = name_to_id.get(normalize_name(item.get("name", "")), fid)
            if old_id == tid:
                tid = name_to_id.get(normalize_name(item.get("name", "")), tid)

        # Ensure hashable after mapping
        if isinstance(fid, list):
            fid = tuple(fid)
        if isinstance(tid, list):
            tid = tuple(tid)

        t = (rt, fid, tid)
        if t not in seen_rels:
            seen_rels.add(t)
            new_rel = dict(r)
            new_rel["from_id"] = fid
            new_rel["to_id"] = tid
            unique_rels.append(new_rel)
    merged["relations"] = unique_rels

    # Clean up _old_ids
    for key in ENTITY_KEYS:
        for item in merged[key]:
            if "_old_ids" in item:
                del item["_old_ids"]

    return merged


def to_yaml_like_value(v):
    if v is None:
        return ""
    if isinstance(v, list):
        if not v:
            return ""
        return "; ".join(str(x) for x in v)
    return str(v)


def render_markdown(merged):
    lines = ["# 《影响力（经典版）》知识本体", ""]
    lines.append("> 从清洗文本自动抽取的语义层、思维链、行动链三层结构。")
    lines.append("> 生成时间：自动生成，待人工抽检。")
    lines.append("")

    lines.append("## 统计摘要")
    lines.append("")
    for key in ENTITY_KEYS:
        lines.append(f"- {key}: {len(merged[key])}")
    lines.append(f"- relations: {len(merged['relations'])}")
    lines.append("")

    for key in ENTITY_KEYS:
        if not merged[key]:
            continue
        cn_name = {
            "principles": "影响力原则",
            "concepts": "核心概念",
            "terms": "术语",
            "cases": "案例",
            "experiments": "实验",
            "persons": "人物",
            "reasoning_chains": "推理链",
            "tactics": "策略/技巧",
            "action_steps": "行动步骤",
            "scripts": "话术",
            "scenarios": "应用场景",
        }[key]
        lines.append(f"## {cn_name} ({len(merged[key])})")
        lines.append("")
        for item in merged[key]:
            name = item.get("name", item.get("id", ""))
            item_id = item.get("id", "")
            lines.append(f"### {name} (`{item_id}`)")
            for k, v in item.items():
                if k in ("id", "name"):
                    continue
                val = to_yaml_like_value(v)
                if val:
                    lines.append(f"- **{k}**: {val}")
            lines.append("")

    lines.append(f"## 关系 ({len(merged['relations'])})")
    lines.append("")
    for r in merged["relations"]:
        rel_type = r.get("relation_type", "")
        from_id = r.get("from_id", "")
        to_id = r.get("to_id", "")
        desc = r.get("description", "")
        line = f"- `{from_id}` —[{rel_type}]→ `{to_id}`"
        if desc:
            line += f": {desc}"
        lines.append(line)
    lines.append("")

    return "\n".join(lines)


def main():
    all_data = load_all_raw()
    merged = merge_and_dedup(all_data)

    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)
    print(f"Saved {OUT_JSON}")

    md = render_markdown(merged)
    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"Saved {OUT_MD}")

    for key in ENTITY_KEYS:
        print(f"  {key}: {len(merged[key])}")
    print(f"  relations: {len(merged['relations'])}")


if __name__ == "__main__":
    main()
