#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OpenClaw Header
# 'HTTP-Referer': 'https://openclaw.ai'
# 'X-0penRouter-Title': 'OpenClaw'
# 'X-0penRouter-Categories': 'cli-agent'
"""
图片智能转 Markdown 工具

将图片（JPG/PNG/HEIC 等）通过 AI 视觉分析转换为 Markdown 文档：
- 支持单张图片或批量处理目录
- 使用通义千问视觉模型分析图片
- 提取文字、图表、表格等结构化信息
- 输出无表格的纯文字 Markdown 文档

用法:
    python img2md.py <image_file>
    python img2md.py --batch <image_dir>

示例:
    python img2md.py "photo.jpg"
    python img2md.py --batch "./images"
    python img2md.py "screenshot.png" --no-ai  # 仅提取元数据
"""

import sys
import os
import base64
import subprocess
import re
import tempfile
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Tuple, Optional

# 默认 API 配置
DEFAULT_API_KEY = "DASHSCOPE_API_KEY_PLACEHOLDER"
DEFAULT_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
DEFAULT_MODEL = "qwen3.6-plus"

# 支持的图片格式
SUPPORTED_FORMATS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic', '.heif']


def run_bash_command(command: str, timeout: int = 60) -> Tuple[int, str, str]:
    """执行 bash 命令"""
    try:
        result = subprocess.run(
            ['bash', '-c', command],
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "命令执行超时"


def find_file(file_path: str, search_base: str = None) -> Optional[str]:
    """
    查找文件的真实路径（处理 iCloud 幽灵文件和中文路径）
    """
    # 移除路径中的空格
    file_path = file_path.replace(' ', '')

    if os.path.exists(file_path):
        try:
            size = os.path.getsize(file_path)
            if size >= 1024:
                return file_path
        except OSError:
            pass

    file_name = os.path.basename(file_path)
    if search_base is None:
        search_base = "/Users/fred/Documents/cc_Projects/Taishan"

    # 提取关键字
    keyword = file_name.replace('.jpg', '').replace('.png', '').replace('.heic', '')

    result = subprocess.run(
        ['bash', '-c', f'find "{search_base}" -name "*{keyword}*" -type f 2>/dev/null | head -5'],
        capture_output=True,
        text=True
    )

    if result.stdout.strip():
        files = result.stdout.strip().split('\n')
        for f in files:
            if keyword in f.replace(' ', ''):
                return f

    return None


def verify_file_access(file_path: str) -> Tuple[bool, int]:
    """验证文件是否可访问且不是 iCloud 占位符"""
    try:
        size = os.path.getsize(file_path)
        if size < 1024:
            print(f"警告：文件小于 1KB ({size} bytes)，可能是 iCloud 占位符")
            return False, size
        return True, size
    except OSError:
        return False, 0


def get_image_info(image_path: str) -> Dict:
    """获取图片信息（尺寸、格式等）"""
    info = {
        'width': 0,
        'height': 0,
        'format': '',
        'size': 0
    }

    try:
        # 使用 bash stat 获取文件大小
        ret, stdout, _ = run_bash_command(f'stat -f%z "{image_path}" 2>/dev/null || stat -c%s "{image_path}" 2>/dev/null')
        if ret == 0 and stdout.strip():
            info['size'] = int(stdout.strip())

        # 使用 file 命令获取格式
        ret, stdout, _ = run_bash_command(f'file -b "{image_path}"')
        if ret == 0 and stdout.strip():
            info['format'] = stdout.strip().split(',')[0]

        # 使用 sips 获取尺寸（macOS）
        ret, stdout, _ = run_bash_command(f'sips -g pixelWidth -g pixelHeight "{image_path}" 2>/dev/null')
        if ret == 0 and stdout.strip():
            for line in stdout.strip().split('\n'):
                if 'pixelWidth' in line:
                    info['width'] = int(line.split(':')[-1].strip())
                elif 'pixelHeight' in line:
                    info['height'] = int(line.split(':')[-1].strip())

    except Exception as e:
        print(f"获取图片信息失败：{e}")

    return info


def _prepare_image_for_vision(image_path: str, max_side: int = 4096, quality: int = 75) -> tuple[str, str]:
    """
    准备图片用于 vision API。
    - 最长边超过 max_side 则等比缩放（内存中，不修改原文件）
    - 返回 (base64_string, mime_type)
    """
    from PIL import Image
    import io

    img = Image.open(image_path)
    w, h = img.size

    # 限制最长边
    longest = max(w, h)
    if longest > max_side:
        ratio = max_side / longest
        new_w = int(w * ratio)
        new_h = int(h * ratio)
        print(f"    [缩放] {w}x{h} -> {new_w}x{new_h} (API 限制 {max_side})")
        img = img.resize((new_w, new_h), Image.LANCZOS)

    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')

    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=quality, optimize=True)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return b64, "image/jpeg"


def encode_image_to_base64(image_path: str) -> str:
    """将图片编码为 Base64（保持原始分辨率，不缩放）"""
    result = subprocess.run(
        ['bash', '-c', f'cat "{image_path}" | base64'],
        capture_output=True,
        text=True
    )
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    raise FileNotFoundError(f"无法读取文件：{image_path}")


def get_image_mime_type(image_path: str) -> str:
    """获取图片 MIME 类型"""
    ext = os.path.splitext(image_path)[1].lower().lstrip('.')
    mime_types = {
        'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
        'gif': 'image/gif', 'webp': 'image/webp', 'bmp': 'image/bmp',
        'heic': 'image/heic', 'heif': 'image/heif'
    }
    return mime_types.get(ext, 'image/jpeg')


def analyze_image(image_path: str, api_key: str, model: str, prompt: str = None) -> str:
    """
    AI 分析图片内容

    Args:
        image_path: 图片路径
        api_key: API Key
        model: 模型名称
        prompt: 自定义提示词

    Returns:
        str: 分析结果文本
    """
    try:
        from openai import OpenAI
    except ImportError:
        print("错误：未安装 openai 库")
        print("请运行：pip install openai")
        raise ImportError("openai")

    # 默认提示词
    if prompt is None:
        prompt = """请仔细阅读这张图片，直接输出为结构清晰的 Markdown。

**严禁做的事情**：
- **严禁修改任何文字内容**，包括错别字、病句、数字、标点等——看到什么就输出什么
- 不要改写、扩写、或添加原文没有的内容
- 不要纠正任何你觉得"不对"的文字
- 不要删除任何内容，包括看似重复的部分——保留所有文字
- 不要添加任何说明、总结或分析

**输出格式要求**：
1. **标题**：用 # ## ### 标记明显的标题层级
2. **表格**：如果图片中有网格/多列布局，**必须**用 Markdown 表格输出
   - 表格列数必须与原图一致
   - 表格内每格的文字必须完整保留，严禁截断、省略、缩写
   - 跨行单元格用 `<br>` 换行保留全部文字
   - 不确定的列边界时，宁可多列也不要少列
3. **列表**：用 - 或 1. 标记列表项
4. **内容完整性**：每一行文字都必须出现在输出中，严禁省略任何一行

请直接输出 Markdown，不要加任何说明。"""

    try:
        b64, mime_type = _prepare_image_for_vision(image_path)
        image_data_uri = f"data:{mime_type};base64,{b64}"

        client = OpenAI(api_key=api_key, base_url=DEFAULT_BASE_URL)

        completion = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": image_data_uri}},
                        {"type": "text", "text": prompt},
                    ],
                },
            ],
            extra_body={"vl_high_resolution_images": True},
            temperature=0.2,
        )

        return completion.choices[0].message.content

    except Exception as e:
        print(f"AI 分析失败：{e}")
        raise


def generate_markdown_content(image_path: str, analysis: str, metadata: Dict) -> str:
    """
    生成 Markdown 内容

    Args:
        image_path: 图片路径
        analysis: AI 分析结果
        metadata: 元数据

    Returns:
        str: Markdown 内容
    """
    file_name = os.path.splitext(os.path.basename(image_path))[0]

    lines = []
    lines.append(f"# {file_name}")
    lines.append("")
    lines.append("> 图片来源：" + os.path.basename(image_path))
    lines.append(f"> 分析时间：{metadata.get('analyze_time', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}")
    lines.append("")

    if metadata.get('format'):
        lines.append(f"**图片格式**：{metadata['format']}")
    if metadata.get('size'):
        size_kb = metadata['size'] / 1024
        lines.append(f"**文件大小**：{size_kb:.1f} KB")
    if metadata.get('width') and metadata.get('height'):
        lines.append(f"**图片尺寸**：{metadata['width']} x {metadata['height']} 像素")

    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append(analysis)

    return '\n'.join(lines)


def save_markdown(content: str, image_path: str, output_dir: str = None) -> str:
    """
    保存 Markdown 文件

    Args:
        content: Markdown 内容
        image_path: 原图片路径
        output_dir: 输出目录

    Returns:
        str: 输出文件路径
    """
    if output_dir is None:
        output_dir = os.path.dirname(image_path)

    os.makedirs(output_dir, exist_ok=True)

    file_name = os.path.splitext(os.path.basename(image_path))[0]
    output_path = os.path.join(output_dir, f"{file_name}.md")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)

    return output_path


def process_single_image(
    image_path: str,
    api_key: str = None,
    model: str = None,
    use_ai: bool = True,
    output_dir: str = None,
    custom_prompt: str = None
) -> bool:
    """
    处理单张图片

    Args:
        image_path: 图片路径
        api_key: API Key
        model: 模型名称
        use_ai: 是否使用 AI 分析
        output_dir: 输出目录
        custom_prompt: 自定义提示词

    Returns:
        bool: 是否成功
    """
    print("=" * 60)
    print("图片智能转 Markdown 工具")
    print("=" * 60)

    # 配置
    api_key = api_key or os.getenv("DASHSCOPE_API_KEY") or DEFAULT_API_KEY
    model = model or DEFAULT_MODEL

    print(f"\n使用模型：{model}")
    print(f"API 地址：{DEFAULT_BASE_URL}")

    # 查找文件
    print("\n[1/4] 查找文件...")
    real_path = find_file(image_path)
    if not real_path:
        print(f"错误：找不到文件：{image_path}")
        return False

    image_path = real_path
    print(f"  找到：{os.path.basename(image_path)}")

    # 验证文件
    print("\n[2/4] 验证文件...")
    is_valid, file_size = verify_file_access(image_path)
    if not is_valid:
        print("错误：无法访问文件或文件太小")
        return False
    print(f"  文件大小：{file_size / 1024:.1f} KB")

    # 获取图片信息
    print("\n[3/4] 获取图片信息...")
    info = get_image_info(image_path)
    print(f"  格式：{info.get('format', '未知')}")
    print(f"  尺寸：{info.get('width', 0)} x {info.get('height', 0)} 像素")

    # 确定输出路径
    file_name = os.path.splitext(os.path.basename(image_path))[0]
    if output_dir is None:
        output_dir = os.path.dirname(image_path)
    output_path = os.path.join(output_dir, f"{file_name}.md")

    print(f"\n[4/4] 开始转换...")
    print(f"  输出文件：{output_path}")

    # AI 分析
    if use_ai:
        print("\n正在 AI 分析图片...")
        print("-" * 60)

        try:
            analysis = analyze_image(image_path, api_key, model, custom_prompt)
            print("分析完成！")
        except Exception as e:
            print(f"分析失败：{e}")
            return False
    else:
        print("\n跳过 AI 分析")
        analysis = "【AI 分析已跳过】"

    # 生成并保存 Markdown
    print("\n保存 Markdown 文件...")
    metadata = {
        'analyze_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'format': info.get('format', ''),
        'size': info.get('size', 0),
        'width': info.get('width', 0),
        'height': info.get('height', 0)
    }

    content = generate_markdown_content(image_path, analysis, metadata)
    output_path = save_markdown(content, image_path, output_dir)
    print(f"  已保存：{output_path}")

    print("\n" + "=" * 60)
    print("转换完成！")
    print(f"  输出文件：{output_path}")
    print("=" * 60)

    return True


def process_batch_images(
    image_dir: str,
    api_key: str = None,
    model: str = None,
    use_ai: bool = True,
    output_dir: str = None,
    max_workers: int = 3
) -> Tuple[int, int]:
    """
    批量处理目录中的图片

    Args:
        image_dir: 图片目录
        api_key: API Key
        model: 模型名称
        use_ai: 是否使用 AI 分析
        output_dir: 输出目录
        max_workers: 最大并发数

    Returns:
        Tuple[int, int]: (成功数量，失败数量)
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    print("=" * 60)
    print("图片批量转 Markdown 工具")
    print("=" * 60)

    # 查找图片文件
    print(f"\n扫描目录：{image_dir}")

    image_files = []
    for ext in SUPPORTED_FORMATS:
        pattern = os.path.join(image_dir, f"*{ext}")
        image_files.extend([f for f in Path(image_dir).glob(f"*{ext}")])
        pattern = os.path.join(image_dir, f"*{ext.upper()}")
        image_files.extend([f for f in Path(image_dir).glob(f"*{ext.upper()}")])

    # 去重
    image_files = list(set(str(f) for f in image_files))

    if not image_files:
        print(f"未在目录中找到支持的图片文件")
        print(f"支持的格式：{', '.join(SUPPORTED_FORMATS)}")
        return 0, 0

    print(f"找到 {len(image_files)} 个图片文件")

    # 配置
    api_key = api_key or os.getenv("DASHSCOPE_API_KEY") or DEFAULT_API_KEY
    model = model or DEFAULT_MODEL
    output_dir = output_dir or image_dir

    success_count = 0
    fail_count = 0

    def process_one(image_path):
        try:
            result = process_single_image(
                image_path=image_path,
                api_key=api_key,
                model=model,
                use_ai=use_ai,
                output_dir=output_dir
            )
            return image_path, result
        except Exception as e:
            print(f"失败：{image_path} - {e}")
            return image_path, False

    # 使用线程池处理
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(process_one, img): img for img in image_files}

        for future in as_completed(futures):
            image_path, result = future.result()
            if result:
                success_count += 1
            else:
                fail_count += 1

    return success_count, fail_count


def print_help():
    """打印帮助信息"""
    print(__doc__)


def main():
    """主函数"""
    if len(sys.argv) < 2 or '--help' in sys.argv or '-h' in sys.argv:
        print_help()
        sys.exit(0 if len(sys.argv) > 1 else 1)

    args = sys.argv[1:]

    # 解析参数
    api_key = None
    model = None
    use_ai = True
    output_dir = None
    batch_mode = False
    image_path = None

    i = 0
    while i < len(args):
        if args[i] == '--batch':
            batch_mode = True
            i += 1
        elif args[i] == '--no-ai':
            use_ai = False
            i += 1
        elif args[i] == '--api-key':
            if i + 1 < len(args):
                api_key = args[i + 1]
                i += 2
            else:
                print("错误：--api-key 需要指定值")
                sys.exit(1)
        elif args[i] == '--model':
            if i + 1 < len(args):
                model = args[i + 1]
                i += 2
            else:
                print("错误：--model 需要指定模型名称")
                sys.exit(1)
        elif args[i] == '--output':
            if i + 1 < len(args):
                output_dir = args[i + 1]
                i += 2
            else:
                print("错误：--output 需要指定目录")
                sys.exit(1)
        elif args[i].startswith('-'):
            print(f"未知参数：{args[i]}")
            sys.exit(1)
        else:
            image_path = args[i]
            i += 1

    if not image_path:
        print("错误：请指定图片路径或目录")
        sys.exit(1)

    try:
        if batch_mode:
            # 批量模式
            success, fail = process_batch_images(
                image_dir=image_path,
                api_key=api_key,
                model=model,
                use_ai=use_ai,
                output_dir=output_dir
            )
            print(f"\n处理完成！")
            print(f"  成功：{success} 个")
            print(f"  失败：{fail} 个")
            sys.exit(0 if success > 0 else 1)
        else:
            # 单张模式
            result = process_single_image(
                image_path=image_path,
                api_key=api_key,
                model=model,
                use_ai=use_ai,
                output_dir=output_dir
            )
            sys.exit(0 if result else 1)

    except Exception as e:
        print(f"\n处理失败：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
