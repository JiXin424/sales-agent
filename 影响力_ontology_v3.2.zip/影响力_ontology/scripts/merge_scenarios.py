#!/usr/bin/env python3
"""将新场景和话术集成到影响力本体"""

import json
from pathlib import Path

# 配置
ONTOLOGY_PATH = Path(__file__).parent.parent / "influence_ontology_enriched.json"
SCENARIOS_PATH = Path(__file__).parent.parent / "scenarios_extended.json"
OUTPUT_PATH = Path(__file__).parent.parent / "influence_ontology_final.json"

def merge_scenarios_and_scripts():
    """合并新场景和话术到本体"""
    print("=" * 60)
    print("集成新场景和话术到影响力本体")
    print("=" * 60)

    # 加载本体
    print(f"\n📖 加载本体: {ONTOLOGY_PATH}")
    with open(ONTOLOGY_PATH, 'r', encoding='utf-8') as f:
        ontology = json.load(f)

    # 加载新场景和话术
    print(f"📖 加载新场景和话术: {SCENARIOS_PATH}")
    with open(SCENARIOS_PATH, 'r', encoding='utf-8') as f:
        new_data = json.load(f)

    new_scenarios = new_data.get('scenarios', [])
    new_scripts = new_data.get('scripts', [])

    print(f"✅ 新场景数: {len(new_scenarios)}")
    print(f"✅ 新话术数: {len(new_scripts)}")

    # 合并场景
    print(f"\n🔗 合并场景...")
    existing_scenarios = ontology.get('scenarios', [])
    existing_scenario_ids = {s.get('id') for s in existing_scenarios}

    added_count = 0
    for scenario in new_scenarios:
        if scenario.get('id') not in existing_scenario_ids:
            scenario['type'] = 'scenario'
            existing_scenarios.append(scenario)
            added_count += 1

    ontology['scenarios'] = existing_scenarios
    print(f"   新增场景: {added_count} 个")

    # 合并话术
    print(f"\n🔗 合并话术...")
    existing_scripts = ontology.get('scripts', [])
    existing_script_ids = {s.get('id') for s in existing_scripts}

    added_count = 0
    for script in new_scripts:
        if script.get('id') not in existing_script_ids:
            script['type'] = 'script'
            existing_scripts.append(script)
            added_count += 1

    ontology['scripts'] = existing_scripts
    print(f"   新增话术: {added_count} 个")

    # 补充关系（场景 → 话术）
    print(f"\n🔗 补充场景-话术关系...")
    relations = ontology.get('relations', [])

    for script in new_scripts:
        scenario_id = script.get('scenario')
        if scenario_id:
            # 检查是否已有关系
            existing_rel = any(
                r['from_id'] == scenario_id and r['to_id'] == script['id']
                for r in relations
            )
            if not existing_rel:
                relations.append({
                    'id': f"scenario-has-script-{script['id']}",
                    'from_id': scenario_id,
                    'to_id': script['id'],
                    'relation_type': 'scenario_has_script',
                    'description': f'场景{scenario_id}包含话术{script["name"]}'
                })

    print(f"   新增关系: {len(new_scripts)} 个")

    ontology['relations'] = relations

    # 保存
    print(f"\n💾 保存到: {OUTPUT_PATH}")
    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        json.dump(ontology, f, ensure_ascii=False, indent=2)

    # 统计
    print(f"\n📊 本体统计:")
    print(f"   场景总数: {len(ontology.get('scenarios', []))} 个")
    print(f"   话术总数: {len(ontology.get('scripts', []))} 个")
    print(f"   关系总数: {len(ontology.get('relations', []))} 个")

    print(f"\n✅ 完成!")
    print(f"\n📝 下一步:")
    print(f"1. 检查 {OUTPUT_PATH}")
    print(f"2. 替换: mv {OUTPUT_PATH} {ONTOLOGY_PATH}")
    print(f"3. 重启服务验证")

if __name__ == '__main__':
    merge_scenarios_and_scripts()
