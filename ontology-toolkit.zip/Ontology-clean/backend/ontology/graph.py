"""NetworkX 图查询"""

from collections import defaultdict

import networkx as nx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sqlalchemy.orm import selectinload

from backend.ontology.models import Object, Link


class OntologyGraph:
    """基于 NetworkX 的本体图查询"""

    def __init__(self):
        self.graph = nx.DiGraph()

    async def build_from_db(self, session: AsyncSession) -> None:
        """从数据库加载所有实体和关系构建图"""
        objects = (await session.execute(
            select(Object).options(selectinload(Object.type))
        )).scalars().all()
        links = (await session.execute(
            select(Link).options(selectinload(Link.type), selectinload(Link.source), selectinload(Link.target))
        )).scalars().all()

        self.graph.clear()

        for obj in objects:
            self.graph.add_node(obj.id, name=obj.name, type=obj.type.name if obj.type else None)

        for link in links:
            if self.graph.has_node(link.source_id) and self.graph.has_node(link.target_id):
                self.graph.add_edge(
                    link.source_id, link.target_id,
                    type=link.type.name if link.type else None,
                )

    def multi_hop_neighbors(self, node_id: int, max_hops: int = 2) -> dict:
        """多跳邻居查询，返回每跳的邻居"""
        result = {}
        visited = {node_id}
        current_level = {node_id}

        for hop in range(1, max_hops + 1):
            next_level = set()
            for n in current_level:
                for neighbor in self.graph.successors(n):
                    if neighbor not in visited:
                        next_level.add(neighbor)
                for neighbor in self.graph.predecessors(n):
                    if neighbor not in visited:
                        next_level.add(neighbor)

            if next_level:
                result[hop] = [
                    {"id": n, **self.graph.nodes[n]} for n in next_level
                ]
                visited.update(next_level)
                current_level = next_level
            else:
                break

        return result

    def get_subgraph(self, center_id: int, radius: int = 2) -> dict:
        """获取以某节点为中心的子图"""
        if not self.graph.has_node(center_id):
            return {"nodes": [], "edges": []}

        ego = nx.ego_graph(self.graph, center_id, radius=radius, undirected=True)

        nodes = [{"id": n, **data} for n, data in ego.nodes(data=True)]
        edges = [
            {"source": u, "target": v, "type": data.get("type")}
            for u, v, data in ego.edges(data=True)
        ]

        return {"nodes": nodes, "edges": edges}

    def get_stats(self) -> dict:
        return {
            "nodes": self.graph.number_of_nodes(),
            "edges": self.graph.number_of_edges(),
        }

    def find_paths(self, source_id: int, target_id: int, max_length: int = 4) -> list[list[int]]:
        """查找两个节点之间的路径"""
        if not self.graph.has_node(source_id) or not self.graph.has_node(target_id):
            return []

        try:
            return list(nx.all_simple_paths(
                self.graph, source_id, target_id, cutoff=max_length
            ))
        except nx.NetworkXNoPath:
            return []
