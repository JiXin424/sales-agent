"""结构化回答生成 — DeepSeek Pro/Flash 自适应"""

import json
import logging

from backend.llm import chat_pro, chat_flash

logger = logging.getLogger(__name__)

RESPONSE_PROMPT = """你是九峰医疗的AI销售教练，基于本体知识库回答问题。

已知信息：
- 实体：{entities}
- 关系：{relations}
{extra_context}

用户问题：{question}
意图：{intent}

要求：
1. 基于已知信息回答，不要编造
2. 回答要具体、有数据支撑——必须直接引用实体properties中的具体数字和关键数值（如94.2%、1:40.45、99元、400万次、4830人等），不要泛泛而谈"效率高""效果好"
3. 回答300字以内，信息密度高
4. 如果已知信息中有相关数据但不在前3个实体中，也要深入查找并引用

意图专用指令：
- comparison（对比）：列出双方关键差异，用表格或分点对比。即使知识库中某方数据不全，也要基于已有信息对比分析。必须提到：资质差异（三类证vs二类证）、技术指标对比、产品线覆盖差异
- objection（异议）：严格按五步法回答：
  ① Acknowledge（共情）：一句话理解客户顾虑，不否定
  ② Clarify（澄清）：识别表面异议背后的真正关切（价格→预算风险，品牌→信任，时间→优先级）
  ③ Reframe（重构）：用数据和政策转换视角（如"1元投入节省94元""400万次实战验证""三类证=合规防火墙"）
  ④ Evidence（证据）：引用具体数字和政策条文（99元公卫补贴/斯坦福冠军/WHO推荐/南昌航空4830人案例）
  ⑤ Ask（行动）：提一个推进性的问题，引导下一步
  关键：每个异议必须引用至少2个具体数据点，不要泛泛而谈
- scenario（场景）：描述具体业务流程和技术架构，引用案例中的具体数字说明效果
- prep（准备）：给出具体可执行的建议清单，包含话术要点、关键数据支撑、切入角度

输出 JSON：
{{"answer": "回答内容", "evidence": ["证据1", "证据2"], "confidence": 0.8}}"""


def _trim_context(context: dict, max_entities: int = 30) -> tuple[str, str, str]:
    """精简上下文，避免超长 prompt"""
    entities = context.get("entities", [])[:max_entities]
    relations = context.get("relations", [])[:40]

    entities_str = json.dumps(
        [{"name": e["name"], "type": e["type"], "properties": e.get("properties", {})} for e in entities],
        ensure_ascii=False,
    )
    relations_str = json.dumps(relations, ensure_ascii=False)

    extra = ""
    subgraph = context.get("subgraph")
    if subgraph and subgraph.get("nodes"):
        extra = f"- 关联子图：{len(subgraph['nodes'])} 个实体, {len(subgraph['edges'])} 条关系"

    return entities_str, relations_str, extra


async def generate_response(question: str, context: dict, intent: str = "entity_info", use_flash: bool = False) -> dict:
    """基于上下文生成结构化回答"""
    entities_str, relations_str, extra = _trim_context(context)

    prompt = RESPONSE_PROMPT.format(
        entities=entities_str,
        relations=relations_str,
        extra_context=extra,
        question=question,
        intent=intent,
    )

    call_fn = chat_flash if use_flash else chat_pro
    result_text = await call_fn(
        messages=[{"role": "user", "content": prompt}],
        max_tokens=1500,
        response_format={"type": "json_object"},
    )

    try:
        result = json.loads(result_text)
    except json.JSONDecodeError:
        logger.warning(f"回答生成 JSON 解析失败: {result_text[:200]}")
        result = {"answer": result_text, "evidence": [], "confidence": 0.5}

    return {
        "answer": result.get("answer", ""),
        "evidence": result.get("evidence", []),
        "confidence": result.get("confidence", 0.5),
    }
