#!/usr/bin/env python3
"""
Qdrant 分库注入 — 基于新设计的 7 库结构

Collections: CompanyProduct, Competitor, SalesStrategy,
              TopSalesBehavior, Customer, MedicalKnowledge, SystemFAQ
"""

import os, sys, re, json, time
from pathlib import Path
from typing import List, Dict, Tuple
from openai import OpenAI
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

# ── Config ──────────────────────────────────────
QDRANT_URL = "http://localhost:7334"
EMBED_API_KEY = "DASHSCOPE_API_KEY_PLACEHOLDER"
EMBED_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
EMBED_MODEL = "text-embedding-v4"
EMBED_DIM = 1024
CHUNK_SIZE = 500  # chars
BATCH_SIZE = 10    # DashScope embedding batch limit

OPT_DIR = Path("/root/Project/apps/Ontology-clean/docs/ProductX_batch1/md-优化")

# ── Collection definitions ──────────────────────
COLLECTIONS = {
    "CompanyProduct": {
        "description": "产品知识、机制、临床数据、公司信息",
        "keywords": ["ProductX", "商品名", "某药企", "ORR", "mOS", "PFS", "DCR",
                     "适应症", "剂量", "给药方案", "医保", "PD-1", "全人源",
                     "某转基因平台", "一期", "二期", "三期", "临床研究", "注册研究",
                     "获批", "标准剂量", "COMPASS", "Study-B-Gastric"],
    },
    "Competitor": {
        "description": "竞品对比数据",
        "keywords": ["竞品C", "竞品D", "竞品B", "竞品A",
                     "竞品F", "竞品H", "竞品I", "竞品J", "竞品C",
                     "竞品D", "竞品", "对比", "差异", "竞品E"],
    },
    "SalesStrategy": {
        "description": "销售策略、话术、异议处理、市场分析",
        "keywords": ["话术", "异议", "策略", "卖点", "优势", "谈判", "价格",
                     "医保", "客情", "拜访", "沟通", "处方", "提单", "进药",
                     "市场", "竞品应对", "定位"],
    },
    "TopSalesBehavior": {
        "description": "顶级销售行为、最佳实践、案例",
        "keywords": ["行为", "信任", "需求", "价值", "案例", "成功", "技巧",
                     "销冠", "演练", "模拟", "教练", "复盘"],
    },
    "Customer": {
        "description": "客户画像、医生特征、决策链",
        "keywords": ["医生", "主任", "院长", "药剂科", "客户", "决策",
                     "画像", "处方习惯", "偏好", "影响力"],
    },
    "MedicalKnowledge": {
        "description": "疾病知识、irAE管理、临床指南",
        "keywords": ["适应症A", "适应症B", "适应症C", "irAE", "不良反应", "毒性",
                     "Guideline-Body", "Guideline-Body-B", "指南", "分期", "病理", "免疫",
                     "化疗", "放疗", "手术", "诊断", "筛查", "HPV",
                     "FIGO", "PD-L1表达", "CPS", "TMB", "MSI"],
    },
    "SystemFAQ": {
        "description": "FAQ快速匹配",
        "keywords": ["FAQ", "常见问题", "Q:", "问:", "多少钱", "怎么用",
                     "效果", "副作用", "报销", "疗程", "多久"],
    },
}

# ── Embedding ────────────────────────────────────
embed_client = OpenAI(api_key=EMBED_API_KEY, base_url=EMBED_BASE_URL)

def embed_batch(texts: List[str]) -> List[List[float]]:
    """DashScope 批量嵌入"""
    resp = embed_client.embeddings.create(model=EMBED_MODEL, input=texts, dimensions=EMBED_DIM)
    return [item.embedding for item in resp.data]


# ── Chunking ─────────────────────────────────────
def chunk_text(text: str, max_len: int = CHUNK_SIZE) -> List[str]:
    """沿自然边界分块"""
    # 跳过 YAML 头
    if text.startswith("---"):
        end = text.find("---", 3)
        if end > 0:
            text = text[end + 3:]

    chunks = []
    # 按段落分（双换行）
    paras = re.split(r'\n\n+', text)
    current = ""
    for para in paras:
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) < max_len:
            current += ("\n\n" if current else "") + para
        else:
            if current:
                chunks.append(current)
            current = para
    if current:
        chunks.append(current)

    # 对超大段落再切割
    result = []
    for ch in chunks:
        if len(ch) <= max_len:
            result.append(ch)
        else:
            # 按句子分
            sents = re.split(r'(?<=[。！？.!?])', ch)
            cur = ""
            for s in sents:
                if len(cur) + len(s) < max_len:
                    cur += s
                else:
                    if cur:
                        result.append(cur)
                    cur = s
            if cur:
                result.append(cur)
    return result


# ── Content classification ──────────────────────
def classify_chunk(chunk: str) -> List[str]:
    """返回匹配的 collection 列表"""
    matches = []
    chunk_lower = chunk.lower()
    for coll_name, cfg in COLLECTIONS.items():
        score = sum(1 for kw in cfg["keywords"] if kw.lower() in chunk_lower)
        if score >= 2:  # 至少命中2个关键词
            matches.append(coll_name)
    # 兜底：FAQ文件内容优先归入 SystemFAQ
    if not matches:
        if any(q in chunk for q in ["Q:", "问:", "？", "多少钱", "怎么"]):
            matches.append("SystemFAQ")
        else:
            matches.append("CompanyProduct")  # 默认
    return matches


# ── Main ─────────────────────────────────────────

def main():
    qdrant = QdrantClient(QDRANT_URL)

    # ── Create collections ──────────────────
    existing = {c.name for c in qdrant.get_collections().collections}
    for name in COLLECTIONS:
        if name not in existing:
            qdrant.create_collection(
                collection_name=name,
                vectors_config=VectorParams(size=EMBED_DIM, distance=Distance.COSINE),
            )
            print(f"Created: {name}")
        else:
            print(f"Exists: {name}")

    # ── Scan files ──────────────────────────
    files = sorted(OPT_DIR.rglob("*.md"))
    print(f"\n共 {len(files)} 个文件\n")

    total_points = {name: 0 for name in COLLECTIONS}
    all_points: Dict[str, List[PointStruct]] = {name: [] for name in COLLECTIONS}
    global_point_id = 0

    for fp in files:
        rel = str(fp.relative_to(OPT_DIR))
        try:
            content = fp.read_text(encoding="utf-8")
        except:
            continue

        chunks = chunk_text(content)
        if not chunks:
            continue

        # 对每个 chunk 分类
        chunk_collections = []
        for i, ch in enumerate(chunks):
            colls = classify_chunk(ch)
            chunk_collections.append((i, ch, colls))

        # 批量嵌入
        all_texts = [ch for _, ch, _ in chunk_collections]
        all_embeddings = []
        for i in range(0, len(all_texts), BATCH_SIZE):
            batch = all_texts[i:i + BATCH_SIZE]
            try:
                embs = embed_batch(batch)
                all_embeddings.extend(embs)
            except Exception as e:
                print(f"  Embed error: {e}")
                all_embeddings.extend([None] * len(batch))

        # 分配到 collection
        for (idx, ch, colls), emb in zip(chunk_collections, all_embeddings):
            if emb is None:
                continue
            global_point_id += 1
            payload = {
                "text": ch[:800],
                "source_file": rel,
                "chunk_idx": idx,
            }
            point = PointStruct(id=global_point_id, vector=emb, payload=payload)
            for coll in set(colls):
                all_points[coll].append(point)

        if len(files) <= 5 or global_point_id % 100 == 0:
            pass  # silent

    # ── Batch upsert ────────────────────────
    print(f"\n=== Injecting ===")
    total = 0
    for coll_name, points in all_points.items():
        if not points:
            continue
        for i in range(0, len(points), 100):
            batch = points[i:i + 100]
            qdrant.upsert(collection_name=coll_name, points=batch)
        print(f"  {coll_name}: {len(points)} points ✅")
        total += len(points)

    print(f"\n=== Done ===")
    print(f"Total points: {total}")

    # Verify
    for name in COLLECTIONS:
        info = qdrant.count(collection_name=name, exact=True)
        print(f"  {name}: {info.count}")


if __name__ == "__main__":
    main()
