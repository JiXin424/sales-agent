"""端到端测试：主体文件 → 背景知识 → 补充文件抽取"""

import json
import os
import sys
import tempfile

import pytest
import pytest_asyncio
from sqlalchemy import delete, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import backend.knowledge.context as ctx
from backend.ontology.models import Base

TEST_DB_URL = "postgresql+asyncpg://ontology:ontology_dev_2026@localhost:5432/ontology"


CORE_DOC = """九峰医疗 AI 产品介绍

九峰医疗（江西中科九峰智慧医疗科技有限公司）成立于2015年，专注基层医疗AI影像。

核心产品：
1. 肺结核X射线影像辅助评估软件（JF CXR-1）— 国内首张肺部AI三类证
2. 5G+AI基层呼吸系统传染病监测预警系统

主要竞争对手：深圳市智影医疗科技有限公司、北京推想科技有限公司。

应用场景：高校新生结核病筛查、65岁以上老年人体检、基层医疗影像诊断。
"""


SUPPLEMENT_DOC = """竞品分析：智影医疗方案

智影医疗推出I-Sight系列产品，覆盖DR和CT模态。
但智影仅有二类证，九峰持有国内唯一肺部AI三类证。

在高校筛查场景中，九峰已有南昌航空大学4830人筛查的成功案例。
"""


@pytest_asyncio.fixture
async def real_session():
    """E2E 专用：真实 session（允许 commit），测试后清理数据"""
    engine = create_async_engine(TEST_DB_URL, echo=False)
    session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with session_factory() as session:
        yield session

    # 测试后清理
    async with session_factory() as cleanup:
        from backend.ontology.models import Link, Object, Document
        await cleanup.execute(delete(Link))
        await cleanup.execute(delete(Object))
        await cleanup.execute(delete(Document))
        await cleanup.commit()

    await engine.dispose()


@pytest.fixture(autouse=True)
def temp_context():
    """每个测试使用临时目录存放 context 文件"""
    with tempfile.TemporaryDirectory() as tmpdir:
        old = ctx.CONTEXT_FILE
        ctx.CONTEXT_FILE = os.path.join(tmpdir, "knowledge_context.json")
        yield tmpdir
        ctx.CONTEXT_FILE = old


@pytest.mark.asyncio
async def test_e2e_core_then_supplement(real_session):
    """E2E: 先传主体文件 → 建背景 → 再传补充文件"""
    from backend.ontology.crud import ensure_default_types
    from backend.document.pipeline import process_document
    from backend.knowledge.context import save_context, load_context_text

    await ensure_default_types(real_session)

    # Phase 1: 上传主体文件
    with tempfile.NamedTemporaryFile(suffix=".md", mode="w", delete=False, encoding="utf-8") as f:
        f.write(CORE_DOC)
        core_path = f.name

    try:
        result = await process_document(core_path, real_session)
        assert result["objects_count"] > 0, f"主体文件应抽取实体，实际: {result}"
    finally:
        os.unlink(core_path)

    # Phase 2: 生成背景知识
    text = await save_context(real_session)
    assert len(text) > 0
    assert "九峰" in text

    loaded = load_context_text()
    assert loaded is not None, "背景知识应能从文件加载"
    assert "九峰" in loaded

    # Phase 3: 上传补充文件（此时 extractor 应自动注入背景）
    with tempfile.NamedTemporaryFile(suffix=".md", mode="w", delete=False, encoding="utf-8") as f:
        f.write(SUPPLEMENT_DOC)
        supp_path = f.name

    try:
        result = await process_document(supp_path, real_session)
        assert result["objects_count"] > 0, f"补充文件应抽取实体"
    finally:
        os.unlink(supp_path)


@pytest.mark.asyncio
async def test_context_injection_in_prompt():
    """测试背景知识被注入到抽取 prompt 中"""
    from backend.document.extractor import _get_context_section

    # 没有背景文件时应返回空
    result = _get_context_section()
    assert result == ""

    # 写入背景文件
    fake_data = {
        "generated_at": "2026-01-01",
        "total_objects": 2,
        "total_links": 1,
        "type_counts": {},
        "objects": [],
        "links": [],
        "text": "## Company\n- 九峰医疗\n\n## 关系\n- 九峰医疗 —[produces]→ AI评估软件",
    }
    with open(ctx.CONTEXT_FILE, "w") as f:
        json.dump(fake_data, f)

    result = _get_context_section()
    assert result != "", "有背景文件时应返回非空内容"
    assert "九峰医疗" in result, "背景知识中应包含已知实体"
    assert "produces" in result, "背景知识中应包含已知关系"
