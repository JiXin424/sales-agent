"""阿里云 Embedding + PGVector 向量存储"""

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession
from backend.ontology.models import Object


async def embed_and_store(session: AsyncSession, object_id: int, text: str) -> None:
    """为实体生成向量并存入 PGVector — 动态导入 embed 避免 FastAPI namespace 污染"""
    from backend.llm import embed as _embed

    vectors = await _embed([text])
    if not vectors:
        return

    embedding = vectors[0]
    vector_str = str(embedding)
    await session.execute(
        text("UPDATE objects SET embedding = :vec WHERE id = :id"),
        {"vec": vector_str, "id": object_id},
    )
    await session.flush()


async def get_embedding(text: str) -> list[float]:
    """获取文本的向量嵌入（避免 FastAPI namespace 污染）"""
    from backend.llm import embed as _embed
    vectors = await _embed([text])
    return vectors[0] if vectors else []


async def search_similar(
    session: AsyncSession, query_embedding: list[float], top_k: int = 10
) -> list[dict]:
    """向量相似度搜索"""
    vector_str = str(query_embedding)
    rows = await session.execute(
        text("""
            SELECT o.id, o.name, ot.name as type_name, o.properties,
                   o.embedding <=> :vec::vector as distance
            FROM objects o
            JOIN object_types ot ON o.type_id = ot.id
            WHERE o.embedding IS NOT NULL
            ORDER BY o.embedding <=> :vec::vector
            LIMIT :limit
        """),
        {"vec": vector_str, "limit": top_k},
    )

    return [
        {
            "id": row.id,
            "name": row.name,
            "type": row.type_name,
            "properties": row.properties,
            "distance": float(row.distance),
        }
        for row in rows
    ]
