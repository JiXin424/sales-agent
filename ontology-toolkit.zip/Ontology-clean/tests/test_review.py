"""Sprint 4 测试：访后复盘"""

import pytest


@pytest.mark.asyncio
async def test_review_analysis(db_session):
    """测试访后复盘分析"""
    from backend.ontology.crud import ensure_default_types, create_object
    from backend.coach.review import analyze_visit

    await ensure_default_types(db_session)
    await create_object(db_session, "Company", "九峰医疗", {})
    await create_object(db_session, "Product", "肺结核AI软件", {"特点": "AI辅助诊断"})
    await create_object(db_session, "Scenario", "基层医院筛查", {})
    await db_session.commit()

    visit_notes = "今天拜访了XX基层医院，介绍了肺结核AI软件，客户对产品很感兴趣，但担心价格和实施难度。"
    result = await analyze_visit(visit_notes, db_session)

    assert result["summary"]
    assert len(result["summary"]) > 30
    assert "action_items" in result


@pytest.mark.asyncio
async def test_review_empty_notes(db_session):
    """测试空记录处理"""
    from backend.coach.review import analyze_visit

    result = await analyze_visit("", db_session)
    assert "error" in result or "summary" in result
