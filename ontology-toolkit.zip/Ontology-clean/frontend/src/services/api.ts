import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8001';

const api = axios.create({ baseURL: API_BASE });

// Chat
export const chat = (question: string) =>
  api.post('/api/v1/chat/', { question });

export const chatStream = (question: string) =>
  fetch(`${API_BASE}/api/v1/chat/stream`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question }),
  });

// Coach
export const coachPrep = (question: string) =>
  api.post('/api/v1/coach/prep', { question });

export const coachObjection = (question: string) =>
  api.post('/api/v1/coach/objection', { question });

export const coachComparison = (question: string) =>
  api.post('/api/v1/coach/comparison', { question });

export const coachReview = (visitNotes: string) =>
  api.post('/api/v1/coach/review', { visit_notes: visitNotes });

// Documents
export const uploadDocument = (file: File) => {
  const form = new FormData();
  form.append('file', file);
  return api.post('/api/v1/documents/upload', form);
};

export const uploadBatch = (files: File[]) => {
  const form = new FormData();
  files.forEach(f => form.append('files', f));
  return api.post('/api/v1/documents/upload/batch', form);
};

export const listDocuments = () => api.get('/api/v1/documents/');

export const deleteDocument = (id: number) => api.delete(`/api/v1/documents/${id}`);

// Ontology
export const getGraph = () => api.get('/api/v1/ontology/graph');

export const getObjects = (type?: string) =>
  api.get('/api/v1/ontology/objects', { params: { type } });

export const getObject = (id: number) => api.get(`/api/v1/ontology/objects/${id}`);

export const getOntologyStats = () => api.get('/api/v1/ontology/stats');

// Stats
export const getEntityStats = () => api.get('/api/v1/stats/entities');

export const getSystemStats = () => api.get('/api/v1/stats/system');

export const getCostStats = () => api.get('/api/v1/stats/costs');

// Feedback
export const submitFeedback = (data: { question: string; answer: string; rating: number; comment?: string }) =>
  api.post('/api/v1/feedback/', data);

export const getFeedbackStats = () => api.get('/api/v1/feedback/stats');

// Health
export const checkHealth = () => api.get('/health');

export default api;
