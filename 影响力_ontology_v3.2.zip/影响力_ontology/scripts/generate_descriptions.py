#!/usr/bin/env python3
"""从源资料补全实体描述 - 基于influence_ontology.json的现有字段"""

import json
from pathlib import Path

# 文件路径
ONTOLOGY_PATH = Path(__file__).parent.parent / "influence_ontology.json"
OUTPUT_PATH = Path(__file__).parent.parent / "influence_ontology_enriched.json"

def enrich_description_from_source(entity):
    """从现有源资料字段补全description"""

    # 如果已有description且非空，直接返回
    if entity.get('description') and len(entity.get('description', '')) > 10:
        return entity

    entity_type = entity.get('type', '')
    desc = ''

    # 优先级1: summary字段（最完整的描述）
    if entity.get('summary'):
        desc = entity['summary']
        # 如果summary太短，结合其他字段
        if len(desc) < 30:
            if entity.get('core_mechanism'):
                desc += f"\n\n核心机制: {entity['core_mechanism']}"
            if entity.get('social_function'):
                desc += f"\n\n社会功能: {entity['social_function']}"

    # 优先级2: source_text（原文引用）
    elif entity.get('source_text'):
        source = entity['source_text']
        desc = source if len(source) <= 200 else source[:200] + '...'

    # 优先级3: 组合多个字段构建描述
    else:
        if entity_type == 'principle':
            desc = f"{entity.get('name', '')}"
            if entity.get('core_mechanism'):
                desc += f"\n\n核心机制: {entity['core_mechanism']}"
            if entity.get('social_function'):
                desc += f"\n\n社会功能: {entity['social_function']}"
            if entity.get('keywords'):
                desc += f"\n\n关键词: {', '.join(entity['keywords'])}"

        elif entity_type == 'case':
            desc = f"案例: {entity.get('name', '')}"
            if entity.get('summary'):
                desc += f"\n\n{entity['summary']}"
            if entity.get('characters'):
                desc += f"\n\n涉及人物: {', '.join(entity['characters'])}"
            if entity.get('outcome'):
                desc += f"\n\n结果: {entity['outcome']}"

        elif entity_type == 'tactic':
            desc = f"策略: {entity.get('name', '')}"
            if entity.get('summary'):
                desc += f"\n\n{entity['summary']}"

        elif entity_type == 'script':
            desc = f"话术: {entity.get('name', '')}"
            if entity.get('context'):
                desc += f"\n\n适用场景: {entity['context']}"
            text = entity.get('text', '')
            if text:
                desc += f"\n\n话术内容: {text if len(text) <= 200 else text[:200] + '...'}"

        elif entity_type == 'reasoning_chain':
            desc = f"推理链: {entity.get('name', '')}"
            premises = entity.get('premises', '')
            consequence = entity.get('consequence', '')
            if premises and consequence:
                desc += f"\n\n推理: {premises} → {consequence}"
            if entity.get('evidence'):
                desc += f"\n\n证据: {entity['evidence']}"

        elif entity_type == 'scenario':
            desc = f"场景: {entity.get('name', '')}"
            if entity.get('summary'):
                desc += f"\n\n{entity['summary']}"

        elif entity_type == 'concept':
            desc = f"概念: {entity.get('name', '')}"
            if entity.get('description'):
                desc = entity['description']

        elif entity_type == 'term':
            desc = f"术语: {entity.get('name', '')}"
            if entity.get('description'):
                desc = entity['description']

        else:
            # 默认使用name
            desc = entity.get('name', entity.get('id', ''))

    entity['description'] = desc
    return entity

def main():
    """主函数"""
    print("=" * 60)
    print("影响力本体 - 从源资料补全实体描述")
    print("=" * 60)

    # 加载本体数据
    print(f"\n📖 加载本体数据: {ONTOLOGY_PATH}")
    with open(ONTOLOGY_PATH, 'r', encoding='utf-8') as f:
        ontology = json.load(f)

    # 统计
    total_entities = sum(len(ontology.get(t, [])) for t in ['principles', 'concepts', 'terms', 'cases', 'experiments', 'persons', 'reasoning_chains', 'tactics', 'action_steps', 'scripts', 'scenarios'])
    print(f"📊 总计 {total_entities} 个实体")

    # 处理每种类型
    print("\n🚀 开始补全description...")
    processed = 0
    improved = 0  # 有改进的数量

    entity_types = ['principles', 'concepts', 'terms', 'cases', 'experiments', 'persons',
                   'reasoning_chains', 'tactics', 'action_steps', 'scripts', 'scenarios']

    for entity_type in entity_types:
        if entity_type not in ontology:
            continue

        type_name = entity_type.rstrip('s')
        count = len(ontology[entity_type])

        for entity in ontology[entity_type]:
            old_desc = entity.get('description', '')
            old_len = len(old_desc)

            # 添加type字段
            entity['type'] = type_name

            # 补全description
            enriched = enrich_description_from_source(entity)
            new_len = len(enriched['description'])

            processed += 1
            if new_len > old_len:
                improved += 1

            if processed % 50 == 0:
                print(f"   进度: {processed}/{total_entities} ({processed/total_entities*100:.1f}%) - 改进: {improved}")

    # 保存结果
    print(f"\n💾 保存到: {OUTPUT_PATH}")
    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        json.dump(ontology, f, ensure_ascii=False, indent=2)

    print(f"\n✅ 完成!")
    print(f"📁 输出文件: {OUTPUT_PATH}")
    print(f"📊 处理了 {processed} 个实体")
    print(f"📈 改进了 {improved} 个实体的description")

if __name__ == '__main__':
    main()
