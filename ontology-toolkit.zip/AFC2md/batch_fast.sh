#!/bin/bash
# 快速批量处理 - 并行处理DOCX/XLSX，串行处理PPTX/PDF
set -e

SRC="/Users/fred/Documents/cc_Projects/Taishan/二期库/0515/福多多raw"
DST="/Users/fred/Documents/cc_Projects/Taishan/二期库/0515/福多多md_ready"
CONVERT="/Users/fred/Documents/cc_Projects/Taishan/api-software/AFC2md/convert.py"

# 获取未处理文件
get_pending() {
    python3 -c "
import os
src = '$SRC'
dst = '$DST'
SUPPORTED = {'.pdf', '.pptx', '.docx', '.doc', '.xlsx', '.jpg', '.jpeg', '.png'}
for root, _, files in os.walk(src):
    if '_extracted' in root or '_images' in root:
        continue
    for f in files:
        if f.startswith('~'):
            continue
        ext = os.path.splitext(f)[1].lower()
        if ext in SUPPORTED:
            base = os.path.splitext(f)[0]
            dst_path = os.path.join(dst, os.path.relpath(root, src), base + '.md')
            if not os.path.exists(dst_path):
                print(os.path.join(root, f))
"
}

# 处理单个文件
process_file() {
    local src_file="$1"
    local rel_path=$(python3 -c "import os; print(os.path.relpath('$src_file', '$SRC'))")
    local base_name=$(basename "$src_file")
    local ext="${base_name##*.}"
    ext=$(echo "$ext" | tr '[:upper:]' '[:lower:]')

    echo "[$(date +%H:%M:%S)] 开始: $rel_path"

    local start=$(date +%s)
    if python3 "$CONVERT" "$src_file" > /tmp/convert_$$.log 2>&1; then
        # 移动生成的md到目标目录
        local src_dir=$(dirname "$src_file")
        local md_base=$(python3 -c "import os; print(os.path.splitext(os.path.basename('$src_file'))[0])")
        local generated_md="$src_dir/${md_base}.md"

        if [ -f "$generated_md" ]; then
            local target_subdir="$DST/$(dirname "$rel_path")"
            mkdir -p "$target_subdir"
            mv "$generated_md" "$target_subdir/"
            local end=$(date +%s)
            echo "[$(date +%H:%M:%S)] ✅ 完成: $rel_path ($((end-start))s)"
        else
            echo "[$(date +%H:%M:%S)] ⚠️  未找到MD: $rel_path"
        fi
    else
        local end=$(date +%s)
        echo "[$(date +%H:%M:%S)] ❌ 失败: $rel_path ($((end-start))s)"
        tail -20 /tmp/convert_$$.log | sed 's/^/    /'
    fi

    # 清理中间目录
    local src_dir=$(dirname "$src_file")
    local md_base=$(python3 -c "import os; print(os.path.splitext(os.path.basename('$src_file'))[0])")
    rm -rf "$src_dir/${md_base}_images" "$src_dir/${md_base}_extracted" 2>/dev/null
}
export -f process_file
export SRC DST CONVERT

echo "========================================"
echo "快速批量文档转 Markdown"
echo "========================================"

# 获取未处理文件列表
pending=$(get_pending)
if [ -z "$pending" ]; then
    echo "所有文件已处理完成！"
    exit 0
fi

echo "待处理文件数: $(echo "$pending" | wc -l | tr -d ' ')"
echo ""

# 分离文件类型
vision_files=""      # PPTX/PDF - 需要AI vision，串行
fast_files=""        # DOCX/XLSX - 可以并行

while IFS= read -r f; do
    ext="${f##*.}"
    ext=$(echo "$ext" | tr '[:upper:]' '[:lower:]')
    if [ "$ext" = "pptx" ] || [ "$ext" = "pdf" ]; then
        vision_files="$vision_files$f\n"
    else
        fast_files="$fast_files$f\n"
    fi
done <<< "$pending"

# 并行处理 fast_files (DOCX/XLSX)，最多5个并发
echo "=== 并行处理 DOCX/XLSX (最多5并发) ==="
if [ -n "$fast_files" ]; then
    echo -e "$fast_files" | grep -v '^$' | xargs -P 5 -I {} bash -c 'process_file "$@"' _ {}
fi

# 串行处理 vision_files (PPTX/PDF)
echo ""
echo "=== 串行处理 PPTX/PDF ==="
if [ -n "$vision_files" ]; then
    echo -e "$vision_files" | grep -v '^$' | while IFS= read -r f; do
        process_file "$f"
    done
fi

echo ""
echo "========================================"
echo "批量处理完成"
echo "========================================"
