#!/usr/bin/env python3
"""
split_large_files — 大文件预拆分工具

在 build_ontology.py 之前运行，将超大 .md 文件沿自然边界拆分为小块，
避免单文件被 --max-doc-chars 严重截断。

拆分边界优先级：
  1. <!-- page N -->  页面标记
  2. ---              Markdown 水平线 / PPT 幻灯片分隔
  3. ##               二级标题

用法:
    python split_large_files.py <dir>                          # 默认 50KB 阈值
    python split_large_files.py <dir> --max-chunk 40KB        # 自定义块大小
    python split_large_files.py <dir> --threshold 60KB        # 自定义触发阈值
    python split_large_files.py <dir> --dry-run               # 仅预览
    python split_large_files.py <dir> --undo                  # 撤销拆分（删除 _chunk_*.md）
"""

import argparse
import os
import re
import sys
from pathlib import Path
from typing import List, Optional


# ──────────────────────────────────────────────────────────────
# 参数解析
# ──────────────────────────────────────────────────────────────

def _parse_size(s: str) -> int:
    """解析大小字符串，如 '40KB' → 40960"""
    s = s.strip().upper()
    if s.endswith("KB"):
        return int(s[:-2]) * 1024
    if s.endswith("MB"):
        return int(s[:-2]) * 1024 * 1024
    if s.endswith("B"):
        return int(s[:-1])
    return int(s)


# ──────────────────────────────────────────────────────────────
# 拆分逻辑
# ──────────────────────────────────────────────────────────────

def _find_split_points(text: str) -> List[int]:
    """在文本中找到自然拆分点（字符偏移量），按优先级返回"""
    points = set()

    # 优先级 1：页面标记
    for m in re.finditer(r'<!-- page \d+ -->', text):
        points.add(m.start())

    # 优先级 2：水平线 / PPT 分隔
    for m in re.finditer(r'^\s*---\s*$', text, re.MULTILINE):
        points.add(m.start())

    # 优先级 3：二级标题
    for m in re.finditer(r'^##\s+', text, re.MULTILINE):
        points.add(m.start())

    return sorted(points)


def _split_text(text: str, max_chunk_size: int) -> List[str]:
    """将文本沿自然边界拆分为多个块，每块 ≤ max_chunk_size"""
    points = _find_split_points(text)

    if not points:
        # 没有自然边界，强制等分
        chunks = []
        for i in range(0, len(text), max_chunk_size):
            chunks.append(text[i:i + max_chunk_size])
        return chunks

    chunks = []
    start = 0

    for pt in points:
        if pt <= start:
            continue
        segment = text[start:pt]
        if len(segment) > max_chunk_size:
            # 当前段仍太大，递归拆分
            sub_chunks = _split_text(segment, max_chunk_size)
            chunks.extend(sub_chunks)
        else:
            if segment.strip():
                chunks.append(segment)
        start = pt

    # 处理最后一段
    remainder = text[start:]
    if remainder.strip():
        if len(remainder) > max_chunk_size:
            sub_chunks = _split_text(remainder, max_chunk_size)
            chunks.extend(sub_chunks)
        else:
            chunks.append(remainder)

    return chunks


# ──────────────────────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────────────────────

def split_file(
    md_path: Path,
    max_chunk_size: int,
    dry_run: bool = False,
) -> int:
    """拆分单个 .md 文件，返回拆出的块数（0 表示未拆分）"""
    size = md_path.stat().st_size
    if size <= max_chunk_size:
        return 0

    text = md_path.read_text(encoding="utf-8")

    # 提取 YAML 前置元数据（如果有）
    yaml_header = ""
    body = text
    if text.startswith("---"):
        end = text.find("---", 3)
        if end > 0:
            yaml_header = text[:end + 3] + "\n\n"
            body = text[end + 3:]

    chunks = _split_text(body, max_chunk_size - len(yaml_header))
    if len(chunks) <= 1:
        return 0

    parent = md_path.parent
    stem = md_path.stem  # basename without .md

    if dry_run:
        print(f"   📄 {md_path.name}: {size/1024:.0f}KB → {len(chunks)} 块")
        return len(chunks)

    written = 0
    for i, chunk in enumerate(chunks, 1):
        chunk_path = parent / f"{stem}_chunk_{i:03d}.md"
        content = f"{yaml_header}{chunk.strip()}\n"
        chunk_path.write_text(content, encoding="utf-8")
        written += 1

    # 重命名原文件为 .bak，避免 build_ontology 重复扫描
    bak_path = parent / f"{stem}.orig.bak"
    md_path.rename(bak_path)

    print(f"   ✂️  {md_path.name}: {size/1024:.0f}KB → {written} 块 (原文件 → .orig.bak)")
    return written


def split_directory(
    src_dir: Path,
    max_chunk_size: int,
    threshold: int,
    dry_run: bool = False,
    undo: bool = False,
) -> dict:
    """扫描目录并拆分大文件"""
    md_files: List[Path] = []
    for root, _, fnames in os.walk(src_dir):
        for fname in fnames:
            if fname.lower().endswith(".md") and "_chunk_" not in fname:
                md_files.append(Path(root) / fname)

    if undo:
        undone = 0
        for f in md_files:
            # 删除 chunk 文件
            parent = f.parent
            stem = f.stem
            for cf in parent.glob(f"{stem}_chunk_*.md"):
                cf.unlink()
                undone += 1
            # 恢复 .orig.bak
            bak = parent / f"{stem}.orig.bak"
            if bak.exists():
                bak.rename(f)
                undone += 1
        print(f"🔄 撤销完成：删除 {undone} 个 chunk 文件，恢复原文件")
        return {}

    stats = {"total": len(md_files), "split": 0, "chunks": 0}

    for f in sorted(md_files):
        size = f.stat().st_size
        if size < threshold:
            continue
        n = split_file(f, max_chunk_size, dry_run)
        if n > 0:
            stats["split"] += 1
            stats["chunks"] += n

    return stats


def main():
    parser = argparse.ArgumentParser(
        description="大文件预拆分工具（build_ontology.py 前置步骤）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python split_large_files.py ../docs/培训材料md/
  python split_large_files.py ../docs/培训材料md/ --max-chunk 40KB --threshold 60KB
  python split_large_files.py ../docs/培训材料md/ --dry-run
  python split_large_files.py ../docs/培训材料md/ --undo
        """,
    )
    parser.add_argument("dir", help="待扫描的 .md 文件目录")
    parser.add_argument(
        "--max-chunk", default="50KB",
        help="每块最大大小（默认 50KB）"
    )
    parser.add_argument(
        "--threshold", default="50KB",
        help="触发拆分的最小文件大小（默认 50KB）"
    )
    parser.add_argument("--dry-run", action="store_true", help="仅预览，不实际拆分")
    parser.add_argument("--undo", action="store_true", help="撤销拆分，恢复原文件")

    args = parser.parse_args()

    src_dir = Path(args.dir).resolve()
    if not src_dir.is_dir():
        print(f"❌ 目录不存在: {src_dir}")
        sys.exit(1)

    max_chunk = _parse_size(args.max_chunk)
    threshold = _parse_size(args.threshold)

    print(f"\n{'=' * 60}")
    print(f"✂️  split_large_files — 大文件预拆分")
    print(f"{'=' * 60}")
    print(f"  目录: {src_dir}")
    print(f"  触发阈值: {args.threshold}")
    print(f"  块大小上限: {args.max_chunk}")

    if args.dry_run:
        print(f"  模式: dry-run（仅预览）\n")
    elif args.undo:
        print(f"  模式: undo（撤销拆分）\n")
    else:
        print()

    stats = split_directory(src_dir, max_chunk, threshold, args.dry_run, args.undo)

    if not args.undo:
        print(f"\n{'=' * 60}")
        if stats:
            print(f"✅ 共 {stats['total']} 个 .md，拆分 {stats['split']} 个 → {stats['chunks']} 块")
        else:
            print(f"📁 共 {stats.get('total', 0) if stats else len(list(src_dir.rglob('*.md')))} 个 .md")
        print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
