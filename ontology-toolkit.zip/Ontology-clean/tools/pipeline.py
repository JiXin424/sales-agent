"""一键流水线 — 清库→上传→建背景→评测→对比

用法：
    python -m tools.pipeline             # 完整流水线
    python -m tools.pipeline --skip-eval # 跳过评测（只重传）
    python -m tools.pipeline --eval-only # 只跑评测
"""

import asyncio
import json
import os
import shutil
import sys
import time
from dataclasses import dataclass, field

import httpx

# 路径配置
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVAL_RESULTS_DIR = os.path.join(BASE_DIR, "eval_results")
UPLOAD_SCRIPT = "/tmp/upload_all.py"

API = "http://localhost:8001/api/v1"
STATS_URL = f"{API}/stats/system"
BUILD_CTX_URL = f"{API}/documents/build-context"
UPLOAD_URL = f"{API}/documents/upload"
DOCUMENTS_URL = f"{API}/documents/"
CHAT_URL = f"{API}/chat/"

# 评测题目（从eval_nine_rounds.py导入）
sys.path.insert(0, BASE_DIR)


@dataclass
class PipelineResult:
    success: bool
    steps_completed: int
    steps_total: int
    eval_score: float
    eval_report: dict = field(default_factory=dict)
    diff_from_previous: dict = field(default_factory=dict)
    elapsed_seconds: float = 0.0
    error: str = ""


PIPELINE_STEPS = [
    {"name": "清空数据库", "description": "按FK顺序清空Conflict→Link→Object→Document"},
    {"name": "上传文档", "description": "两阶段上传：核心文件→建背景→全部文件"},
    {"name": "生成背景知识", "description": "从实体生成结构化文本持久化到JSON"},
    {"name": "运行评测", "description": "9轮滚动评测（3套×30题×3轮）"},
]


async def clear_db() -> bool:
    """步骤1：清空数据库"""
    sys.path.insert(0, BASE_DIR)
    from sqlalchemy import delete
    from backend.db import async_session
    from backend.ontology.models import Conflict, Link, Object, Document

    async with async_session() as s:
        await s.execute(delete(Conflict))
        await s.execute(delete(Link))
        await s.execute(delete(Object))
        await s.execute(delete(Document))
        await s.commit()
    print("  ✅ 数据库已清空")
    return True


async def upload_all() -> bool:
    """步骤2：两阶段上传"""
    # 调用现有上传脚本
    proc = await asyncio.create_subprocess_exec(
        "python3", UPLOAD_SCRIPT,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await proc.communicate()
    output = stdout.decode("utf-8", errors="replace")

    if proc.returncode != 0:
        print(f"  ❌ 上传失败: {output[-200:]}")
        return False

    # 统计
    async with httpx.AsyncClient() as client:
        resp = await client.get(DOCUMENTS_URL, timeout=30)
        docs = resp.json().get("documents", [])
        print(f"  ✅ 上传完成: {len(docs)} 篇文档")
    return True


async def build_context() -> bool:
    """步骤3：生成背景知识"""
    async with httpx.AsyncClient() as client:
        resp = await client.post(BUILD_CTX_URL, timeout=60)
        data = resp.json()
        length = data.get("context_length", 0)
        print(f"  ✅ 背景知识已生成: {length} 字符")
    return True


async def run_eval() -> tuple[bool, dict]:
    """步骤4：运行9轮评测"""
    from eval_nine_rounds import main as eval_main
    report = await eval_main()
    avg = round(sum(r["score_pct"] for r in report["rounds_summary"]) / len(report["rounds_summary"]), 1)
    print(f"  ✅ 评测完成: 平均分 {avg}%")
    return True, report


async def save_eval_snapshot(report: dict) -> str:
    """保存评测快照（带时间戳）"""
    os.makedirs(EVAL_RESULTS_DIR, exist_ok=True)
    from datetime import datetime
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    snapshot_path = os.path.join(EVAL_RESULTS_DIR, f"full_report_{ts}.json")
    with open(snapshot_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    return snapshot_path


def compare_with_previous(report: dict) -> dict:
    """与上一次评测对比"""
    from tools.eval_compare import compare_results

    # 找上一次full_report（非快照）
    main_report = os.path.join(EVAL_RESULTS_DIR, "full_report.json")
    if not os.path.exists(main_report):
        return {}
    with open(main_report, encoding="utf-8") as f:
        old = json.load(f)
    return compare_results(old, report)


async def run_pipeline(skip_eval: bool = False, eval_only: bool = False) -> PipelineResult:
    """执行完整流水线"""
    start = time.time()
    steps_total = 4 if not skip_eval and not eval_only else (1 if eval_only else 3)
    steps_completed = 0

    try:
        if not eval_only:
            # 步骤1：清空
            print("\n[1/4] 清空数据库...")
            await clear_db()
            steps_completed += 1

            # 步骤2：上传
            print("\n[2/4] 上传文档...")
            ok = await upload_all()
            if not ok:
                return PipelineResult(False, steps_completed, steps_total, 0, elapsed_seconds=time.time() - start, error="上传失败")
            steps_completed += 1

            # 步骤3：背景知识
            print("\n[3/4] 生成背景知识...")
            await build_context()
            steps_completed += 1

        if not skip_eval:
            # 步骤4：评测
            print("\n[4/4] 运行评测...")
            ok, report = await run_eval()
            if not ok:
                return PipelineResult(False, steps_completed, steps_total, 0, elapsed_seconds=time.time() - start, error="评测失败")
            steps_completed += 1

            # 保存快照
            snapshot = await save_eval_snapshot(report)

            # 对比
            diff = compare_with_previous(report)
            avg = round(sum(r["score_pct"] for r in report["rounds_summary"]) / len(report["rounds_summary"]), 1)

            if diff:
                from tools.eval_compare import format_diff_report
                print(format_diff_report(diff, "上一次", "本次"))

            elapsed = round(time.time() - start, 1)
            print(f"\n=== 流水线完成: {steps_completed}/{steps_total} 步, 评测分 {avg}%, 耗时 {elapsed}s ===")

            return PipelineResult(
                success=True,
                steps_completed=steps_completed,
                steps_total=steps_total,
                eval_score=avg,
                eval_report=report,
                diff_from_previous=diff,
                elapsed_seconds=elapsed,
            )

        elapsed = round(time.time() - start, 1)
        print(f"\n=== 流水线完成: {steps_completed}/{steps_total} 步, 耗时 {elapsed}s ===")
        return PipelineResult(True, steps_completed, steps_total, 0, elapsed_seconds=elapsed)

    except Exception as e:
        elapsed = round(time.time() - start, 1)
        print(f"\n❌ 流水线失败: {e}")
        return PipelineResult(False, steps_completed, steps_total, 0, elapsed_seconds=elapsed, error=str(e))


if __name__ == "__main__":
    args = sys.argv[1:]
    skip_eval = "--skip-eval" in args
    eval_only = "--eval-only" in args
    asyncio.run(run_pipeline(skip_eval=skip_eval, eval_only=eval_only))
