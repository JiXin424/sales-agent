#!/usr/bin/env python3
"""自动化测试影响力本体问答系统"""

import requests
import json
from typing import Dict, List

BASE_URL = "http://localhost:3000"

# 测试查询
TEST_QUERIES = [
    "客户嫌贵",
    "如何建立信任",
    "客户拖延不决策",
    "第一次拜访客户",
    "丢单后如何维护关系",
    "如何制造紧迫感",
    "客户说比竞品贵",
    "如何运用对比原理",
    "稀缺原则如何应用",
    "互惠原则实战技巧"
]

def test_query(query: str) -> Dict:
    """测试单个查询"""
    try:
        response = requests.post(
            f"{BASE_URL}/api/chat",
            json={"query": query},
            timeout=10
        )
        response.raise_for_status()
        data = response.json()

        return {
            'query': query,
            'success': True,
            'entity_count': data.get('relevant_entities_count', 0),
            'answer_length': len(data.get('answer', '')),
            'has_markdown': '#' in data.get('answer', ''),
            'entities': [e['name'] for e in data.get('entities', [])]
        }
    except Exception as e:
        return {
            'query': query,
            'success': False,
            'error': str(e)
        }

def main():
    print("=" * 60)
    print("影响力本体问答系统 - 自动化测试")
    print("=" * 60)

    results = []

    for i, query in enumerate(TEST_QUERIES, 1):
        print(f"\n[{i}/{len(TEST_QUERIES)}] 测试: {query}")
        result = test_query(query)
        results.append(result)

        if result['success']:
            print(f"  ✅ 成功 - 找到 {result['entity_count']} 个实体")
            if result['entity_count'] > 0:
                print(f"  实体: {', '.join(result['entities'][:3])}")
            print(f"  回答长度: {result['answer_length']} 字符")
            print(f"  Markdown: {'是' if result['has_markdown'] else '否'}")
        else:
            print(f"  ❌ 失败: {result.get('error', 'Unknown error')}")

    # 统计
    print("\n" + "=" * 60)
    print("测试统计")
    print("=" * 60)

    success_count = sum(1 for r in results if r['success'])
    total_with_entities = sum(1 for r in results if r['success'] and r['entity_count'] > 0)
    avg_entity_count = sum(r['entity_count'] for r in results if r['success']) / len(results) if results else 0

    print(f"总查询数: {len(TEST_QUERIES)}")
    print(f"成功响应: {success_count} ({success_count/len(TEST_QUERIES)*100:.1f}%)")
    print(f"找到实体: {total_with_entities} ({total_with_entities/len(TEST_QUERIES)*100:.1f}%)")
    print(f"平均实体数: {avg_entity_count:.1f}")

    # 保存结果
    with open('/tmp/test_results.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"\n详细结果已保存到: /tmp/test_results.json")

if __name__ == '__main__':
    main()
