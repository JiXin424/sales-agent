# Ontology-clean — 纯净初始化版本

> **零客户数据**的本体知识引擎。上传服务器后一键初始化，即可服务任何新客户。
>
> 包含完整运行时引擎 + 预处理工具链 + 通用传库指南。

---

## 与 Ontology-minimal 的区别

| 项目 | Ontology-minimal | **Ontology-clean** |
|------|-----------------|-------------------|
| 客户数据 | 含九峰 48 篇 + 1098 实体 | **无任何客户数据** |
| PostgreSQL | 预置 .pgdata/ 70MB | **空，首次启动自动创建** |
| 用途 | 复用九峰成果做演示 | **部署到新服务器服务新客户** |
| 大小 | 73MB | **0.6MB** |

---

## 项目结构

```
Ontology-clean/
├── init.sh                   # ★ 一键初始化脚本
├── .env.example              # 环境变量模板
├── .env                      # 真实配置（需手动填写）
├── docker-compose.yml        # PostgreSQL
├── requirements.txt          # Python 依赖
├── pyproject.toml
│
├── backend/                  # ★ 后端引擎（FastAPI + SQLAlchemy）
│   ├── main.py               # 入口（9 个 API router）
│   ├── api/                  # REST 接口
│   ├── coach/                # 销售教练 4 场景
│   ├── document/             # 文档抽取 + 流水线
│   ├── knowledge/            # 背景知识生成
│   ├── ontology/             # 本体 CRUD + 图 + 向量
│   └── reasoning/            # OAG 推理引擎
│
├── preprocessor/             # ★ 文档预处理工具链
│   ├── md_optimizer.py       # Markdown 向量化优化（MAX 级别）
│   ├── build_ontology.py     # 主体文件自动生成
│   ├── ontology_extractor.py # 实体+关系抽取
│   ├── ontology_types.yaml   # 类型预设（general/sales）
│   ├── MAX-v3-prompt.md      # MAX 级别提示词
│   └── 主体文件-模板.md       # 主体文件参考模板
│
├── data/                     # ★ 空数据目录（等客户填充）
│   ├── uploads/              # 客户原始/优化后文档放这里
│   └── README.md
│
├── .pgdata/                  # ★ PostgreSQL 数据（首次启动自动创建）
│   └── README.md
│
├── eval_results/             # ★ 空评测目录（运行后填充）
├── eval_nine_rounds.py       # 评测脚本
│
├── scripts/                  # 验证脚本（DashScope/DeepSeek/pgvector）
├── tools/                    # 流水线 + 评测工具
├── tests/                    # 单元测试
│
├── docs/                     # ★ 通用文档（适用于所有客户）
│   ├── 传库文件指南.md          # 必备文件清单
│   └── 传库文件优先级矩阵.xlsx   # 商务风格优先级矩阵
│
└── frontend/                 # React 前端（源码）
```

---

## 部署流程（3 步）

### Step 1：上传服务器

```bash
# 解压
unzip Ontology-clean.zip -d /opt/
cd /opt/Ontology-clean

# 编辑配置
cp .env.example .env
vim .env   # 填入 DeepSeek 和 DashScope 的 API Key
```

### Step 2：一键初始化

```bash
# 方式 A：仅部署系统（无客户文档）
bash init.sh

# 方式 B：同时预处理客户文档
bash init.sh /path/to/客户文档
```

`init.sh` 自动完成 7 步：
1. 环境检查（Python 3.10+ / Docker）
2. 配置 .env 校验
3. 创建虚拟环境 + 安装依赖
4. 启动 PostgreSQL（首次创建 .pgdata/）
5. 初始化数据库表结构
6. 客户文档预处理（主体文件生成 → 文档优化 → 入库 → 构建背景知识）
7. 输出启动指引

### Step 3：启动服务

```bash
source venv/bin/activate
python3 backend/main.py
```

- 后端 API：`http://localhost:8000`
- Swagger 文档：`http://localhost:8000/docs`

---

## 客户文档上传流程

### 推荐方式：先预处理再上传（命中率 70%+）

```bash
# 1. 准备客户文档（参考 docs/传库文件指南.md）
ls /path/to/客户文档/
# 公司介绍.md / 产品规格.md / 竞品对比.md / 案例.md / ...

# 2. 一键预处理（主体文件 + 优化）
bash init.sh /path/to/客户文档

# 3. 启动后端后测试
curl -X POST http://localhost:8000/api/v1/chat/ \
  -H "Content-Type: application/json" \
  -d '{"question":"你们公司的主要产品是什么？"}'
```

### 简易方式：直接 API 上传（命中率 50% 左右）

```bash
# 启动后端后
curl -F "file=@公司介绍.md" http://localhost:8000/api/v1/documents/upload
curl -F "file=@产品规格.md" http://localhost:8000/api/v1/documents/upload

# 重建背景知识
curl -X POST http://localhost:8000/api/v1/documents/build-context
```

---

## 配置说明（.env）

```ini
# DeepSeek（主 LLM）
DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxx
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL_PRO=deepseek-v4-pro
DEEPSEEK_MODEL_FLASH=deepseek-v4-flash

# 阿里云 DashScope（Embedding + 视觉）
DASHSCOPE_API_KEY=sk-xxxxxxxxxxxxx
DASHSCOPE_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
DASHSCOPE_EMBEDDING_MODEL=text-embedding-v4
DASHSCOPE_EMBEDDING_DIM=1024

# PostgreSQL（首次启动自动创建）
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=ontology
POSTGRES_USER=ontology
POSTGRES_PASSWORD=ontology_dev_2026
```

---

## 核心能力

| 能力 | 模块 | 说明 |
|------|------|------|
| **文档预处理** | `preprocessor/` | LLM 优化文档结构（YAML + FAQ + 锚点）|
| **主体文件生成** | `preprocessor/build_ontology.py` | 自动抽取实体+关系，注入 LLM 全局上下文 |
| **实体+关系抽取** | `backend/document/extractor.py` | 22 类实体 + 22 种关系 |
| **背景知识生成** | `backend/knowledge/context.py` | 结构化摘要注入 system prompt |
| **OAG 推理引擎** | `backend/reasoning/engine.py` | 查询→意图→本体检索→上下文增强→LLM 生成 |
| **销售教练** | `backend/coach/` | 异议/对比/准备/复盘 4 场景 |
| **向量检索** | `backend/ontology/embedding.py` | 1024 维 + pgvector 混合检索 |
| **冲突检测** | `backend/api/conflicts.py` | 多源数据数字不一致自动检测 |

---

## API 端点总览

| 分类 | 端点 | 方法 | 说明 |
|------|------|------|------|
| 健康 | `/health` | GET | 服务健康检查 |
| 对话 | `/api/v1/chat/` | POST | 知识问答（同步） |
| 对话 | `/api/v1/chat/stream` | POST | 知识问答（SSE 流式） |
| 教练 | `/api/v1/coach/{prep,objection,comparison,review}` | POST | 销售教练 4 场景 |
| 本体 | `/api/v1/ontology/{graph,objects,stats}` | GET | 实体/关系查询 |
| 文档 | `/api/v1/documents/upload` | POST | 上传文档 |
| 文档 | `/api/v1/documents/build-context` | POST | 重建背景知识 |
| 冲突 | `/api/v1/conflicts/` | GET | 冲突列表 |
| 反馈 | `/api/v1/feedback/` | POST | 提交反馈 |
| 统计 | `/api/v1/stats/{entities,system,costs}` | GET | 仪表盘数据 |

完整 API 说明：启动后访问 `http://localhost:8000/docs`

---

## 首次使用 Checklist

部署前对照检查：

- [ ] 服务器已安装 Python 3.10+
- [ ] 服务器已安装 Docker
- [ ] 已申请 DeepSeek API Key
- [ ] 已申请 DashScope API Key
- [ ] 已准备至少 P0 类客户文档（公司主体 + 产品规格 + 5 个案例）
- [ ] 已阅读 `docs/传库文件指南.md`

参考 `docs/传库文件优先级矩阵.xlsx` 了解完整的文件类别和优先级。

---

## 常见问题

**Q: 初始化中途失败如何重试？**
```bash
# 删除虚拟环境和数据库，重新开始
rm -rf venv .pgdata
bash init.sh /path/to/客户文档
```

**Q: 已经初始化过，如何添加新文档？**
```bash
# 方式 1：API 上传
curl -F "file=@新文档.md" http://localhost:8000/api/v1/documents/upload

# 方式 2：预处理 + 入库
python3 preprocessor/md_optimizer.py /path/to/新文档 --subject preprocessor/主体文件.md
cp 新文档-优化/* data/uploads/
# 重启后端，调 build-context
```

**Q: 如何备份客户数据？**
```bash
# 备份 PostgreSQL
docker compose exec db pg_dump -U ontology ontology > backup_$(date +%Y%m%d).sql

# 备份上传文件
tar -czf uploads_backup.tar.gz data/uploads/
```

**Q: 如何升级到新版本？**
```bash
# 拉取新版代码
git pull  # 或重新解压新版 zip

# 重启服务
docker compose restart db
source venv/bin/activate
pip install -r requirements.txt --upgrade
python3 backend/main.py
```

---

## 性能基准（参考九峰实战）

| 指标 | 九峰实战数据 | 新客户预期 |
|------|------------|----------|
| 文档数 | 48 篇 | 30-50 篇 |
| 实体数 | 1098 | 500-1500 |
| 关系数 | 1159 | 500-2000 |
| 关键词命中率 | 70% | 50-75% |
| 首次响应时间 | 3-8s | 3-10s |
| 流式首字时间 | 1-2s | 1-2s |

---

## 许可

内部工具，仅供泰山兄弟内部使用。
