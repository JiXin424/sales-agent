# 影响力本体系统 - 多级跳转功能设计

**日期**：2026-06-25
**功能类型**：知识图谱导航

---

## 🎯 什么是多级跳转？

**定义**：
用户在查看一个实体时，可以沿着实体之间的关系"跳转"到相关实体，形成知识探索路径。

**示例路径**：
```
用户查询: "如何应用互惠原理？"

↓ Level 1: 匹配到
[原则] 互惠原理

↓ Level 2: 跳转到应用
[概念] 互惠式让步 → 说明如何应用
[策略] 拒绝-后撤术 → 具体策略

↓ Level 3: 跳转到案例
[案例] 服务员文森特案例 → 真实案例
[案例] 特百惠聚会案例 → 另一个案例

↓ Level 4: 跳转到话术
[话术] 互惠开场白话术 → 可用话术
[话术] 互惠式让步话术 → 具体话术
```

---

## 🧠 头脑风暴：多级跳转设计

### 方案1：基于现有relations字段

**现状**：
influence_ontology.json中有166个relations

**关系类型**：
```json
{
  "from": "reciprocity-principle",
  "to": "tupperware-party-case",
  "type": "exemplifies",  // 体现
  "strength": "strong"
}
```

**实现**：
```python
def get_related_entities(entity_id, relation_type=None, max_depth=2):
    """获取相关实体（支持多级跳转）"""
    
    # Level 1: 直接关系
    direct_relations = [
        r for r in ontology['relations']
        if r['from'] == entity_id
    ]
    
    # Level 2: 二级关系
    if max_depth >= 2:
        for relation in direct_relations:
            target_id = relation['to']
            secondary_relations = [
                r for r in ontology['relations']
                if r['from'] == target_id
            ]
            # 添加到结果...
    
    return related_entities
```

**优势**：
- ✅ 基于现有数据
- ✅ 关系明确
- ✅ 可控制跳转深度

**劣势**：
- ⚠️ 需要检查relations数据完整性
- ⚠️ 可能缺少某些关系

### 方案2：智能推荐跳转

**思路**：
根据实体类型和内容，智能推荐应该跳转到哪些实体

**跳转规则**：
```python
JUMP_RULES = {
    'principle': {
        '推荐跳转': ['concepts', 'tactics', 'cases'],
        '理由': '从原理到应用方法和案例'
    },
    'tactic': {
        '推荐跳转': ['cases', 'scripts', 'scenarios'],
        '理由': '从策略到案例、话术和场景'
    },
    'case': {
        '推荐跳转': ['principles', 'tactics', 'scripts'],
        '理由': '从案例到原理、策略和话术'
    },
    'concept': {
        '推荐跳转': ['principles', 'tactics'],
        '理由': '从概念到原理和策略'
    }
}
```

**实现**：
```python
def recommend_jumps(entity):
    """推荐跳转目标"""
    entity_type = entity['type']
    principle_id = entity.get('principle')
    
    recommendations = []
    
    if entity_type == 'principle':
        # 推荐应用该原则的策略
        recommendations.extend([
            e for e in ontology['tactics']
            if e.get('principle') == entity['id']
        ])
        
        # 推荐体现该原则的案例
        recommendations.extend([
            e for e in ontology['cases']
            if e.get('principle') == entity['id']
        ])
    
    elif entity_type == 'case':
        # 推荐案例体现的原则
        if principle_id:
            recommendations.extend([
                e for e in ontology['principles']
                if e['id'] == principle_id
            ])
        
        # 推荐可用策略
        recommendations.extend([
            e for e in ontology['tactics']
            if e.get('principle') == principle_id
        ])
    
    return recommendations[:5]
```

### 方案3：用户意图驱动跳转

**思路**：
根据用户查询意图，自动生成跳转路径

**示例**：
```
用户查询: "如何应用互惠原理？"
意图: 应用型

系统自动生成路径:
1. [原则] 互惠原理（是什么）
2. [概念] 互惠式让步（核心概念）
3. [策略] 拒绝-后撤术（具体策略）
4. [案例] 服务员文森特案例（真实案例）
5. [话术] 互惠式让步话术（可直接使用）
```

**实现**：
```python
def generate_learning_path(query, matched_entities):
    """根据查询意图生成学习路径"""
    
    intent = classify_intent(query)  # apply, understand, compare, etc.
    
    path = []
    
    if intent == 'apply':
        # 应用型路径：原理 → 概念 → 策略 → 案例 → 话术
        for entity in matched_entities:
            if entity['type'] == 'principle':
                path.append(('理解', entity))
                path.append(('应用', find_related_concepts(entity)))
                path.append(('策略', find_related_tactics(entity)))
                path.append(('案例', find_related_cases(entity)))
                path.append(('话术', find_related_scripts(entity)))
                break
    
    return path
```

### 方案4：可视化知识图谱

**思路**：
在前端以图形方式展示实体关系

**实现**：
```javascript
// 使用 D3.js 或 Cytoscape.js
function displayKnowledgeGraph(centerEntity) {
    const nodes = [centerEntity];
    const links = [];
    
    // 添加一级关联
    centerEntity.related.forEach(rel => {
        nodes.push(rel);
        links.push({source: centerEntity, target: rel});
        
        // 添加二级关联
        rel.related.forEach(rel2 => {
            nodes.push(rel2);
            links.push({source: rel, target: rel2});
        });
    });
    
    // 渲染图谱
    renderGraph(nodes, links);
}
```

**UI展示**：
```
┌─────────────────────────────────┐
│     互惠原理                      │
│        [核心原则]               │
└──────────┬──────────┬───────────┘
           │          │
    ┌──────▼──────┐ ┌▼──────────┐
    │ 互惠式让步  │ │服务员案例  │
    │  [概念]    │ │  [案例]   │
    └──────┬──────┘ └┬─────────┘
           │          │
    ┌──────▼──────┐ ┌▼──────────┐
    │拒绝-后撤术  │ │特百惠案例 │
    │  [策略]    │ │  [案例]   │
    └─────────────┘ └───────────┘
```

---

## 🎯 多级跳转的UI设计

### 设计1：点击展开式

**实现**：
```html
<div class="entity-card" onclick="toggleRelated(this)">
    <h3>[principle] 互惠原理</h3>
    <p>当别人帮了我们的忙...</p>
    
    <div class="related-entities" style="display:none;">
        <div class="related-title">相关实体 (点击跳转)</div>
        
        <div class="related-item" onclick="jumpTo('互惠式让步')">
            <span class="badge">[概念]</span>
            <span class="name">互惠式让步</span>
            <span class="arrow">→</span>
        </div>
        
        <div class="related-item" onclick="jumpTo('服务员文森特案例')">
            <span class="badge">[案例]</span>
            <span class="name">服务员文森特案例</span>
            <span class="arrow">→</span>
        </div>
    </div>
</div>
```

### 设计2：面包屑导航

**实现**：
```html
<div class="breadcrumb">
    <span class="item">查询</span>
    <span class="separator">→</span>
    <span class="item">互惠原理</span>
    <span class="separator">→</span>
    <span class="item">互惠式让步</span>
    <span class="separator">→</span>
    <span class="item active">拒绝-后撤术</span>
</div>

<div class="path-suggestions">
    <div class="suggestion-title">继续探索：</div>
    <a href="#" onclick="jumpTo('服务员案例')">
        查看该策略的案例 →
    </a>
    <a href="#" onclick="jumpTo('互惠话术')">
        查看该策略的话术 →
    </a>
</div>
```

### 设计3：侧边栏知识树

**实现**：
```html
<div class="main-container">
    <!-- 主内容区 -->
    <div class="content-area">
        当前实体详情...
    </div>
    
    <!-- 右侧知识树 -->
    <div class="knowledge-tree">
        <div class="tree-title">知识图谱</div>
        
        <div class="tree-node level-1" onclick="expandNode(this)">
            <span class="icon">📖</span>
            <span class="label">互惠原理</span>
            <span class="count">[12 related]</span>
            
            <div class="tree-children" style="display:none;">
                <div class="tree-node level-2">
                    <span class="icon">💡</span>
                    <span class="label">互惠式让步</span>
                    <span class="jump">→</span>
                </div>
                
                <div class="tree-node level-2">
                    <span class="icon">📋</span>
                    <span class="label">拒绝-后撤术</span>
                    <span class="jump">→</span>
                </div>
                
                <div class="tree-node level-2 expandable">
                    <span class="icon">📖</span>
                    <span class="label">相关案例</span>
                    <span class="count">[8]</span>
                </div>
            </div>
        </div>
    </div>
</div>
```

### 设计4：对话式探索

**实现**：
```
系统: "我找到了'互惠原理'。您想："
      A. 了解互惠原理的定义
      B. 看看如何应用互惠原理
      C. 查看互惠原理的成功案例
      
用户: "B"

系统: "好的。应用互惠原理有几种方式："
      "1. 互惠式让步 - 先提大要求被拒后再提小要求"
      "2. 直接施恩 - 先给予好处再提要求"
      ""
      "您想深入了解哪种方式？"
      
用户: "1"

系统: "互惠式让步的核心是..."
      "想看真实案例吗？[服务员文森特案例] [特百惠聚会案例]"
```

---

## 📊 关系类型分析

### 现有关系（166个）

**分析influence_ontology.json中的relations**：
```python
relation_types = {}
for rel in ontology['relations']:
    rel_type = rel['type']
    relation_types[rel_type] = relation_types.get(rel_type, 0) + 1

print(relation_types)
```

**预期关系类型**：
- `exemplifies`: 案例体现原则
- `applies`: 策略应用原则
- `demonstrates`: 案例演示策略
- `related-to`: 相关实体
- `is-a`: 概念归类
- `part-of`: 属于某个集合

### 推荐关系类型

**建议补充**：
1. **principle → concept**
   - type: "has-concept"
   - example: 互惠原理 → 互惠式让步

2. **principle → tactic**
   - type: "applies-as"
   - example: 互惠原理 → 拒绝-后撤术

3. **principle → case**
   - type: "exemplified-by"
   - example: 互惠原理 → 服务员文森特案例

4. **tactic → case**
   - type: "demonstrated-in"
   - example: 拒绝-后撤术 → 服务员文森特案例

5. **tactic → script**
   - type: "implemented-as"
   - example: 拒绝-后撤术 → 拒绝后撤话术

6. **case → script**
   - type: "related-script"
   - example: 服务员文森特案例 → 互惠开场话术

---

## 🚀 实施路线

### Phase 1：数据准备（1周）

**目标**：建立完整的关系网络

1. **分析现有relations**
   - 检查166个relations的质量
   - 识别关系类型分布
   - 找出关系缺失

2. **补充缺失关系**
   - principle → tactic
   - principle → concept
   - tactic → case
   - case → script
   - 等...

3. **验证关系完整性**
   - 确保每个重要实体都有关系
   - 检查关系的双向性

### Phase 2：后端实现（1周）

1. **API接口**
   ```python
   @app.route('/api/ontology/related/<entity_id>')
   def get_related_entities(entity_id, depth=2):
       """获取相关实体（支持多级跳转）"""
       pass
   ```

2. **跳转逻辑**
   - 实现get_related_entities()
   - 支持深度控制（1-3级）
   - 支持关系过滤

3. **路径生成**
   - 实现generate_learning_path()
   - 根据意图生成跳转路径
   - 返回结构化路径

### Phase 3：前端实现（1周）

1. **基础交互**
   - 点击跳转
   - 面包屑导航
   - 相关实体推荐

2. **高级功能**
   - 知识图谱可视化
   - 对话式探索
   - 路径推荐

### Phase 4：用户体验优化（1周）

1. **性能优化**
   - 关系缓存
   - 预加载相关实体
   - 懒加载二级关系

2. **用户引导**
   - 新手教程
   - 提示信息
   - 快捷键

---

## 💡 预期效果

### 用户价值

1. **深度学习**
   - 从一个知识点出发，系统学习整个知识体系
   - 理解原则、策略、案例、话术之间的关系

2. **快速导航**
   - 不需要重新查询，直接点击跳转
   - 节省时间，提高效率

3. **发现新知识**
   - 通过关系发现意想不到的关联
   - 扩展知识面

### 技术价值

1. **知识活化**
   - 静态知识变成动态网络
   - 实体之间建立连接

2. **智能推荐**
   - 基于关系推荐相关内容
   - 提高内容发现效率

3. **数据分析**
   - 分析用户跳转路径
   - 优化知识结构

---

## 🎯 成功指标

### 功能指标
- ✅ 90%的实体至少有3个相关关系
- ✅ 平均跳转深度达到2-3级
- ✅ 跳转响应时间 < 1秒

### 用户指标
- ✅ 用户平均跳转次数 > 3次/查询
- ✅ 跳转功能使用率 > 60%
- ✅ 用户满意度提升 > 30%

---

## 📝 下一步行动

### 立即可做
1. 分析现有166个relations
2. 设计关系补充策略
3. 创建关系补充工具

### 本周完成
1. 实施后端get_related_entities()
2. 实现前端点击跳转
3. 测试基础跳转功能

### 中期规划
1. 补充完整关系网络
2. 实现知识图谱可视化
3. 实现对话式探索

---

**总结**：多级跳转是将知识库升级为知识图谱的关键功能，能让用户深度探索、系统性学习影响力知识。

**优先级**：⭐⭐⭐⭐⭐ 高优先级
**实施难度**：⭐⭐⭐ 中等
**用户价值**：⭐⭐⭐⭐⭐ 极高
