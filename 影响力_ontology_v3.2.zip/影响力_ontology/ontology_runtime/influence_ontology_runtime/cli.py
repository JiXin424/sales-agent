"""命令行交互工具。"""

from __future__ import annotations

import argparse
import sys
from typing import Any, List, Optional

from .loader import load
from .queries import QueryParser, execute
from .store import OntologyStore


class Colors:
    HEADER = "\033[95m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    END = "\033[0m"
    BOLD = "\033[1m"


def _print_entity(entity: Any, indent: int = 0) -> None:
    prefix = "  " * indent
    name = getattr(entity, "name", entity.id) or entity.id
    print(f"{prefix}- {Colors.CYAN}{name}{Colors.END} ({Colors.YELLOW}{type(entity).__name__}{Colors.END})")
    for key, value in entity.model_dump().items():
        if key in ("id", "name"):
            continue
        if value is None or value == [] or value == "":
            continue
        if isinstance(value, list):
            value_str = "; ".join(str(x) for x in value[:5])
            if len(value) > 5:
                value_str += f" ... (+{len(value) - 5})"
        else:
            value_str = str(value)
            if len(value_str) > 200:
                value_str = value_str[:200] + "..."
        print(f"{prefix}  {Colors.BOLD}{key}{Colors.END}: {value_str}")


def _print_list(entities: List[Any], title: Optional[str] = None) -> None:
    if title:
        print(f"\n{Colors.HEADER}{title} ({len(entities)}){Colors.END}")
    for e in entities:
        name = getattr(e, "name", e.id) or e.id
        print(f"  - {name} ({Colors.YELLOW}{type(e).__name__}{Colors.END}) [`{e.id}`]")


def _cmd_get(store: OntologyStore, args: argparse.Namespace) -> None:
    entity = store.get_by_id(args.id)
    if not entity:
        print(f"{Colors.RED}未找到 id={args.id}{Colors.END}")
        return
    _print_entity(entity)


def _cmd_list(store: OntologyStore, args: argparse.Namespace) -> None:
    t = store.resolve_type(args.type)
    if not t:
        print(f"{Colors.RED}未知类型: {args.type}{Colors.END}")
        return
    entities = store.get_by_type(t)
    _print_list(entities, f"{args.type} 列表")


def _cmd_search(store: OntologyStore, args: argparse.Namespace) -> None:
    results = store.search(args.query)
    _print_list(results, f"搜索 '{args.query}' 结果")


def _cmd_principle(store: OntologyStore, args: argparse.Namespace) -> None:
    explanation = store.explain_principle(args.id)
    principle = explanation.get("principle", [None])[0]
    if not principle:
        print(f"{Colors.RED}未找到原则 id={args.id}{Colors.END}")
        return
    print(f"\n{Colors.HEADER}=== {principle.name} ==={Colors.END}")
    if principle.description:
        print(principle.description)
    for key, entities in explanation.items():
        if key == "principle" or not entities:
            continue
        _print_list(entities, key)


def _cmd_related(store: OntologyStore, args: argparse.Namespace) -> None:
    neighbors = store.get_neighbors(args.id)
    _print_list(neighbors, f"与 {args.id} 相关的实体")


def _cmd_query(store: OntologyStore, args: argparse.Namespace) -> None:
    query = QueryParser.parse(args.query)
    results = execute(store, query)
    _print_list(results, f"查询 '{args.query}' 结果")


def _cmd_stats(store: OntologyStore, args: argparse.Namespace) -> None:
    stats = store.stats()
    print(f"\n{Colors.HEADER}本体统计{Colors.END}")
    for key, count in stats.items():
        print(f"  {key}: {count}")


def _interactive_loop(store: OntologyStore) -> None:
    print(f"\n{Colors.GREEN}《影响力》知识本体 CLI{Colors.END}")
    print("输入 help 查看命令，quit 退出。\n")
    while True:
        try:
            line = input("influence> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line.lower() in ("quit", "exit", "q"):
            break
        if line.lower() == "help":
            print(
                "命令:\n"
                "  list <type>                列出某类型实体\n"
                "  get <id>                  按 id 查看实体\n"
                "  search <query>            全文搜索\n"
                "  principle <id>            解释某原则（跨层视图）\n"
                "  related <id>              查看相关实体\n"
                "  query <dsl>               DSL 查询，如 type=Case principle=reciprocity-principle\n"
                "  stats                     统计\n"
                "  quit / exit               退出"
            )
            continue

        parts = line.split(maxsplit=1)
        cmd = parts[0].lower()
        rest = parts[1] if len(parts) > 1 else ""

        if cmd == "list":
            _cmd_list(store, argparse.Namespace(type=rest))
        elif cmd == "get":
            _cmd_get(store, argparse.Namespace(id=rest))
        elif cmd == "search":
            _cmd_search(store, argparse.Namespace(query=rest))
        elif cmd == "principle":
            _cmd_principle(store, argparse.Namespace(id=rest))
        elif cmd == "related":
            _cmd_related(store, argparse.Namespace(id=rest))
        elif cmd == "query":
            _cmd_query(store, argparse.Namespace(query=rest))
        elif cmd == "stats":
            _cmd_stats(store, argparse.Namespace())
        else:
            # 默认按 DSL 查询处理
            _cmd_query(store, argparse.Namespace(query=line))


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="《影响力》知识本体 CLI")
    parser.add_argument("--json", "-j", default=None, help="influence_ontology.json 路径")
    subparsers = parser.add_subparsers(dest="command")

    p_list = subparsers.add_parser("list", help="列出某类型实体")
    p_list.add_argument("type", help="实体类型")

    p_get = subparsers.add_parser("get", help="按 id 查看实体")
    p_get.add_argument("id", help="实体 id")

    p_search = subparsers.add_parser("search", help="全文搜索")
    p_search.add_argument("query", help="搜索关键词")

    p_principle = subparsers.add_parser("principle", help="解释某原则")
    p_principle.add_argument("id", help="原则 id")

    p_related = subparsers.add_parser("related", help="查看相关实体")
    p_related.add_argument("id", help="实体 id")

    p_query = subparsers.add_parser("query", help="DSL 查询")
    p_query.add_argument("query", help="查询字符串，如 type=Case principle=reciprocity-principle")

    p_stats = subparsers.add_parser("stats", help="统计")

    args = parser.parse_args(argv)

    store = load(args.json)

    if args.command == "list":
        _cmd_list(store, args)
    elif args.command == "get":
        _cmd_get(store, args)
    elif args.command == "search":
        _cmd_search(store, args)
    elif args.command == "principle":
        _cmd_principle(store, args)
    elif args.command == "related":
        _cmd_related(store, args)
    elif args.command == "query":
        _cmd_query(store, args)
    elif args.command == "stats":
        _cmd_stats(store, args)
    else:
        _interactive_loop(store)

    return 0


if __name__ == "__main__":
    sys.exit(main())
