"""CLI 测试。"""

from pathlib import Path

from influence_ontology_runtime.cli import main

DATA_PATH = Path(__file__).resolve().parent.parent.parent / "influence_ontology.json"


def test_cli_stats(capsys):
    main(["--json", str(DATA_PATH), "stats"])
    captured = capsys.readouterr()
    assert "principles: 13" in captured.out
    assert "cases: 111" in captured.out


def test_cli_query(capsys):
    main(["--json", str(DATA_PATH), "query", "type=Case principle=reciprocity-principle"])
    captured = capsys.readouterr()
    assert "Case" in captured.out
    assert "reciprocity" not in captured.out or "Case" in captured.out  # 只需确认有输出


def test_cli_get(capsys):
    main(["--json", str(DATA_PATH), "get", "reciprocity-principle"])
    captured = capsys.readouterr()
    assert "互惠" in captured.out or "reciprocity-principle" in captured.out


def test_cli_list(capsys):
    main(["--json", str(DATA_PATH), "list", "principles"])
    captured = capsys.readouterr()
    assert "principle" in captured.out.lower()
