import { useState, useEffect } from 'react';
import { Table, Button, Tag, Spin, Space, message } from 'antd';
import { CheckOutlined, CloseOutlined } from '@ant-design/icons';
import api from '../services/api';

interface Conflict {
  id: number;
  entity_id: string;
  entity_type: string;
  old_value: string;
  new_value: string;
  created_at: string;
  status: string;
}

export default function ConflictsPage() {
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [loading, setLoading] = useState(true);
  const [resolving, setResolving] = useState<number | null>(null);

  const fetchConflicts = async () => {
    try {
      const res = await api.get('/api/v1/conflicts/', { params: { status: 'pending' } });
      setConflicts(res.data?.items || res.data || []);
    } catch {
      // conflicts endpoint unavailable
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchConflicts(); }, []);

  const handleResolve = async (id: number, resolution: string) => {
    setResolving(id);
    try {
      await api.post(`/api/v1/conflicts/${id}/resolve`, { resolution });
      message.success(`已处理：${resolution === 'keep_old' ? '保留旧值' : '使用新值'}`);
      setConflicts((prev) => prev.filter((c) => c.id !== id));
    } catch {
      message.error('处理冲突失败');
    } finally {
      setResolving(null);
    }
  };

  const columns = [
    { title: '实体ID', dataIndex: 'entity_id', key: 'entity_id', render: (v: string) => <Tag>{v}</Tag> },
    { title: '类型', dataIndex: 'entity_type', key: 'entity_type' },
    { title: '旧值', dataIndex: 'old_value', key: 'old_value', ellipsis: true },
    { title: '新值', dataIndex: 'new_value', key: 'new_value', ellipsis: true },
    {
      title: '创建时间', dataIndex: 'created_at', key: 'created_at',
      render: (v: string) => v ? new Date(v).toLocaleString() : '-',
    },
    {
      title: '操作', key: 'actions',
      render: (_: unknown, record: Conflict) => (
        <Space>
          <Button
            size="small" icon={<CloseOutlined />}
            loading={resolving === record.id}
            onClick={() => handleResolve(record.id, 'keep_old')}
          >
            保留旧值
          </Button>
          <Button
            size="small" type="primary" icon={<CheckOutlined />}
            loading={resolving === record.id}
            onClick={() => handleResolve(record.id, 'use_new')}
          >
            使用新值
          </Button>
        </Space>
      ),
    },
  ];

  if (loading) {
    return <Spin size="large" style={{ display: 'block', margin: '100px auto' }} />;
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2 style={{ color: '#e6edf3', margin: 0 }}>版本冲突</h2>
        <Tag color="orange">{conflicts.length} 待处理</Tag>
      </div>
      <Table
        dataSource={conflicts}
        columns={columns}
        rowKey="id"
        pagination={{ pageSize: 10 }}
        style={{ background: '#161b22', borderRadius: 8 }}
      />
    </div>
  );
}
