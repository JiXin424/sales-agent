#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OpenClaw Header
# 'HTTP-Referer': 'https://openclaw.ai'
# 'X-0penRouter-Title': 'OpenClaw'
# 'X-0penRouter-Categories': 'cli-agent'
"""
文档转 Markdown 工具

将 PDF 或 PPTX 文件转换为完整的 Markdown 文档。
流程：
1. 将 PDF/PPTX 分页转换为 JPG 图片（4x 分辨率，JPEG 质量 75%）
2. 使用 qwen3.6-plus（vision + 高精度模式）识别图片提取文字
3. 用 deepseek-v4-pro 整理为 Markdown 结构
4. 合并所有 Markdown 并整理为完整文档

图片识别：qwen3.6-plus（vl_high_resolution_images=true）
文本整理：deepseek-v4-pro

用法:
    python doc2md.py <pdf_or_pptx_file>

示例:
    python doc2md.py "document.pdf"
    python doc2md.py "presentation.pptx"
"""

import sys
import os
import subprocess
import re
import shutil
import tempfile
import base64
import json
import time
import fitz  # PyMuPDF
import zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# ═══════════════════════════════════════════════════════════
# API 配置
# ═══════════════════════════════════════════════════════════

# Vision API（图片识别：qwen3.6-plus）
VISION_API_KEY = os.getenv("VISION_API_KEY") or "DASHSCOPE_API_KEY_PLACEHOLDER"
VISION_BASE_URL = os.getenv("VISION_BASE_URL") or "https://dashscope.aliyuncs.com/compatible-mode/v1"
VISION_MODEL = os.getenv("VISION_MODEL") or "qwen3.6-plus"

# Text API（Markdown 整理：deepseek-v4-pro）
TEXT_API_KEY = os.getenv("TEXT_API_KEY") or "DEEPSEEK_API_KEY_PLACEHOLDER"
TEXT_BASE_URL = os.getenv("TEXT_BASE_URL") or "https://api.deepseek.com/v1"
TEXT_MODEL = os.getenv("TEXT_MODEL") or "deepseek-v4-pro"

# PDF/PPTX 转图片配置
ZOOM_FACTOR = 6.0          # 分辨率倍率
JPEG_QUALITY = 75          # JPEG 压缩质量（9/12 ≈ 75%，范围 1-100）
MAX_IMAGE_SIDE = 4096      # vision API 最长边限制
MAX_IMAGE_SIZE_MB = 20     # vision API 单图大小限制（MB）


# ═══════════════════════════════════════════════════════════
# Prompt 定义
# ═══════════════════════════════════════════════════════════

VISION_PROMPT = """请仔细阅读这张图片，直接输出为结构清晰的 Markdown。

**严禁做的事情**：
- **严禁修改任何文字内容**，包括错别字、病句、数字、标点等——看到什么就输出什么
- 不要改写、扩写、或添加原文没有的内容
- 不要纠正任何你觉得"不对"的文字
- 不要删除任何内容，包括看似重复的部分——保留所有文字
- 不要添加任何说明、总结或分析

**输出格式要求**：
1. **标题**：用 # ## ### 标记明显的标题层级
2. **表格**：如果图片中有网格/多列布局，**必须**用 Markdown 表格输出
   - 表格列数必须与原图一致
   - 表格内每格的文字必须完整保留，严禁截断、省略、缩写
   - 跨行单元格用 `<br>` 换行保留全部文字
   - 不确定的列边界时，宁可多列也不要少列
3. **列表**：用 - 或 1. 标记列表项
4. **内容完整性**：每一行文字都必须出现在输出中，严禁省略任何一行

请直接输出 Markdown，不要加任何说明。"""

DOCUMENT_SUMMARIZE_PROMPT = """你是一个文档合并助手。以下是将一个文档的每一页分别转录成的 Markdown 内容。

**任务：只做两件事，不要重新组织内容**
1. 将各页内容按顺序拼接为一个完整的 Markdown 文档
2. 修正跨页时可能出现的 OCR 明显错字（如错别字、缺失标点），但**严禁改写原文意思**

**严禁做的事情：**
- 不要调整内容顺序
- 不要合并段落或改变段落结构
- 不要把分散的内容归类汇总
- 不要修改标题层级
- 不要"优化"表述或扩写缩写，保持转录的原样
- 不要删除任何内容，包括看似重复的部分——保留所有文字

请直接输出合并后的完整 Markdown 内容，不要加任何说明文字。
"""


# ═══════════════════════════════════════════════════════════
# 图片处理函数
# ═══════════════════════════════════════════════════════════

def _prepare_image_for_vision(image_path: str) -> tuple[str, str]:
    """
    准备图片用于 vision API 调用。
    - 最长边超过 MAX_IMAGE_SIDE 则等比缩放
    - 文件大小超过 MAX_IMAGE_SIZE_MB 则降低 quality
    - 返回 (base64_string, mime_type)
    """
    from PIL import Image
    import io

    img = Image.open(image_path)
    w, h = img.size
    orig_size = os.path.getsize(image_path) / (1024 * 1024)

    # 1. 检查最长边，超过则缩放
    longest = max(w, h)
    if longest > MAX_IMAGE_SIDE:
        ratio = MAX_IMAGE_SIDE / longest
        new_w = int(w * ratio)
        new_h = int(h * ratio)
        print(f"    [缩放] {w}x{h} -> {new_w}x{new_h} (最长边限制 {MAX_IMAGE_SIDE})")
        img = img.resize((new_w, new_h), Image.LANCZOS)
        w, h = new_w, new_h

    # 2. 确保 RGB 模式
    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')

    # 3. 检查并控制文件大小
    quality = JPEG_QUALITY
    while True:
        buf = io.BytesIO()
        img.save(buf, format='JPEG', quality=quality, optimize=True)
        size_mb = buf.tell() / (1024 * 1024)
        if size_mb <= MAX_IMAGE_SIZE_MB or quality <= 30:
            break
        quality -= 5
        print(f"    [压缩] quality {quality + 5}% -> {quality}% ({size_mb:.1f}MB > {MAX_IMAGE_SIZE_MB}MB)")

    image_bytes = buf.getvalue()
    b64 = base64.b64encode(image_bytes).decode()

    if quality < JPEG_QUALITY:
        print(f"    [压缩完成] 最终 {size_mb:.1f}MB, quality={quality}%")

    return b64, "image/jpeg"


def _save_pixmap_jpeg(pix, output_path: str, quality: int = JPEG_QUALITY, max_side: int = 4096) -> None:
    """用 Pillow 将 PyMuPDF Pixmap 保存为 JPEG，精确控制压缩质量，限制最长边。"""
    from PIL import Image
    tmp_path = output_path + ".tmp.png"
    try:
        pix.save(tmp_path)
        img = Image.open(tmp_path)

        # 缩放：最长边超过 max_side 则等比缩放到 max_side
        w, h = img.size
        longest = max(w, h)
        if longest > max_side:
            ratio = max_side / longest
            new_w = int(w * ratio)
            new_h = int(h * ratio)
            print(f"    [磁盘缩放] {w}x{h} -> {new_w}x{new_h} (最长边限制 {max_side})")
            img = img.resize((new_w, new_h), Image.LANCZOS)

        if img.mode in ('RGBA', 'P'):
            img = img.convert('RGB')
        img.save(output_path, format="JPEG", quality=quality, optimize=True)
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


# ═══════════════════════════════════════════════════════════
# Vision API（qwen3.6-plus 图片识别）
# ═══════════════════════════════════════════════════════════

def call_vision_api(image_path: str) -> str:
    """
    调用 qwen3.6-plus vision API 识别图片中的文字。
    启用 vl_high_resolution_images 高精度模式。
    """
    try:
        from openai import OpenAI
    except ImportError:
        raise RuntimeError("未安装 openai SDK: pip install openai")

    print(f"  [Vision] 准备图片: {os.path.basename(image_path)}")
    b64, mime_type = _prepare_image_for_vision(image_path)

    data_url = f"data:{mime_type};base64,{b64}"

    client = OpenAI(api_key=VISION_API_KEY, base_url=VISION_BASE_URL)

    print(f"  [Vision] 调用 {VISION_MODEL} 识别中...")
    completion = client.chat.completions.create(
        model=VISION_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": data_url}},
                    {"type": "text", "text": VISION_PROMPT},
                ],
            },
        ],
        extra_body={"vl_high_resolution_images": True},
        temperature=0.2,
    )

    result = completion.choices[0].message.content or ""
    print(f"  [Vision] 识别完成 ({len(result)} chars)")
    return result


def analyze_single_image(image_path: str) -> str:
    """
    分析单张图片：qwen3.6-plus vision 直接输出 Markdown。
    """
    final_md = call_vision_api(image_path)
    return final_md


# ═══════════════════════════════════════════════════════════
# 原有工具函数
# ═══════════════════════════════════════════════════════════

def find_file(file_path: str, search_base: str = None) -> str:
    """使用 find 命令查找文件的真实路径"""
    if os.path.exists(file_path):
        return file_path

    file_name = os.path.basename(file_path)
    if search_base is None:
        search_base = "/Users/fred/Documents/cc_Projects/Taishan"

    chinese_chars = re.findall(r'[\u4e00-\u9fff]+', file_name)
    patterns = []

    if chinese_chars:
        longest_chinese = max(chinese_chars, key=len)
        patterns.append(f"*{longest_chinese}*")

    file_name_no_spaces = file_name.replace(' ', '')
    patterns.append(f"*{file_name_no_spaces}*")
    patterns.append(f"*{file_name}*")

    for pattern in patterns:
        result = subprocess.run(
            ['bash', '-c', f'find "{search_base}" -name {pattern} 2>/dev/null'],
            capture_output=True,
            text=True
        )
        if result.stdout.strip():
            return result.stdout.strip().split('\n')[0].strip()

    return None


def verify_file_access(file_path: str) -> tuple[bool, int]:
    """验证文件是否可访问"""
    result = subprocess.run(
        ['bash', '-c', f'ls -la "{file_path}"'],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return False, 0

    try:
        file_size = int(result.stdout.split()[4])
        if file_size < 1024:
            print(f"警告：文件小于 1KB ({file_size} bytes)，可能是 iCloud 占位符")
            return False, file_size
        return True, file_size
    except (IndexError, ValueError):
        return False, 0


def pdf_to_images(pdf_path: str, output_dir: str, zoom: float = ZOOM_FACTOR) -> int:
    """将 PDF 转换为图片（默认 4x 分辨率，JPEG 质量 75%）"""
    real_path = find_file(pdf_path)
    if not real_path:
        print(f"错误：找不到 PDF 文件：{pdf_path}")
        return -1

    pdf_path = real_path
    is_valid, file_size = verify_file_access(pdf_path)
    if not is_valid:
        return -1

    print(f"PDF 路径：{pdf_path}")
    print(f"文件大小：{file_size / 1024:.1f}KB")

    os.makedirs(output_dir, exist_ok=True)

    try:
        doc = fitz.open(pdf_path)
        page_count = len(doc)
        print(f"PDF 页数：{page_count}")

        matrix = fitz.Matrix(zoom, zoom)

        for page_num in range(page_count):
            page = doc[page_num]
            pix = page.get_pixmap(matrix=matrix)
            output_filename = f"page_{page_num + 1:02d}.jpg"
            output_path = os.path.join(output_dir, output_filename)
            _save_pixmap_jpeg(pix, output_path)
            print(f"  [{page_num + 1:2d}/{page_count}] {output_filename}")

        doc.close()
        return page_count

    except Exception as e:
        print(f"PDF 转换失败：{e}")
        return -1


def pptx_to_images(pptx_path: str, output_dir: str) -> int:
    """将 PPTX 转换为图片（跨平台方案：LibreOffice + PyMuPDF，4x 分辨率，JPEG 质量 75%）"""
    real_path = find_file(pptx_path)
    if not real_path:
        print(f"错误：找不到 PPTX 文件：{pptx_path}")
        return -1

    pptx_path = real_path
    is_valid, file_size = verify_file_access(pptx_path)
    if not is_valid:
        return -1

    print(f"PPTX 路径：{pptx_path}")
    print(f"文件大小：{file_size / 1024:.1f}KB")

    try:
        os.makedirs(output_dir, exist_ok=True)

        print("正在使用 LibreOffice 转换 PPTX → PDF...")
        temp_pdf_dir = tempfile.mkdtemp()
        pdf_result = subprocess.run(
            ['soffice', '--headless', '--convert-to', 'pdf', pptx_path, '--outdir', temp_pdf_dir],
            capture_output=True,
            text=True,
            timeout=120
        )

        if pdf_result.returncode != 0:
            print(f"  LibreOffice 失败：{pdf_result.stderr}")
            raise Exception("LibreOffice 转换失败")

        pdf_files = [f for f in os.listdir(temp_pdf_dir) if f.endswith('.pdf')]
        if not pdf_files:
            raise Exception("未生成 PDF 文件")

        pdf_path = os.path.join(temp_pdf_dir, pdf_files[0])
        print(f"  PDF 已生成：{pdf_files[0]}")

        print("正在使用 PyMuPDF 转换 PDF → JPG...")
        doc = fitz.open(pdf_path)
        page_count = len(doc)
        print(f"  PDF 页数：{page_count}")

        for i in range(page_count):
            page = doc[i]
            pix = page.get_pixmap(matrix=fitz.Matrix(ZOOM_FACTOR, ZOOM_FACTOR))
            output_path = os.path.join(output_dir, f"page_{i+1:02d}.jpg")
            _save_pixmap_jpeg(pix, output_path)
            print(f"  已保存：page_{i+1:02d}.jpg")

        doc.close()
        shutil.rmtree(temp_pdf_dir)

        print(f"\n转换完成：{page_count} 页")
        return page_count

    except Exception as e:
        print(f"LibreOffice + PyMuPDF 方案失败：{e}，尝试备用方法...")

    return _pptx_zip_method(pptx_path, output_dir)


def _pptx_zip_method(pptx_path: str, output_dir: str) -> int:
    """备用方法：解压 PPTX 提取图片"""
    os.makedirs(output_dir, exist_ok=True)

    temp_pptx = None
    try:
        temp_fd, temp_pptx = tempfile.mkstemp(suffix='.pptx')
        os.close(temp_fd)

        subprocess.run(
            ['bash', '-c', f'cat "{pptx_path}" > "{temp_pptx}"'],
            capture_output=True
        )

        slide_images = []
        with zipfile.ZipFile(temp_pptx, 'r') as zip_ref:
            for name in zip_ref.namelist():
                if 'media' in name.lower() and name.endswith(('.png', '.jpg', '.jpeg', '.emf', '.wmf')):
                    ext = os.path.splitext(name)[1].lower()
                    if ext in ['.emf', '.wmf']:
                        ext = '.png'
                    slide_images.append((name, ext))

        if not slide_images:
            print("未找到幻灯片图片文件")
            return 0

        print(f"找到 {len(slide_images)} 个图片文件")

        with zipfile.ZipFile(temp_pptx, 'r') as zip_ref:
            for i, (slide_file, ext) in enumerate(slide_images, 1):
                try:
                    content = zip_ref.read(slide_file)
                    output_path = os.path.join(output_dir, f"page_{i:02d}{ext}")
                    with open(output_path, 'wb') as f:
                        f.write(content)
                    print(f"  已提取：page_{i:02d}{ext}")
                except Exception as e:
                    print(f"  提取失败 {slide_file}: {e}")

        return len(slide_images)

    except Exception as e:
        print(f"备用方法失败：{e}")
        return 0

    finally:
        if temp_pptx and os.path.exists(temp_pptx):
            os.remove(temp_pptx)


# ═══════════════════════════════════════════════════════════
# 图片分析核心函数（Vision + DeepSeek）
# ═══════════════════════════════════════════════════════════

def analyze_images(image_dir: str, max_workers: int = 5) -> dict[int, str]:
    """
    批量分析图片（qwen vision 识别 → deepseek 整理）。
    vision API 调用较慢，并发数不宜过高。
    """
    jpg_files = sorted([f for f in os.listdir(image_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))])

    if not jpg_files:
        print(f"错误：在 {image_dir} 中未找到图片文件")
        return {}

    print(f"找到 {len(jpg_files)} 个图片文件\n")

    results = {}

    def process_image(jpg_file: str) -> tuple[int, str]:
        image_path = os.path.join(image_dir, jpg_file)
        page_num = int(re.search(r'page_(\d+)', jpg_file).group(1))
        try:
            content = analyze_single_image(image_path)
            return page_num, content
        except Exception as e:
            print(f"分析失败 {jpg_file}: {e}")
            return page_num, None

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_image, jpg) for jpg in jpg_files]
        for future in as_completed(futures):
            page_num, content = future.result()
            if content:
                results[page_num] = content
                print(f"  已分析：page_{page_num:02d}.jpg")

    return results


def save_page_markdown(results: dict[int, str], output_dir: str) -> list[str]:
    """保存每页的 Markdown 文件"""
    os.makedirs(output_dir, exist_ok=True)
    md_files = []

    for page_num in sorted(results.keys()):
        content = results[page_num]
        md_path = os.path.join(output_dir, f"page_{page_num:02d}.md")
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(f"# page_{page_num:02d}\n\n{content}")
        md_files.append(md_path)
        print(f"  已保存：page_{page_num:02d}.md")

    return md_files


def merge_and_summarize(md_files: list[str], output_path: str) -> bool:
    """直接合并所有 Markdown 文件（不再调用 deepseek 整理）"""
    print(f"\n正在合并 {len(md_files)} 个 Markdown 文件...")

    all_content = []
    for md_path in md_files:
        with open(md_path, 'r', encoding='utf-8') as f:
            all_content.append(f.read())

    combined_text = "\n\n---\n\n".join(all_content)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(combined_text)

    print(f"已保存合并文档：{output_path}")
    return True


# ═══════════════════════════════════════════════════════════
# 主流程
# ═══════════════════════════════════════════════════════════

def doc_to_md(file_path: str) -> bool:
    """
    主流程：将 PDF 或 PPTX 转换为完整的 Markdown 文档

    视觉方案：qwen3.6-plus vision（高精度模式）→ deepseek-v4-pro 整理排版
    """
    print("=" * 60)
    print("文档转 Markdown 工具")
    print("=" * 60)

    print(f"\n[视觉分析方案]")
    print(f"  图片识别：{VISION_MODEL} @ {VISION_BASE_URL}")
    print(f"  文本整理：{TEXT_MODEL} @ {TEXT_BASE_URL}")

    real_path = find_file(file_path)
    if not real_path:
        print(f"错误：找不到文件：{file_path}")
        return False

    file_path = real_path
    file_ext = os.path.splitext(file_path)[1].lower()

    is_valid, file_size = verify_file_access(file_path)
    if not is_valid:
        return False

    file_name = os.path.splitext(os.path.basename(file_path))[0]
    base_output_dir = os.path.join(os.path.dirname(file_path), f"{file_name}_images")
    md_output_dir = os.path.join(base_output_dir, "md")
    final_output = os.path.join(os.path.dirname(file_path), f"{file_name}.md")

    print(f"\n输出目录：{base_output_dir}")

    # 步骤 1：转换为图片
    print(f"\n{'='*60}")
    print(f"步骤 1: 转换为图片（{ZOOM_FACTOR}x 分辨率，JPEG 质量 {JPEG_QUALITY}%）")
    print('='*60)

    if file_ext == '.pdf':
        page_count = pdf_to_images(file_path, base_output_dir)
    elif file_ext in ['.pptx', '.ppt']:
        page_count = pptx_to_images(file_path, base_output_dir)
    else:
        print(f"不支持的文件类型：{file_ext}")
        print("支持的格式：PDF, PPTX")
        return False

    if page_count <= 0:
        print("错误：未能转换任何页面")
        return False

    print(f"\n转换完成：{page_count} 页")

    # 步骤 2：AI 分析图片
    print(f"\n{'='*60}")
    print("步骤 2: AI 分析图片")
    print('='*60)

    results = analyze_images(base_output_dir)

    if not results:
        print("错误：AI 分析失败")
        return False

    print(f"\n分析完成：{len(results)} 页")

    # 步骤 3：保存每页 Markdown
    print(f"\n{'='*60}")
    print("步骤 3: 保存每页 Markdown")
    print('='*60)

    md_files = save_page_markdown(results, md_output_dir)

    # 步骤 4：合并并整理
    print(f"\n{'='*60}")
    print("步骤 4: 合并并 AI 整理")
    print('='*60)

    success = merge_and_summarize(md_files, final_output)

    # 清理中间文件
    if os.path.exists(base_output_dir):
        try:
            shutil.rmtree(base_output_dir)
            print(f"\n  [清理] 已删除中间文件：{base_output_dir}")
        except Exception as e:
            print(f"\n  [警告] 清理中间文件失败：{e}")

    print(f"\n{'='*60}")
    print("处理完成!")
    print(f"  最终文档：{final_output}")
    print('='*60)

    return True


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("\n用法:")
        print("  python doc2md.py <pdf_or_pptx_file>")
        print("\n示例:")
        print('  python doc2md.py "document.pdf"')
        print('  python doc2md.py "presentation.pptx"')
        sys.exit(1)

    file_path = sys.argv[1]

    try:
        success = doc_to_md(file_path)
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n处理失败：{e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
