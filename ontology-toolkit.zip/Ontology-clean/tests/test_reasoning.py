"""Sprint 2 测试：意图分类 + 推理引擎 + 回答生成"""

import json
import pytest


# === Intent Classification Tests ===

@pytest.mark.asyncio
async def test_classify_entity_info():
    """测试实体查询意图"""
    from backend.reasoning.intent import classify_intent
    result = await classify_intent("九峰医疗有哪些产品？")
    assert result["intent"] == "entity_info"
    assert "九峰医疗" in str(result.get("entities", []))


@pytest.mark.asyncio
async def test_classify_relation_query():
    """测试关系查询意图"""
    from backend.reasoning.intent import classify_intent
    result = await classify_intent("肺结核AI软件属于哪个公司？")
    assert result["intent"] in ("relation_query", "entity_info")


@pytest.mark.asyncio
async def test_classify_scenario():
    """测试场景查询意图"""
    from backend.reasoning.intent import classify_intent
    result = await classify_intent("5G+AI预警平台用在什么场景？")
    assert result["intent"] == "scenario"


@pytest.mark.asyncio
async def test_classify_comparison():
    """测试比较意图"""
    from backend.reasoning.intent import classify_intent
    result = await classify_intent("九峰医疗和竞品相比有什么优势？")
    assert result["intent"] == "comparison"


@pytest.mark.asyncio
async def test_classify_prep():
    """测试拜访准备意图"""
    from backend.reasoning.intent import classify_intent
    result = await classify_intent("帮我准备拜访基层医院的材料")
    assert result["intent"] == "prep"


@pytest.mark.asyncio
async def test_classify_objection():
    """测试异议处理意图"""
    from backend.reasoning.intent import classify_intent
    result = await classify_intent("客户说你们的系统太贵了怎么回应？")
    assert result["intent"] == "objection"


@pytest.mark.asyncio
async def test_classify_general():
    """测试一般性问题"""
    from backend.reasoning.intent import classify_intent
    result = await classify_intent("你好")
    assert result["intent"] == "general"


# === Reasoning Engine Tests ===

@pytest.mark.asyncio
async def test_engine_find_entities_by_name(db_session):
    """测试通过名称查找实体"""
    from backend.ontology.crud import ensure_default_types, create_object
    from backend.reasoning.engine import ReasoningEngine

    await ensure_default_types(db_session)
    await create_object(db_session, "Company", "测试公司", {})
    await db_session.commit()

    engine = ReasoningEngine(db_session)
    results = await engine.find_entities(["测试公司"])
    assert len(results) > 0
    assert results[0]["name"] == "测试公司"


@pytest.mark.asyncio
async def test_engine_gather_context(db_session):
    """测试上下文收集"""
    from backend.ontology.crud import ensure_default_types, create_object, create_link
    from backend.reasoning.engine import ReasoningEngine

    await ensure_default_types(db_session)
    await create_object(db_session, "Company", "公司A", {})
    await create_object(db_session, "Product", "产品B", {})
    await db_session.commit()
    await create_link(db_session, "公司A", "产品B", "produces")
    await db_session.commit()

    engine = ReasoningEngine(db_session)
    context = await engine.gather_context(["公司A"], intent="entity_info")
    assert "entities" in context
    assert len(context["entities"]) >= 1


@pytest.mark.asyncio
async def test_engine_multi_hop(db_session):
    """测试多跳推理"""
    from backend.ontology.crud import ensure_default_types, create_object, create_link
    from backend.reasoning.engine import ReasoningEngine

    await ensure_default_types(db_session)
    await create_object(db_session, "Company", "公司A", {})
    await create_object(db_session, "Product", "产品B", {})
    await create_object(db_session, "Certification", "认证C", {})
    await db_session.commit()
    await create_link(db_session, "公司A", "产品B", "produces")
    await create_link(db_session, "产品B", "认证C", "certified_for")
    await db_session.commit()

    engine = ReasoningEngine(db_session)
    context = await engine.gather_context(["公司A"], intent="entity_info", max_hops=2)
    assert len(context["entities"]) >= 2


# === Response Generator Tests ===

@pytest.mark.asyncio
async def test_generate_response():
    """测试回答生成"""
    from backend.reasoning.response import generate_response

    question = "九峰医疗有哪些产品？"
    context = {
        "entities": [
            {"name": "九峰医疗", "type": "Company"},
            {"name": "肺结核AI软件", "type": "Product"},
            {"name": "5G+AI预警平台", "type": "Product"},
        ],
        "relations": [
            {"source": "九峰医疗", "target": "肺结核AI软件", "type": "produces"},
            {"source": "九峰医疗", "target": "5G+AI预警平台", "type": "produces"},
        ],
    }

    result = await generate_response(question, context)
    assert result["answer"]
    assert len(result["answer"]) > 20
    assert "evidence" in result


# === Chat API Tests ===

def test_chat_endpoint_exists():
    """测试 chat router 已注册"""
    from backend.api.chat import router
    assert router is not None
