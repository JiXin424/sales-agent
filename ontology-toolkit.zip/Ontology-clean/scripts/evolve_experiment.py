"""自进化实验：对比不同实体匹配策略

实验目标：减少"信息不足"的回答数量，提高回答质量分数。

假设：
- H1: 关键词拆分匹配 (entity_name 分词后 OR 匹配)
- H2: 向量相似度回退 (名称匹配失败时用 embedding 搜索)
- H3: 两者结合

基线 (Baseline): 当前 ILIKE 模糊匹配
"""

import asyncio
import json
import time
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import select, text
from backend.db import engine, async_session
from backend.ontology.models import Base, Object
from backend.ontology.crud import ensure_default_types
from backend.document.pipeline import process_document


# 测试问题 (选择基线测试中回答"信息不足"的问题)
PROBLEM_QUESTIONS = [
    "九峰医疗有哪些产品？",
    "肺结核AI软件属于哪个公司？",
    "哪些产品获得了资质认证？",
    "九峰医疗的产品面向哪些客户？",
    "5G+AI预警平台用在什么场景？",
    "肺结核AI软件解决什么问题？",
    "帮我准备拜访基层医院的材料",
    "客户说你们的系统太贵了怎么回应？",
]


async def find_entities_baseline(names: list, session) -> list:
    """基线: 当前 ILIKE 匹配"""
    from sqlalchemy import or_
    stmt = select(Object).where(or_(*[Object.name.ilike(f"%{n}%") for n in names]))
    return (await session.execute(stmt)).scalars().all()


async def find_entities_h1(names: list, session) -> list:
    """H1: 关键词拆分 — 每个实体名拆成2-4字的关键词"""
    from sqlalchemy import or_
    import re

    keywords = []
    for name in names:
        # 拆分实体名为2-4字关键词
        if len(name) >= 4:
            keywords.append(name)
            keywords.append(name[:4])
            keywords.append(name[-4:])
        else:
            keywords.append(name)
        # 也保留原词
        keywords.append(name)

    stmt = select(Object).where(or_(*[Object.name.ilike(f"%{kw}%") for kw in keywords]))
    return (await session.execute(stmt)).scalars().all()


async def find_entities_h2(names: list, session) -> list:
    """H2: 名称匹配 + 向量搜索回退"""
    # 先尝试名称匹配
    baseline = await find_entities_baseline(names, session)
    if len(baseline) >= 2:
        return baseline

    # 回退到向量搜索
    from backend.llm import embed
    from backend.ontology.embedding import search_similar

    try:
        query = " ".join(names)
        query_embedding = (await embed([query]))[0]
        results = await search_similar(session, query_embedding, limit=5)
        return results
    except Exception:
        return baseline


async def find_entities_h3(names: list, session) -> list:
    """H3: H1 + H2 结合"""
    # 先用关键词匹配
    h1 = await find_entities_h1(names, session)
    if len(h1) >= 2:
        return h1

    # 回退到向量搜索
    from backend.llm import embed
    from backend.ontology.embedding import search_similar

    try:
        query = " ".join(names)
        query_embedding = (await embed([query]))[0]
        results = await search_similar(session, query_embedding, limit=5)
        # 合并去重
        existing_ids = {o.id for o in h1}
        combined = list(h1)
        for r in results:
            if r.id not in existing_ids:
                combined.append(r)
                existing_ids.add(r.id)
        return combined
    except Exception:
        return h1


async def run_experiment():
    """运行对比实验"""
    print("=== 自进化实验：实体匹配策略对比 ===\n")

    # 准备数据
    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)

    async with async_session() as session:
        await ensure_default_types(session)

        test_file = "/Users/fred/Documents/cc_Projects/Taishan/一期库/九峰/raw/九峰_公司产品/九峰_公司介绍_20250520_v1_方铭.docx"
        result = await process_document(test_file, session)
        await session.commit()
        print(f"数据准备: {result['objects_count']} 实体, {result['links_count']} 关系\n")

    # 加载全部实体名作为参考
    async with async_session() as session:
        all_objects = (await session.execute(select(Object))).scalars().all()
        print(f"数据库中实体: {len(all_objects)}")
        for obj in all_objects:
            print(f"  [{obj.type_id}] {obj.name}")
        print()

    # 运行每个策略
    strategies = {
        "Baseline (ILIKE)": find_entities_baseline,
        "H1 (关键词拆分)": find_entities_h1,
        "H2 (向量回退)": find_entities_h2,
        "H3 (H1+H2)": find_entities_h3,
    }

    # 模拟意图分类返回的实体名
    test_cases = [
        {"question": "九峰医疗有哪些产品？", "entities": ["九峰医疗", "产品"]},
        {"question": "肺结核AI软件属于哪个公司？", "entities": ["肺结核AI软件"]},
        {"question": "哪些产品获得了资质认证？", "entities": ["资质", "认证"]},
        {"question": "5G+AI预警平台用在什么场景？", "entities": ["5G+AI预警平台", "场景"]},
        {"question": "肺结核AI软件解决什么问题？", "entities": ["肺结核AI软件"]},
        {"question": "帮我准备拜访基层医院的材料", "entities": ["基层医院"]},
    ]

    for name, strategy in strategies.items():
        print(f"\n--- {name} ---")
        total_hits = 0

        async with async_session() as session:
            for tc in test_cases:
                entities = tc["entities"]
                results = await strategy(entities, session)
                hit = len(results)
                total_hits += hit
                names = [r.name if hasattr(r, 'name') else str(r) for r in results]
                print(f"  Q: {tc['question'][:30]:30s} | 实体: {entities} | 命中: {hit} → {names[:3]}")

        print(f"  总命中: {total_hits}")

    await engine.dispose()
    print("\n=== 实验结束 ===")


if __name__ == "__main__":
    asyncio.run(run_experiment())
