#!/usr/bin/env python3
"""LLM 关键词提取器

用 DeepSeek 从用户长查询 + 多轮历史中提炼 3-5 个核心搜索词，
喂给知识图谱引擎的 Layer 3 多词匹配。

知识库类型段（原则/概念/术语/策略/场景/客户）从本体库动态生成，
保证提示词与本体保持一致。
"""

import os
import json
from functools import lru_cache

import openai

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
KEYWORD_MODEL = "deepseek-chat"

# === 精选术语清单（手工筛选自 influence_ontology_enriched.json + synonyms.json）===
# 设计原则：去掉描述性的、过长的 name，只保留用户查询时最可能用到的核心术语
CURATED_PRINCIPLES = [
    '互惠原理', '稀缺原理', '权威原理', '对比原理',
    '承诺和一致原理', '承诺原理', '社会认同原理', '喜好原理',
    '价格质量原理', '心理逆反', '维特效应',
]

CURATED_CONCEPTS = [
    '互惠式让步', '互惠帮助', '亏欠感', '自动影响力',
    '稀缺价值', '稀缺性与物品价值', '信息稀缺', '对稀缺资源的竞争',
    '新出现的稀缺', '潜在损失', '潜在收益', '自由限制',
    '多元无知现象', '社会认同', '权威象征', '服从权威',
    '光环效应', '关联原理', '固定行为模式', '捷径响应',
    '自动保持一致', '死脑筋地保持一致', '公开承诺', '书面承诺',
    '口头承诺', '登门槛技巧', '抛低球手法',
]

CURATED_TERMS = [
    '互惠', '承诺', '一致性', '权威', '稀缺', '象征',
    '拒绝—后撤术', '接受的义务', '登门槛', '抛低球',
    '拍卖', '午宴术', '顺从技巧', '言行一致',
    '自我形象', '珍贵的错误', '罗密欧与朱丽叶效应',
]

CURATED_TACTICS = [
    '拒绝—后撤术', '互惠可信度策略', '稀缺促销策略', '对比销售策略',
    '提价销售策略', '登门槛策略', '公开承诺策略', '抛低球策略',
    '数量有限策略', '最后期限战术', '利用社会认同策略',
    '减少不确定性策略', '先建立关系再谈需求策略',
    '先给予价值降低戒备策略', '获取小承诺推进下一步策略',
    '高管对齐策略', '内部资源稀缺推动优先级策略',
    '权威象征运用策略', '诱导承诺策略',
]

CURATED_SCENARIOS = [
    '价格异议', '初次拜访', '客户拖延', '建立信任',
    '推进成交', '关系维护', '冷漠客户', '制造紧迫感',
    '丢单挽回', '竞品对比', '客户犹豫', '拒绝处理',
    '讨价还价', '老客户复购', '成交后跟进',
]

CURATED_CUSTOMERS = [
    'ToB 决策者', 'ToC 消费者', '大客户', '新客户',
    '老客户', '冷漠客户', '犹豫客户',
]

CURATED_ACTIONS = [
    '应对', '建立', '推进', '制造', '提升', '降低',
    '说服', '引导', '激发', '强化',
]


@lru_cache(maxsize=1)
def _build_kb_overview():
    """构建知识库类型概览段（Markdown 格式）"""
    sections = [
        ('核心原则', CURATED_PRINCIPLES),
        ('核心概念', CURATED_CONCEPTS),
        ('专业术语', CURATED_TERMS),
        ('策略方法', CURATED_TACTICS),
        ('核心场景（现代销售）', CURATED_SCENARIOS),
        ('客户类型与行为', CURATED_CUSTOMERS + CURATED_ACTIONS),
    ]
    lines = ["## 知识库类型（你提炼的词应该尽量能映射到这些类型，每类按重要性排列）", ""]
    for label, items in sections:
        lines.append(f"- **{label}**：{' / '.join(items)}")
    return "\n".join(lines)


@lru_cache(maxsize=1)
def _get_system_prompt():
    """组装完整系统提示词（首次调用时构建并缓存）"""
    kb_overview = _build_kb_overview()
    return f"""你是销售影响力知识库的检索关键词提取助手。

## 你的任务

从用户的销售问题（可能很长、可能含历史对话）中，提炼出 3-5 个最关键的搜索词，
用于在《影响力》知识库中检索相关知识。

{kb_overview}

## 提炼规则

1. **只输出关键词本身**，每词一行，不要序号、不要解释、不要标点
2. **3-5 个**，宁少勿多，宁精勿泛
3. **优先标准术语**：能用"价格异议"就别用"嫌贵"，能用"互惠原理"就别用"互惠"
4. **合并同义**：用户说"客户嫌贵、预算紧、能不能便宜"合并为"价格异议"
5. **抓住核心意图**：长输入里找出真正的诉求（是问原理？问策略？问话术？）
6. **历史信息**：如果用户当前问题简短但历史里有上下文，把历史里的关键要素也提炼进来
7. **覆盖多维**：尽量覆盖"原则 + 场景 + 策略/话术"三个维度，便于知识图谱多跳扩展

## 输出格式（严格遵守）

只输出关键词，每词一行，例如：

价格异议
对比原理
说服策略
话术

## 示例

**示例 1**
用户问题：客户嫌贵怎么办
输出：
价格异议
对比原理
说服策略

**示例 2**
用户问题：我今天去拜访一个制造业的客户，初次见面，对方说我们产品比竞品贵 30%，他预算只有 50 万，怎么用对比原理说服他接受我们的价格？
输出：
初次拜访
价格异议
对比原理
说服策略

**示例 3**
历史对话：
用户：什么是互惠原理
助手：互惠原理是…
用户：那这个原理怎么用到客户初次拜访上？
输出：
互惠原理
初次拜访
建立信任
互惠可信度策略

**示例 4**
用户问题：客户拖延说再考虑考虑，怎么用稀缺原理制造紧迫感推进成交？
输出：
客户拖延
稀缺原理
制造紧迫感
推进成交
稀缺促销策略

现在请提取下面这个销售问题的关键搜索词。
"""


def _build_user_message(query, history=None):
    """构造 user 消息：含历史和当前问题"""
    parts = []
    if history:
        parts.append("历史对话：")
        for h in history[-3:]:
            role = h.get('role', '')
            content = h.get('content', '').strip()
            if not content:
                continue
            label = '用户' if role == 'user' else '助手'
            parts.append(f"{label}：{content}")
        parts.append("")
        parts.append(f"当前问题：{query}")
    else:
        parts.append(f"用户问题：{query}")
    return "\n".join(parts)


def extract_with_llm(query, history=None, timeout=10):
    """用 LLM 提取关键词。失败返回 None（调用方自己兜底）。"""
    if not DEEPSEEK_API_KEY:
        return None
    try:
        client = openai.OpenAI(
            api_key=DEEPSEEK_API_KEY,
            base_url=DEEPSEEK_BASE_URL,
            timeout=timeout,
        )
        response = client.chat.completions.create(
            model=KEYWORD_MODEL,
            messages=[
                {"role": "system", "content": _get_system_prompt()},
                {"role": "user", "content": _build_user_message(query, history)},
            ],
            temperature=0,
            max_tokens=100,
            stream=False,
        )
        raw = response.choices[0].message.content.strip()
        keywords = [line.strip() for line in raw.split('\n') if line.strip()]
        keywords = [k for k in keywords if 1 < len(k) <= 20]
        return keywords[:5] if keywords else None
    except Exception as e:
        print(f"[keyword_extractor] LLM 调用失败: {e}")
        return None


def extract_with_fallback(query):
    """LLM 失败时的兜底：基础关键词切分（不带 AI）"""
    import re
    clean = re.sub(r'[，。？！；：""''（）、.\?\!\;\:\(\)]', '', query)
    stop = {'的', '了', '是', '我', '有', '和', '就', '不', '人', '都',
            '一', '个', '在', '你', '会', '着', '吗', '呢', '吧', '啊',
            '这', '那', '什么', '怎么', '如何', '怎样', '客户', '问题'}
    result = []
    for length in range(4, 1, -1):
        for i in range(len(clean) - length + 1):
            w = clean[i:i + length]
            if w not in stop and w not in result:
                result.append(w)
                if len(result) >= 5:
                    return result
    return result


def extract(query, history=None):
    """统一入口：先 LLM，失败回退。返回 (keywords, source)"""
    kws = extract_with_llm(query, history)
    if kws:
        return kws, 'llm'
    return extract_with_fallback(query), 'fallback'


if __name__ == '__main__':
    import sys
    args = sys.argv[1:]
    q = args[0] if args else "客户嫌贵怎么办"
    print(f"=== 测试 query: {q} ===\n")
    print("--- 系统提示词 ---")
    print(_get_system_prompt())
    print("\n--- user 消息 ---")
    print(_build_user_message(q))
    print("\n--- 提取结果 ---")
    result, source = extract(q)
    print(f"source: {source}")
    print(f"keywords: {result}")
