"""SSE 流式对话 API — 逐 token 推送回答"""

import json
import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.responses import StreamingResponse

from backend.db import async_session
from backend.reasoning.intent import classify_intent
from backend.reasoning.engine import ReasoningEngine
from backend.reasoning.response import generate_response

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/chat", tags=["chat-stream"])


class ChatStreamRequest(BaseModel):
    question: str


async def get_session():
    async with async_session() as session:
        yield session


def _sse_event(event: str, data: dict) -> str:
    """格式化单个 SSE 事件"""
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


@router.post("/stream")
async def chat_stream(
    request: ChatStreamRequest, session: AsyncSession = Depends(get_session)
):
    """流式知识问答 — SSE 逐 token 推送"""
    question = request.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="问题不能为空")

    async def event_generator():
        # 1. 意图分类
        intent_result = await classify_intent(question)
        logger.info(f"[stream] 意图分类: {intent_result}")

        yield _sse_event("intent", {
            "intent": intent_result["intent"],
            "entities": intent_result.get("entities", []),
        })

        if intent_result["intent"] == "general":
            yield _sse_event("token", {"content": "您好！我是销售知识助手，可以回答关于产品、客户、竞品等问题。"})
            yield _sse_event("done", {"confidence": 1.0})
            return

        # 2. 推理引擎收集上下文
        engine = ReasoningEngine(session)
        context = await engine.reason(question, intent_result)

        # 3. 生成回答
        use_flash = intent_result["intent"] in ("entity_info", "scenario")
        response = await generate_response(question, context, intent=intent_result["intent"], use_flash=use_flash)

        # 4. 逐句推送（按标点拆分模拟流式效果）
        answer = response.get("answer", "")
        # 将回答按句号/问号/感叹号/换行拆成片段
        chunks = _split_answer(answer)

        for chunk in chunks:
            yield _sse_event("token", {"content": chunk})

        # 5. 发送完成事件，附带元数据
        yield _sse_event("done", {
            "intent": intent_result["intent"],
            "entities": intent_result.get("entities", []),
            "evidence": response.get("evidence", []),
            "confidence": response.get("confidence", 0.5),
        })

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


def _split_answer(text: str) -> list[str]:
    """将回答按句子拆分，用于模拟流式推送"""
    if not text:
        return []

    import re
    # 按中文标点和换行拆分，保留分隔符
    parts = re.split(r"([。！？\n；])", text)
    chunks = []
    for i in range(0, len(parts) - 1, 2):
        chunk = parts[i] + (parts[i + 1] if i + 1 < len(parts) else "")
        if chunk.strip():
            chunks.append(chunk)
    # 处理末尾无标点的尾部
    if len(parts) % 2 == 1 and parts[-1].strip():
        chunks.append(parts[-1])

    return chunks if chunks else [text]
