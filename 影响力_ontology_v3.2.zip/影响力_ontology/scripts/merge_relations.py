#!/usr/bin/env python3
"""影响力本体 - 合并补充关系到本体

功能：
1. 加载候选关系
2. 去重（避免与现有关系重复）
3. 合并到本体
4. 生成统计报告
"""

import json
from pathlib import Path
from typing import List, Dict, Set

# 配置
ONTOLOGY_PATH = Path(__file__).parent.parent / "influence_ontology_enriched.json"
CANDIDATES_PATH = Path(__file__).parent.parent / "relations_supplemented.json"
OUTPUT_PATH = Path(__file__).parent.parent / "influence_ontology_with_relations.json"

class RelationMerger:
    """关系合并器"""

    def __init__(self, ontology_path: Path, candidates_path: Path):
        self.ontology_path = ontology_path
        self.candidates_path = candidates_path
        self.ontology = None
        self.candidates = None

    def load_data(self):
        """加载本体和候选关系"""
        print(f"📖 加载本体: {self.ontology_path}")
        with open(self.ontology_path, 'r', encoding='utf-8') as f:
            self.ontology = json.load(f)

        print(f"📖 加载候选关系: {self.candidates_path}")
        with open(self.candidates_path, 'r', encoding='utf-8') as f:
            self.candidates = json.load(f)

        print(f"✅ 本体关系数: {len(self.ontology.get('relations', []))}")
        print(f"✅ 候选关系数: {len(self.candidates)}")

    def get_existing_relation_keys(self) -> Set[str]:
        """获取现有关系的唯一键集合"""
        existing = set()
        for rel in self.ontology.get('relations', []):
            # 用(from_id, to_id, relation_type)作为唯一键
            key = (rel['from_id'], rel['to_id'], rel['relation_type'])
            existing.add(key)
        return existing

    def deduplicate_candidates(self, existing_keys: Set[str]) -> List[Dict]:
        """去重候选关系"""
        print("\n🔍 去重候选关系...")

        unique_candidates = []
        duplicate_count = 0

        for candidate in self.candidates:
            key = (candidate['from_id'], candidate['to_id'], candidate['relation_type'])

            if key not in existing_keys:
                unique_candidates.append(candidate)
                existing_keys.add(key)  # 避免候选关系内部重复
            else:
                duplicate_count += 1

        print(f"   去重后: {len(unique_candidates)} 个")
        print(f"   重复: {duplicate_count} 个")

        return unique_candidates

    def merge(self):
        """合并关系到本体"""
        # 加载数据
        self.load_data()

        # 获取现有关系键
        existing_keys = self.get_existing_relation_keys()

        # 去重
        unique_candidates = self.deduplicate_candidates(existing_keys)

        if not unique_candidates:
            print("\n⚠️  没有新关系需要合并")
            return

        # 合并
        print("\n🔗 合并关系到本体...")
        self.ontology.setdefault('relations', []).extend(unique_candidates)
        print(f"✅ 合并完成")

        # 保存
        print(f"\n💾 保存到: {OUTPUT_PATH}")
        with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
            json.dump(self.ontology, f, ensure_ascii=False, indent=2)

        # 统计
        self.show_statistics(unique_candidates)

    def show_statistics(self, new_relations: List[Dict]):
        """显示统计信息"""
        print("\n📊 关系统计:\n")

        # 按类型统计
        rel_types = {}
        for rel in new_relations:
            rel_type = rel['relation_type']
            rel_types[rel_type] = rel_types.get(rel_type, 0) + 1

        print("新增关系类型:")
        for rel_type, count in sorted(rel_types.items(), key=lambda x: x[1], reverse=True):
            print(f"  {rel_type}: {count}")

        print(f"\n总计: {len(new_relations)} 个新关系")
        print(f"原有关系: {len(self.ontology.get('relations', [])) - len(new_relations)} 个")
        print(f"现有关系: {len(self.ontology.get('relations', []))} 个")

        # 置信度分布
        confidences = [rel['confidence'] for rel in new_relations if 'confidence' in rel]
        if confidences:
            avg_confidence = sum(confidences) / len(confidences)
            max_confidence = max(confidences)
            min_confidence = min(confidences)

            print(f"\n置信度统计:")
            print(f"  平均: {avg_confidence:.2f}")
            print(f"  最高: {max_confidence:.2f}")
            print(f"  最低: {min_confidence:.2f}")

def main():
    """主函数"""
    print("=" * 60)
    print("影响力本体 - 合并补充关系到本体")
    print("=" * 60)

    merger = RelationMerger(ONTOLOGY_PATH, CANDIDATES_PATH)
    merger.merge()

    print("\n✅ 完成!")
    print(f"\n📝 下一步:")
    print(f"1. 检查 {OUTPUT_PATH}")
    print(f"2. 替换原文件: mv {OUTPUT_PATH} {ONTOLOGY_PATH}")
    print(f"3. 重启服务验证")

if __name__ == '__main__':
    main()
