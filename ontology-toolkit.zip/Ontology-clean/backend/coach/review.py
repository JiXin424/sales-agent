"""访后复盘 — 分析拜访记录，提取要点和行动项"""

import json
import logging

from sqlalchemy.ext.asyncio import AsyncSession

from backend.llm import chat_pro
from backend.reasoning.engine import ReasoningEngine

logger = logging.getLogger(__name__)

REVIEW_PROMPT = """你是资深销售教练，分析拜访记录并给出复盘建议。

拜访记录：
{notes}

已知产品知识：
{context}

请分析：
1. 拜访摘要（3句话）
2. 客户反馈亮点
3. 客户疑虑/异议
4. 下一步行动项
5. 知识缺口（需要补充哪些信息）
6. 改进建议

输出 JSON：
{{"summary": "拜访摘要", "highlights": ["亮点1", "亮点2"], "concerns": ["疑虑1"], "action_items": [{{"action": "行动", "priority": "high/medium/low", "deadline": "建议时间"}}], "knowledge_gaps": ["缺口1"], "improvement_suggestions": ["建议1"]}}"""


async def analyze_visit(visit_notes: str, session: AsyncSession) -> dict:
    """分析拜访记录"""
    if not visit_notes.strip():
        return {"error": "拜访记录不能为空"}

    # 收集所有知识作为背景
    engine = ReasoningEngine(session)
    context_data = await engine.gather_context(["九峰医疗"], intent="prep")

    entities = json.dumps(
        [{"name": e["name"], "type": e["type"]} for e in context_data.get("entities", [])],
        ensure_ascii=False,
    )

    prompt = REVIEW_PROMPT.format(
        notes=visit_notes,
        context=entities,
    )

    result_text = await chat_pro(
        messages=[{"role": "user", "content": prompt}],
        max_tokens=3000,
        response_format={"type": "json_object"},
    )

    try:
        result = json.loads(result_text)
    except json.JSONDecodeError:
        result = {
            "summary": result_text,
            "highlights": [],
            "concerns": [],
            "action_items": [],
            "knowledge_gaps": [],
            "improvement_suggestions": [],
        }

    return {
        "summary": result.get("summary", ""),
        "highlights": result.get("highlights", []),
        "concerns": result.get("concerns", []),
        "action_items": result.get("action_items", []),
        "knowledge_gaps": result.get("knowledge_gaps", []),
        "improvement_suggestions": result.get("improvement_suggestions", []),
    }
