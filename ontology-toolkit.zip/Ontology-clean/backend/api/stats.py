"""统计 API — 仪表盘数据端点"""

import logging
import time

from fastapi import APIRouter, Depends
from sqlalchemy import select, func, text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.db import async_session, engine
from backend.ontology.models import Object, ObjectType, Document

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/stats", tags=["stats"])


async def get_session():
    async with async_session() as session:
        yield session


@router.get("/entities")
async def entity_stats(session: AsyncSession = Depends(get_session)):
    """实体统计：总数、按类型分布、近期趋势"""
    # 按类型统计
    type_stats = await session.execute(
        select(ObjectType.name, func.count(Object.id))
        .join(Object, Object.type_id == ObjectType.id, isouter=True)
        .group_by(ObjectType.name)
    )
    by_type = {name: count for name, count in type_stats.all()}

    # 总数
    total = await session.execute(select(func.count(Object.id)))
    total_count = total.scalar() or 0

    # 近 7 天新增趋势
    trend = await session.execute(
        select(
            func.date_trunc("day", Object.created_at).label("day"),
            func.count(Object.id).label("count"),
        )
        .where(Object.created_at >= func.now() - text("interval '7 days'"))
        .group_by(func.date_trunc("day", Object.created_at))
        .order_by(text("day"))
    )
    recent_trend = [
        {"date": str(day), "count": count}
        for day, count in trend.all()
    ]

    return {
        "total": total_count,
        "by_type": by_type,
        "recent_trend": recent_trend,
    }


@router.get("/queries")
async def query_stats(session: AsyncSession = Depends(get_session)):
    """查询分析统计（预留，后续接入反馈表）"""
    # TODO: 待 feedback 表创建后实现真实统计
    return {
        "total_queries": 0,
        "avg_confidence": 0.0,
        "intent_distribution": {},
        "note": "查询统计功能待反馈数据表建成后启用",
    }


@router.get("/system")
async def system_stats(session: AsyncSession = Depends(get_session)):
    """系统健康状态"""
    # DB 连通性检测
    db_ok = True
    db_latency_ms = 0.0
    try:
        start = time.monotonic()
        await session.execute(text("SELECT 1"))
        db_latency_ms = round((time.monotonic() - start) * 1000, 1)
    except Exception as e:
        logger.error(f"DB health check failed: {e}")
        db_ok = False

    # 文档统计
    doc_count = 0
    if db_ok:
        result = await session.execute(select(func.count(Document.id)))
        doc_count = result.scalar() or 0

    return {
        "database": {
            "status": "ok" if db_ok else "error",
            "latency_ms": db_latency_ms,
        },
        "documents": {
            "total": doc_count,
        },
        "api": {
            "status": "ok",
        },
    }


@router.get("/costs")
async def cost_stats(session: AsyncSession = Depends(get_session)):
    """预估成本追踪"""
    # 基于已处理文档数量估算成本
    doc_result = await session.execute(select(func.count(Document.id)))
    doc_count = doc_result.scalar() or 0

    obj_result = await session.execute(select(func.count(Object.id)))
    obj_count = obj_result.scalar() or 0

    # 粗略估算：每篇文档处理约 ¥0.5（含解析+LLM抽取+embedding）
    processing_cost_per_doc = 0.5
    # 每次对话约 ¥0.1（含意图分类+推理+回答生成）
    query_cost_per_call = 0.1

    estimated_processing_cost = round(doc_count * processing_cost_per_doc, 2)
    estimated_total = estimated_processing_cost  # 对话成本后续接入反馈表后累加

    return {
        "documents_processed": doc_count,
        "entities_extracted": obj_count,
        "estimated_processing_cost": estimated_processing_cost,
        "cost_breakdown": {
            "document_processing": estimated_processing_cost,
            "query_handling": 0.0,  # 待接入对话记录后计算
        },
        "estimated_total": estimated_total,
        "currency": "CNY",
        "note": "成本为粗略估算，实际以云服务商账单为准",
    }
