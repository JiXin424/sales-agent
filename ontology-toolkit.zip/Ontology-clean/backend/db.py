"""PostgreSQL + PGVector 连接封装"""

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy import text

from backend.config import DATABASE_URL

engine = create_async_engine(DATABASE_URL, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def get_db() -> AsyncSession:
    """FastAPI 依赖注入用"""
    async with async_session() as session:
        yield session


async def ensure_pgvector(conn) -> None:
    """确保 PGVector 扩展已安装"""
    await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
