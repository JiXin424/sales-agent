"""V4: 验证 AFC2md 文档解析质量"""

import subprocess
import sys
import os

AFC2MD_DIR = "/Users/fred/Documents/cc_Projects/Taishan/api-software/AFC2md"
RAW_DIR = "/Users/fred/Documents/cc_Projects/Taishan/一期库/九峰/raw"

# 挑选 3 份代表性文档
TEST_FILES = [
    ("九峰_公司产品", "九峰_公司介绍_20250520_v1_方铭.docx"),
    ("九峰_公司产品", "九峰_产品定价表_20260213_v1_方铭.pdf"),
    ("九峰_公司产品", "九峰_肺结核X射线辅助评估软件技术参数_20260213_v1_方铭.docx"),
]


def convert_file(subdir: str, filename: str) -> str | None:
    """用 AFC2md 转换单个文件"""
    file_path = os.path.join(RAW_DIR, subdir, filename)
    ext = os.path.splitext(filename)[1].lower()

    script = {
        ".docx": "docx2md.py",
        ".pdf": "docx2md.py",
        ".doc": "doc97tomd.py",
        ".xlsx": "xlsx2md.py",
    }.get(ext)

    if not script:
        print(f"  ⚠️ 不支持的格式: {ext}")
        return None

    script_path = os.path.join(AFC2MD_DIR, script)
    if not os.path.exists(script_path):
        print(f"  ⚠️ 脚本不存在: {script_path}")
        return None

    result = subprocess.run(
        [sys.executable, script_path, file_path],
        capture_output=True,
        text=True,
        cwd=AFC2MD_DIR,
        timeout=120,
    )

    if result.returncode != 0:
        print(f"  ❌ 转换失败: {result.stderr[:200]}")
        return None

    return result.stdout


def main():
    print("V4: 验证 AFC2md 文档解析质量\n")

    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "test_output")
    os.makedirs(output_dir, exist_ok=True)

    for subdir, filename in TEST_FILES:
        print(f"转换: {filename}")
        md_content = convert_file(subdir, filename)

        if md_content:
            out_name = os.path.splitext(filename)[0] + ".md"
            out_path = os.path.join(output_dir, out_name)
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(md_content)

            lines = md_content.split("\n")
            headings = [l for l in lines if l.startswith("#")]
            print(f"  ✅ 输出 {len(md_content)} 字符, {len(lines)} 行, {len(headings)} 个标题")
            for h in headings[:5]:
                print(f"     {h}")
            if len(headings) > 5:
                print(f"     ... 还有 {len(headings) - 5} 个标题")
        print()

    print(f"输出目录: {output_dir}")
    print("✅ AFC2md 验证完成（请人工检查输出质量）")


if __name__ == "__main__":
    main()
