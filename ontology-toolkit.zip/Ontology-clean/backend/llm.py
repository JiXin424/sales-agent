"""统一 LLM 调用封装 — DeepSeek + 阿里云"""

from openai import AsyncOpenAI

from backend.config import (
    DEEPSEEK_API_KEY,
    DEEPSEEK_BASE_URL,
    DEEPSEEK_MODEL_PRO,
    DEEPSEEK_MODEL_FLASH,
    DASHSCOPE_API_KEY,
    DASHSCOPE_BASE_URL,
    DASHSCOPE_EMBEDDING_MODEL,
    DASHSCOPE_EMBEDDING_DIM,
)


def get_deepseek_client() -> AsyncOpenAI:
    return AsyncOpenAI(api_key=DEEPSEEK_API_KEY, base_url=DEEPSEEK_BASE_URL)


def get_dashscope_client() -> AsyncOpenAI:
    return AsyncOpenAI(api_key=DASHSCOPE_API_KEY, base_url=DASHSCOPE_BASE_URL)


async def chat_pro(messages: list[dict], **kwargs) -> str:
    """调用 DeepSeek Pro 模型（复杂推理）"""
    client = get_deepseek_client()
    resp = await client.chat.completions.create(
        model=DEEPSEEK_MODEL_PRO,
        messages=messages,
        **kwargs,
    )
    return resp.choices[0].message.content


async def chat_flash(messages: list[dict], **kwargs) -> str:
    """调用 DeepSeek Flash 模型（快速任务）"""
    client = get_deepseek_client()
    resp = await client.chat.completions.create(
        model=DEEPSEEK_MODEL_FLASH,
        messages=messages,
        **kwargs,
    )
    return resp.choices[0].message.content


async def embed(texts: list[str]) -> list[list[float]]:
    """调用阿里云 Embedding"""
    client = get_dashscope_client()
    resp = await client.embeddings.create(
        model=DASHSCOPE_EMBEDDING_MODEL,
        input=texts,
        dimensions=DASHSCOPE_EMBEDDING_DIM,
    )
    return [item.embedding for item in resp.data]
