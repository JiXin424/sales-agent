#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量文档转 Markdown 工具

遍历源目录中的所有支持格式文件，调用 convert.py 进行转换，
保持文件夹结构保存到目标目录，并生成处理报告。
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# 配置
SOURCE_DIR = "/Users/fred/Documents/cc_Projects/Taishan/二期库/0515/福多多raw"
TARGET_DIR = "/Users/fred/Documents/cc_Projects/Taishan/二期库/0515/福多多md_ready"
CONVERT_PY = "/Users/fred/Documents/cc_Projects/Taishan/api-software/AFC2md/convert.py"

# 支持的格式
SUPPORTED_EXTS = {'.pdf', '.pptx', '.docx', '.doc', '.xlsx', '.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.heic', '.heif'}


def find_files(source_dir):
    """查找所有需要转换的文件"""
    files = []
    for root, _, filenames in os.walk(source_dir):
        # 跳过中间提取目录
        if '_extracted' in root or '_images' in root:
            continue
        for fname in filenames:
            if fname.startswith('.') or fname == '.DS_Store':
                continue
            ext = os.path.splitext(fname)[1].lower()
            if ext in SUPPORTED_EXTS:
                full_path = os.path.join(root, fname)
                files.append(full_path)
    return sorted(files)


def convert_file(src_path, source_dir, target_dir):
    """
    转换单个文件

    Returns:
        dict: 处理结果
    """
    rel_path = os.path.relpath(src_path, source_dir)
    target_subdir = os.path.dirname(os.path.join(target_dir, rel_path))
    os.makedirs(target_subdir, exist_ok=True)

    result = {
        'source': src_path,
        'relative': rel_path,
        'success': False,
        'error': None,
        'md_path': None,
        'duration': 0,
    }

    start = datetime.now()

    try:
        # 调用 convert.py 处理文件
        # convert.py 会在源文件同目录生成 .md 文件
        proc = subprocess.run(
            [sys.executable, CONVERT_PY, src_path],
            capture_output=True,
            text=True,
            timeout=1800,  # 单个文件最多30分钟
        )

        # 检查 convert.py 是否成功
        if proc.returncode != 0:
            result['error'] = f"convert.py 失败: {proc.stderr[-500:] if proc.stderr else 'unknown'}"
            return result

        # 查找生成的 .md 文件（在同目录下）
        src_dir = os.path.dirname(src_path)
        base_name = os.path.splitext(os.path.basename(src_path))[0]
        md_name = f"{base_name}.md"
        generated_md = os.path.join(src_dir, md_name)

        if not os.path.exists(generated_md):
            result['error'] = f"未找到生成的 MD 文件: {generated_md}"
            return result

        # 移动到目标目录
        target_md = os.path.join(target_subdir, md_name)
        shutil.move(generated_md, target_md)

        result['success'] = True
        result['md_path'] = target_md

    except subprocess.TimeoutExpired:
        result['error'] = "处理超时（超过30分钟）"
    except Exception as e:
        result['error'] = f"异常: {str(e)}"

    result['duration'] = (datetime.now() - start).total_seconds()
    return result


def generate_report(results, report_path):
    """生成处理报告"""
    success = [r for r in results if r['success']]
    failed = [r for r in results if not r['success']]

    lines = []
    lines.append("# 批量文档转 Markdown 处理报告")
    lines.append("")
    lines.append(f"- **处理时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"- **源目录**: `{SOURCE_DIR}`")
    lines.append(f"- **目标目录**: `{TARGET_DIR}`")
    lines.append(f"- **总文件数**: {len(results)}")
    lines.append(f"- **成功**: {len(success)}")
    lines.append(f"- **失败**: {len(failed)}")
    lines.append("")

    if success:
        lines.append("## 成功文件")
        lines.append("")
        for r in success:
            lines.append(f"- ✅ `{r['relative']}` → `{r['md_path']}` ({r['duration']:.1f}s)")
        lines.append("")

    if failed:
        lines.append("## 失败文件")
        lines.append("")
        for r in failed:
            lines.append(f"- ❌ `{r['relative']}` — {r['error']}")
        lines.append("")

    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

    return report_path


def main():
    print("=" * 70)
    print("批量文档转 Markdown")
    print("=" * 70)

    # 查找文件
    print(f"\n扫描目录: {SOURCE_DIR}")
    files = find_files(SOURCE_DIR)
    print(f"找到 {len(files)} 个待转换文件")

    if not files:
        print("没有需要转换的文件")
        sys.exit(0)

    # 创建目标目录
    os.makedirs(TARGET_DIR, exist_ok=True)

    # 逐个处理（避免并发导致API限流）
    results = []
    for i, src_path in enumerate(files, 1):
        print(f"\n[{i}/{len(files)}] 处理: {os.path.relpath(src_path, SOURCE_DIR)}")
        result = convert_file(src_path, SOURCE_DIR, TARGET_DIR)
        results.append(result)

        if result['success']:
            print(f"  ✅ 成功 ({result['duration']:.1f}s) → {result['md_path']}")
        else:
            print(f"  ❌ 失败: {result['error']}")

    # 生成报告
    report_path = os.path.join(TARGET_DIR, "_batch_report.md")
    generate_report(results, report_path)

    # 汇总
    success_count = sum(1 for r in results if r['success'])
    print("\n" + "=" * 70)
    print(f"处理完成: 成功 {success_count}/{len(files)}")
    print(f"报告文件: {report_path}")
    print("=" * 70)

    sys.exit(0 if success_count == len(files) else 1)


if __name__ == "__main__":
    main()
