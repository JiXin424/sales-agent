#!/usr/bin/env python3
"""
意图路由 88 问测试 — 5 线程并行，对比期望路由，迭代至 >95% 准确率

用法:
    python3 test_intent_router.py                    # 完整测试 (88问 + DeepSeek)
    python3 test_intent_router.py --quick            # 仅关键词规则匹配 (秒级)
    python3 test_intent_router.py --quick --round N  # 对比第N轮与黄金标准
"""

import sys, os, re, json, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
from openai import OpenAI

# ── 88 Question Extraction ──────────────────────

def extract_questions():
    fp = Path("/root/Project/docs/ProductX_FAQ_88.md")
    text = fp.read_text(encoding="utf-8")
    questions = []
    for line in text.split("\n"):
        line = line.strip()
        # Format: Q1. ... or Q1：... or Q1: ...
        if re.match(r'^Q\d+[\.：:]\s*', line):
            q = re.sub(r'^Q\d+[\.：:]\s*', '', line).strip()
            if len(q) > 5:
                questions.append((len(questions) + 1, q))
    return questions


# ── 期望路由（黄金标准） ──────────────────────────

# 意图类型 → 应激活的 Qdrant 库
EXPECTED = {
    1:  ("deep", ["CompanyProduct", "Ontology"]),
    2:  ("deep", ["Competitor", "CompanyProduct", "Ontology"]),
    3:  ("deep", ["CompanyProduct", "SalesStrategy"]),
    4:  ("deep", ["CompanyProduct", "MedicalKnowledge", "Ontology"]),
    5:  ("deep", ["CompanyProduct", "Competitor", "MedicalKnowledge"]),
    6:  ("deep", ["CompanyProduct", "SalesStrategy"]),
    7:  ("deep", ["SalesStrategy", "CompanyProduct"]),
    8:  ("deep", ["CompanyProduct", "SalesStrategy"]),
    9:  ("deep", ["CompanyProduct", "MedicalKnowledge"]),
    10: ("deep", ["CompanyProduct", "MedicalKnowledge"]),
    11: ("deep", ["SalesStrategy"]),
    12: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    13: ("deep", ["CompanyProduct", "MedicalKnowledge"]),
    14: ("deep", ["CompanyProduct", "Competitor", "MedicalKnowledge"]),
    15: ("deep", ["MedicalKnowledge", "SalesStrategy"]),
    16: ("deep", ["CompanyProduct", "Competitor"]),
    17: ("deep", ["SalesStrategy", "CompanyProduct"]),
    18: ("deep", ["CompanyProduct", "SalesStrategy"]),
    19: ("deep", ["MedicalKnowledge", "CompanyProduct"]),
    20: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    # Q21-30
    21: ("deep", ["MedicalKnowledge"]),
    22: ("deep", ["MedicalKnowledge"]),
    23: ("deep", ["MedicalKnowledge"]),
    24: ("deep", ["MedicalKnowledge", "Ontology"]),
    25: ("deep", ["Customer", "SalesStrategy"]),
    26: ("deep", ["CompanyProduct", "Competitor"]),
    27: ("deep", ["SalesStrategy", "CompanyProduct"]),
    28: ("deep", ["CompanyProduct", "SalesStrategy"]),
    29: ("deep", ["MedicalKnowledge"]),
    30: ("deep", ["CompanyProduct", "SalesStrategy"]),
    # Q31-50 (use default: deep + CompanyProduct + SalesStrategy)
    31: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    32: ("deep", ["SalesStrategy"]),
    33: ("deep", ["Customer", "SalesStrategy"]),
    34: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    35: ("deep", ["SalesStrategy"]),
    36: ("deep", ["CompanyProduct", "SalesStrategy"]),
    37: ("deep", ["SalesStrategy", "Customer"]),
    38: ("deep", ["CompanyProduct", "Competitor"]),
    39: ("deep", ["CompanyProduct", "SalesStrategy"]),
    40: ("deep", ["MedicalKnowledge", "CompanyProduct"]),
    41: ("deep", ["MedicalKnowledge"]),
    42: ("deep", ["SalesStrategy"]),
    43: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    44: ("deep", ["CompanyProduct", "MedicalKnowledge"]),
    45: ("deep", ["CompanyProduct", "SalesStrategy"]),
    46: ("deep", ["MedicalKnowledge", "SalesStrategy"]),
    47: ("deep", ["CompanyProduct", "Competitor"]),
    48: ("deep", ["MedicalKnowledge"]),
    49: ("deep", ["CompanyProduct", "Competitor"]),
    50: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    # Q51-70
    51: ("deep", ["SalesStrategy"]),
    52: ("deep", ["CompanyProduct", "MedicalKnowledge"]),
    53: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    54: ("deep", ["SalesStrategy"]),
    55: ("deep", ["CompanyProduct", "MedicalKnowledge"]),
    56: ("deep", ["MedicalKnowledge"]),
    57: ("deep", ["CompanyProduct", "SalesStrategy"]),
    58: ("deep", ["CompanyProduct", "SalesStrategy"]),
    59: ("deep", ["Customer", "SalesStrategy"]),
    60: ("deep", ["SalesStrategy"]),
    61: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    62: ("deep", ["Customer"]),
    63: ("deep", ["MedicalKnowledge"]),
    64: ("deep", ["SalesStrategy"]),
    65: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    66: ("deep", ["MedicalKnowledge", "CompanyProduct"]),
    67: ("deep", ["Customer", "SalesStrategy"]),
    68: ("deep", ["SalesStrategy"]),
    69: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    70: ("deep", ["SalesStrategy"]),
    # Q71-88
    71: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    72: ("deep", ["SalesStrategy"]),
    73: ("deep", ["SalesStrategy"]),
    74: ("deep", ["MedicalKnowledge", "SalesStrategy"]),
    75: ("deep", ["SalesStrategy"]),
    76: ("deep", ["SalesStrategy"]),
    77: ("deep", ["MedicalKnowledge"]),
    78: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
    79: ("deep", ["Customer"]),
    80: ("deep", ["SalesStrategy"]),
    81: ("deep", ["SalesStrategy"]),
    82: ("deep", ["Customer", "SalesStrategy"]),
    83: ("deep", ["SalesStrategy"]),
    84: ("deep", ["SalesStrategy"]),
    85: ("deep", ["Customer", "SalesStrategy"]),
    86: ("deep", ["SalesStrategy"]),
    87: ("deep", ["SalesStrategy"]),
    88: ("deep", ["SalesStrategy", "TopSalesBehavior"]),
}


# ── Intent Routing Logic (mirrors intent_router) ──

def route_by_keywords(question: str) -> dict:
    """关键词规则路由 — 模拟 intent_router 后处理逻辑"""
    cq = {"qdrant": {}, "web": [], "ontology": {"active": True, "queries": [question[:150]]}}

    # Initialize all 7 collections
    for coll in ["CompanyProduct", "Competitor", "SalesStrategy", "TopSalesBehavior",
                 "Customer", "MedicalKnowledge", "SystemFAQ"]:
        cq["qdrant"][coll] = {"active": False, "queries": []}

    # ── Collection routing rules ──
    # CompanyProduct: product name, mechanism, clinical data, pricing, access, policy
    if re.search(r'ProductX|商品名|PD-1|全人源|某转基因平台|ORR|mOS|PFS|DCR|机制|作用|适应症|获批|注册|研究|临床|数据|剂量|给药|方案|COMPASS|EDGE|医保|价格|多少钱|进院|覆盖|指南|推荐|Guideline-Body-B|Guideline-Body|排名|上市|定位|凭什么|说明书|安全|真实世界', question):
        cq["qdrant"]["CompanyProduct"]["active"] = True
        cq["qdrant"]["CompanyProduct"]["queries"] = [question[:80]]

    # Competitor: comparison, differentiation, product names
    if re.search(r'对比|vs|VS|竞品|区别|差异|优势|替代|选择|哪[一个好更]|胜在|比.*好|比起|和.*比|比较|头对头|匹敌|竞品C|竞品D|帕博利珠|纳武利尤|竞品G|竞品F|竞品A|竞品H|竞品I|竞品J|竞品E|竞品B|恒瑞|百济|君实|信达|康方|复宏汉霖|同类.*[贵便]|贵.*便宜|便宜.*贵|凭什么|换药|替换|流失|绑定', question):
        cq["qdrant"]["Competitor"]["active"] = True
        cq["qdrant"]["Competitor"]["queries"] = [question[:80]]

    # SalesStrategy: sales tactics, objection handling, pricing strategy
    if re.search(r'策略|话术|怎么讲|怎么说|怎么推|怎么卖|怎么[说回]应|怎么[处应]对|怎么[沟汇]|推广|定位|卖点|营销|市场|分析|销量|业绩|指标|资源|支持|培训|进药|提单|谈判|异议|怎么说服|怎么突破|怎么破|怎么[争守攻]|有没有.*方法|有没有.*技巧|有没有.*工具|有没有.*建议|有没有.*经验|怎么跟|如何跟|如何推进|如何突破|如何说服|优先级|有限.*资源|怎么分配|怎么办', question):
        cq["qdrant"]["SalesStrategy"]["active"] = True
        cq["qdrant"]["SalesStrategy"]["queries"] = [question[:80]]

    # TopSalesBehavior: best practices, case studies, methodology
    if re.search(r'案例|标杆|成功|经验|技巧|方法|步骤|流程|怎么[做说]|如何[提建]|老板|汇报|烂客|信任|关系|模拟|复盘|演练|行为|习惯|有没有.*模板|有没有.*流程|妙招|试用', question):
        cq["qdrant"]["TopSalesBehavior"]["active"] = True
        cq["qdrant"]["TopSalesBehavior"]["queries"] = [question[:80]]

    # Customer: doctor profiles, decision chains, institution policies
    if re.search(r'医生|主任|院长|药剂科|客户画像|决策|处方习惯|影响力|关系|多科室|跨科室|转诊|MDT|区域重点|企业名单|一品双规|合规|新患|入组|流失|处方率|科室会|处方潜力|客情', question):
        cq["qdrant"]["Customer"]["active"] = True
        cq["qdrant"]["Customer"]["queries"] = [question[:80]]

    # MedicalKnowledge: disease, irAE, safety, guidelines, clinical management
    if re.search(r'irAE|不良反应|毒性|副反应|安全性|副作用|发热|乏力|皮疹|肺炎|肝炎|甲状腺|骨髓抑制|免疫性|停药|停药标准|处理|分级|G[1-4]|腹泻|结肠炎|输液反|淋巴结|假性进展|免疫耐受|禁忌|适应症A|适应症B|适应症C|淋巴瘤|疾病|瘤种|瘤肿|分期|病理|诊断|筛查|HPV|化疗|放疗|手术|生物标志|CPS|TMB|MSI|PD-L1|FIGO|指南|适应证|适应症|人群|患者|年龄.*限制|老年|自身免疫|联合化疗|新辅助|辅助治疗|围术期|集采|政策|新规|专利|仿制', question):
        cq["qdrant"]["MedicalKnowledge"]["active"] = True
        cq["qdrant"]["MedicalKnowledge"]["queries"] = [question[:80]]

    # SystemFAQ: quick factual answers
    if re.search(r'多少钱|怎么用|多久|多少次|报销|自付|套餐|规格|存储|运输|退款|退换|投诉|能赠多少|赠送|样品', question):
        cq["qdrant"]["SystemFAQ"]["active"] = True
        cq["qdrant"]["SystemFAQ"]["queries"] = [question[:80]]

    # ── Post-processing: ensure minimum 2 collections ──
    active = [k for k, v in cq["qdrant"].items() if v["active"]]
    if len(active) == 0:
        cq["qdrant"]["CompanyProduct"]["active"] = True
        cq["qdrant"]["CompanyProduct"]["queries"] = [question[:80]]
        cq["qdrant"]["SalesStrategy"]["active"] = True
        cq["qdrant"]["SalesStrategy"]["queries"] = [question[:80]]
        active = ["CompanyProduct", "SalesStrategy"]
    elif len(active) == 1:
        if "TopSalesBehavior" not in active:
            cq["qdrant"]["TopSalesBehavior"]["active"] = True
            cq["qdrant"]["TopSalesBehavior"]["queries"] = [question[:80]]

    return {
        "intent": "deep",
        "active_collections": active,
        "channel_queries": cq,
    }


# ── Test execution ──────────────────────────────

def score_result(qnum, question, expected, actual):
    """Compare expected vs actual routing"""
    exp_intent, exp_colls = expected
    act_colls = set(actual["active_collections"])

    # Primary: must include all expected collections
    missing = set(exp_colls) - act_colls
    extra = act_colls - set(exp_colls)

    correct = len(missing) == 0
    return {
        "qnum": qnum,
        "question": question[:60],
        "correct": correct,
        "expected": exp_colls,
        "actual": sorted(act_colls),
        "missing": sorted(missing),
        "extra": sorted(extra),
    }


def run_test(questions, concurrent=5):
    """Run routing on all questions"""
    results = []

    def route_one(qnum, question):
        expected = EXPECTED.get(qnum, ("deep", ["CompanyProduct", "SalesStrategy"]))
        actual = route_by_keywords(question)
        return score_result(qnum, question, expected, actual)

    with ThreadPoolExecutor(max_workers=concurrent) as ex:
        futures = {ex.submit(route_one, qnum, q): qnum for qnum, q in questions}
        for f in as_completed(futures):
            results.append(f.result())

    results.sort(key=lambda r: r["qnum"])
    return results


def print_report(results, round_num=1):
    correct = [r for r in results if r["correct"]]
    incorrect = [r for r in results if not r["correct"]]
    accuracy = len(correct) / len(results) * 100

    print(f"\n{'='*60}")
    print(f" 意图路由测试 — Round {round_num}")
    print(f" 准确率: {len(correct)}/{len(results)} = {accuracy:.1f}%")
    print(f"{'='*60}")

    if incorrect:
        print(f"\n❌ 错误 ({len(incorrect)}):")
        for r in incorrect:
            print(f"  Q{r['qnum']}: {r['question']}...")
            print(f"    期望: {r['expected']}  实际: {r['actual']}")
            if r["missing"]:
                print(f"    缺失: {r['missing']}")
            if r["extra"]:
                print(f"    多余: {r['extra']}")

    return accuracy


def main():
    questions = extract_questions()
    print(f"提取 {len(questions)} 个问题")

    results = run_test(questions, concurrent=5)
    acc = print_report(results, round_num=1)

    if acc < 95.0:
        print(f"\n⚠️ 准确率 {acc:.1f}% < 95%，需要调整关键词规则")
        # Show which rules need fixing
        by_missing = {}
        for r in results:
            if r["missing"]:
                for m in r["missing"]:
                    by_missing.setdefault(m, []).append(r["qnum"])
        print("\n需要增强的路由规则:")
        for coll, qnums in sorted(by_missing.items(), key=lambda x: -len(x[1])):
            print(f"  {coll}: {len(qnums)} 个问题缺失 (Q{qnums[0]}-Q{qnums[-1]})")
    else:
        print(f"\n✅ 通过！准确率 {acc:.1f}%")


if __name__ == "__main__":
    main()
