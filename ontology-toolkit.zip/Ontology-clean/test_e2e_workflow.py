#!/usr/bin/env python3
"""端到端工作流测试 — 运行完整 workflow 检查每个节点是否有报错"""

import sys, os, json, time
sys.path.insert(0, "/root/Project/apps/node-editor")

os.environ["DASHSCOPE_API_KEY"] = "DASHSCOPE_API_KEY_PLACEHOLDER"
os.environ["DEEPSEEK_API_KEY"] = "DEEPSEEK_API_KEY_PLACEHOLDER"
os.environ["QDRANT_URL"] = "http://localhost:7334"
os.environ["POSTGRES_HOST"] = "localhost"
os.environ["POSTGRES_PORT"] = "5534"

def test_question(question, test_id):
    """Run workflow with one question, check all node outputs"""
    print(f"\n{'='*60}")
    print(f"Test {test_id}: {question[:80]}...")
    print(f"{'='*60}")

    # Build workflow fresh each time
    sys.path.insert(0, "/root/Project/apps/node-editor/workflows")
    import importlib
    spec = importlib.util.spec_from_file_location(
        "workflow_test", "/root/Project/apps/node-editor/workflows/product_x.running.py"
    )
    mod = importlib.util.module_from_spec(spec)

    try:
        spec.loader.exec_module(mod)
    except Exception as e:
        print(f"  ❌ 工作流加载失败: {e}")
        return {"test_id": test_id, "question": question, "error": str(e), "nodes": []}

    engine = mod.main()

    # Inject initial variables
    initial = {
        "msg_source": {
            "message_text": question,
            "sender_id": "test_user_001",
            "sender_name": "测试销售",
            "chat_id": "test_chat_001",
            "chat_type": "p2p",
            "open_id": "ou_test_001",
            "msg_type": "text",
        },
        "platform": {"platform": "feishu"},
        "sys": {
            "user_wiki_profile": "",
            "is_bot_mentioned": False,
        },
        "user_cache_loader": {
            "user_map": "{}",
            "name_list": "测试销售",
        },
        "convo_history": {
            "conversation_history": "",
        },
    }

    # Run workflow
    try:
        state = engine.run(initial_variables=initial)
    except Exception as e:
        print(f"  ❌ 工作流执行异常: {e}")
        import traceback
        traceback.print_exc()
        return {"test_id": test_id, "question": question, "error": str(e), "nodes": []}

    # Check each node
    node_results = []
    errors = []
    for node_id, node in engine.graph.nodes.items():
        if node_id in state.variables:
            val = state.variables[node_id]
            if isinstance(val, dict) and val.get("error"):
                errors.append(f"{node_id}: {val['error']}")
                node_results.append({"node": node_id, "status": "ERROR", "error": val["error"]})
            else:
                node_results.append({"node": node_id, "status": "OK"})
        else:
            node_results.append({"node": node_id, "status": "SKIPPED"})

    # Key outputs
    intent = state.variables.get("intent_router", {})
    context = state.variables.get("context_merge", {})
    generation = state.variables.get("llm_reply", {}).get("generation", "")

    total_nodes = len(engine.graph.nodes)
    executed = sum(1 for r in node_results if r["status"] in ("OK", "ERROR"))
    errored = sum(1 for r in node_results if r["status"] == "ERROR")
    skipped = sum(1 for r in node_results if r["status"] == "SKIPPED")

    print(f"  总节点: {total_nodes}, 执行: {executed}, 错误: {errored}, 跳过: {skipped}")
    print(f"  意图: {intent.get('intent', '?')} — {intent.get('intent_reason', '?')[:60]}")
    print(f"  上下文: {len(context.get('context', ''))} chars")

    if generation:
        print(f"  生成: {generation[:120]}...")
    elif errors:
        for e in errors[:5]:
            print(f"  错误: {e}")

    if errored > 0:
        print(f"\n  ❌ 错误节点:")
        for r in node_results:
            if r["status"] == "ERROR":
                print(f"    {r['node']}: {r.get('error', '?')}")

    return {
        "test_id": test_id,
        "question": question,
        "total_nodes": total_nodes,
        "executed": executed,
        "errored": errored,
        "skipped": skipped,
        "intent": intent.get("intent"),
        "context_len": len(context.get("context", "")),
        "generation_len": len(generation),
        "errors": errors,
    }

# ── Run 3 tests ──
tests = [
    ("ProductX在适应症A二线治疗中的ORR是多少？", 1),
    ("患者出现irAE皮肤毒性应该怎么分级处理？", 2),
    ("ProductX和竞品C在适应症A治疗中有什么区别？", 3),
]

results = []
for question, tid in tests:
    r = test_question(question, tid)
    results.append(r)
    time.sleep(2)  # Avoid overwhelming APIs

# Summary
print(f"\n{'='*60}")
print("总结")
print(f"{'='*60}")
all_ok = True
for r in results:
    status = "✅" if r["errored"] == 0 else "❌"
    print(f"  {status} Test {r['test_id']}: {r['executed']}/{r['total_nodes']} nodes executed ({r['errored']} errors)")
    if r["errored"] > 0:
        all_ok = False

if all_ok:
    print("\n🎉 全部通过！")
else:
    print(f"\n⚠️ 有 {sum(1 for r in results if r['errored'] > 0)} 个测试失败")
