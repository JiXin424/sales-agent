"""Phase 4 自动化工具链 — TDD 测试

测试3个核心模块：
1. tools.eval_compare — 两次评测结果对比
2. tools.pipeline — 一键流水线
3. API端点 automation — 触发+轮询
"""

import json
import os
import tempfile

import pytest


# ============================================================
# 1. eval_compare 模块测试
# ============================================================

class TestEvalCompare:
    """评测结果对比"""

    def test_compare_two_rounds_basic(self):
        """基本对比：两次评测的分数差异"""
        from tools.eval_compare import compare_results

        old = {
            "rounds_summary": [
                {"round": 1, "set": "基础认知", "score_pct": 70.0, "pass_rate": 90.0, "intent_accuracy": 93.3},
                {"round": 4, "set": "复杂推理", "score_pct": 68.7, "pass_rate": 86.7, "intent_accuracy": 80.0},
                {"round": 7, "set": "实战应用", "score_pct": 62.0, "pass_rate": 83.3, "intent_accuracy": 86.7},
            ]
        }
        new = {
            "rounds_summary": [
                {"round": 1, "set": "基础认知", "score_pct": 72.9, "pass_rate": 93.3, "intent_accuracy": 96.7},
                {"round": 4, "set": "复杂推理", "score_pct": 73.1, "pass_rate": 90.0, "intent_accuracy": 87.7},
                {"round": 7, "set": "实战应用", "score_pct": 58.0, "pass_rate": 80.0, "intent_accuracy": 80.0},
            ]
        }

        diff = compare_results(old, new)
        assert diff["基础认知"]["score_pct"] == pytest.approx(2.9)
        assert diff["复杂推理"]["score_pct"] == pytest.approx(4.4)
        assert diff["实战应用"]["score_pct"] == pytest.approx(-4.0)
        assert diff["整体"]["score_pct"] > 0  # 平均提升

    def test_compare_overall_metrics(self):
        """整体指标：通过率、意图准确率的加权平均"""
        from tools.eval_compare import compare_results

        old = {"rounds_summary": [
            {"round": 1, "set": "A", "score_pct": 60.0, "pass_rate": 80.0, "intent_accuracy": 70.0},
            {"round": 2, "set": "B", "score_pct": 50.0, "pass_rate": 70.0, "intent_accuracy": 60.0},
        ]}
        new = {"rounds_summary": [
            {"round": 1, "set": "A", "score_pct": 70.0, "pass_rate": 90.0, "intent_accuracy": 80.0},
            {"round": 2, "set": "B", "score_pct": 55.0, "pass_rate": 75.0, "intent_accuracy": 65.0},
        ]}

        diff = compare_results(old, new)
        assert diff["整体"]["score_pct"] == pytest.approx(7.5)
        assert diff["整体"]["pass_rate"] == pytest.approx(7.5)

    def test_format_diff_report(self):
        """格式化输出差异报告"""
        from tools.eval_compare import format_diff_report

        diff = {
            "基础认知": {"score_pct": 2.9, "pass_rate": 3.3, "intent_accuracy": 3.4},
            "复杂推理": {"score_pct": -1.0, "pass_rate": 0, "intent_accuracy": -5.0},
            "实战应用": {"score_pct": 0, "pass_rate": 0, "intent_accuracy": 0},
            "整体": {"score_pct": 0.6, "pass_rate": 1.1, "intent_accuracy": -0.5},
        }
        report = format_diff_report(diff, "Phase 2", "Phase 3")
        assert "Phase 2" in report
        assert "Phase 3" in report
        assert "基础认知" in report
        assert "+2.9" in report
        assert "-1.0" in report


# ============================================================
# 2. pipeline 模块测试
# ============================================================

class TestPipeline:
    """一键流水线"""

    def test_pipeline_steps_defined(self):
        """流水线步骤正确定义"""
        from tools.pipeline import PIPELINE_STEPS

        assert len(PIPELINE_STEPS) >= 4
        step_names = [s["name"] for s in PIPELINE_STEPS]
        assert "清空数据库" in step_names
        assert "上传文档" in step_names
        assert "生成背景知识" in step_names
        assert "运行评测" in step_names

    def test_pipeline_result_structure(self):
        """流水线结果结构正确"""
        from tools.pipeline import PipelineResult

        result = PipelineResult(
            success=True,
            steps_completed=4,
            steps_total=4,
            eval_score=72.5,
            eval_report={"rounds_summary": []},
            diff_from_previous={"整体": {"score_pct": 3.0}},
            elapsed_seconds=120.0,
        )
        assert result.success
        assert result.eval_score == 72.5
        assert result.steps_completed == 4


# ============================================================
# 3. API 端点测试
# ============================================================

class TestAutomationAPI:
    """自动化API端点"""

    @pytest.mark.asyncio
    async def test_compare_endpoint(self, tmp_path):
        """GET /api/v1/automation/compare 对比两次评测"""
        from httpx import AsyncClient, ASGITransport
        from backend.main import app

        # 准备两个评测结果文件
        old_report = {"rounds_summary": [
            {"round": 1, "set": "基础认知", "score_pct": 60.0, "pass_rate": 80.0, "intent_accuracy": 70.0},
        ]}
        new_report = {"rounds_summary": [
            {"round": 1, "set": "基础认知", "score_pct": 70.0, "pass_rate": 90.0, "intent_accuracy": 80.0},
        ]}

        eval_dir = tmp_path / "eval_results"
        eval_dir.mkdir()
        with open(eval_dir / "full_report_old.json", "w") as f:
            json.dump(old_report, f)
        with open(eval_dir / "full_report.json", "w") as f:
            json.dump(new_report, f)

        # 需要mock eval_results路径 — 用monkeypatch
        import backend.api.automation as auto_module
        original_dir = auto_module.EVAL_RESULTS_DIR
        auto_module.EVAL_RESULTS_DIR = str(eval_dir)

        try:
            transport = ASGITransport(app=app)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/v1/automation/compare")
                assert resp.status_code == 200
                data = resp.json()
                assert "diff" in data
                assert data["diff"]["基础认知"]["score_pct"] == pytest.approx(10.0)
        finally:
            auto_module.EVAL_RESULTS_DIR = original_dir

    @pytest.mark.asyncio
    async def test_eval_history_endpoint(self, tmp_path):
        """GET /api/v1/automation/eval-history 返回评测历史"""
        from httpx import AsyncClient, ASGITransport
        from backend.main import app

        eval_dir = tmp_path / "eval_results"
        eval_dir.mkdir()
        for i in range(1, 4):
            report = {"rounds_summary": [
                {"round": j, "set": "测试", "score_pct": 60 + i, "pass_rate": 80, "intent_accuracy": 70}
                for j in range(1, i + 1)
            ], "timestamp": f"2026-06-12T1{i}:00:00"}
            with open(eval_dir / f"full_report_{i}.json", "w") as f:
                json.dump(report, f)

        import backend.api.automation as auto_module
        original_dir = auto_module.EVAL_RESULTS_DIR
        auto_module.EVAL_RESULTS_DIR = str(eval_dir)

        try:
            transport = ASGITransport(app=app)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/v1/automation/eval-history")
                assert resp.status_code == 200
                data = resp.json()
                assert "history" in data
                assert len(data["history"]) >= 1
        finally:
            auto_module.EVAL_RESULTS_DIR = original_dir
