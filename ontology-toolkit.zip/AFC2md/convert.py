#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OpenClaw Header
# 'HTTP-Referer': 'https://openclaw.ai'
# 'X-0penRouter-Title': 'OpenClaw'
# 'X-0penRouter-Categories': 'cli-agent'
"""
统一文档转 Markdown 工具

支持格式：
- PDF (.pdf) - 使用 PyMuPDF 渲染 + AI 视觉分析
- PPTX (.pptx) - 使用 PowerPoint 导出 + AI 视觉分析
- DOCX (.docx) - 直接提取文本和图片
- DOC (.doc) - Word 97-2003 格式，OLE 流提取
- XLSX (.xlsx) - Excel 工作表数据
- 图片 (.jpg/.jpeg/.png/.webp/.gif/.bmp/.heic/.heif) - AI 视觉分析

用法:
    python convert.py <file>
    python convert.py "document.pdf"
    python convert.py "数据表.xlsx" --no-ai
    python convert.py file1.pdf file2.docx file3.xlsx  # 批量处理
    python convert.py file1.pdf file2.docx --no-ai    # 批量 + 参数

输出：与输入文件同目录，生成同名 .md 文件
"""

import sys
import os
import subprocess
import importlib
import shutil
from pathlib import Path
from typing import Optional, Tuple, List, Dict
from concurrent.futures import ThreadPoolExecutor, as_completed

# 支持的格式及对应处理器
SUPPORTED_FORMATS = {
    '.pdf': ('doc2md', 'PDF 文档'),
    '.pptx': ('doc2md', 'PPTX 演示文稿'),
    '.docx': ('docx2md', 'DOCX 文档'),
    '.doc': ('doc97tomd', 'DOC 文档 (Word 97-2003)'),
    '.xlsx': ('xlsx2md', 'XLSX 表格'),
    '.jpg': ('img2md', '图片'),
    '.jpeg': ('img2md', '图片'),
    '.png': ('img2md', '图片'),
    '.webp': ('img2md', '图片'),
    '.gif': ('img2md', '图片'),
    '.bmp': ('img2md', '图片'),
    '.heic': ('img2md', '图片'),
    '.heif': ('img2md', '图片'),
}

# 依赖检查
DEPENDENCIES = {
    'doc2md': ['fitz', 'PyMuPDF', 'openai'],
    'docx2md': ['docx', 'python-docx', 'openai', 'PIL'],
    'doc97tomd': ['olefile', 'openai', 'PIL'],
    'xlsx2md': ['openpyxl', 'openai'],
    'img2md': ['openai', 'PIL'],
}


def check_dependencies(handler: str) -> Tuple[bool, list]:
    """检查所需依赖是否已安装"""
    missing = []
    deps = DEPENDENCIES.get(handler, [])

    for dep in deps:
        try:
            if dep == 'PIL':
                __import__('PIL')
            elif dep == 'fitz':
                __import__('fitz')
            elif dep == 'python-docx':
                __import__('docx')
            elif dep == 'PyMuPDF':
                pass  # fitz 已检查
            else:
                __import__(dep)
        except ImportError:
            actual_name = {'python-docx': 'python-docx', 'PyMuPDF': 'PyMuPDF',
                          'PIL': 'pillow', 'fitz': 'PyMuPDF'}.get(dep, dep)
            missing.append(actual_name)

    return len(missing) == 0, missing


def find_file(file_path: str, search_base: str = None) -> Optional[str]:
    """查找文件的真实路径（处理 iCloud 幽灵文件和中文路径）"""
    # 先尝试原始路径
    if os.path.exists(file_path):
        try:
            size = os.path.getsize(file_path)
            if size >= 1024:
                return file_path
        except OSError:
            pass

    file_name = os.path.basename(file_path)
    if search_base is None:
        search_base = "/Users/fred/Documents/cc_Projects/Taishan"

    keyword = file_name.split('.')[0]

    result = subprocess.run(
        ['bash', '-c', f'find "{search_base}" -name "*{keyword}*" -type f 2>/dev/null | head -5'],
        capture_output=True,
        text=True
    )

    if result.stdout.strip():
        files = result.stdout.strip().split('\n')
        for f in files:
            if keyword in f.replace(' ', ''):
                return f

    return None


def verify_file_access(file_path: str) -> Tuple[bool, int]:
    """验证文件是否可访问且不是 iCloud 占位符"""
    try:
        size = os.path.getsize(file_path)
        if size < 1024:
            print(f"警告：文件小于 1KB ({size} bytes)，可能是 iCloud 占位符")
            return False, size
        return True, size
    except OSError:
        return False, 0


def cleanup_temp_files(temp_dirs: List[str]) -> int:
    """
    清理临时文件和目录

    Args:
        temp_dirs: 临时目录列表

    Returns:
        int: 清理的目录数量
    """
    cleaned = 0
    for temp_dir in temp_dirs:
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                print(f"  已清理临时目录：{temp_dir}")
                cleaned += 1
            except Exception as e:
                print(f"  清理失败 {temp_dir}: {e}")
    return cleaned


# OCR 跳过阈值
MAX_OCR_PAGES = 40       # 超过此页数仅文字提取
MAX_OCR_SIZE_MB = 10     # 超过此大小仅文字提取


def _should_skip_ocr(file_path: str, ext: str) -> tuple[bool, str]:
    """检查是否应跳过 OCR，返回 (skip, reason)"""
    file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
    if file_size_mb > MAX_OCR_SIZE_MB:
        return True, f"文件 {file_size_mb:.1f}MB > {MAX_OCR_SIZE_MB}MB"

    if ext == '.pdf':
        try:
            import fitz
            doc = fitz.open(file_path)
            pages = doc.page_count
            doc.close()
            if pages > MAX_OCR_PAGES:
                return True, f"PDF {pages} 页 > {MAX_OCR_PAGES} 页"
        except Exception:
            pass
    return False, ""


def _pdf_text_only(file_path: str) -> bool:
    """PyMuPDF 直接提取 PDF 文字，不经过 OCR"""
    import fitz
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    output_path = os.path.join(os.path.dirname(file_path), f"{file_name}.md")

    doc = fitz.open(file_path)
    total = doc.page_count
    lines = [
        f"# {file_name}",
        "",
        f"> 提取方式：PyMuPDF 直接文字提取（{total} 页，跳过 OCR）",
        "",
        "---",
        "",
    ]
    empty = 0
    for i in range(total):
        text = doc[i].get_text()
        if text.strip():
            lines.append(f"<!-- page {i+1} -->")
            lines.append("")
            lines.append(text.strip())
            lines.append("")
        else:
            empty += 1
    doc.close()

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

    print(f"   ✅ 文字提取完成：{total} 页，{empty} 空白页 → {output_path}")
    return True


def _pptx_text_only(file_path: str) -> bool:
    """PPTX 直接提取文字（python-pptx），跳过 OCR"""
    from pptx import Presentation
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    output_path = os.path.join(os.path.dirname(file_path), f"{file_name}.md")

    prs = Presentation(file_path)
    lines = [
        f"# {file_name}",
        "",
        f"> 提取方式：python-pptx 直接文字提取（{len(prs.slides)} 页，跳过 OCR）",
        "",
        "---",
        "",
    ]
    for i, slide in enumerate(prs.slides, 1):
        slide_lines = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    t = para.text.strip()
                    if t:
                        slide_lines.append(t)
        if slide_lines:
            lines.append(f"<!-- slide {i} -->")
            lines.append("")
            lines.append("\n\n".join(slide_lines))
            lines.append("")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

    print(f"   ✅ 文字提取完成：{len(prs.slides)} 页 → {output_path}")
    return True


def convert_pdf_pptx(file_path: str, use_ai: bool = True, cleanup: bool = True) -> Tuple[bool, List[str]]:
    """使用 doc2md 处理 PDF/PPTX；超大文件自动跳过 OCR"""
    ext = os.path.splitext(file_path)[1].lower()

    skip_ocr, reason = _should_skip_ocr(file_path, ext)
    if skip_ocr:
        print(f"   ⚠️ 跳过 OCR（{reason}），使用直接文字提取...")
        if ext == '.pdf':
            return _pdf_text_only(file_path), []
        elif ext in ['.pptx', '.ppt']:
            return _pptx_text_only(file_path), []

    try:
        handler = importlib.import_module('doc2md')
        success = handler.doc_to_md(file_path)
        # 获取中间目录路径
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        temp_dir = os.path.join(os.path.dirname(file_path), f"{file_name}_images")
        temp_dirs = [temp_dir] if success and cleanup else []
        return success, temp_dirs
    except Exception as e:
        print(f"处理失败：{e}")
        return False, []


def convert_docx(file_path: str, use_ai: bool = True, cleanup: bool = True) -> Tuple[bool, List[str]]:
    """使用 docx2md 处理 DOCX"""
    try:
        handler = importlib.import_module('docx2md')
        success = handler.docx_to_md(file_path)
        # 获取中间目录路径
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        temp_dir = os.path.join(os.path.dirname(file_path), f"{file_name}_extracted")
        temp_dirs = [temp_dir] if success and cleanup else []
        return success, temp_dirs
    except Exception as e:
        print(f"处理失败：{e}")
        return False, []


def convert_doc(file_path: str, use_ai: bool = True, cleanup: bool = True) -> Tuple[bool, List[str]]:
    """使用 doc97tomd 处理 DOC"""
    try:
        handler = importlib.import_module('doc97tomd')
        success = handler.doc_to_md(file_path)
        # 获取中间目录路径
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        temp_dir = os.path.join(os.path.dirname(file_path), f"{file_name}_images")
        temp_dirs = [temp_dir] if success and cleanup else []
        return success, temp_dirs
    except Exception as e:
        print(f"处理失败：{e}")
        return False, []


def convert_xlsx(file_path: str, use_ai: bool = True, cleanup: bool = True) -> Tuple[bool, List[str]]:
    """使用 xlsx2md 处理 XLSX"""
    try:
        handler = importlib.import_module('xlsx2md')
        success = handler.xlsx_to_md(file_path, use_ai=use_ai)
        # xlsx2md 使用临时文件（tempfile.mkstemp），会自动清理
        return success, []
    except Exception as e:
        print(f"处理失败：{e}")
        return False, []


def convert_image(file_path: str, use_ai: bool = True, cleanup: bool = True) -> Tuple[bool, List[str]]:
    """使用 img2md 处理图片"""
    try:
        handler = importlib.import_module('img2md')
        success = handler.process_single_image(file_path, use_ai=use_ai)
        # img2md 使用临时文件，会自动清理
        return success, []
    except Exception as e:
        print(f"处理失败：{e}")
        return False, []


def convert_file(file_path: str, use_ai: bool = True, cleanup: bool = True) -> Tuple[bool, List[str]]:
    """
    主转换函数：自动检测文件类型并调用相应处理器

    Args:
        file_path: 输入文件路径
        use_ai: 是否使用 AI 整理
        cleanup: 是否清理中间文件

    Returns:
        Tuple[bool, List[str]]: (是否成功，临时目录列表)
    """
    print("=" * 60)
    print("统一文档转 Markdown 工具")
    print("=" * 60)

    # 查找文件
    print("\n[1/4] 查找文件...")
    real_path = find_file(file_path)
    if not real_path:
        print(f"错误：找不到文件：{file_path}")
        return False, []

    file_path = real_path
    file_name = os.path.basename(file_path)
    ext = os.path.splitext(file_name)[1].lower()

    print(f"  找到：{file_name}")

    # 验证文件
    print("\n[2/4] 验证文件...")
    is_valid, file_size = verify_file_access(file_path)
    if not is_valid:
        print("错误：无法访问文件或文件太小")
        return False, []
    print(f"  文件大小：{file_size / 1024:.1f} KB")

    # 检测文件类型
    print("\n[3/4] 检测文件类型...")
    if ext not in SUPPORTED_FORMATS:
        print(f"错误：不支持的文件格式：{ext}")
        print(f"\n支持的格式：{', '.join(SUPPORTED_FORMATS.keys())}")
        return False, []

    handler_name, file_type = SUPPORTED_FORMATS[ext]
    print(f"  类型：{file_type} (.{ext.lstrip('.')})")
    print(f"  处理器：{handler_name}.py")

    # 检查依赖
    print("\n[4/4] 检查依赖...")
    deps_ok, missing = check_dependencies(handler_name)
    if not deps_ok:
        print(f"错误：缺少依赖库：{', '.join(missing)}")
        print(f"\n请运行：pip install {' '.join(missing)}")
        return False, []
    print("  依赖检查：通过")

    # 执行转换
    print(f"\n开始转换...")
    print("-" * 60)

    if ext in ['.pdf', '.pptx']:
        return convert_pdf_pptx(file_path, use_ai, cleanup)
    elif ext == '.docx':
        return convert_docx(file_path, use_ai, cleanup)
    elif ext == '.doc':
        return convert_doc(file_path, use_ai, cleanup)
    elif ext == '.xlsx':
        return convert_xlsx(file_path, use_ai, cleanup)
    elif ext in ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.heic', '.heif']:
        return convert_image(file_path, use_ai, cleanup)
    else:
        print(f"错误：未实现的处理器")
        return False, []


def main():
    """主函数"""
    if len(sys.argv) < 2 or '--help' in sys.argv or '-h' in sys.argv:
        print(__doc__)
        sys.exit(0 if len(sys.argv) > 1 else 1)

    args = sys.argv[1:]

    # 解析参数
    file_paths = []
    use_ai = True

    for arg in args:
        if arg == '--no-ai':
            use_ai = False
        elif arg.startswith('-'):
            print(f"未知参数：{arg}")
            print("可用参数：--no-ai, --help, -h")
            sys.exit(1)
        else:
            file_paths.append(arg)

    if not file_paths:
        print("错误：请指定输入文件路径")
        sys.exit(1)

    # 批量处理
    if len(file_paths) == 1:
        # 单个文件，直接处理
        try:
            success, temp_dirs = convert_file(file_paths[0], use_ai)
            # 清理临时文件
            if temp_dirs:
                print("\n清理临时文件...")
                cleanup_temp_files(temp_dirs)
            sys.exit(0 if success else 1)
        except Exception as e:
            print(f"\n处理失败：{e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    else:
        # 多个文件，使用 3 线程并行处理
        print(f"\n🚀 批量处理模式：{len(file_paths)} 个文件，3 线程并行")
        print("=" * 60)

        success_count = 0
        fail_count = 0
        results = []
        all_temp_dirs = []

        def process_file(path):
            """线程函数：处理单个文件"""
            try:
                success, temp_dirs = convert_file(path, use_ai)
                return (path, success, None, temp_dirs)
            except Exception as e:
                return (path, False, str(e), [])

        with ThreadPoolExecutor(max_workers=3) as executor:
            future_to_file = {executor.submit(process_file, path): path for path in file_paths}

            for future in as_completed(future_to_file):
                path, success, error, temp_dirs = future.result()
                results.append((path, success, error))
                all_temp_dirs.extend(temp_dirs)

                if success:
                    success_count += 1
                    print(f"\n✅ 完成：{os.path.basename(path)}")
                else:
                    fail_count += 1
                    print(f"\n❌ 失败：{os.path.basename(path)}")
                    if error:
                        print(f"   错误：{error}")

        # 清理临时文件
        if all_temp_dirs:
            print("\n" + "=" * 60)
            print("清理临时文件...")
            print("=" * 60)
            cleanup_temp_files(all_temp_dirs)

        # 汇总结果
        print("\n" + "=" * 60)
        print(f"批量处理完成：成功 {success_count}/{len(file_paths)} 个文件")
        if fail_count > 0:
            print(f"失败 {fail_count} 个文件")

        sys.exit(0 if fail_count == 0 else 1)


if __name__ == "__main__":
    main()
