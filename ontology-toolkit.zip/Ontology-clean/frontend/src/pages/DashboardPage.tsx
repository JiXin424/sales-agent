import { useState, useEffect } from 'react';
import { Card, Row, Col, Statistic, List, Spin } from 'antd';
import {
  NodeIndexOutlined,
  ShareAltOutlined,
  FileTextOutlined,
  StarOutlined,
} from '@ant-design/icons';
import { getOntologyStats, getEntityStats } from '../services/api';

interface Stats {
  total_entities?: number;
  total_relations?: number;
  total_documents?: number;
  avg_rating?: number;
}

interface EntityStat {
  type: string;
  count: number;
}

interface Activity {
  id: number;
  action: string;
  detail: string;
  time: string;
}

const defaultStats: Stats = {
  total_entities: 0,
  total_relations: 0,
  total_documents: 0,
  avg_rating: 0,
};

const typeColors: Record<string, string> = {
  Company: '#58a6ff',
  Product: '#3fb950',
  Competitor: '#f85149',
  CustomerSegment: '#f778ba',
  Partner: '#e3b341',
  Feature: '#79c0ff',
  Spec: '#7ee787',
  Equipment: '#a5d6ff',
  Pricing: '#d29922',
  Certification: '#d2a8ff',
  Award: '#56d364',
  Scenario: '#ffa657',
  Solution: '#db61a2',
  Disease: '#ff7b72',
  Industry: '#8957e5',
  Objection: '#f85149',
  SalesScript: '#56d364',
  Case: '#a5d6ff',
  Advantage: '#d2a8ff',
  Policy: '#58a6ff',
  Contact: '#e3b341',
  Institution: '#8957e5',
};

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats>(defaultStats);
  const [entityStats, setEntityStats] = useState<EntityStat[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [statsRes, entityRes] = await Promise.allSettled([
          getOntologyStats(),
          getEntityStats(),
        ]);

        if (statsRes.status === 'fulfilled') {
          setStats(statsRes.value.data || defaultStats);
          const d = statsRes.value.data as Stats & { recent_activity?: Activity[] };
          if (d.recent_activity) setActivities(d.recent_activity);
        }

        if (entityRes.status === 'fulfilled') {
          const data = entityRes.value.data;
          if (Array.isArray(data)) {
            setEntityStats(data);
          } else if (data && typeof data === 'object') {
            const entries = Object.entries(data as Record<string, number>);
            setEntityStats(entries.map(([type, count]) => ({ type, count })));
          }
        }
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return <Spin size="large" style={{ display: 'block', margin: '100px auto' }} />;
  }

  const maxCount = Math.max(...entityStats.map((e) => e.count), 1);

  return (
    <div>
      <h2 style={{ color: '#e6edf3', marginBottom: 24 }}>数据看板</h2>

      {/* Row 1: Stat Cards */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col span={6}>
          <Card>
            <Statistic
              title="实体总数"
              value={stats.total_entities}
              prefix={<NodeIndexOutlined />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="关系总数"
              value={stats.total_relations}
              prefix={<ShareAltOutlined />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="文档总数"
              value={stats.total_documents}
              prefix={<FileTextOutlined />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="平均评分"
              value={stats.avg_rating ?? 0}
              precision={1}
              prefix={<StarOutlined />}
            />
          </Card>
        </Col>
      </Row>

      {/* Row 2: Entity Distribution */}
      <Card title="实体分布" style={{ marginBottom: 24 }}>
        {entityStats.length === 0 ? (
          <div style={{ color: '#8b949e', textAlign: 'center', padding: 20 }}>暂无数据</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {entityStats.map((item) => (
              <div key={item.type} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{ width: 100, color: '#8b949e', fontSize: 13, textAlign: 'right' }}>
                  {item.type}
                </span>
                <div
                  style={{
                    width: `${(item.count / maxCount) * 100}%`,
                    minWidth: 4,
                    height: 20,
                    borderRadius: 4,
                    background: typeColors[item.type] || '#30363d',
                    transition: 'width 0.3s',
                  }}
                />
                <span style={{ color: '#e6edf3', fontSize: 13 }}>{item.count}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Row 3: Recent Activity */}
      <Card title="最近活动">
        {activities.length === 0 ? (
          <div style={{ color: '#8b949e', textAlign: 'center', padding: 20 }}>暂无活动记录</div>
        ) : (
          <List
            size="small"
            dataSource={activities}
            renderItem={(item) => (
              <List.Item>
                <List.Item.Meta
                  title={<span style={{ color: '#e6edf3' }}>{item.action}</span>}
                  description={`${item.detail} - ${item.time}`}
                />
              </List.Item>
            )}
          />
        )}
      </Card>
    </div>
  );
}
