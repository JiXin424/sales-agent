# 《影响力》知识本体运行时

> 基于 `influence_ontology.json` 构建的最小可运行知识本体系统。

---

## 快速开始

```bash
cd ontology_runtime

# 直接运行 CLI
python -m influence_ontology_runtime.cli stats

# 安装为命令
pip install -e .
influence-ontology stats
```

---

## CLI 命令

### 单次命令

```bash
# 统计
python -m influence_ontology_runtime.cli stats

# 按 id 查看
python -m influence_ontology_runtime.cli get reciprocity-principle

# 列出某类型
python -m influence_ontology_runtime.cli list cases

# 搜索
python -m influence_ontology_runtime.cli search "稀缺"

# DSL 查询
python -m influence_ontology_runtime.cli query "type=Case principle=reciprocity-principle"

# 解释原则（跨层视图）
python -m influence_ontology_runtime.cli principle authority-principle

# 查看相关实体
python -m influence_ontology_runtime.cli related jewelry-store-case
```

### 交互式 REPL

```bash
python -m influence_ontology_runtime.cli

influence> list principles
influence> get reciprocity-principle
influence> query type=Case principle=reciprocity-principle
influence> principle authority-principle
influence> search "稀缺"
influence> stats
influence> quit
```

---

## Python API

```python
from influence_ontology_runtime import load, OntologyStore

store = load("../influence_ontology.json")

# 基础查询
p = store.get_by_id("reciprocity-principle")
cases = store.get_cases_by_principle("reciprocity-principle")

# 图遍历
neighbors = store.get_neighbors("jewelry-store-case")
rels = store.get_relations("reciprocity-principle", direction="out")

# 全文搜索
results = store.search("稀缺")

# 跨层解释原则
exp = store.explain_principle("authority-principle")
```

---

## 测试

```bash
python -m pytest tests/ -v
```

---

## 架构

```
influence_ontology_runtime/
├── models.py      # Pydantic 实体/关系模型
├── loader.py      # JSON 加载
├── store.py       # 内存索引与查询服务
├── queries.py     # DSL 查询解析与执行
└── cli.py         # 命令行交互
```

---

## 数据

运行时直接读取 `../influence_ontology.json`，包含：

- 13 个影响力原则
- 49 个核心概念
- 40 个术语
- 111 个案例
- 47 个实验
- 136 个人物
- 35 条推理链
- 26 个策略/技巧
- 44 个行动步骤
- 25 条话术
- 42 个应用场景
- 166 条关系

---

*生成时间：2026-06-24*
