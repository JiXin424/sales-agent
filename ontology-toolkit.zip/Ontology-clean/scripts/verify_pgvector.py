"""V3: 验证 PG + PGVector 连通性"""

import asyncio
import asyncpg


async def main():
    try:
        conn = await asyncpg.connect(
            host="localhost",
            port=5432,
            database="ontology",
            user="ontology",
            password="ontology_dev_2026",
        )
        print("✅ PostgreSQL 连接成功")

        # 验证 PGVector 扩展
        await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
        version = await conn.fetchval(
            "SELECT extversion FROM pg_extension WHERE extname = 'vector'"
        )
        print(f"✅ PGVector 版本: {version}")

        # 测试向量表创建+插入+查询
        await conn.execute("DROP TABLE IF EXISTS test_embeddings")
        await conn.execute("""
            CREATE TABLE test_embeddings (
                id SERIAL PRIMARY KEY,
                content TEXT,
                embedding VECTOR(1024)
            )
        """)

        # 插入测试向量
        import random
        fake_vec = [random.random() for _ in range(1024)]
        await conn.execute(
            "INSERT INTO test_embeddings (content, embedding) VALUES ($1, $2)",
            "测试内容",
            str(fake_vec),
        )

        # 查询
        row = await conn.fetchrow("SELECT count(*) as cnt FROM test_embeddings")
        print(f"✅ 向量插入+查询成功，行数: {row['cnt']}")

        # 清理
        await conn.execute("DROP TABLE test_embeddings")
        await conn.close()

        print("\n✅ PG + PGVector 连通性验证完成")

    except Exception as e:
        print(f"❌ 连接失败: {e}")
        print("提示: 请先运行 docker compose up -d postgres")


if __name__ == "__main__":
    asyncio.run(main())
