#!/usr/bin/env python3
"""
fix_asr — 修复 Paraformer ASR 视频转写中的语音识别错别字

用 DeepSeek v4-pro 逐文件修复，保留所有数值、日期、百分比不变，
仅修正语音识别导致的错别字/同音字/乱码。
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
from md_optimizer import OpenAIClient

ASR_DIR = Path("/root/Project/apps/Ontology-clean/docs/ProductX_batch1/md/视频培训材料")
MODEL = "deepseek-v4-pro"
API_KEY = "DEEPSEEK_API_KEY_PLACEHOLDER"
BASE_URL = "https://api.deepseek.com"

PROMPT = """你是医学术语校正专家。以下文本来自语音识别(ASR)转写，包含大量同音字/错别字。

**核心规则**：
1. **只修正语音识别错误**，不改变原意、不添加内容、不删除内容
2. **所有数字、百分比、日期、时间、剂量、生存率等数值必须原封不动保留**
3. 修正方向：
   - 同音/近音字 → 正确医学术语（如"适应症A_ASRerr"→"适应症A"，"ProductX_ASRerr"→"ProductX"）
   - 乱码/断裂词 → 根据上下文还原（如"P量烷"→"PD-L1"，"活性_ASRerr"→"生物活性"）
   - 口语填充词（"就是说""然后呢""那个"等）→ 保留，这是口语转写特征
4. **产品名标准写法**：
   - "ProductX"（商品名®，GenericName）— 不要写"塞帕""三派""ProductX_ASRerr"等
   - "竞品E" — 不要写"竞品E_ASRerr"
   - "竞品C"（竞品C，BrandC）
   - "竞品D"（竞品D，Opdivo）
   - 其他 PD-1/PD-L1 产品名同样标准化
5. 输出格式与原 Markdown 完全一致

请直接输出修正后的全文，不要加任何说明。"""


def fix_file(client: OpenAIClient, md_path: Path) -> bool:
    """修复单个 ASR 文件"""
    name = md_path.name
    print(f"  🔧 {name} ...", end=" ", flush=True)

    content = md_path.read_text(encoding="utf-8")
    if len(content) < 500:
        print("跳过（太短）")
        return True

    try:
        result = client.chat_stream(
            system="你是专业的医学语音转写校正助手。",
            user=f"{PROMPT}\n\n---\n\n{content}",
            temperature=0.1,
            extra_body={
                "max_tokens": 16000,
                "reasoning_effort": "medium",
            },
        )

        # 验证关键数值未被改变
        # 抽查原文中的数字是否还在结果中
        import re
        orig_nums = set(re.findall(r'\d+\.?\d*%?', content))
        fixed_nums = set(re.findall(r'\d+\.?\d*%?', result))
        missing = orig_nums - fixed_nums
        if missing:
            nums_str = ", ".join(sorted(missing)[:10])
            print(f"⚠️ 丢失数值: {nums_str}")

        out_path = md_path.with_suffix(".fixed.md")
        out_path.write_text(result, encoding="utf-8")
        print(f"✅ {len(content)}→{len(result)} chars")
        return True

    except Exception as e:
        print(f"❌ {e}")
        return False


def main():
    files = sorted(ASR_DIR.glob("*.md"))
    if not files:
        print("❌ 未找到 ASR 文件")
        return

    print(f"\n{'='*60}")
    print(f"🔧 fix_asr — 修复 {len(files)} 个 ASR 转写文件")
    print(f"{'='*60}\n")

    client = OpenAIClient(api_key=API_KEY, base_url=BASE_URL, model=MODEL)

    ok = 0
    for f in files:
        if fix_file(client, f):
            ok += 1

    print(f"\n{'='*60}")
    print(f"✅ 完成：{ok}/{len(files)} 文件已修复")
    print(f"   输出：*.fixed.md（与原文件同目录）")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
