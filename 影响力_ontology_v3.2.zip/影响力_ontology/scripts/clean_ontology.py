#!/usr/bin/env python3
"""本体清洗脚本

把低质量的"description = 类型: name"格式清洗成真实有价值的描述。
- concept / term:     description ← definition
- reasoning_chain:    description ← premises → consequence + evidence
- script:             description ← 适用场景 + 话术
- experiment:         description ← method + 结论

原始文件保留为 .bak，清洗后写入 cleaned.json
"""

import json
import shutil
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SRC = BASE_DIR / "influence_ontology_enriched.json"
DST = BASE_DIR / "influence_ontology_cleaned.json"
BACKUP = BASE_DIR / "influence_ontology_enriched.json.bak2"


def is_self_repetition(name, desc):
    if not desc or not name:
        return False
    d = desc.strip()
    n = name.strip()
    prefixes = ['概念: ', '术语: ', '话术: ', '推理链: ', '实验: ', '策略: ',
                '场景: ', '案例: ', '行动步骤: ', '人物: ', '原则: ']
    for p in prefixes:
        if d.startswith(p):
            rest = d[len(p):].strip()
            if rest == n:
                return True
    return d == n


def join_parts(parts, sep=' | '):
    return sep.join(p for p in parts if p and p.strip())


def clean_concept_or_term(e):
    name = e.get('name', '')
    desc = e.get('description', '')
    if 'definition' in e and e['definition'] and not is_self_repetition(name, e['definition']):
        return e['definition'].strip()
    if is_self_repetition(name, desc):
        return ''
    return desc


def clean_reasoning_chain(e):
    name = e.get('name', '')
    parts = []
    for f in ['premises', 'reasoning', 'trigger', 'behavior', 'consequence']:
        v = e.get(f)
        if v and not is_self_repetition(name, v):
            parts.append(v.strip())
    ev = e.get('evidence')
    if ev:
        if isinstance(ev, list):
            ev_str = ', '.join(ev)
        else:
            ev_str = ev
        if ev_str.strip():
            parts.append(f"证据: {ev_str.strip()}")
    return join_parts(parts, ' → ')


def clean_script(e):
    name = e.get('name', '')
    parts = []
    ctx = e.get('context')
    if ctx and not is_self_repetition(name, ctx):
        parts.append(f"适用场景: {ctx.strip()}")
    text = e.get('text')
    if text and not is_self_repetition(name, text):
        parts.append(f"话术: {text.strip()}")
    if parts:
        return join_parts(parts, ' | ')
    desc = e.get('description', '')
    return '' if is_self_repetition(name, desc) else desc


def clean_experiment(e):
    name = e.get('name', '')
    parts = []
    method = e.get('method')
    if method and not is_self_repetition(name, method):
        parts.append(method.strip())
    con = e.get('conclusion')
    if con and not is_self_repetition(name, con):
        parts.append(f"结论: {con.strip()}")
    if parts:
        return join_parts(parts, ' | ')
    desc = e.get('description', '')
    return '' if is_self_repetition(name, desc) else desc


CLEANERS = {
    'concepts': clean_concept_or_term,
    'terms': clean_concept_or_term,
    'reasoning_chains': clean_reasoning_chain,
    'scripts': clean_script,
    'experiments': clean_experiment,
}


def main():
    if not SRC.exists():
        raise SystemExit(f"找不到源文件: {SRC}")

    print(f"读取本体: {SRC}")
    with open(SRC, 'r', encoding='utf-8') as f:
        data = json.load(f)

    stats = {}
    for type_key, cleaner in CLEANERS.items():
        entities = data.get(type_key, [])
        changed = 0
        empty_before = 0
        empty_after = 0
        for e in entities:
            before = e.get('description', '')
            if not before.strip():
                empty_before += 1
            new_desc = cleaner(e)
            if new_desc != before:
                changed += 1
                e['description'] = new_desc
            if not new_desc.strip():
                empty_after += 1
        stats[type_key] = {
            'total': len(entities),
            'changed': changed,
            'empty_before': empty_before,
            'empty_after': empty_after,
        }

    if not BACKUP.exists():
        shutil.copy2(SRC, BACKUP)
        print(f"原文件已备份: {BACKUP}")
    else:
        print(f"备份已存在（不覆盖）: {BACKUP}")

    with open(DST, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"清洗后写入: {DST}\n")

    print("清洗统计:")
    print(f"{'类型':<20}{'总数':<8}{'已改':<8}{'空(前)':<10}{'空(后)':<10}")
    print('-' * 56)
    for k, v in stats.items():
        print(f"{k:<20}{v['total']:<8}{v['changed']:<8}{v['empty_before']:<10}{v['empty_after']:<10}")


if __name__ == '__main__':
    main()
