"""背景知识上下文 — 从已入库实体生成结构化摘要，供后续抽取使用"""

import json
import logging
import os
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.ontology.models import Object, ObjectType, Link, LinkType

logger = logging.getLogger(__name__)

CONTEXT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "data")
CONTEXT_FILE = os.path.join(CONTEXT_DIR, "knowledge_context.json")

# 按 type 分组的展示顺序
TYPE_ORDER = [
    "Company", "Product", "Competitor", "Equipment",
    "Feature", "Spec", "Pricing", "Certification", "Award",
    "CustomerSegment", "Contact", "Partner",
    "Scenario", "Solution", "Disease", "Industry",
    "Advantage", "Policy", "Institution",
    "Objection", "SalesScript", "Case",
]

# 关系类型的展示顺序
LINK_ORDER = [
    "produces", "competes_with", "targets", "includes", "priced_at",
    "certified_for", "solves", "has_spec", "detects", "component_of",
    "part_of", "demonstrated_in", "uses", "triggers", "handled_by",
    "supported_by", "mandates", "belongs_to", "contact_at",
    "distributes", "awarded_to", "cooperates_with",
]


def _group_by_type(objects: list[dict]) -> dict[str, list[dict]]:
    grouped: dict[str, list[dict]] = {}
    for o in objects:
        t = o.get("type", "Unknown")
        grouped.setdefault(t, []).append(o)
    return grouped


def _build_text(groups: dict[str, list[dict]], links: list[dict]) -> str:
    """将实体和关系格式化为可读文本"""
    lines = ["# 九峰医疗销售知识本体 — 背景知识", ""]

    for t in TYPE_ORDER:
        items = groups.get(t, [])
        if not items:
            continue
        lines.append(f"## {t} ({len(items)})")
        for item in items:
            name = item.get("name", "?")
            props = item.get("properties", {})
            if props:
                prop_str = ", ".join(f"{k}: {v}" for k, v in props.items() if v)
                lines.append(f"- {name} ({prop_str})")
            else:
                lines.append(f"- {name}")
        lines.append("")

    if links:
        lines.append(f"## 关系 ({len(links)})")
        for link in links[:200]:
            lines.append(f"- {link.get('source','?')} —[{link.get('type','?')}]→ {link.get('target','?')}")
        if len(links) > 200:
            lines.append(f"- ... (共 {len(links)} 条)")
        lines.append("")

    return "\n".join(lines)


async def build_context_from_db(session: AsyncSession) -> dict:
    """从数据库加载所有实体和关系，生成背景知识"""
    # 加载所有实体
    stmt = (
        select(Object)
        .options(selectinload(Object.type))
    )
    objects = (await session.execute(stmt)).scalars().all()

    obj_list = []
    for o in objects:
        obj_list.append({
            "id": o.id,
            "name": o.name,
            "type": o.type.name if o.type else "Unknown",
            "properties": o.properties or {},
        })

    # 加载所有关系
    stmt = (
        select(Link)
        .options(selectinload(Link.type), selectinload(Link.source), selectinload(Link.target))
    )
    links = (await session.execute(stmt)).scalars().all()

    link_list = []
    for l in links:
        link_list.append({
            "source": l.source.name if l.source else "?",
            "target": l.target.name if l.target else "?",
            "type": l.type.name if l.type else "?",
        })

    groups = _group_by_type(obj_list)
    text = _build_text(groups, link_list)

    context = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total_objects": len(obj_list),
        "total_links": len(link_list),
        "type_counts": {t: len(items) for t, items in groups.items()},
        "objects": obj_list,
        "links": link_list,
        "text": text,
    }

    return context


async def save_context(session: AsyncSession) -> str:
    """生成并持久化背景知识到文件"""
    context = await build_context_from_db(session)

    os.makedirs(CONTEXT_DIR, exist_ok=True)
    with open(CONTEXT_FILE, "w", encoding="utf-8") as f:
        json.dump(context, f, ensure_ascii=False, indent=2)

    logger.info(f"背景知识已保存: {context['total_objects']} 实体, {context['total_links']} 关系")
    return context["text"]


def load_context_text() -> str | None:
    """从文件加载背景知识文本（用于抽取时注入 prompt）"""
    if not os.path.exists(CONTEXT_FILE):
        return None
    try:
        with open(CONTEXT_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        text = data.get("text", "")
        if text:
            return text
    except Exception as e:
        logger.warning(f"加载背景知识失败: {e}")
    return None
