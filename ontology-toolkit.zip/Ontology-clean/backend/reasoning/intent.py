"""意图分类 — DeepSeek Flash

Phase 2 优化记录：
- 新增10个 comparison/prep/scenario/objection 的 few-shot 示例
- 新增"关键区分规则"显式指导边界判断
- 解决的核心误判：comparison→entity_info, prep→scenario, scenario→entity_info
"""

import json
import logging

from backend.llm import chat_flash

logger = logging.getLogger(__name__)

INTENT_PROMPT = """你是销售知识问答系统的意图分类器。分析用户问题，返回意图和关键实体。

意图类型（注意区分，这是最关键的一步）：
- entity_info: 查询某个实体的纯信息（"X是什么"、"X有哪些"、"X有什么特点"、"X包括什么"）
- relation_query: 查询实体之间的关系
- comparison: 涉及两个或多个实体的对比/差异/优劣（"X和Y比"、"X有什么优势"、"谁更好"、"区别"、"差异"、"对比"）
- scenario: 场景应用/业务流程/技术架构（"用在什么场景"、"解决什么问题"、"流程是什么"、"架构"）
- prep: 拜访准备/销售准备/推荐方案/如何推销（"帮我准备"、"推荐什么方案"、"切入点"、"怎么推销"、"核心卖点"）
- objection: 异议处理/客户质疑/说服（"客户说"、"怎么回应"、"怎么应对"、"怎么说"、"如何说服"）
- general: 一般性问题或闲聊

关键区分规则：
- "X和Y的区别/差异/对比" → comparison（不是entity_info）
- "X的优势/先发优势" 且涉及对比语境 → comparison（不是entity_info）
- "推荐什么方案/适合什么方案" → prep（不是scenario）
- "X的流程/架构/全流程" → scenario（不是entity_info）
- "如果客户问/如果卫健委问" → objection（不是scenario）

【scenario vs prep 核心区分】这是最容易混淆的一对：
- scenario：分析某个政策/技术/案例在销售中的**应用场景和作用机制**。关键词："意味着什么"、"有什么帮助"、"说明了什么"、"如何帮助"、"对...有什么影响"
- prep：销售人员要**做具体准备动作**。关键词："帮我准备"、"推荐什么方案"、"切入点"、"核心卖点"、"怎么推销"
- "如何用X推动销售/拓展业务" → prep（因为有"推动销售"这个动作）
- "如何用X帮助客户完成考核" → scenario（分析X帮助客户的方式，不是销售准备）
- "X的经验数据对销售有什么帮助" → scenario（分析数据的价值，不是准备动作）
- "如何用政策文件来推动预算审批" → scenario（分析政策文件在审批流程中的作用）
- "如何利用X创建活动拓展业务" → scenario（分析X在业务拓展中的应用方式）

示例：
- "九峰的核心产品有哪些" → entity_info
- "客户说太贵了怎么回应" → objection
- "九峰和智影有什么区别" → comparison
- "如何利用政策推动销售" → prep
- "给卫健委主任汇报重点讲什么" → prep
- "九峰的三类证意味着什么" → entity_info
- "WHO推荐CAD技术意味着什么" → entity_info
- "如何用政策文件推动预算审批" → prep
- "如果卫健委问为什么选九峰" → objection
- "九峰和智影在肺结核筛查领域的核心差异" → comparison
- "在招标场景中九峰的三类证能带来什么优势" → comparison
- "国内AI影像厂商中持有肺结核三类证的有哪些" → comparison
- "九峰在基层筛查领域的先发优势" → comparison
- "九峰的防筛诊治管康全流程包括哪些环节" → scenario
- "医共体影像中心方案的技术架构" → scenario
- "如何利用65岁以上老年人体检政策推动销售" → prep
- "一个三甲医院要建设AI影像诊断中心推荐什么方案" → prep
- "预算20万左右的基层医院适合什么方案" → prep
- "九峰的交付服务流程是怎样的" → scenario
- "九峰在西藏的成功案例说明了什么" → scenario
- "如何用九峰的解决方案帮助卫健委完成考核指标" → prep
- "九峰产品的定价和竞品相比如何" → comparison
- "代理商要向医院推销九峰产品核心卖点是什么" → prep
- "如何用结核病防治成本效益数据说服领导投资" → prep
- "WHO推荐CAD技术用于结核病筛查意味着什么" → scenario
- "如何用'在有鱼的地方打鱼'这个策略指导销售" → scenario
- "如何利用'无结核社区'创建活动拓展业务" → scenario
- "九峰产品如何帮助地方完成结核病防治考核指标" → scenario
- "如何用政策文件来推动预算审批" → scenario
- "广西玉林结核病防治的经验数据对销售有什么帮助" → scenario

输出 JSON：
{{"intent": "意图类型", "entities": ["实体1", "实体2"], "params": {{}}}}

用户问题：{question}"""


async def classify_intent(question: str) -> dict:
    """分类用户问题意图，返回 intent + entities + params"""
    result_text = await chat_flash(
        messages=[{"role": "user", "content": INTENT_PROMPT.format(question=question)}],
        max_tokens=500,
        response_format={"type": "json_object"},
    )

    try:
        result = json.loads(result_text)
    except json.JSONDecodeError:
        logger.warning(f"意图分类 JSON 解析失败: {result_text[:200]}")
        result = {"intent": "general", "entities": [], "params": {}}

    return {
        "intent": result.get("intent", "general"),
        "entities": result.get("entities", []),
        "params": result.get("params", {}),
    }
