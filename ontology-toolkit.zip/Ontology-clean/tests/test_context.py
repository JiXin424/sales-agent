"""测试背景知识上下文系统"""

import json
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.knowledge.context import (
    _group_by_type,
    _build_text,
    load_context_text,
    CONTEXT_FILE,
)


# --- 测试数据 ---

SAMPLE_OBJECTS = [
    {"id": 1, "name": "九峰医疗", "type": "Company", "properties": {"founded": "2015"}},
    {"id": 2, "name": "肺结核AI评估软件", "type": "Product", "properties": {}},
    {"id": 3, "name": "智影医疗", "type": "Competitor", "properties": {}},
    {"id": 4, "name": "基层医院", "type": "CustomerSegment", "properties": {}},
    {"id": 5, "name": "敏感度94.2%", "type": "Spec", "properties": {"value": "94.2%"}},
]

SAMPLE_LINKS = [
    {"source": "九峰医疗", "target": "肺结核AI评估软件", "type": "produces"},
    {"source": "九峰医疗", "target": "智影医疗", "type": "competes_with"},
    {"source": "肺结核AI评估软件", "target": "基层医院", "type": "targets"},
]


# --- 单元测试 ---


def test_group_by_type():
    """测试实体按类型分组"""
    groups = _group_by_type(SAMPLE_OBJECTS)

    assert "Company" in groups
    assert "Product" in groups
    assert "Competitor" in groups
    assert "CustomerSegment" in groups
    assert "Spec" in groups

    assert len(groups["Company"]) == 1
    assert groups["Company"][0]["name"] == "九峰医疗"
    assert len(groups["Spec"]) == 1


def test_group_by_type_empty():
    """空列表应返回空 dict"""
    assert _group_by_type([]) == {}


def test_build_text():
    """测试文本生成"""
    groups = _group_by_type(SAMPLE_OBJECTS)
    text = _build_text(groups, SAMPLE_LINKS)

    assert "九峰医疗" in text
    assert "肺结核AI评估软件" in text
    assert "智影医疗" in text
    assert "produces" in text
    assert "competes_with" in text
    assert "94.2%" in text
    assert "founded: 2015" in text


def test_build_text_no_links():
    """无关系时不应报错"""
    groups = _group_by_type(SAMPLE_OBJECTS)
    text = _build_text(groups, [])
    assert "九峰医疗" in text
    assert "关系" not in text


def test_build_text_empty():
    """空数据应生成标题"""
    text = _build_text({}, [])
    assert "背景知识" in text


def test_load_context_text_missing_file():
    """文件不存在时应返回 None"""
    with tempfile.TemporaryDirectory() as tmpdir:
        import backend.knowledge.context as ctx
        old = ctx.CONTEXT_FILE
        ctx.CONTEXT_FILE = os.path.join(tmpdir, "nonexistent.json")
        try:
            result = load_context_text()
            assert result is None
        finally:
            ctx.CONTEXT_FILE = old


def test_load_context_text_valid_file():
    """有效 JSON 文件应返回 text 字段"""
    import backend.knowledge.context as ctx

    with tempfile.TemporaryDirectory() as tmpdir:
        fake_path = os.path.join(tmpdir, "knowledge_context.json")
        fake_data = {
            "generated_at": "2026-01-01T00:00:00",
            "total_objects": 5,
            "total_links": 3,
            "type_counts": {},
            "objects": [],
            "links": [],
            "text": "## 测试背景知识\n\n- 九峰医疗",
        }
        with open(fake_path, "w") as f:
            json.dump(fake_data, f)

        old = ctx.CONTEXT_FILE
        ctx.CONTEXT_FILE = fake_path
        try:
            result = load_context_text()
            assert result is not None
            assert "测试背景知识" in result
        finally:
            ctx.CONTEXT_FILE = old


def test_load_context_text_invalid_json():
    """损坏的 JSON 应返回 None 而非抛异常"""
    import backend.knowledge.context as ctx

    with tempfile.TemporaryDirectory() as tmpdir:
        fake_path = os.path.join(tmpdir, "knowledge_context.json")
        with open(fake_path, "w") as f:
            f.write("not valid json{{{")

        old = ctx.CONTEXT_FILE
        ctx.CONTEXT_FILE = fake_path
        try:
            result = load_context_text()
            assert result is None
        finally:
            ctx.CONTEXT_FILE = old


# --- 集成测试：DB → context ---


@pytest.mark.asyncio
async def test_build_context_from_db(db_session):
    """测试从数据库构建背景知识"""
    from backend.ontology.crud import ensure_default_types, create_object, create_link
    from backend.knowledge.context import build_context_from_db

    await ensure_default_types(db_session)

    await create_object(db_session, "Company", "九峰医疗", {"founded": "2015"})
    await create_object(db_session, "Product", "AI评估软件")
    await create_object(db_session, "Competitor", "智影医疗")
    await db_session.flush()

    await create_link(db_session, "九峰医疗", "AI评估软件", "produces")
    await create_link(db_session, "九峰医疗", "智影医疗", "competes_with")
    await db_session.flush()

    context = await build_context_from_db(db_session)

    assert context["total_objects"] >= 3
    assert context["total_links"] >= 2
    assert "九峰医疗" in context["text"]
    assert "produces" in context["text"]
    assert "Company" in context["type_counts"]


@pytest.mark.asyncio
async def test_save_and_load_context(db_session):
    """测试保存和加载背景知识文件"""
    import backend.knowledge.context as ctx
    from backend.ontology.crud import ensure_default_types, create_object

    await ensure_default_types(db_session)
    await create_object(db_session, "Company", "测试公司")
    await db_session.flush()

    with tempfile.TemporaryDirectory() as tmpdir:
        old = ctx.CONTEXT_FILE
        ctx.CONTEXT_FILE = os.path.join(tmpdir, "knowledge_context.json")
        try:
            text = await ctx.save_context(db_session)
            assert "测试公司" in text

            loaded = load_context_text()
            assert loaded is not None
            assert "测试公司" in loaded
        finally:
            ctx.CONTEXT_FILE = old
