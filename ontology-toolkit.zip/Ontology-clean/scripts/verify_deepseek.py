"""V1: 验证 DeepSeek API 连通性 (Pro + Flash)"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openai import AsyncOpenAI
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))


async def main():
    api_key = os.getenv("DEEPSEEK_API_KEY")
    base_url = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

    if not api_key:
        print("❌ DEEPSEEK_API_KEY 未配置")
        return

    client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    # 测试 Pro 模型
    print("测试 DeepSeek V4 Pro...")
    try:
        resp = await client.chat.completions.create(
            model="deepseek-v4-pro",
            messages=[{"role": "user", "content": "你好，请用一句话介绍你自己"}],
            max_tokens=100,
        )
        print(f"  ✅ Pro: {resp.choices[0].message.content}")
        print(f"  Tokens: {resp.usage.prompt_tokens}in / {resp.usage.completion_tokens}out")
    except Exception as e:
        print(f"  ❌ Pro 失败: {e}")

    # 测试 Flash 模型
    print("\n测试 DeepSeek V4 Flash...")
    try:
        resp = await client.chat.completions.create(
            model="deepseek-v4-flash",
            messages=[{"role": "user", "content": "1+1=?"}],
            max_tokens=10,
        )
        print(f"  ✅ Flash: {resp.choices[0].message.content}")
        print(f"  Tokens: {resp.usage.prompt_tokens}in / {resp.usage.completion_tokens}out")
    except Exception as e:
        print(f"  ❌ Flash 失败: {e}")

    print("\n✅ DeepSeek API 连通性验证完成")


if __name__ == "__main__":
    asyncio.run(main())
