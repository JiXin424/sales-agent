# 产品X材料 — 第一批（已脱敏）

> 整理日期：2026-06-18
> 本目录包含产品X（Product X）2026年 Q1-Q2 培训材料，涵盖 PPTX/PDF 课件、会议记录、视频转写等。

---

## 目录结构

```
产品X材料第一批/
├── README.md                         ← 本文件
├── 培训材料/                          ← ★ 主工作区（去重整理后 31 个文件）
│   ├── 2026 Q1/
│   │   ├── 2025.12.11 irAE/          irAE识别与管理（皮肤毒性 V1.pdf）
│   │   ├── 2025.12.25 适应症C/          适应症C基础知识.pptx + 产品X在适应症C中的应用.pptx
│   │   ├── 2026.1.8-适应症B/            会议纪要/转写原文 + 适应症B+特殊人群筛查 PPT
│   │   ├── 2026.1.15适应症A/           (会议记录已转 mp4，见下方)
│   │   ├── 2026.1.22适应症A疾病基础/   适应症A疾病基础.pptx + 产品X在适应症A中的应用V3.pptx
│   │   ├── 2026.2.26 irAE/           irAE识别与管理（二）V1.2.pdf + （四）V1.pdf
│   │   ├── 2026.3.12 FAQ & 临床研究汇总/  产品X FAQ.pptx
│   │   └── 2026.3.25 适应症A免疫治疗进展/  适应症A免疫治疗进展2026.3.pptx
│   ├── 2026 Q2/
│   │   ├── 2026 Q2 培训计划.pptx
│   │   ├── 2026.4.9 产品X机制、临床研究、剂量调整/
│   │   ├── 2026.5.7/话术-专家A/       最终版 PDF + 思维导图
│   │   ├── 2026.5.21 2026 Conference-A/       肿瘤领域A最新研究进展 + 参考论文
│   │   ├── 2026.6.11/                irAE管理 + Guideline-Body毒性指南
│   │   └── 2026.6.18 其他瘤种数据/     临床研究汇总
│   └── 视频培训材料/                   ← ★ 7 个视频的结构化 Markdown 转写
│       ├── 适应症C基础知识及产品X在适应症C中的应用.md      (65分钟)
│       ├── 适应症B基础知识及产品X在适应症B中的应用.md      (70分钟)
│       ├── 适应症A疾病基础及产品X在适应症A中的应用.md  (56分钟)
│       ├── 适应症A培训会议记录.md                         (48分钟)
│       ├── 适应症A免疫治疗进展.md                          (64分钟)
│       ├── 产品X产品培训及irAE管理.md               (42分钟)
│       └── 产品X FAQ及临床研究汇总.md                (48分钟)
├── bak/                              ← 冗余/旧版本文件备份（14 个）
│   └── 文件迁移清单.txt               ← 每个文件的迁移原因和原路径
├── mp4/                              ← 原始视频及提取的音频
│   ├── *.mp4                         7 个原始视频（787MB）
│   ├── .extracted_audio/             拆出的原始 AAC 音频流 (.m4a)
│   └── audio/.asr_output/           Paraformer v2 转写原始输出
└── 培训材料md/                        ← 培训材料镜像转换（30 个 .md，文件夹结构同 培训材料/）
```

---

## 内容覆盖

| 主题 | 课件 | 视频转写 | 会议记录 |
|------|:----:|:--------:|:--------:|
| 适应症C基础知识 + 产品X应用 | ✅ | ✅ | — |
| 适应症B基础知识 + 产品X应用 | ✅ | ✅ | ✅ DOCX |
| 适应症A疾病基础 + 产品X应用 | ✅ | ✅ | — |
| 适应症A免疫治疗进展 (2026 Conference-A/Conference-B) | ✅ | ✅ | — |
| 适应症A销售培训会议 | — | ✅ | — |
| irAE 识别与管理 (皮肤/胃肠/骨骼肌肉/心肺肝) | ✅ | ✅ | — |
| 产品X FAQ + 临床研究汇总 | ✅ | ✅ | — |
| 产品X机制+剂量调整+给药方案 | ✅ | — | — |
| 销售话术 (五竞品 + 市场策略) | ✅ | — | — |
| 代理商培训 FAQ (88问完整版) | ✅ | — | — |
| 用药机会点思维导图 | PNG | — | — |

---

## 数据整理记录

### 格式转换完成（2026-06-18 21:30）

共 31 个文件转换完成（含 1 个直接新增的 Markdown，总计 38 个），其中：
- 29 个文件通过标准管道（PyMuPDF 渲染 + qwen3.6-plus 视觉识别 + DeepSeek v4-pro 整理）
- `2026 Conference-A摘要集.pdf`（1158页/49MB，全英文学术摘要 → 已移至 bak/）
- `中国肿瘤免疫治疗获批适应症一览.png`（2023×7359 信息图）通过 qwen3.6-plus 视觉分析
- `FAQ/产品X代理商培训FAQ_88问_完整版.md`（51KB，直接新增，无需转换）

### 去重清理（2026-06-18）

| 操作 | 数量 | 节省空间 |
|------|:----:|:--------:|
| PPTX/PDF 同版本冗余 → 仅保留 PDF | 5 | ~80MB |
| 多版本冲突 → 仅保留最新版 PDF | 4 | ~1MB |
| 跨目录完全相同文件 → 保留最新目录副本 | 3 | ~47MB |
| XMind 文件移至 bak | 1 | 237KB |
| **小计 (→ bak/)** | **14** | **~128MB** |
| MP4 视频集中至 mp4/ | 7 | 787MB |
| MP4 → AAC 音频流拆出 | 7 | 330MB |
| 音频 → Paraformer v2 转写 | 7 | — |
| 转写 → 结构化 Markdown | 7 | 276KB |

### 文件统计

| 目录 | 文件数 | 大小 |
|------|:------:|------|
| `培训材料/`（去重后） | 31 | ~200MB |
| `培训材料/视频培训材料/` | 7 | 276KB |
| `bak/` | 14 | ~125MB |
| `mp4/` | 66 | ~1.3GB |
| `培训材料md/` | 30 | ~2.1MB（✅ 已完成） |

---

## 格式转换与恢复机制

### 批量转换（batch_mirror_convert.py）

将 `培训材料/` 中所有 PPTX/PDF/DOCX/PNG 等格式文件，通过 `convert.py`（PyMuPDF 渲染 + qwen3.6-plus 视觉识别 + DeepSeek v4-pro 文本整理）转为 Markdown，保持文件夹结构镜像输出到 `培训材料md/`。

```bash
cd /root/Project-Agent/apps/ready/AFC2md
python3 batch_mirror_convert.py
```

### 断点续传

脚本每完成一个文件就写入 `_convert_state.json`，进程被中断后重新运行自动跳过已完成的文件：

```bash
# 查看当前进度
python3 batch_mirror_convert.py --status

# 从中断处继续（自动跳过已完成，重试失败）
python3 batch_mirror_convert.py
```

状态文件位置：`培训材料md/_convert_state.json`，每个文件状态为 `pending` / `done` / `failed`。

### 重试失败文件

失败的文件状态标记为 `failed`，再次运行脚本会自动重试。如需强制重新转换某个文件，从 `_convert_state.json` 中删除对应条目或将其状态改为 `pending`。

---

## 使用建议

1. **快速查阅**：优先看 `培训材料/视频培训材料/` 中的 Markdown 转写，已修正语音识别错别字并按主题分段
2. **课件原文**：PPTX/PDF 在 `培训材料/2026 Q1-Q2/` 对应日期子目录中
3. **原始视频**：在 `mp4/` 目录，如需重新观看
4. **已移除的旧版本**：在 `bak/`，如需恢复可查看 `bak/文件迁移清单.txt`

## 维护说明

- 新增培训材料放入 `培训材料/` 对应季度的日期子目录
- 视频文件统一放入 `mp4/`，转写后 Markdown 放入 `培训材料/视频培训材料/`
- PDF 优先于 PPTX；新版本替代旧版本时，旧版移至 `bak/`

---

## 全流程处理记录（自动化开发参考）

### 文件分级体系

所有 `.md` 文件按来源标注置信度：

| 级别 | 来源 | 特征 | 处理要求 |
|:----:|------|------|------|
| 🟢 **金标** | FAQ 88问、访谈整理 | 人工编写/校对，可直接信任 | 直接注入本体 + 作为交叉验证锚点 |
| 🟡 **银标** | PPTX/PDF → PyMuPDF + 视觉OCR | 文字准确但可能有 OCR/排版误差 | 需抽查数值，自动术语标准化 |
| 🔴 **铜标** | 视频培训材料 → Paraformer ASR → DeepSeek 修复 | 语音识别残留错字，已修一轮 | 需额外校验，不用于关键数值引用 |

### 首次处理流程（2026-06-18 第一轮）

```
Step 1: 格式转换
  培训材料/ (PPTX/PDF/DOCX/PNG)
  ├─ >40页 或 >10MB → PyMuPDF 直接文字提取（跳过 OCR）
  └─ 其他 → 渲染图片 → qwen3.6-plus 视觉识别 → DeepSeek 整理
  → 培训材料md/ (31 + 7 视频 = 38 个 .md)

Step 1.5: 文件检查
  ├─ 大小摸底：识别 4 个 >100KB 大文件
  ├─ Conference-A摘要集 (2.1MB, 1158页, 全英文) → 移至 bak/
  └─ 新增 FAQ/产品X代理商培训FAQ_88问_完整版.md (51KB, 金标)

Step 2: 构建本体 (build_ontology.py)
  ├─ 38 文件, --workers 3 → 6, --batch-size 5
  ├─ 问题1: DeepSeek v4-pro 推理链过长 → API 挂起
  │  修复: reasoning_effort: "medium" (ontology_extractor.py)
  ├─ 问题2: 输出缓冲导致进度不可见
  │  修复: PYTHONUNBUFFERED=1 + stderr debug 日志
  ├─ 问题3: redirect_stdout 吞掉主线程进度打印
  │  发现但未修复（不影响处理结果）
  └─ 产出: 主体文件.md (16K) + ontology.json (348K, 696 实体, 840 关系)

Step 3: 交叉验证
  ├─ 发现 ASR 视频转写存在严重错别字
  │  (产品名/适应症/生物标志物 误识别严重)
  ├─ fix_asr.py: DeepSeek 逐文件修复 7 个 ASR 文件
  └─ 备份原始为 .asr_orig.bak

Step 2 (redo): ASR 修复后重建本体
  ├─ Phase 2 timeout=600s 不足 → 改为 1800s
  ├─ 加入断点续跑: 每 Phase 产出存在则跳过
  └─ 产出: 主体文件_v2.md (16K) + ontology_v2.json (300K)

Step 3 (规则去重): phase3_fix_ontology
  ├─ LLM 方案失败: 696 实体 JSON 太大 (300KB), API 返回格式错误
  ├─ 改为 Python 规则: 同 type + 标准化名称 → 合并 properties
  ├─ 516 对疑似重复 → 实际 0 合并 (不同 type 的实体名相似但合法)
  └─ 产出: 主体文件_fixed.md (64K) + ontology_fixed.json (300K)

Step 4: 文档优化 (md_optimizer.py)
  ├─ MAX 13 策略, --workers 10
  └─ 产出: 培训材料md-优化/ (38 文件, 924KB)
```

### 增量文件处理流程（2026-06-19 第二轮）

新增 `培训材料md/访谈整理/` 目录（4 个金标文件，共 44KB）：

| 文件 | 大小 | 内容 |
|------|:----:|------|
| 综合销冠行为库_信任建立_需求挖掘_价值传递.md | 16K | 销售行为最佳实践 |
| 某药企_医生独特价值.md | 8K | 产品核心价值主张 |
| 某药企_医生卖点清单.md | 12K | 医生沟通关键卖点 |
| patient_winning_behaviors_患者价值.md | 8K | 患者获益行为 |

```
增量流程:
  1. 新 .md 直接放入 培训材料md/ 对应子目录（金标文件无需转换）
  2. 重新运行 auto_pipeline.py (Phase 1→2→3→4)
     ├─ Phase 1: ASR 修复 → 跳过（已完成）
     ├─ Phase 2: build_ontology → 重新扫描全部 42 文件
     ├─ Phase 3: 实体去重 → 重新合并
     └─ Phase 4: md_optimizer → 重新优化全部 42 文件
  3. 交叉验证 (A+B+C):
     ├─ A. 自动一致性扫描: 正则扫全库，标产品名变体/数值矛盾/ASR残留
     ├─ B. DeepSeek 抽样精校: 每级各取样，逐字比对
     └─ C. 金标交叉验证: FAQ+访谈 5个金标文件 → grep 全库标矛盾
  4. 汇总: 🟢金标印证 / 🟡数值偏差 / 🔴明显错误 + 置信度加权 + 修复建议
```

### 关键教训

| # | 教训 | 影响 | 解决方案 |
|---|------|------|------|
| 1 | `redirect_stdout` 在线程池中吞掉主线程 print | 进度不可见 | 用 stderr 输出 debug + `PYTHONUNBUFFERED=1` |
| 2 | DeepSeek v4-pro 推理链无上限导致 API 超时 | 进程卡死 | `reasoning_effort: "medium"` |
| 3 | `budget_tokens` 非有效 DeepSeek 参数 | API 静默挂起 | 换 `reasoning_effort` |
| 4 | 大 JSON (300KB) 送 LLM 修复杂返回格式错误 | Phase 3 失败 | 改用 Python 规则去重 |
| 5 | `subprocess.run(timeout=600)` 不够 | Phase 2 超时 | 改 1800s + 断点续跑 |
| 6 | 文件来源决定置信度，不能同等对待 | 低质 ASR 污染本体 | 金标/银标/铜标分级体系 |
| 7 | 同 type 实体名相似不一定是重复 | 516 对假阳性 | 仅合并同 type + 完全标准化匹配 |

---

## 知识引擎管道（Ontology-clean + 向量检索优化工具 v3）

### 架构概览

本批材料通过统一管道同时注入 **两个后端**，形成互补的双通道检索能力：

```
客户文档 (.pptx/.pdf/.docx/.xlsx/.md)
        │
        ▼  convert.py                   格式转换 → 原始 .md
        │
        ▼  build_ontology.py            DeepSeek 实体+关系提取
        │                               输出: 主体文件.md (本体背景知识, ~8000 字)
        │
        ▼  md_optimizer.py              MAX 13 策略文档优化
        │                               YAML 前置元数据 / FAQ / 检索锚点
        │                               输出: 产品X材料第一批-优化/
        │
        ├─────────────────────────────────────────────────────┐
        ▼                                                     ▼
  通道 A: 本体后端 (PostgreSQL)                     通道 B: 向量守护进程 (Qdrant)
        │                                                     │
  process_document()                                daemon L1 → L2 → L3
  ├─ DeepSeek 提取实体+关系                        ├─ 按实体智能分块 (max 500字)
  ├─ DashScope 嵌入 (1024维)                       ├─ DashScope 嵌入 (1024维)
  ├─ 存入 objects/links 表                        ├─ 存入 5 领域集合
  └─ 构建知识上下文.json                           └─ 实体卡片索引 v3_entities
        │                                                     │
        ▼                                                     ▼
  实体图查询 + 多跳图遍历                         5 库语义搜索 + 领域分析
  (精确实体查找, 关系发现)                          (段落语义匹配, 检索锚点命中)
        │                                                     │
        └─────────────┬──────────────────────────────────────┘
                      ▼
              统一编排器 (SearchOrchestrator)
              双通道并行搜索 → 上下文合成 → 冲突检测 → 响应生成
```

### 两通道能力对比

| 维度 | 通道 A：本体后端 | 通道 B：Qdrant 向量库 |
|------|:---:|:---:|
| 数据库 | PostgreSQL + pgvector | Qdrant (5 领域集合 + 1 实体集合) |
| 搜索粒度 | 实体级别 (名字 → 嵌入) | 段落级别 (500字分块 → 嵌入) |
| 核心能力 | 精确实体查找、多跳图遍历 | 语义搜索、检索锚点命中、FAQ 匹配 |
| 关系发现 | NetworkX 图 BFS (2-3跳) | 实体图距离重排序 (GraphDistanceReranker) |
| 领域路由 | 意图分类 (7 种) | 领域分类 (5 库: 产品/策略/竞品/行为/客户) |
| 输出形式 | 结构化实体卡片 + 关系列表 | 上下文段落 + 领域分析 + 约束规则 |
| 特有功能 | 版本感知实体合并、冲突检测 | 查询改写 (J)、检索失败反馈闭环 (F) |

### 管道步骤详解

#### Step 1 — 格式转换 (`batch_mirror_convert.py` → `convert.py`)

将非 Markdown 文档（PPTX/PDF/DOCX/XLSX/PNG）转为 Markdown。本批材料中视频已通过 Paraformer v2 转写为 `.md`，课件 PPTX/PDF 通过以下管道转换：

```
源文件 → PyMuPDF/LibreOffice 渲染为图片 (4x分辨率)
       → qwen3.6-plus 视觉识别提取文字
       → DeepSeek v4-pro 整理为结构化 Markdown
```

输出保持源目录结构镜像到 `培训材料md/`，支持断点续传。

**转换策略约束**（✅ 已实装到 `convert.py`）：

| 条件 | 策略 |
|------|------|
| 页数 > 40 | 跳过视觉 OCR，仅用 PyMuPDF 直接提取文字 |
| 文件 > 10MB | 同上，跳过视觉 OCR |
| 页数 ≤ 40 且 ≤ 10MB | 标准管道（渲染 → qwen3.6-plus 视觉 → DeepSeek 整理） |

> 例：Conference-A摘要集（1158页/49MB）同时触发两个条件 → 仅文字提取。

```bash
cd /root/Project-Agent/apps/ready/AFC2md
python3 batch_mirror_convert.py          # 全量转换（自动跳过已完成）
python3 batch_mirror_convert.py --status # 查看进度
# → 培训材料md/*.md（31 个文件，结构同 培训材料/）
```

#### Step 1.5 — 分批规划（⚠️ 运行 build_ontology 前必读）

`build_ontology.py` 默认 `--max-doc-chars 4000`，即每个文件只取前 4000 字符送入 LLM。大文件若不预拆分，绝大部分内容将被截断丢弃。

**约束（✅ 已实装到 `build_ontology.py`，reasoning 上限 5000 token 已实装到 `ontology_extractor.py`）**：

| 约束 | 值 | 说明 |
|------|:--:|------|
| 单文件截断 | 4000 字符 | `--max-doc-chars`，超出部分丢弃 |
| 每批上下文上限 | 200K token | `build_ontology.py` 每批处理前校验 + 警告 |
| 大文件跳过 OCR | >40页 或 >10MB | `convert.py` 自动检测 → `_pdf_text_only` / `_pptx_text_only` |
| 大文件预拆分 | >50KB | `split_large_files.py`（新工具，沿页面/标题边界拆分） |
| Reasoning 控制 | `"medium"` | `ontology_extractor.py` `reasoning_effort: "medium"` |

##### 文件大小分布（38 个 .md，总计 ~4.1MB）

| 量级 | 数量 | 典型文件 |
|------|:----:|----------|
| 🔴 超大 (>1MB) | 1 | Conference-A摘要集 (2.1MB, 1158页) |
| 🟠 大型 (100-300KB) | 3 | 毒性管理指南Guideline-Body (251KB), Conference-A卵巢癌-竞品D (201KB), 适应症A免疫治疗进展 (147KB) |
| 🟡 中型 (50-100KB) | 5 | Conference-A卵巢癌 (113KB), Conference-A肿瘤领域A进展 (83KB), 临床研究汇总 (78KB), Conference-A适应症A-恒瑞 (67KB), irAE心脏 V2 (63KB) |
| 🟢 小型 (<50KB) | 29 | Study-B-Gastric (62KB) 及以下 |

##### 预拆分策略

| 文件 | 原始大小 | 拆分方式 | 预计块数 |
|------|:--------:|----------|:--------:|
| Conference-A摘要集 | 2.1MB | 按页拆分，每 50 页一个文件 (~90KB/块)，从 `<!-- page N -->` 注释处切割 | ~24 块 |
| 毒性管理指南Guideline-Body | 251KB | 按 `##` 标题边界拆分为 3-4 段，保持章节完整 | 3-4 块 |
| Conference-A卵巢癌-竞品D | 201KB | 按 `##` 标题边界拆分 2-3 段 | 2-3 块 |
| 适应症A免疫治疗进展 | 147KB | 按幻灯片边界 (`---`) 拆分 2 段 | 2 块 |

其余 34 个文件各 ≤113KB，`--max-doc-chars 4000` 下每文件约覆盖 40-100% 内容，无需拆分。

##### 分批执行计划

拆分后总文件数约 **66-70 个**，按每批 5 个文件编排：

| 批次 | 内容 | 预估大小 |
|:----:|------|:--------:|
| 1-2 | 视频培训材料 7 个 + Q1 小文件 3 个 | ~30-50KB/文件 |
| 3-5 | Q1 中型文件 + Q2 小型文件 | ~40-60KB/文件 |
| 6-8 | Q2 中型文件 (50-100KB) | ~50-80KB/文件 |
| 9-11 | Conference-A摘要集 拆分块 (1-15) | ~90KB/块 |
| 12-14 | Conference-A摘要集 拆分块 (16-24) | ~90KB/块 |
| 15 | 毒性管理指南 拆分块 | ~70KB/块 |
| 16 | Conference-A卵巢癌-竞品D 拆分块 | ~80KB/块 |
| 17 | 适应症A免疫治疗进展 拆分块 | ~75KB/块 |

> ✅ `split_large_files.py` 已编写，执行 `build_ontology.py` 前先跑拆分。
> ```bash
> python3 split_large_files.py ../docs/产品X材料第一批/培训材料md/ --dry-run   # 预览
> python3 split_large_files.py ../docs/产品X材料第一批/培训材料md/              # 执行
> python3 split_large_files.py ../docs/产品X材料第一批/培训材料md/ --undo       # 撤销
> ```

#### Step 2 — 构建本体 (`build_ontology.py`)

扫描所有 `.md` 文件，用 DeepSeek v4-pro 提取实体和关系，构建"主体文件"作为后续优化的背景知识。**迭代式注入**：每批 5 个文件，前一批提取的实体作为后一批的上下文，逐步细化。

**⚠️ 前置条件**：先执行 `split_large_files.py` 拆分超大文件（见 Step 1.5）。

```bash
cd /root/Project-Agent/apps/Ontology-clean/preprocessor

# 先跑 dry-run 确认文件数
python3 build_ontology.py ../docs/产品X材料第一批/培训材料md/ \
  --types sales \
  --dry-run

# 正式构建（拆分后的文件目录或原始目录）
python3 build_ontology.py ../docs/产品X材料第一批/培训材料md/ \
  --types sales \
  --workers 6 \          # DeepSeek API 并发上限
  --batch-size 5 \
  --max-doc-chars 4000 \
  -o ../docs/产品X材料第一批/主体文件.md \
  --dump-json ../docs/产品X材料第一批/ontology.json
```

输出：
- `主体文件.md` — 结构化实体清单（按 22 种类型分组）和关系汇总（最大 8000 字）
- `ontology.json` — 完整原始数据（entities + relations + stats）

#### Step 3 — 文档优化 (`md_optimizer.py`)

将主体文件作为背景知识注入系统提示词，DeepSeek v4-pro 对每个 `.md` 应用 MAX 13 项策略进行优化：

| 策略 | 说明 |
|------|------|
| 格式预处理 | 去除重复页眉页脚，压缩装饰分隔符 |
| 主语显式化 | 为每个动词句子补齐主语 |
| 语义自包含 | 任意 512 token 切片独立可理解 |
| 术语一致性治理 | 统一命名，首次出现标注全称+别名 |
| ER 实体增强 | 每个核心语义单元 = 实体-关系-实体 |
| FAQ 嵌入与质控 | 每千字最少 FAQ 数量，答案 ≤120 字 |
| 层级结构化 | 所有表格拆解为带标题的段落 |
| 检索锚点预埋 | 口语化查询变体、同义词内联标注 |
| 多版本融合 | 合并同主题多版本精华 |
| YAML 元数据块 | 文档类型、核心主题、15-20 个相关概念、术语映射 |
| 关键词密度 | 产品名 ≥8 次/千字，公司名 ≥6 次/千字 |
| 保真保护 | 不猜测缩写、不窄化多维定位 |
| 语义浓度锁定 | 极端副词不可弱化 |

```bash
python3 md_optimizer.py 培训材料-已转换/ \
  --model deepseek-v4-pro \
  --workers 10 \
  --subject 主体文件.md \
  --prompt MAX-v3-prompt.md
```

输出：`培训材料-已转换-优化/*.md` — 每个文件包含 YAML 前置元数据、`快速定位`/`用户常搜` 摘要、10+ FAQ（按主题分类）、8-12 个检索锚点。

#### Step 4 — 双通道注入

**通道 A：本体后端**

```bash
# 复制优化后的文档到上传目录
cp -r 培训材料-已转换-优化/* data/uploads/

# 对每个 .md 执行 process_document()：
#   parse → DeepSeek 提取实体 → DashScope 嵌入 → 存入 objects 表
#        → DeepSeek 提取关系 → 存入 links 表
#        → 版本感知合并（同名实体自动融合）

# 构建全局知识上下文（供后续新文档提取时引用）
curl -X POST http://localhost:8000/api/v1/documents/build-context
# → data/knowledge_context.json
```

**通道 B：Qdrant 守护进程**

```bash
# 守护进程监视 data/uploads/，自动触发 L1→L2→L3：
#   L1: SHA256 检测变更 → DeepSeek 提取实体+关系 → 写入 StateStore (SQLite)
#   L2: 智能分块 (按主实体, max 500字) → DashScope 嵌入 → 写入 5 领域集合
#   L3: 实体卡片生成 → DashScope 嵌入 → 写入 v3_entities 集合

python3 -m daemon.daemon --watch data/uploads/ --db .progress/daemon.db &
```

### 统一查询示例

```python
from daemon.orchestrator import SearchOrchestrator
from daemon.state import StateStore
from md_optimizer import OpenAIClient
import os, httpx

# 初始化双通道编排器
orch = SearchOrchestrator(
    llm_client=OpenAIClient(
        api_key=os.environ["DEEPSEEK_API_KEY"],
        model="deepseek-v4-pro",
    ),
    store=StateStore("./.progress/daemon.db"),
    qdrant_url="http://localhost:6333",
    collection_prefix="v3",
)

# 通道 A 补充：本体图查询
async def ontology_graph_search(query: str) -> dict:
    """查询 PostgreSQL 本体图获取结构化实体关系"""
    async with httpx.AsyncClient() as client:
        # 先检索相似实体
        r = await client.get(
            "http://localhost:8000/api/v1/chat/context",
            params={"query": query}
        )
        return r.json()  # {objects: [...], links: [...]}

# 双通道查询
query = "产品X在适应症A中的临床数据如何？"

# 通道 B：Qdrant 5 库搜索 + 分析
result_v3 = orch.search(query)
# result_v3.synthesis.context          — 合成的上下文文本
# result_v3.synthesis.sources_summary  — 来源摘要
# result_v3.synthesis.conflicts        — 跨源数值冲突
# result_v3.analysis_by_domain         — 每个领域的 LLM 分析

# 通道 A：本体图多跳查询
import asyncio
entities = asyncio.run(ontology_graph_search(query))
# entities["objects"]                  — 匹配的实体列表
# entities["links"]                    — 实体间关系
```

### 预期效果

优化后的文档经过双通道注入，可实现：

| 查询类型 | 命中通道 | 示例 |
|---------|:--------:|------|
| 精确产品信息 | A + B | "产品X的适应症有哪些？" → 实体卡片 + FAQ 锚点命中 |
| 竞品对比 | A (图遍历) | "产品X和竞品A在适应症A上的区别？" → 多跳关系图 |
| 操作性问题 | B (语义搜索) | "irAE 皮肤毒性怎么处理？" → 分块段落 + FAQ |
| 临床数据 | A + B | "Study-A 试验的 ORR 是多少？" → 实体精确值 + 段落上下文 |
| 销售话术 | B (策略库) | "客户嫌价格贵怎么回应？" → 销售策略领域 + 话术锚点 |
| 跨主题推理 | A (图遍历) | "哪些产品在肿瘤领域A有布局？" → 2-3 跳图扩散 |

### 基础设施依赖

| 服务 | 端口 | 用途 | 状态 |
|------|:----:|------|:----:|
| PostgreSQL + pgvector | 5432 | 本体实体图存储 | 需启动 |
| Qdrant | 7334 | 向量分块索引 | ✅ 已注入 |
| DeepSeek API | — | LLM (v4-pro + v4-flash) | 需 API Key |
| DashScope API | — | 嵌入 (text-embedding-v4, 1024维) | 需 API Key |
| Ontology Backend | 8000 | FastAPI 知识引擎 | ✅ 运行中 |

---

## 提示词优化（2026-06-19）

### 优化来源

从 `访谈整理-优化/` 目录的 4 个金标文件中提取核心销售方法论，注入工作流 LLM 提示词：

| 源文件 | 核心内容 | 注入到 |
|------|------|------|
| 某药企_医生独特价值-优化.md | 三大USP（安全性/学术/联合） + 筛选标准 | system_prompt |
| 某药企_医生卖点清单-优化.md | 14个场景化卖点 + A/B医生分层 | qdrant_llm_SalesStrategy |
| 综合销冠行为库_...优化.md | 信任建立6步法 + 需求挖掘3层 + 行为评分 | qdrant_llm_TopSalesBehavior |
| patient_winning_behaviors_患者价值-优化.md | 患者沟通话术 + 依从性管理 | qdrant_llm_Customer |

### 三大不可改变的核心价值（USP）

```
USP 1: 长疗程免疫安全性高 → "一直有牌可打"
  SAE较低（竞品一半），零心肌炎/零神经炎，顶级期刊发表免疫再挑战

USP 2: 真实学术成果转化 → "你的患者数据=你自己的文章"
  300+经伦理审查的IIT，AI辅助工具，专家B20年投资人网络→专利转化

USP 3: 灵活联合用药基石 → "不是单次最强，但牌永远没打完"
  5个产品组合（联用药A/联用药B/联用技术C），300+IIT确保每线有承接方案
```

### 提示词设计原则

1. **强标记+必须输出清单** — `🔴 核心价值观` 不可稀释，强制每问必体现
2. **医生恐惧驱动** — 围绕"无药可选"、"纠纷风险"、"升职焦虑"构建话术
3. **每回答必须输出**：核心定位(1-2句) + 数据支撑 + 话术建议 + 注意事项 + 知识来源

### 验证结果

| 测试问题 | USP1 | 核心格式 | 关键数据 | 知识来源 |
|------|:--:|:--:|:--:|:--:|
| 和竞品C有什么区别 | ✅ | ✅ | ✅ | ✅ |
| 国产生物标志物A质量说服 | ✅ | ✅ | ✅ | ✅ |
| 太贵了不想用 | ✅ | ✅ | ✅ | ✅ |

---

## 检索自优化分析（2026-06-19）

### 发现的问题

RAGAS 评测 Round 3 发现所有 Qdrant 库返回大量相同 FAQ 内容（同一 chunk 出现在 3-7 个库中），导致：
- 上下文浪费（8 chunks 中可能有 4+ 是重复的）
- 差异化内容被挤掉（SalesStrategy 独有内容因 Score 不够高排不上去）
- LLM 回答缺乏多样性

### 自优化方案（当前库内可修复）

| 优化项 | 方法 | 效果 | 已实装？ |
|------|------|------|:--:|
| 跨库去重 | `text[:120]` 哈希去重，保留最高分副本 | medical +0.30, comparison +0.41 | ✅ eval_ragas.py |
| 检索量提升 | `top_k` 3→5 | 上下文更多样，降噪 | ✅ eval_ragas.py |
| 关键词加权 | query-chunk 匹配 +0.03 | 策略查询精准度提升 | ✅ eval_ragas.py |

### 不可自愈的问题（需外部补库）

| 类别 | 问题 | 解决方案 |
|------|------|------|
| behavior/customer | 知识库真缺销冠行为细节和医生管理内容 | 补充 TopSalesBehavior/Customer 库内容 |
| strategy | 话术模板和异议应对模板不足 | 补充 SalesStrategy 库 |
| API 超时 | DeepSeek 偶发超时返回空 | 加重试逻辑 |

---

## Golden Dataset + RAGAS 评测基线

### 最终结果（Round 5, V2 优化后）

| 指标 | 得分 | 目标 | 说明 |
|------|:--:|:--:|------|
| Faithfulness | 3.74 | ≥4.5 | 事实类/医学类已达 4+ |
| Answer Relevancy | 3.80 | ≥4.5 | 60% 问题 ≥4 分 |
| Factual Correctness | 3.62 | ≥4.5 | 事实类 >4.0 |
| Completeness | 3.10 | ≥4.0 | 内容覆盖不足是主因 |
| **综合** | **3.56** | **4.5** | |

### 按类别

| 类别 | 得分 | 评语 |
|------|:--:|------|
| medical | **4.58** ✅ | 超目标，irAE/疾病检索极佳 |
| factual | **4.25** | 产品数据准确，ORR/mOS 等关键数可靠 |
| faq | **4.25** | 价格/剂量/储存信息准确 |
| comparison | 3.19 | 跨库去重明显改善，部分竞品数据缺失 |
| strategy | 2.84 | 话术库内容需补充 |
| behavior | 2.60 | 行为库有内容但不够 |
| customer | 2.60 | 医生管理内容不足 |

### 评测脚本

```bash
# 完整评测（50 QA pairs, 5 并发）
python3 eval_ragas.py

# 仅意图路由测试（88 FAQ questions）
python3 test_intent_router.py
```

### 评测数据集

- Golden Dataset：50 QA pairs（`eval_ragas.py` 内嵌）
- 意图路由标注：88 FAQ questions（`faq_intent_annotations.json`）
- 评测报告：`/root/Project-Agent/docs/产品X知识库/ragas_eval_report.json`

---

## 专家审核机制（2026-06-19）

### 目的

本体自动构建后，需经领域专家审核确认关键事实（疗效数据、产品定位、竞品信息），再反馈修正到数据库。全流程为：

```
本体构建 → 生成审核清单 → 专家审核 → 修正反馈 → 重新注入
```

### 审核清单生成方法

**原则**：不是 dump 数据库，而是按业务域归类、机器字段翻译为人类语言、逐行可审。

**步骤**：

1. **从 PostgreSQL 导出全部实体和关系**
   ```sql
   SELECT ot.name, o.name, o.properties, d.filename
   FROM objects o JOIN object_types ot ON o.type_id=ot.id
   LEFT JOIN documents d ON o.source_document_id=d.id
   ```

2. **按业务域归类**（而非数据库类型）：
   | 章节 | 内容来源 | 翻译方法 |
   |------|------|------|
   | 一、产品核心事实 | Product + Feature + Spec | 疗效数据表格 + 基本信息列表 |
   | 二、三大USP | 人工提炼自访谈整理金标文件 | 固定文案，逐条确认 |
   | 三、竞品对比 | Competitor | 公司|类型|适应症|差异点 一行一个 |
   | 四、疾病知识 | Disease（合并变体） | 发病/死亡/生存/分子分型 → 一段话 |
   | 五、竞争优势 | Advantage | description → 一行一个卖点 |
   | 六、销售策略 | Objection + SalesScript | description → 异议/话术逐条 |

3. **疾病名变体合并**：
   ```python
   DISEASE_MERGE = {
       '适应症A': ['适应症A', '复发或转移性适应症A', '适应症A（局晚期）', ...],
       '适应症B': ['适应症B'],
       '适应症D': ['适应症D', '经典适应症D', ...],
   }
   ```

4. **机器字段 → 人类语言翻译**：
   ```python
   KEY_MAP = {
       'incidence_rate': '发病率',
       'new_cases_china_2022': '2022年中国新发病例',
       'pd_l1_expression_rate': '生物标志物表达率',
       ...
   }
   ```

5. **生成 Markdown**：每行末尾 `⬜` 供专家标注 `✅准确 / ⚠️需修改 / ❌删除`

### 审核清单输出

| 文件 | 用途 |
|------|------|
| `docs/产品X知识库/专家审核清单.md` | 人类可读，逐行审核 |
| `docs/产品X知识库/ragas_eval_report.json` | RAGAS 自动化评测报告 |

### 审核后反馈流程

```
专家在审核清单.md 上标注 → 提取修改意见 →
  ├─ 数值修正 → 更新 PostgreSQL objects.properties
  ├─ 删除误提取实体 → DELETE FROM objects
  ├─ 合并重复实体 → fix_entity_dedup.py
  └─ 术语修正 → 同步更新 Qdrant + ontology_fixed.json
→ 重新跑 build_ontology → 重新注入
```

### 自动化脚本

```bash
# 生成审核清单
python3 -c "import psycopg2; ..." > 专家审核清单.md

# 专家标注后，提取修改意见
python3 apply_expert_feedback.py --input 专家审核清单_已标注.md

# 重新注入
python3 inject_all.py && python3 inject_qdrant.py
```

### 关键设计原则

| 原则 | 说明 |
|------|------|
| 一行一条 | 每条事实独立一行，专家逐行判断 |
| 人类语言 | 禁止机器字段名出现在审核清单中 |
| 合并变体 | 同一疾病的多个数据库条目合并为一行 |
| 分级审核 | 核心数据（疗效/适应症/价格）在前，次要条目在后 |
| 来源追溯 | 每条事实标注源文件路径 |
| 可操作反馈 | 审核后可直接转化为 SQL UPDATE / DELETE |

---

## 后续 TODO

| 优先级 | 任务 | 预期提升 |
|:--:|------|------|
| P0 | 重启 node 服务使提示词变更生效 | — |
| P0 | 真实消息端到端测试（走完整 workflow） | — |
| P1 | 补充 SalesStrategy 库内容（话术模板+异议应对） | strategy +0.5-1.0 |
| P1 | 补充 Customer/TopSalesBehavior 库内容 | behavior +0.5-1.0 |
| P1 | 跨库去重实装到 context_merge（workflow层面） | 全局提升 |
| P2 | DeepSeek API 重试逻辑 | 减少空回答 |
| P2 | CI 集成（每次 ontology/Qdrant 更新后自动跑评测） | — |

---

## 第二批材料合并（2026-06-22）

### 新增内容

第二批为学术论文和指南（45 文件，1253 页 PDF/DOCX），经完整的清洗-翻译-构建-注入管道。

### 处理流程

| 步骤 | 内容 | 结果 |
|:--:|------|------|
| Step 1 | 42/43 格式转换 + 32 英文中译 | MD 2.6MB |
| Step 1.6 | 大文件拆分（5 个 >50KB 指南） | → 573 chunks（后续跳过） |
| Step 2 | 第一批 + 第二批合并构建本体 | 72 文件 → ontology_统一.json (527KB) |
| Step 3 | md_optimizer (MAX13) | 610 文件 / 7.1MB |
| Step 3.5 | 交叉验证 | 术语修复 7366 处 |
| Step 4 | PostgreSQL 注入 | 37 文件 (过滤碎片后) |

### 合并后数据库（已清理）

| 指标 | 第一批 | 合并后（去重前） | 合并后（去重后） |
|------|:--:|:--:|:--:|
| 文档 | 42 | 705 | **676** |
| 实体 | 750 | 5875 | **5829** |
| 关系 | 623 | 6720 | **6695** |
| 嵌入覆盖 | 100% | 100% | 100% |

### 质量审计发现与修复

| 问题 | 根因 | 修复 |
|------|------|------|
| 🔴 29 个孤儿文档 | 实体合并后文档无关联对象 | DELETE FROM documents WHERE NOT EXISTS (objects) |
| 🟡 46 个重复实体 | 全角/半角括号变体（如 "Guideline-Body指南2023版" vs "Guideline-Body指南2023"） | 按 (type + normalized_name) 合并，保留最早 id |
| 🟡 25 条重复关系 | 实体合并后产生 (source, target, type) 三元组重复 | DELETE ... GROUP BY 去重 |
| 🔴 1690 条冲突记录 | auto-generated 冲突从未清理 | DELETE FROM conflicts（后续注入会重新生成） |
| 🟡 613 个优化碎片注入 | md_optimizer 生成大量子文件（42→610），初次注入未过滤 | 后续注入过滤 <2KB 碎片；已有数据保留（含有效实体） |

### 第二批特有实体类型

学术论文引入了大量新类型实体：
- **Contact (+248)**：临床试验研究者、PI
- **Institution (+308)**：研究机构、医院、期刊
- **Policy (+249)**：适应症获批、指南推荐
- **Scenario (+792)**：临床研究场景、治疗方案

### 经验教训

| # | 教训 |
|---|------|
| 1 | 学术论文 md_optimizer 产生大量碎片文件（42→610），后续注入需过滤 <2KB 文件 |
| 2 | 大文件拆分后构建本体过于缓慢（645 chunks × 2 API），直接用原始文件 + 更高 max_doc_chars 更高效 |
| 3 | 英文论文翻译时 15000 字符截断会导致内容丢失，需分批翻译大文件 |
| 4 | 合并第一批+第二批时，实体去重依赖同名+同类型，需后续人工审核 |

### 专家审核清单

已更新为合并版：`/root/Project-Agent/docs/产品X知识库/专家审核清单.md` + `.docx`

---

## 专家审核反馈闭环（2026-06-19）

### 审核清单 → 数据库修正 的可追溯机制

**核心问题**：专家在 Markdown 上标注后，能否反向找到 PostgreSQL 中对应的实体/关系行？

**答案**：可以。每条实体/关系在生成时携带了 `📄 源文件名`，通过 **实体名 + 类型 + 源文件** 三元组即可唯一定位。

### 反馈标注格式

专家审核时在 `⬜` 后填写：

| 标注 | 含义 | 数据库操作 |
|------|------|------|
| `✅` | 通过 | 无操作 |
| `⚠️ 疗效数据ORR应为28%` | 需修改 | `UPDATE objects SET properties = jsonb_set(properties, '{ORR}', '"28%"') WHERE name='产品X' AND type='Product'` |
| `❌ 重复，与第N条合并` | 删除 | `DELETE FROM objects WHERE id=X`（先迁移关联links） |
| `⚠️ 话术不准确：应改为XXX` | 修改描述 | `UPDATE objects SET properties = jsonb_set(properties, '{description}', '"XXX"')` |

### 反向定位SQL模板

```sql
-- 按名称+类型定位实体
SELECT o.id, o.name, o.properties, ot.name as type, d.filename
FROM objects o
JOIN object_types ot ON o.type_id = ot.id
LEFT JOIN documents d ON o.source_document_id = d.id
WHERE o.name = '产品X' AND ot.name = 'Product';

-- 按源文件批量定位
SELECT o.id, o.name, ot.name as type
FROM objects o
JOIN object_types ot ON o.type_id = ot.id
JOIN documents d ON o.source_document_id = d.id
WHERE d.filename LIKE '%产品X在适应症A中的应用%' AND ot.name = 'Advantage';

-- 按关系类型+端点定位关系
SELECT l.id, lt.name as rtype, s.name as source, t.name as target
FROM links l
JOIN link_types lt ON l.type_id = lt.id
JOIN objects s ON l.source_id = s.id
JOIN objects t ON l.target_id = t.id
WHERE lt.name = 'targets' AND s.name = '产品X' AND t.name = '适应症A';
```

### 反馈执行流程

```
专家返回 专家审核清单_已标注.md
  │
  ├─ 提取 ⚠️ 和 ❌ 标注行
  │   ├─ 正则匹配实体名称 + 修改意见
  │   └─ 生成 JSON 修正指令清单
  │
  ├─ apply_expert_feedback.py（待实现）
  │   ├─ 按 fix_type 分类: UPDATE property / DELETE entity / MERGE entities
  │   ├─ 逐条执行 SQL
  │   └─ 记录修正日志（undo 支持）
  │
  ├─ 重新构建 ontology_fixed.json
  │   └─ python3 build_ontology.py --input 修正后的数据
  │
  ├─ 重新注入 PostgreSQL + Qdrant
  │   ├─ python3 inject_all.py
  │   └─ python3 inject_qdrant.py
  │
  └─ 重新跑 RAGAS 评测
      └─ python3 eval_ragas.py → 对比修正前后得分
```

### 审核清单生成脚本

```bash
# 从 PostgreSQL 导出全量审核清单（34KB, 人类可读）
python3 << 'HEREDOC'
import psycopg2
# 三级粒度: L1精细(产品/USP/竞品/疾病/优势/话术) 
#           L2列表(场景/特性/方案/案例/关系) 
#           L3概要(机构/人员/政策)
# 机器字段→人类语言翻译 | 疾病名变体合并 | 关系类型中文化
# 每行末尾 ⬜ 供专家标注
HEREDOC
```

### DOCX 商业排版规范

审核清单 Markdown → DOCX 的转换参数（`python-docx`）：

```python
from docx import Document
from docx.shared import Pt, Cm, RGBColor

# ── 页面 ──
section.top_margin = Cm(2.5); section.bottom_margin = Cm(2.5)
section.left_margin = Cm(3); section.right_margin = Cm(3)

# ── 正文：宋体 五号(10.5pt) 不加粗，1.15倍行距，段落间距前6pt后10pt ──
style = doc.styles['Normal']
style.font.name = '宋体'; style.font.size = Pt(10.5)
style.paragraph_format.space_after = Pt(10)
style.paragraph_format.space_before = Pt(6)
style.paragraph_format.line_spacing = 1.15

# ── 标题：微软雅黑加粗 ──
# H1: 15pt 深蓝 #1a56db, 段前20pt
# H2: 12pt 深灰 #2d2d2d, 段前14pt
# H3: 11pt 中灰 #4a4a4a, 段前14pt
h.font.name = '微软雅黑'; h.font.bold = True

# ── 强调(**text**)：微软雅黑不加粗，仅通过字体切换区分 ──
run.font.name = '微软雅黑'
run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
# 不设 run.bold = True

# ── 源文件引用(📄`filename`)：灰色 8pt 不加粗 ──
run.font.size = Pt(8); run.font.color.rgb = GRAY

# ── 列表项：宋体五号不加粗，段落间距前4pt后8pt ──
lb = doc.styles['List Bullet']
lb.font.name = '宋体'; lb.font.size = Pt(10.5)
lb.paragraph_format.space_after = Pt(8); lb.paragraph_format.space_before = Pt(4)

# ── 内容过滤规则 ──
# 删除: 首行统计(实体 N 个...)、用法说明行、--- 分隔线、> blockquote
# 删除: [L1 精细] [L2 列表] [L3 概要] 标签(strip_tags)
# 删除: SalesScript 类型实体(内部标签 专家无法审核)
# 删除: 设备(1个)/关系清单/审核确认表 章节
# 禁止: 表格(疗效数据改列表)、☐ checkbox

### 关键经验

| # | 经验 | 详情 |
|---|------|------|
| 1 | **源文件是追溯链** | 每个实体必须保留 `source_document_id`→`filename` 映射，否则无法反向定位 |
| 2 | **三级粒度分级** | 核心数据逐条审（L1），辅助数据列表审（L2），参考数据整批审（L3），避免专家疲劳 |
| 3 | **机器标签必须翻译** | `targets/includes/contact_at` 等数据库字段名禁止出现在审核文档中——用「靶向/包含/联系人在」代替 |
| 4 | **疾病名变体必须合并** | 数据库中「适应症A」「复发或转移性适应症A」「适应症A(局晚期)」是不同行，审核清单应合并为一条 |
| 5 | **修改意见必须可操作** | 专家的 ⚠️ 标注要能直接翻译为 SQL UPDATE/DELETE，不能依赖人工再次解读 |
| 6 | **审核后需要重新评测** | 每次修正后必须重跑 RAGAS 评测，确认修正方向正确且未引入新问题 |
| 7 | **反馈闭环自动化** | 理想状态：专家标注完 → 一键执行修正 → 自动重注入 → 自动重评测 → 输出修正前后对比报告 |

---

## 实际执行记录（2026-06-18→19）

## 核心发现与高价值经验（2026-06-19 总结）

### 发现 1：本体库天然适合生成专家审核清单，形成闭环纠错

> **本体输出的实体+关系可直接转为人类可读的知识文档，用于客户审核，帮助系统性自动纠错。**

- 从 PostgreSQL 750 实体 + 623 关系全量导出 → 按业务域归为 8 章 → 机器字段翻译为人类语言 → DOCX 商业排版
- 专家逐条标注 ✅/⚠️/❌ → 反馈直接映射为 SQL UPDATE/DELETE → 重新注入 → 重跑 RAGAS 评测验证
- **价值**：将"AI 黑盒"变成"可审计白盒"，客户清晰看到系统知道什么、不知道什么、哪里有错

### 发现 2：文件来源置信度分级 + 交叉验证 = 显著降低 OCR/ASR 错误率

> **不同来源的文件标注信任等级，用金标文件自动交叉验证银标/铜标内容。**

- 金标（人工编写 FAQ/访谈）→ 银标（OCR 课件）→ 铜标（ASR 视频）三级体系
- `validate_and_fix.py` L1-L4 自动扫描：术语标准化 2959 处 + 结构修复 8 处 + 残留扫描 17797 处
- 12 项金标声明交叉验证全部 42 文件，标出 111 处覆盖缺失
- **价值**：OCR"产品X→ProductX_ASRerr"、ASR"适应症A→适应症A"等错误被系统性消灭，最终零术语残留

### 发现 3：必须根据全量实际文档内容优化所有提示词，才能保证检索和回答质量

> **提示词不能凭空写。必须通读全部文档，提取核心卖点、关键数据、话语体系，再反注回 prompt。**

- 从访谈整理 4 份金标文件中提取：三大 USP、14 个场景化卖点、A/B 医生分层、信任建立 6 步法
- 重写 system_prompt：将"长疗程免疫基石""一直有牌可打""患者数据变文章"固化为强制输出
- 重写 6 个 qdrant_llm 提示词：每回答必体现 USP + 引用来源文件名 + 置信度百分比
- **价值**：验证显示 100% 的回答体现了 USP 1（安全性），核心格式和关键数据全部达标

### 发现 4：先手动 → 再半自动 → 最后全自动，所有过程必须记录

> **自动化不是一步到位。先手动跑通全流程、记录每一步的问题和修复、沉淀为脚本、最后整合为全自动管道。**

- 手动阶段：逐个文件 OCR 转换 → 手动标注 FAQ 意图 → 手动调 context_merge
- 半自动阶段：`auto_pipeline.py` 5 阶段串行，加入断点续跑和超时保护
- 全自动阶段：`validate_and_fix.py` + `eval_ragas.py` + `inject_qdrant.py` 一键执行
- 过程中发现 → 修复 → 记录 → 写回 README 的闭环：redirect_stdout 吞进度、DeepSeek 推理链过长、FastAPI namespace 污染 embed、context_merge f-string 语法错误、ontology 沙箱限制
- **价值**：后续新人接手可直接读 README 重现全部过程，无需试错

### 发现 5：本体库在精确数据检索和深度逻辑再现上有先天优势，当前仅挖出 10%

> **Qdrant 擅长语义匹配（"irAE 怎么处理"），Ontology 擅长精确实体查找和多跳图推理（"哪些产品在适应症A有布局"）。当前双通道互补的价值远未挖尽。**

- 已验证：本体图查询可返回实体关系链（产品X → targets → 适应症A → part_of → 肿瘤领域A → competes_with → 竞品B）
- 已验证：本体冲突检测可发现"ORR ~28% vs 26.8%"跨文件矛盾
- **尚未使用的能力**：
  - 多跳图遍历（BFS 2-3 跳发现隐藏关联）
  - 版本感知实体合并（同名实体自动融合，避免知识碎片化）
  - 图距离重排序（用实体图结构优化 Qdrant 搜索结果排序）
  - 实体卡片索引（Database + Qdrant 联动，精确实体 + 语义段落互补）
- **价值预估**：若充分挖掘，检索精确度可提升 30-50%，幻觉率下降 20%+

---

### Step 4 实施：双通道注入

#### 4A. PostgreSQL 本体注入

**基础设施**：
- 启动专用 pgvector 容器：`docker run -d --name onto-postgres pgvector/pgvector:pg17 -p 5535:5432`
- 启动 FastAPI 后端：`uvicorn backend.main:app --port 8000`

**注入结果**：

| 指标 | 值 |
|------|-----|
| 文档数 | 42 |
| 实体总数 | 750（去重后） |
| 关系总数 | 623 |
| 嵌入覆盖率 | 100% (1024-dim) |
| 孤儿关系 | 0 |
| ASR 残留 | 0 |

**修复的 bug**：
- FastAPI namespace 污染 `embed` 函数 → `pipeline.py` 内联动态导入
- 全角/半角括号实体重复 → `fix_entity_dedup.py` 规则去重（-5 实体）

#### 4B. Qdrant 分库重构

**旧库结构（5 库，281 points）**：CompanyProduct / Competitor / SalesStrategy / TopSalesBehavior / Customer

**新库结构（7 库，1795 points）**：

| 库 | Points | 用途 | 文件来源 |
|------|:--:|------|------|
| MedicalKnowledge | 599 | 疾病基础 + irAE 管理 + Guideline-Body/Guideline-Body-B 指南 | irAE课件 + 疾病课件 + Guideline-Body指南 |
| CompanyProduct | 562 | 产品机制、临床数据、剂量方案 | FAQ + 产品X课件 |
| Competitor | 227 | 竞品对比（Conference-A 学术数据） | Conference-A 论文参考 |
| SalesStrategy | 171 | 销售策略、异议处理、话术 | 话术卡 + 市场策略 |
| SystemFAQ | 132 | FAQ 快速匹配 | FAQ 88问 结构化拆解 |
| TopSalesBehavior | 55 | 顶级销售行为、最佳实践 | 销冠行为库 |
| Customer | 49 | 医生画像、决策链 | 医生卖点清单 |

**注入逻辑**：
- 分块：500 字/chunk，沿自然边界切割（`##` / `---` / 段落）
- 嵌入：DashScope text-embedding-v4, 1024 维, Cosine 距离
- 分类：关键词评分（≥2 命中则归入对应库，多归属允许）
- 脚本：`inject_qdrant.py`

#### 4C. 工作流提示词更新

**变更文件**：
- `产品X.running.py` — 新增 search_qdrant_MedicalKnowledge + qdrant_llm_MedicalKnowledge + qdrant_json_MedicalKnowledge
- `产品X.running.py` — context_merge 新增 MedicalKnowledge 库（置信度 88%）
- `产品X.running.py` — +4 条连接线
- `产品X.prompts.json` — 新增 `qdrant_llm_MedicalKnowledge` system prompt（3532 chars）
- `产品X.py` — 同步覆盖

**知识库文件组织**：
- `/root/Project-Agent/docs/产品X知识库/` — 按 7 库单归属分目录，41 文件

**详细对比**：见 `/root/Project-Agent/docs/工作流提示词更新对比_2026-06-19.md`

### 测试报告

- **PostgreSQL 注入测试**：36/36 通过 → `_test_report.md`
- **系统评测框架**：6 维 22 指标 + Golden Dataset 构建方法 → `docs/系统评测与改进研究报告.md`

### 意图路由测试方法

**目的**：验证 88 个 FAQ 问题的意图路由准确性，确保每个问题激活的 Qdrant 库覆盖所有必需知识域。

**方法**：
1. 从 `产品X代理商培训FAQ_88问_完整版.md` 提取全部 88 问
2. 为每个问题标注必须激活的 Qdrant 库（`faq_intent_annotations.json`）
3. 运行 `test_intent_router.py` 对比实际路由与期望路由
4. 迭代调整关键词规则，直至召回率 >95%

**当前基线**（2026-06-19 Round 2）：

| 指标 | 值 |
|------|:--:|
| 必须库召回率 | 100% (88/88) |
| 激活精度 | 91.1% |
| 平均激活库数 | 2.3 / 问 |
| 平均多余激活 | 0.2 / 问 |
| 测试脚本 | `test_intent_router.py` |
| 标注文件 | `faq_intent_annotations.json` |

**实装位置**：`产品X.running.py` intent_router 节点
- 规则 8：MedicalKnowledge 关键词强制激活（irAE/疾病/指南）
- 规则 10：Web 搜索关键词强制激活（时效性/政策动态/竞品动态/市场数据，15 类触发词）

**Web 检索触发规则**：以下 15 类问题时自动激活网络搜索（知识库定期更新，但实时数据需联网）：
| 触发类型 | 关键词模式 | 示例问题 |
|------|------|------|
| 时效性 | 目前/最新/最近/当前/动态/趋势/未来 | "上市多久了？目前进院数量" |
| 市场数据 | 覆盖.*多少/进院.*数量/市场.*占比 | "覆盖多少医院" |
| 政策动态 | 集采/医保目录/新规/窗口期 | "进了集采怎么办" |
| 竞品动态 | 竞品.*[在布推]/竞品.*策略 | "竞品在布局联合方案" |

**更新流程**：新增 Qdrant 库后，需更新 `faq_intent_annotations.json`，重新运行测试验证召回率 ≥95%。

### Golden Dataset + RAGAS 评测

**数据集**：50 QA pairs，分层覆盖 7 库 + 边缘测试（`eval_ragas.py`）

**当前基线**（2026-06-19 Round 4）：

| 指标 | Round 3 | Round 5 (V2优化) | 目标 |
|------|:--:|:--:|:--:|
| Faithfulness | 3.60 | **3.74** | ≥4.5 |
| Answer Relevancy | 3.86 | **3.80** | ≥4.5 |
| Factual Correctness | 3.54 | **3.62** | ≥4.5 |
| Completeness | 2.98 | **3.10** | ≥4.0 |
| **综合** | **3.50** | **3.56** | **4.5** |

**按类别（V2优化后）**：

| 类别 | 得分 | 变化 | 评语 |
|------|:--:|:--:|------|
| medical (医学知识) | **4.58** ✅ | +0.30 | irAE/疾病检索极佳，超目标 |
| factual (事实查询) | **4.25** | -0.11 | 产品数据准确 |
| faq (快问快答) | **4.25** | +0.06 | 价格/剂量信息可靠 |
| comparison (竞品对比) | **3.19** | +0.41 | 跨库去重明显改善 |
| overview (总览) | **3.00** | — | |
| strategy (销售策略) | **2.84** | +0.18 | |
| behavior (行为指导) | **2.60** | -0.45 | 部分回答为空(API超时) |
| customer (客户管理) | **2.60** | -0.25 | 知识库内容不足 |

**V2 自优化成果**：

| 优化项 | 效果 | 可自愈？ |
|------|------|:--:|
| 跨库去重 (dedup by text[:120]) | medical +0.30, comparison +0.41 | ✅ |
| 检索量提升 (top_k 3→5) | 上下文更多样 | ✅ |
| 关键词加权 (keyword boost +0.03) | 策略/竞品相关度提升 | ✅ |
| behavior/customer 内容缺失 | 回答为空或编造 | ❌ 需补库 |
| API 偶发超时 | 部分答案为空 | ❌ 加重试 |

**改进路线**：
1. 补充 SalesStrategy 库内容（市场策略文档、话术卡、异议处理模板）
2. 补充 Customer 库内容（医生画像、决策链分析）
3. 补充 TopSalesBehavior 库内容（销售演练案例、最佳实践）
4. 补充 Competitor 库内容（竞品最新数据）
5. 重新注入 Qdrant → 重跑 RAGAS 评测

**第二轮优化结果**（2026-06-19）：

| 指标 | Round 1 | Round 2 (V2) |
|------|:--:|:--:|
| 必须库召回率 | 31.8% | **100%** |
| 激活精度 | — | 92.0% |
| 平均激活库 | — | 2.3 |
| Web 检索覆盖 | — | 15/88 (17%) |

### 后续自动化开发参考

| 参考文档 | 用途 |
|------|------|
| `_test_plan.md` | 新数据注入时的回归测试清单 |
| `_test_report.md` | 当前注入质量基线 |
| `_pipeline.log` | 全流程耗时和使用记录 |
| `docs/Qdrant分库设计方案.md` | Qdrant 库结构设计依据 |
| `docs/工作流提示词更新对比_2026-06-19.md` | 提示词变更 before/after |
| `docs/系统评测与改进研究报告.md` | 评测指标体系和改进路线图 |

## 全流程审核报告（2026-06-22）

### 已完成项

| # | 项目 | 状态 |
|:--|------|:--:|
| 1 | 第一批完整管道（Step 1-4） | ✅ |
| 2 | 第二批格式转换+英文翻译 | ✅ |
| 3 | 合并本体构建（72文件） | ✅ |
| 4 | 文档优化 (md_optimizer) | ✅ |
| 5 | 交叉验证 (validate_and_fix) | ✅ |
| 6 | PostgreSQL 注入（过滤后37文件） | ✅ |
| 7 | 实体去重 + 孤儿文档清理 | ✅ |
| 8 | 意图路由 88 FAQ 测试（100%召回） | ✅ |
| 9 | RAGAS 第一批评测 (3.56/5.0) | ✅ |
| 10 | 专家审核清单（合并版, 5829实体） | ✅ |
| 11 | 提示词优化（三大核心价值） | ✅ |
| 12 | 角色意识修正（"专业伙伴"） | ✅ |
| 13 | 源文件引用细化（文件名+置信度） | ✅ |

### 待完成项

| # | 项目 | 优先级 |
|:--|------|:--:|
| 1 | Qdrant 第二批注入（学术论文+指南） | P0 |
| 2 | RAGAS 合并评测（第一批+第二批） | P1 |
| 3 | intent_router 适配第二批新类型 | P1 |
| 4 | 专家审核反馈闭环实现 | P2 |

### 当前数据库基线

| 指标 | 数值 |
|------|:--:|
| 文档 | 676 |
| 实体 | 5829 (21类) |
| 关系 | 6695 (20类) |
| 嵌入覆盖 | 100% (1024-dim) |
| Qdrant points | 1795 (7库，仅第一批) |

### 关键教训汇总

| # | 教训 | 解决方案 |
|---|------|------|
| 1 | redirect_stdout 吞主线程 print | stderr debug + PYTHONUNBUFFERED=1 |
| 2 | DeepSeek v4-pro 推理链无上限 → API 挂起 | reasoning_effort: "medium" |
| 3 | budget_tokens 非有效 DeepSeek 参数 | 换 reasoning_effort |
| 4 | 300KB JSON 送 LLM 修复 → JSON 格式错误 | Python 规则去重 |
| 5 | subprocess.run(timeout=600) 不够 | 改 1800s + 断点续跑 |
| 6 | ASR 转录错误污染本体 | 金标/银标/铜标分级 + validate_and_fix.py |
| 7 | FastAPI namespace 污染 embed 函数 | pipeline.py 内联动态导入 |
| 8 | 全角/半角括号导致实体重复 | fix_entity_dedup.py 标准化合并 |
| 9 | Qdrant 库过少导致检索噪音 | 7 库分库 + 意图路由精准激活 |
| 10 | 每轮改文件后重建本体成本爆炸 | 文件级 L1-L4 检查 → 全修完 → 一次性构建 |
