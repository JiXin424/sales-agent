#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OpenClaw Header
# 'HTTP-Referer': 'https://openclaw.ai'
# 'X-0penRouter-Title': 'OpenClaw'
# 'X-0penRouter-Categories': 'cli-agent'
"""
DOC (Word 97-2003) 智能转 Markdown 工具（支持图片）

将旧版 .doc 文件（Microsoft Word 97-2003 格式）转换为 Markdown 格式：
- 优先使用 macOS textutil 提取文本
- 从 OLE 流中提取嵌入的图片
- AI 分析图片内容
- 按原文档顺序组合文字和图片

用法:
    python doc97to md.py <doc_file>

示例:
    python doc97to md.py "document.doc"
    python doc97to md.py "访谈记录.doc" --no-ai
"""

import sys
import os
import subprocess
import re
import tempfile
import zipfile
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from PIL import Image

# 尝试导入 olefile
try:
    import olefile
except ImportError:
    print("错误：未安装 olefile 库")
    print("请运行：pip install olefile")
    sys.exit(1)

# 尝试导入 openai
try:
    from openai import OpenAI
except ImportError:
    print("警告：未安装 openai 库，AI 功能将不可用")
    print("请运行：pip install openai")
    OPENAI_AVAILABLE = False
else:
    OPENAI_AVAILABLE = True

# 默认 API 配置
DEFAULT_API_KEY = "DASHSCOPE_API_KEY_PLACEHOLDER"
DEFAULT_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
DEFAULT_MODEL = "qwen3.6-plus"

# 图片压缩配置（vision API 限制）
IMAGE_SIZE_LIMIT = 20 * 1024 * 1024  # 20MB
IMAGE_MAX_DIMENSION = 4096  # 最大宽高
IMAGE_QUALITY = 75  # JPEG 品质参数 (1-100)


def find_file(file_path: str, search_base: str = None) -> str:
    """查找文件的真实路径（处理 iCloud 幽灵文件和中文路径）"""
    file_path = file_path.replace(' ', '')

    if os.path.exists(file_path):
        try:
            size = os.path.getsize(file_path)
            if size >= 1024:
                return file_path
        except OSError:
            pass

    file_name = os.path.basename(file_path)
    if search_base is None:
        search_base = "/Users/fred/Documents/cc_Projects/Taishan"

    keyword = file_name.replace('.doc', '').replace('.docx', '')

    result = subprocess.run(
        ['bash', '-c', f'find "{search_base}" -name "*{keyword}*" -type f 2>/dev/null | head -5'],
        capture_output=True,
        text=True
    )

    if result.stdout.strip():
        files = result.stdout.strip().split('\n')
        for f in files:
            if keyword in f.replace(' ', ''):
                return f

    return None


def verify_file_access(file_path: str) -> Tuple[bool, int]:
    """验证文件是否可访问且不是 iCloud 占位符"""
    try:
        size = os.path.getsize(file_path)
        if size < 1024:
            print(f"警告：文件小于 1KB ({size} bytes)，可能是 iCloud 占位符")
            return False, size
        return True, size
    except OSError:
        return False, 0


def check_ole_file(file_path: str) -> bool:
    """检查文件是否为 OLE 复合文档格式"""
    try:
        with open(file_path, 'rb') as f:
            header = f.read(8)
            return header == b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'
    except Exception:
        return False


def copy_file_to_temp(src_path: str) -> str:
    """复制文件到临时目录（避免中文路径问题）"""
    temp_fd, temp_path = tempfile.mkstemp(suffix='.doc')
    os.close(temp_fd)

    result = subprocess.run(
        ['bash', '-c', f'cat "{src_path}" > "{temp_path}"'],
        capture_output=True
    )

    if result.returncode != 0:
        raise IOError(f"复制文件失败：{src_path}")

    return temp_path


def extract_text_with_textutil(doc_path: str) -> str:
    """使用 macOS 的 textutil 命令提取 .doc 文件文本"""
    try:
        temp_dir = tempfile.mkdtemp()
        temp_name = os.path.join(temp_dir, 'document.txt')

        result = subprocess.run(
            ['bash', '-c', f'textutil -convert txt -output "{temp_name}" "{doc_path}" 2>&1'],
            capture_output=True,
            text=True,
            timeout=60
        )

        if result.returncode == 0 and os.path.exists(temp_name):
            with open(temp_name, 'r', encoding='utf-8') as f:
                content = f.read()
            subprocess.run(['bash', '-c', f'rm -rf "{temp_dir}"'])
            if content.strip():
                return content.strip()
    except Exception as e:
        print(f"textutil 提取失败：{e}")
    return ""


def extract_images_from_ole(doc_path: str, output_dir: str) -> List[str]:
    """
    从 OLE 复合文档中提取图片

    .doc 文件中的图片通常存储在：
    - 0Table/1Table 流中的嵌入对象
    - WordDocument 流中的二进制数据

    Returns:
        List[str]: 提取的图片路径列表
    """
    os.makedirs(output_dir, exist_ok=True)
    image_paths = []

    try:
        ole = olefile.OleFileIO(doc_path)

        # 查找可能包含图片的流
        image_streams = []
        for stream in ole.listdir():
            stream_name = '/'.join(stream)
            # 检查是否包含图片相关的流
            if any(kw in stream_name.lower() for kw in ['object', 'image', 'picture', 'data', '1Table', '0Table']):
                image_streams.append(stream_name)

        print(f"  找到 {len(image_streams)} 个可能的图片流")

        # 尝试从每个流中提取图片
        image_index = 0
        for stream_name in image_streams:
            try:
                stream = ole.openstream(stream_name)
                data = stream.read()

                # 检测并提取嵌入的图片（JPEG/PNG/WMF/EMF）
                extracted = extract_images_from_binary(data, output_dir, image_index)
                image_index += len(extracted)
                image_paths.extend(extracted)
            except Exception:
                continue

        # 尝试从整个文件中提取图片
        with open(doc_path, 'rb') as f:
            all_data = f.read()

        # 提取 JPEG (FFD8...FFD9)
        extracted = extract_jpeg_from_binary(all_data, output_dir, image_index)
        image_paths.extend(extracted)
        image_index += len(extracted)

        # 提取 PNG (89504E47...AE426082)
        extracted = extract_png_from_binary(all_data, output_dir, image_index)
        image_paths.extend(extracted)
        image_index += len(extracted)

        ole.close()

        # 去重（基于文件大小）
        unique_images = []
        seen_sizes = set()
        for img_path in image_paths:
            try:
                size = os.path.getsize(img_path)
                if size not in seen_sizes and size > 100:  # 忽略太小的图片
                    seen_sizes.add(size)
                    unique_images.append(img_path)
            except OSError:
                continue

        return unique_images

    except Exception as e:
        print(f"OLE 图片提取失败：{e}")
        return []


def extract_images_from_binary(data: bytes, output_dir: str, start_index: int) -> List[str]:
    """从二进制数据中提取图片（通用）"""
    image_paths = []

    # 检测 JPEG 图片
    jpeg_start = data.find(b'\xFF\xD8\xFF')
    if jpeg_start >= 0:
        jpeg_end = data.find(b'\xFF\xD9', jpeg_start)
        if jpeg_end > 0:
            jpeg_data = data[jpeg_start:jpeg_end + 2]
            if len(jpeg_data) > 100:  # 最小图片大小
                img_path = os.path.join(output_dir, f'image_{start_index:02d}.jpg')
                with open(img_path, 'wb') as f:
                    f.write(jpeg_data)
                image_paths.append(img_path)
                print(f"  提取图片：{os.path.basename(img_path)} ({len(jpeg_data)} bytes)")

    return image_paths


def extract_jpeg_from_binary(data: bytes, output_dir: str, start_index: int) -> List[str]:
    """从二进制数据中提取所有 JPEG 图片"""
    image_paths = []
    pos = 0

    while True:
        # 查找 JPEG 开始标记
        jpeg_start = data.find(b'\xFF\xD8\xFF', pos)
        if jpeg_start < 0:
            break

        # 查找 JPEG 结束标记
        jpeg_end = data.find(b'\xFF\xD9', jpeg_start)
        if jpeg_end < 0:
            break

        jpeg_data = data[jpeg_start:jpeg_end + 2]

        # 检查图片是否足够大
        if len(jpeg_data) > 500:
            img_path = os.path.join(output_dir, f'image_{start_index + len(image_paths):02d}.jpg')
            with open(img_path, 'wb') as f:
                f.write(jpeg_data)
            image_paths.append(img_path)
            print(f"  提取 JPEG: {os.path.basename(img_path)} ({len(jpeg_data)/1024:.1f}KB)")

        pos = jpeg_end + 2

    return image_paths


def extract_png_from_binary(data: bytes, output_dir: str, start_index: int) -> List[str]:
    """从二进制数据中提取所有 PNG 图片"""
    image_paths = []
    pos = 0

    while True:
        # 查找 PNG 开始标记 (89 50 4E 47)
        png_start = data.find(b'\x89PNG', pos)
        if png_start < 0:
            break

        # 查找 PNG 结束标记 (IEND)
        png_end = data.find(b'IEND\xAE\x42\x60\x82', png_start)
        if png_end < 0:
            break

        png_data = data[png_start:png_end + 8]

        # 检查图片是否足够大
        if len(png_data) > 500:
            img_path = os.path.join(output_dir, f'image_{start_index + len(image_paths):02d}.png')
            with open(img_path, 'wb') as f:
                f.write(png_data)
            image_paths.append(img_path)
            print(f"  提取 PNG: {os.path.basename(img_path)} ({len(png_data)/1024:.1f}KB)")

        pos = png_end + 8

    return image_paths


def compress_image(image_path: str) -> Tuple[str, bool]:
    """压缩图片（如果需要）"""
    try:
        file_size = os.path.getsize(image_path)
        need_compress = file_size > IMAGE_SIZE_LIMIT

        if not need_compress:
            print(f"  跳过压缩：{os.path.basename(image_path)} ({file_size/1024:.1f}KB)")
            return image_path, False

        print(f"  压缩：{os.path.basename(image_path)} ({file_size/1024:.1f}KB)")

        img = Image.open(image_path)
        width, height = img.size

        # 转换为 RGB（处理 PNG 透明通道）
        if img.mode in ('RGBA', 'LA', 'P'):
            img = img.convert('RGB')

        # 计算缩放比例
        if width > IMAGE_MAX_DIMENSION or height > IMAGE_MAX_DIMENSION:
            scale = IMAGE_MAX_DIMENSION / max(width, height)
            width = int(width * scale)
            height = int(height * scale)
            img = img.resize((width, height), Image.Resampling.LANCZOS)
            print(f"    缩放：{width}x{height}")

        # 生成输出路径
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_path = os.path.join(os.path.dirname(image_path), f"{base_name}_compressed.jpg")

        # 保存为 JPG
        img.save(output_path, 'JPEG', quality=IMAGE_QUALITY * 10, optimized=True)

        new_size = os.path.getsize(output_path)
        print(f"    结果：{new_size/1024:.1f}KB (压缩比：{100-new_size/file_size*100:.1f}%)")

        return output_path, True

    except Exception as e:
        print(f"    压缩失败：{e}，使用原图")
        return image_path, False


def encode_image_to_base64(image_path: str) -> str:
    """将图片编码为 Base64"""
    result = subprocess.run(
        ['bash', '-c', f'cat "{image_path}" | base64'],
        capture_output=True,
        text=True
    )
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    raise FileNotFoundError(f"无法读取文件：{image_path}")


def get_image_mime_type(image_path: str) -> str:
    """获取图片 MIME 类型"""
    ext = os.path.splitext(image_path)[1].lower().lstrip('.')
    mime_types = {
        'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
        'gif': 'image/gif', 'webp': 'image/webp', 'bmp': 'image/bmp',
    }
    return mime_types.get(ext, 'image/jpeg')


def _prepare_image_for_vision(image_path: str, max_side: int = 4096, quality: int = 75) -> tuple[str, str]:
    """
    准备图片用于 vision API。
    - 最长边超过 max_side 则等比缩放（内存中，不修改原文件）
    - 返回 (base64_string, mime_type)
    """
    img = Image.open(image_path)
    w, h = img.size

    # 限制最长边
    longest = max(w, h)
    if longest > max_side:
        ratio = max_side / longest
        new_w = int(w * ratio)
        new_h = int(h * ratio)
        print(f"    [缩放] {w}x{h} -> {new_w}x{new_h} (API 限制 {max_side})")
        img = img.resize((new_w, new_h), Image.LANCZOS)

    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')

    import io
    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=quality, optimize=True)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return b64, "image/jpeg"


def analyze_image(image_path: str, api_key: str, model: str) -> str:
    """AI 分析图片内容（qwen3.6-plus vision，高精度模式）"""
    try:
        b64, mime_type = _prepare_image_for_vision(image_path)
        image_data_uri = f"data:{mime_type};base64,{b64}"

        client = OpenAI(api_key=api_key, base_url=DEFAULT_BASE_URL)

        IMAGE_ANALYSIS_PROMPT = """请仔细阅读这张图片，直接输出为结构清晰的 Markdown。

**严禁做的事情**：
- **严禁修改任何文字内容**，包括错别字、病句、数字、标点等——看到什么就输出什么
- 不要改写、扩写、或添加原文没有的内容
- 不要纠正任何你觉得"不对"的文字
- 不要删除任何内容，包括看似重复的部分——保留所有文字
- 不要添加任何说明、总结或分析

**输出格式要求**：
1. **标题**：用 # ## ### 标记明显的标题层级
2. **表格**：如果图片中有网格/多列布局，**必须**用 Markdown 表格输出
   - 表格列数必须与原图一致
   - 表格内每格的文字必须完整保留，严禁截断、省略、缩写
   - 跨行单元格用 `<br>` 换行保留全部文字
   - 不确定的列边界时，宁可多列也不要少列
3. **列表**：用 - 或 1. 标记列表项
4. **内容完整性**：每一行文字都必须出现在输出中，严禁省略任何一行

请直接输出 Markdown，不要加任何说明。"""

        completion = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": image_data_uri}},
                        {"type": "text", "text": IMAGE_ANALYSIS_PROMPT},
                    ],
                },
            ],
            extra_body={"vl_high_resolution_images": True},
            temperature=0.2,
        )

        return completion.choices[0].message.content

    except Exception as e:
        print(f"  AI 分析失败：{e}")
        return f"【图片分析失败】{os.path.basename(image_path)}"


def extract_text_with_strings(doc_path: str) -> str:
    """使用 strings 命令提取可读文本（备用方案）"""
    try:
        result = subprocess.run(
            ['strings', '-n', '4', doc_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode == 0 and result.stdout.strip():
            lines = result.stdout.strip().split('\n')
            valid_lines = []
            for line in lines:
                stripped = line.strip()
                has_chinese = bool(re.search(r'[\u4e00-\u9fff]+', stripped))
                has_alpha = bool(re.search(r'[a-zA-Z]{2,}', stripped))
                has_punct = bool(re.search(r'[，。？！、；：""''（）【】《》…—]+', stripped))

                if len(stripped) >= 4 and (has_chinese or has_alpha or has_punct):
                    clean_chars = sum(1 for c in stripped if c.isprintable())
                    if clean_chars / len(stripped) > 0.7:
                        valid_lines.append(stripped)

            return '\n\n'.join(valid_lines)
    except Exception as e:
        print(f"strings 提取失败：{e}")
    return ""


def analyze_and_organize_text(raw_text: str, image_descriptions: List[str],
                              metadata: Dict[str, str], api_key: str, model: str) -> str:
    """AI 分析并整理文本和图片内容"""
    ORGANIZE_PROMPT = """你是一个文档合并助手。以下是从旧版 Word (.doc) 文档提取的内容。

**任务：只做三件事，不要重新组织内容**
1. 去除明显的重复内容（如页眉页脚等）
2. 按原文档顺序拼接内容
3. 修正明显的 OCR/提取错字（如错别字、缺失标点），但**严禁改写原文意思**

**严禁做的事情：**
- 不要调整内容顺序
- 不要合并段落或改变段落结构
- 不要把分散的内容归类汇总
- 不要添加原文中没有的标题
- 不要修改标题层级
- 不要"优化"表述或扩写缩写，保持转录的原样
- **表格保留 Markdown 表格格式，不要改成文字描述**

图片处理：
- 将【图片解读】放在文档末尾的"附录"部分
- 不要试图猜测图片在原文中的位置

请直接输出整理后的完整 Markdown 内容，不要加任何说明文字。
"""

    try:
        client = OpenAI(api_key=api_key, base_url=DEFAULT_BASE_URL)

        # 组装内容：原始文本 + 图片解读
        full_text = raw_text

        if image_descriptions:
            full_text += "\n\n---\n\n【图片解读】\n\n"
            for i, desc in enumerate(image_descriptions, 1):
                full_text += f"\n【图片{i}】\n{desc}\n"

        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "你是专业的文档整理专家。"},
                {"role": "user", "content": f"{ORGANIZE_PROMPT}\n\n{full_text}"},
            ],
            temperature=0.3,
        )

        return completion.choices[0].message.content

    except Exception as e:
        print(f"AI 整理失败：{e}")
        return format_text_simple(raw_text, image_descriptions, metadata)


def format_text_simple(raw_text: str, image_descriptions: List[str], metadata: Dict[str, str]) -> str:
    """简单格式化文本（AI 失败时的回退方案）"""
    lines = []

    if metadata.get('title'):
        lines.append(f"# {metadata['title']}")
    else:
        lines.append("# 文档内容")

    lines.append("")

    if metadata.get('author') or metadata.get('create_time'):
        lines.append("> 元数据信息：")
        if metadata.get('author'):
            lines.append(f"> - 作者：{metadata['author']}")
        if metadata.get('create_time'):
            lines.append(f"> - 创建时间：{metadata['create_time']}")
        lines.append("")
        lines.append("---")
        lines.append("")

    lines.append(raw_text)

    # 添加图片描述
    if image_descriptions:
        lines.append("\n\n---\n\n")
        lines.append("## 图片内容\n\n")
        for i, desc in enumerate(image_descriptions, 1):
            lines.append(f"### 图片{i}\n\n{desc}\n\n")

    return '\n'.join(lines)


def doc_to_md(doc_path: str, api_key: str = None, model: str = None,
              use_ai: bool = True) -> bool:
    """主流程：将 .doc 转换为 Markdown（支持图片）"""
    print("=" * 60)
    print("DOC (Word 97-2003) 智能转 Markdown 工具（支持图片）")
    print("=" * 60)

    api_key = api_key or os.getenv("DASHSCOPE_API_KEY") or DEFAULT_API_KEY
    model = model or DEFAULT_MODEL

    print(f"\n使用模型：{model}")
    print(f"API 地址：{DEFAULT_BASE_URL}")

    # 查找文件
    print("\n[1/6] 查找文件...")
    real_path = find_file(doc_path)
    if not real_path:
        print(f"错误：找不到文件：{doc_path}")
        return False

    doc_path = real_path
    print(f"  找到：{os.path.basename(doc_path)}")

    # 验证文件
    print("\n[2/6] 验证文件...")
    is_valid, file_size = verify_file_access(doc_path)
    if not is_valid:
        print("错误：无法访问文件或文件太小")
        return False
    print(f"  文件大小：{file_size / 1024:.1f} KB")

    # 检查文件格式
    print("\n[3/6] 检查文件格式...")
    if not check_ole_file(doc_path):
        print("警告：文件不是标准的 OLE 复合文档格式")
        print("尝试继续处理...")
    else:
        print("  格式确认：OLE 复合文档（Word 97-2003 格式）")

    # 确定输出路径
    file_name = os.path.splitext(os.path.basename(doc_path))[0]
    output_dir = os.path.dirname(doc_path)
    output_path = os.path.join(output_dir, f"{file_name}.md")
    images_dir = os.path.join(output_dir, f"{file_name}_images")

    print(f"\n[4/6] 输出配置:")
    print(f"  输出文件：{output_path}")
    print(f"  图片目录：{images_dir}")

    # 复制文件到临时目录
    print(f"\n[5/6] 开始转换...")
    print("-" * 60)

    temp_path = None
    image_descriptions = []

    try:
        temp_path = copy_file_to_temp(doc_path)
        print(f"  临时文件：{temp_path}")

        # 步骤 1: 提取文本
        print("\n步骤 1: 提取文本...")
        raw_text = extract_text_with_textutil(temp_path)
        metadata = {}

        if raw_text and len(raw_text.strip()) > 100:
            print(f"  textutil 提取到 {len(raw_text)} 个字符")
        else:
            print("  textutil 提取内容较少，尝试 strings...")
            raw_text = extract_text_with_strings(temp_path)
            print(f"  strings 提取到 {len(raw_text)} 个字符")

        if not raw_text.strip():
            print("  错误：未能提取到任何文本内容")
            return False

        # 步骤 2: 提取图片
        print("\n步骤 2: 提取图片...")
        os.makedirs(images_dir, exist_ok=True)
        image_paths = extract_images_from_ole(temp_path, images_dir)

        if image_paths:
            print(f"  提取到 {len(image_paths)} 张图片")
        else:
            print("  未检测到图片")

        # 步骤 3: 压缩并分析图片
        if image_paths and use_ai and OPENAI_AVAILABLE:
            print("\n步骤 3: 压缩并分析图片...")
            print("-" * 60)

            compressed_images = []
            for img_path in image_paths:
                compressed_path, _ = compress_image(img_path)
                compressed_images.append(compressed_path)

            # AI 分析每张图片
            print("\nAI 分析每张图片...")
            for img_path in compressed_images:
                desc = analyze_image(img_path, api_key, model)
                image_descriptions.append(desc)
                img_name = os.path.basename(img_path)
                title_match = re.search(r'【图片类型】：(.+)', desc)
                title = title_match.group(1).strip() if title_match else '未知'
                print(f"  {img_name}: {title[:50]}...")

        # 步骤 4: AI 整理
        print(f"\n[6/6] AI 整理文档...")
        print("-" * 60)

        if use_ai and OPENAI_AVAILABLE:
            final_md = analyze_and_organize_text(raw_text, image_descriptions, metadata, api_key, model)
        else:
            print("  跳过 AI 整理")
            final_md = format_text_simple(raw_text, image_descriptions, metadata)

        # 保存文件
        print(f"\n保存 Markdown 文件...")
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(final_md)
        print(f"  已保存：{output_path}")

        print("\n" + "=" * 60)
        print("转换完成！")
        print(f"  输出文件：{output_path}")
        print(f"  图片目录：{images_dir} ({len(image_paths)} 张图片)")
        print(f"  提取字符数：{len(raw_text)}")
        print("=" * 60)

        return True

    except Exception as e:
        print(f"\n处理失败：{e}")
        import traceback
        traceback.print_exc()
        return False

    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("\n用法:")
        print("  python doc97to md.py <doc_file>")
        print("\n示例:")
        print('  python doc97to md.py "document.doc"')
        print("\n可选参数:")
        print("  --no-ai    跳过 AI 整理")
        print("  --api-key  指定 API Key")
        print("  --model    指定模型名称")
        sys.exit(1)

    args = sys.argv[1:]

    doc_path = None
    api_key = None
    model = None
    use_ai = True

    i = 0
    while i < len(args):
        if args[i] == '--no-ai':
            use_ai = False
            i += 1
        elif args[i] == '--api-key':
            if i + 1 < len(args):
                api_key = args[i + 1]
                i += 2
            else:
                print("错误：--api-key 需要指定值")
                sys.exit(1)
        elif args[i] == '--model':
            if i + 1 < len(args):
                model = args[i + 1]
                i += 2
            else:
                print("错误：--model 需要指定模型名称")
                sys.exit(1)
        elif args[i].startswith('-'):
            print(f"未知参数：{args[i]}")
            sys.exit(1)
        else:
            doc_path = args[i]
            i += 1

    if not doc_path:
        print("错误：请指定 .doc 文件路径")
        sys.exit(1)

    try:
        success = doc_to_md(doc_path, api_key, model, use_ai)
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n处理失败：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
