"""专用上下文收集端点 — 供外部工作流调用

与 /api/v1/chat/ 的区别：
- 只收集结构化上下文（实体+关系），不生成回答
- 省去 generate_response() 的 LLM token 消耗
- 返回原始结构化数据，由调用方自行格式化

使用示例：
    from backend.reasoning.context_api import get_ontology_context
    result = await get_ontology_context("ProductX的核心优势")
    # → {entities: [...], relations: [...], intent: "entity_info", hit: True}
"""

import logging

from backend.reasoning.intent import classify_intent
from backend.reasoning.engine import ReasoningEngine
from backend.db import async_session

logger = logging.getLogger(__name__)


async def get_ontology_context(question: str) -> dict:
    """收集 Ontology 知识图谱上下文（仅结构化数据，不生成回答）

    Args:
        question: 用户原始问题

    Returns:
        {
            "entities": [{"name": str, "type": str, "properties": dict}, ...],
            "relations": [{"source": str, "target": str, "type": str}, ...],
            "intent": str,       # Ontology 内部意图类型 (entity_info/comparison/...)
            "hit": bool,          # 是否找到相关实体
        }
    """
    if not question or not question.strip():
        return {"entities": [], "relations": [], "intent": "general", "hit": False}

    question = question.strip()

    # 1. Ontology 内部意图分类（entity_info / comparison / objection / scenario / prep）
    try:
        intent_result = await classify_intent(question)
    except Exception as e:
        logger.warning(f"[Ontology] 意图分类失败: {e}")
        return {"entities": [], "relations": [], "intent": "general", "hit": False}

    intent_type = intent_result.get("intent", "general")
    entity_names = intent_result.get("entities", [])

    if intent_type == "general" or not entity_names:
        return {"entities": [], "relations": [], "intent": intent_type, "hit": False}

    # 2. 多跳图遍历收集上下文
    try:
        async with async_session() as session:
            engine = ReasoningEngine(session)
            context = await engine.gather_context(
                entity_names,
                intent=intent_type,
                max_hops=2,
            )
    except Exception as e:
        logger.warning(f"[Ontology] 上下文收集失败: {e}")
        return {"entities": [], "relations": [], "intent": intent_type, "hit": False}

    # 3. 精简实体数据（只保留关键字段，去掉内部 ID）
    entities = []
    for e in context.get("entities", []):
        entities.append({
            "name": e.get("name", "?"),
            "type": e.get("type", "?"),
            "properties": e.get("properties", {}),
        })

    relations = context.get("relations", [])

    return {
        "entities": entities,
        "relations": relations,
        "intent": intent_type,
        "hit": len(entities) > 0,
    }
