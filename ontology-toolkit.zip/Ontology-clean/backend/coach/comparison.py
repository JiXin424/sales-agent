"""竞品对比 — 基于本体知识分析竞争优势"""

import json
import logging

from sqlalchemy.ext.asyncio import AsyncSession

from backend.reasoning.intent import classify_intent
from backend.reasoning.engine import ReasoningEngine
from backend.llm import chat_pro

logger = logging.getLogger(__name__)

COMPARISON_PROMPT = """你是资深销售顾问，帮销售人员分析竞品对比。

基于以下知识：
{context}

我方产品和竞品信息：
- 实体：{entities}
- 关系：{relations}

用户问题：{question}

请生成竞品对比分析：
1. 核心差异对比表
2. 我方优势分析
3. 竞品优势（客观分析）
4. 销售话术建议（如何突出我方优势）
5. 注意事项（不要贬低竞品）

输出 JSON：
{{"analysis": "完整对比分析（Markdown格式）", "our_advantages": ["优势1", "优势2"], "their_advantages": ["竞品优势1"], "talking_points": ["话术要点"], "evidence": ["支撑证据"]}}"""


async def generate_comparison(question: str, session: AsyncSession) -> dict:
    """生成竞品对比分析"""
    # 1. 意图分析
    intent_result = await classify_intent(question)

    # 2. 收集上下文
    engine = ReasoningEngine(session)
    context_data = await engine.reason(question, intent_result)

    entities = json.dumps(
        [{"name": e["name"], "type": e["type"], "properties": e.get("properties", {})}
         for e in context_data.get("entities", [])],
        ensure_ascii=False,
    )
    relations = json.dumps(context_data.get("relations", []), ensure_ascii=False)

    # 3. 生成对比分析
    prompt = COMPARISON_PROMPT.format(
        context="九峰医疗产品知识库",
        entities=entities,
        relations=relations,
        question=question,
    )

    result_text = await chat_pro(
        messages=[{"role": "user", "content": prompt}],
        max_tokens=3000,
        response_format={"type": "json_object"},
    )

    try:
        result = json.loads(result_text)
    except json.JSONDecodeError:
        result = {"analysis": result_text, "our_advantages": [], "their_advantages": [], "talking_points": [], "evidence": []}

    return {
        "analysis": result.get("analysis", ""),
        "our_advantages": result.get("our_advantages", []),
        "their_advantages": result.get("their_advantages", []),
        "talking_points": result.get("talking_points", []),
        "evidence": result.get("evidence", []),
    }
