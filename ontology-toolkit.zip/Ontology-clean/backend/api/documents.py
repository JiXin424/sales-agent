"""文档上传 API — 支持单文件和批量上传"""

import os
import asyncio

from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from backend.db import get_db
from backend.document.pipeline import process_document
from backend.ontology.crud import ensure_default_types

router = APIRouter(prefix="/api/v1/documents", tags=["documents"])

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "uploads")

SUPPORTED_EXTENSIONS = {".docx", ".pdf", ".doc", ".xlsx", ".pptx", ".txt", ".md"}


@router.post("/upload")
async def upload_document(file: UploadFile = File(...), db: AsyncSession = Depends(get_db)):
    """上传单个文档并自动构建本体"""
    if not file.filename:
        raise HTTPException(status_code=400, detail="文件名不能为空")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"不支持的文件格式: {ext}")

    os.makedirs(UPLOAD_DIR, exist_ok=True)

    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)

    try:
        result = await process_document(file_path, db)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upload/batch")
async def upload_batch(files: list[UploadFile] = File(...), db: AsyncSession = Depends(get_db)):
    """批量上传文档并构建本体（支持多文件）"""
    if not files:
        raise HTTPException(status_code=400, detail="至少上传一个文件")

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    await ensure_default_types(db)

    results = []
    errors = []

    for file in files:
        if not file.filename:
            errors.append({"filename": None, "error": "文件名不能为空"})
            continue

        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            errors.append({"filename": file.filename, "error": f"不支持的格式: {ext}"})
            continue

        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)

        try:
            result = await process_document(file_path, db)
            results.append({
                "filename": file.filename,
                "status": "success",
                "objects_count": result["objects_count"],
                "links_count": result["links_count"],
            })
        except Exception as e:
            errors.append({"filename": file.filename, "error": str(e)})

    await db.commit()

    return {
        "status": "completed",
        "processed": len(results),
        "failed": len(errors),
        "results": results,
        "errors": errors,
    }


@router.get("/")
async def list_documents(db: AsyncSession = Depends(get_db)):
    """列出所有文档"""
    from sqlalchemy import select
    from backend.ontology.models import Document

    result = await db.execute(select(Document).order_by(Document.created_at.desc()))
    docs = result.scalars().all()

    return {
        "documents": [
            {
                "id": d.id,
                "filename": d.filename,
                "file_type": d.file_type,
                "status": d.status,
                "created_at": d.created_at.isoformat() if d.created_at else None,
            }
            for d in docs
        ]
    }


@router.delete("/{document_id}")
async def delete_document(document_id: int, db: AsyncSession = Depends(get_db)):
    """删除文档及其关联实体"""
    from sqlalchemy import select, delete
    from backend.ontology.models import Document, Object, Link

    result = await db.execute(select(Document).where(Document.id == document_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(status_code=404, detail="文档不存在")

    # 删除关联关系（源或目标实体属于该文档）
    await db.execute(
        delete(Link).where(
            Link.source_id.in_(select(Object.id).where(Object.source_document_id == document_id))
        )
    )
    await db.execute(
        delete(Link).where(
            Link.target_id.in_(select(Object.id).where(Object.source_document_id == document_id))
        )
    )
    # 删除关联实体
    await db.execute(delete(Object).where(Object.source_document_id == document_id))
    # 删除文档
    await db.delete(doc)
    await db.commit()

    return {"status": "deleted", "document_id": document_id}


@router.post("/build-context")
async def build_context(db: AsyncSession = Depends(get_db)):
    """从已入库实体生成背景知识上下文并持久化"""
    from backend.knowledge.context import save_context

    text = await save_context(db)
    return {"status": "success", "context_length": len(text)}
