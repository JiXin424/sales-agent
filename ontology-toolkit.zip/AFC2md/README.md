# AFC2md — 统一文档转 Markdown 工具

> 将 PDF / PPTX / DOCX / DOC / XLSX / 图片 统一转换为**无表格、无制表符**的 Markdown 文档，输出可直接用于知识库入库和向量化检索。

## 项目定位

企业知识库建设中，最大的瓶颈不是缺内容，而是**内容格式不统一**——PDF 扫描件、PPT 培训材料、Word 访谈记录、Excel 数据表混杂在一起，无法直接入库。

AFC2md 通过 **AI 视觉分析 + 文本整理** 的双模型流水线，将各种格式的文档统一转换为结构清晰、语义完整的 Markdown，解决传统工具（如 pandoc、PyMuPDF）只能提取"文字碎片"、无法还原版面语义的问题。

> **输出即入库**：转换后的 Markdown 无表格、无制表符，可直接送入 md_optimizer 做向量化检索优化。

---

## 核心优势

### 1. 多格式全覆盖，一个工具搞定

| 格式 | 处理方式 | 特点 |
|------|----------|------|
| PDF | PyMuPDF 渲染为图片 → AI 视觉分析 | 识别复杂排版、图表、图文混排 |
| PPTX | 导出为图片 → AI 视觉分析 | 还原幻灯片结构和逻辑 |
| DOCX | 提取文本+图片 → AI 整理 | 保留文档层级和图文关系 |
| DOC | OLE 流提取 / textutil 转换 | 兼容 Word 97-2003 老格式 |
| XLSX | 读取数据 → AI 转为文字描述 | 表格变叙事，适合知识库 |
| 图片 | AI 视觉分析 | 支持 JPG/PNG/WEBP/HEIC 等 8 种格式 |

### 2. AI 双模型流水线（Vision + Text）

针对 PDF/PPTX/图片等视觉密集型格式，采用两阶段处理：

1. **Vision 识别**：qwen3.6-plus（vl_high_resolution_images 模式）逐页识别，理解版面布局、图表含义
2. **文本整理**：deepseek-v4-pro 合并分页、去重、补全上下文，输出连贯的 Markdown

**相比单阶段 OCR 的优势**：不只是"看到文字"，而是"理解文档结构"。

### 3. 输出即入库，零二次加工

- **无表格语法**：XLSX 的表格转为文字描述，PDF 的表格转为结构化列表
- **无制表符**：纯 Markdown 语法，兼容所有 RAG 系统
- **语义完整**：AI 整理时会补全主语、消除指代歧义，输出可直接用于向量化

### 4. 智能批量处理

- **batch_fast.sh**：智能并发策略——DOCX/XLSX 并行 5 并发（速度快），PPTX/PDF 串行（避免 API 限流）
- **自动跳过**：已处理的文件自动跳过，支持断点续传
- **自动清理**：临时图片/中间目录处理完成后自动删除

### 5. 灵活控制

- `--no-ai`：跳过 AI 整理，仅提取原始内容（适合格式已规范的文档）
- `--keep-temp`：保留临时文件，便于调试和复核
- 支持环境变量覆盖 API Key，方便多项目复用

---

## 支持的格式

| 格式 | 扩展名 | 处理方式 |
|------|--------|----------|
| PDF | `.pdf` | PyMuPDF 渲染为图片 → AI 视觉分析 → 文本整理 |
| PPTX | `.pptx` | 导出为图片 → AI 视觉分析 → 文本整理 |
| DOCX | `.docx` | 提取文本 + 图片 → AI 整理 |
| DOC | `.doc` | OLE 流提取 / textutil 转换 → AI 整理 |
| XLSX | `.xlsx` | openpyxl 读取 → AI 整理为文字描述 |
| 图片 | `.jpg` `.jpeg` `.png` `.webp` `.gif` `.bmp` `.heic` `.heif` | AI 视觉分析 |

---

## 安装依赖

```bash
# 全部安装
pip install openai pillow PyMuPDF python-docx olefile openpyxl

# 或按需安装
pip install openai pillow                    # 基础依赖（所有工具必需）
pip install PyMuPDF                          # PDF 处理
pip install python-docx                      # DOCX 处理
pip install olefile                          # DOC (旧版 Word) 处理
pip install openpyxl                         # XLSX 处理
```

---

## 快速开始

### 单文件转换

```bash
python convert.py "document.pdf"
python convert.py "report.pptx"
python convert.py "data.xlsx"
python convert.py "photo.jpg"

# 跳过 AI 整理（仅提取原始内容）
python convert.py "document.docx" --no-ai

# 保留临时文件（不清理中间图片目录）
python convert.py "document.pdf" --keep-temp
```

### 批量转换多个文件

```bash
# convert.py 原生支持多文件
python convert.py file1.pdf file2.docx file3.xlsx

# 或混合参数
python convert.py file1.pdf file2.docx --no-ai
```

### 批量处理整个目录

```bash
# 方式一：batch_fast.sh（推荐）
# - DOCX/XLSX 并行 5 并发（速度快）
# - PPTX/PDF 串行处理（避免 API 限流）
# - 自动跳过已处理的文件
# - 自动清理中间目录
bash batch_fast.sh

# 方式二：batch_convert.py（保持目录结构）
# 编辑文件内的 SOURCE_DIR / TARGET_DIR 后运行
python batch_convert.py
```

**输出位置**：与输入文件同目录，生成同名 `.md` 文件。

---

## 各格式处理详情

### PDF / PPTX

双模型流水线：
1. **Vision 识别**：qwen3.6-plus（vl_high_resolution_images 模式）逐页识别
2. **文本整理**：deepseek-v4-pro 合并分页、整理为连贯 Markdown

输出结构：
```
document.pdf
├── document.md                 # 最终输出
document_images/                # 临时目录（自动清理）
├── page_01.jpg
└── md/page_01.md
```

### DOCX

- 纯文字文档：直接提取文本并结构化
- 带图文档：提取图片 → 压缩 → AI 解读 → 图文拼合 → 整理输出

输出结构：
```
document.docx
├── document.md                 # 最终输出
document_extracted/             # 临时目录（自动清理）
└── media/
```

### DOC (Word 97-2003)

- 优先 OLE 流提取纯文本
- 失败时 fallback 到 macOS `textutil` 转换
- 提取的图片放在附录

### XLSX

- 逐工作表读取
- 表格数据转换为文字描述或数字列表
- 输出无表格语法的纯 Markdown

### 图片

- 单张：`python img2md.py "photo.jpg"`
- 批量：`python img2md.py --batch "./images/"`
- 支持 `--output` 指定输出目录

---

## 文件清单

| 文件 | 说明 |
|------|------|
| `convert.py` | **统一入口**，自动检测格式、调度处理器 |
| `batch_fast.sh` | **快速批量脚本**，智能并发策略 |
| `batch_convert.py` | **批量工具**，保持源目录结构输出 |
| `doc2md.py` | PDF / PPTX 处理器（双模型流水线） |
| `docx2md.py` | DOCX 处理器 |
| `doc97tomd.py` | DOC (Word 97-2003) 处理器 |
| `xlsx2md.py` | XLSX 处理器 |
| `img2md.py` | 图片处理器（单张 / 批量） |

---

## 配置说明

### API 配置

**Vision 识别（PDF/PPTX/图片）**
```python
VISION_API_KEY   = "sk-b97cb2166eae40ea872ba595538179dc"   # 通义千问
VISION_BASE_URL  = "https://dashscope.aliyuncs.com/compatible-mode/v1"
VISION_MODEL     = "qwen3.6-plus"
```

**文本整理（全部格式）**
```python
DEFAULT_API_KEY  = "sk-2a57f0e27d6b46259ce222383f94bf4c"   # DeepSeek
DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL    = "deepseek-v4-pro"
```

### 环境变量覆盖

```bash
export VISION_API_KEY="your-qwen-key"
export DEFAULT_API_KEY="your-deepseek-key"
```

### CLI 参数

| 参数 | 适用工具 | 说明 |
|------|----------|------|
| `--no-ai` | convert.py, xlsx2md.py | 跳过 AI 整理，仅提取原始内容 |
| `--keep-temp` | convert.py | 保留临时文件（不清理 `_images` / `_extracted`） |
| `--api-key` | 各子工具 | 指定 API Key |
| `--model` | 各子工具 | 指定模型名称 |
| `--output` | img2md.py, xlsx2md.py | 指定输出路径 |
| `--batch` | img2md.py | 批量处理目录 |

---

## 故障排查

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 找不到文件 | iCloud 幽灵文件 | 工具自动处理，使用完整路径 |
| 中文路径错误 | macOS 路径编码 | 工具已内置处理 |
| AI 分析超时 | 网络问题 | 检查网络，确认 API Key 有效 |
| 依赖库缺失 | 未安装 | 根据错误运行 `pip install` |
| 文件格式不支持 | 非标准格式 | 检查扩展名是否在支持列表 |
| DOC 转换失败 | 复杂 OLE 结构 | 手动用 Word 另存为 DOCX 后处理 |

---

## 安全说明

- **API Key**：默认配置仅供测试，生产环境请替换为自己的 Key
- **文件处理**：文本提取在本地完成，仅图片数据发送至 AI API
- **临时文件**：处理完成后自动清理，加 `--keep-temp` 可保留

---

## 更新日志

### v3.1
- 新增 `batch_fast.sh` — 智能并发批量脚本（DOCX/XLSX 并行，PPTX/PDF 串行）
- `convert.py` 支持多文件批量参数

### v3.0
- 创建统一 CLI 工具 `convert.py`
- 自动检测文件类型并调度处理器
- 简化目录结构

### v2.0
- 新增 `docx2md.py` / `doc97tomd.py` / `xlsx2md.py` / `img2md.py`

### v1.0
- 初始版本，支持 PDF / PPTX

---

*项目位置：`/Users/fred/Documents/cc_Projects/Taishan/api-software/AFC2md`*
