"""加载 influence_ontology.json 并构建内存存储。"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

from .models import Ontology
from .store import OntologyStore


def load(json_path: Optional[os.PathLike] = None) -> OntologyStore:
    """从 JSON 文件加载本体并构建内存存储。"""
    if json_path is None:
        # 默认从当前包的父目录（即 ontology_runtime 同级）查找
        here = Path(__file__).resolve().parent
        json_path = here.parent.parent / "influence_ontology.json"
    else:
        json_path = Path(json_path)

    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    ontology = Ontology.model_validate(data)
    return OntologyStore(ontology)
