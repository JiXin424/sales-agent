"""加载器与存储集成测试。"""

from pathlib import Path

import pytest

from influence_ontology_runtime import load
from influence_ontology_runtime.models import Case, Ontology, Principle

DATA_PATH = Path(__file__).resolve().parent.parent.parent / "influence_ontology.json"


def test_load_full_ontology():
    store = load(DATA_PATH)
    stats = store.stats()
    assert stats["principles"] == 13
    assert stats["cases"] == 111
    assert stats["relations"] == 166


def test_get_by_id():
    store = load(DATA_PATH)
    p = store.get_by_id("reciprocity-principle")
    assert p is not None
    assert isinstance(p, Principle)
    assert "互惠" in p.name


def test_get_by_type():
    store = load(DATA_PATH)
    cases = store.get_by_type("case")
    assert len(cases) == 111
    assert all(isinstance(c, Case) for c in cases)


def test_get_by_name_fuzzy():
    store = load(DATA_PATH)
    results = store.get_by_name("互惠", fuzzy=True)
    assert any("互惠" in (e.name or "") for e in results)


def test_cases_by_principle():
    store = load(DATA_PATH)
    cases = store.get_cases_by_principle("reciprocity-principle")
    assert len(cases) > 0
    assert all(isinstance(c, Case) for c in cases)


def test_explain_principle():
    store = load(DATA_PATH)
    exp = store.explain_principle("authority-principle")
    assert "principle" in exp
    assert "cases" in exp
    assert "tactics" in exp
    assert len(exp["cases"]) > 0 or len(exp["tactics"]) > 0


def test_relations():
    store = load(DATA_PATH)
    rels = store.get_relations("reciprocity-principle", direction="out")
    assert len(rels) >= 0


def test_neighbors():
    store = load(DATA_PATH)
    neighbors = store.get_neighbors("jewelry-store-case")
    assert isinstance(neighbors, list)
