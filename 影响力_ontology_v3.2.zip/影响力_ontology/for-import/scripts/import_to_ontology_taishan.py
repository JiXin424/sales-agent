#!/usr/bin/env python3
"""将 influence_ontology.json 导入下一版 Ontology-Taishan。

这是一个模板脚本，需要根据实际 Ontology-Taishan 的类型定义和 loader 接口实现。
"""

import json
import os
from pathlib import Path

INFLUENCE_JSON = Path(__file__).parent.parent / "influence_ontology.json"

# TODO: 根据实际项目路径修改
ONTOLOGY_TAISHAN_DIR = Path("/path/to/Ontology-Taishan")


def load_influence_ontology():
    with open(INFLUENCE_JSON, "r", encoding="utf-8") as f:
        return json.load(f)


def map_to_methodology(principle: dict) -> dict:
    """将 Principle 映射为 Ontology-Taishan 的 Methodology。"""
    return {
        "code": principle.get("id", "").upper().replace("-", "_"),
        "name": principle.get("name", ""),
        "description": principle.get("description", ""),
        "mechanism": principle.get("core_mechanism", ""),
        "purpose": principle.get("social_function", ""),
        "tags": principle.get("keywords", []),
        "source": f"《影响力（经典版）》{principle.get('chapter', '')}".strip(),
    }


def map_to_case(case: dict) -> dict:
    """将 Case 映射为 Ontology-Taishan 的 Case。"""
    return {
        "code": case.get("id", ""),
        "name": case.get("name", ""),
        "summary": case.get("summary", ""),
        "characters": case.get("characters", []),
        "trigger": case.get("trigger", ""),
        "behavior": case.get("behavior", ""),
        "outcome": case.get("outcome", ""),
        "source_text": case.get("source_text", ""),
        "related_methodology": case.get("principle", ""),
    }


def map_to_button(tactic: dict) -> dict:
    """将 Tactic 映射为 Ontology-Taishan 的 Button / ScenarioButton。"""
    return {
        "code": tactic.get("id", ""),
        "name": tactic.get("name", ""),
        "en_name": tactic.get("en_name", ""),
        "description": "; ".join(tactic.get("steps", [])),
        "scenario": tactic.get("scenario", ""),
        "expected_result": tactic.get("expected_result", ""),
        "risk": tactic.get("risk", ""),
        "example": tactic.get("example", ""),
        "methodology_code": tactic.get("principle_id", ""),
    }


def detect_conflicts(existing_entities, new_entities, key="code"):
    """检测同名冲突。"""
    existing_codes = {e.get(key, "") for e in existing_entities}
    conflicts = []
    for e in new_entities:
        code = e.get(key, "")
        if code in existing_codes:
            conflicts.append(code)
    return conflicts


def main():
    data = load_influence_ontology()

    methodologies = [map_to_methodology(p) for p in data.get("principles", [])]
    cases = [map_to_case(c) for c in data.get("cases", [])]
    buttons = [map_to_button(t) for t in data.get("tactics", [])]

    print(f"准备导入: {len(methodologies)} 个方法论, {len(cases)} 个案例, {len(buttons)} 个按钮")

    # TODO: 加载现有 Ontology-Taishan 实体并检测冲突
    # existing = load_existing_entities()
    # conflicts = detect_conflicts(existing, methodologies)
    # if conflicts:
    #     print("发现冲突:", conflicts)
    #     return

    # TODO: 调用 loader 导入
    # from ontology_taishan.loader import load_all
    # load_all(...)

    print("导入脚本模板执行完毕。请根据实际 loader 接口实现具体导入逻辑。")


if __name__ == "__main__":
    main()
