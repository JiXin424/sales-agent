#!/usr/bin/env python3
"""升级的系统提示词模板"""

# 《影响力（经典版）》知识库结构
ONTOLOGY_STRUCTURE = """
## 《影响力（经典版）》知识库结构

### 核心分类（11大类）

1. **principles (13)** - 核心影响力原则
   - 互惠原理 (reciprocity-principle)
   - 稀缺原理 (scarcity-principle)
   - 权威原理 (authority-principle)
   - 对比原理 (principle-contrast)
   - 承诺和一致原理 (commitment-and-consistency-principle)
   - 社会认同原理 (social-identity-principle)
   - 喜好原理 (liking-principle)
   - 价格-质量原则 (principle-price-quality)
   - 自我责任原理 (self-responsibility-principle)
   - 公开承诺原理 (public-commitment-principle)
   - 心理逆反理论 (psychological-reactance-theory)
   - 维特效应 (Werther-effect)
   - 承诺原理 (commitment-principle)

2. **concepts (49)** - 核心概念
   - 对失去某种东西的恐惧 (fear-of-loss)
   - 对获得同一物品的渴望 (desire-for-gain)
   - 死脑筋地保持一致 (mindless-consistency)
   - 稀缺性与物品价值 (scarcity-and-value)
   - 等等...

3. **terms (40)** - 专业术语
   - 互惠式让步
   - 拒绝—后撤术
   - 接受的义务
   - 登门槛技巧
   - 等等...

4. **cases (111)** - 案例研究
   - 服务员文森特案例
   - 特百惠聚会案例
   - 珠宝店绿宝石销售案例
   - 零售台球桌销售案例
   - 等等...

5. **experiments (47)** - 心理学实验
   - 中西部医院实验
   - 线路实验
   - 停车场实验
   - 等等...

6. **reasoning_chains (35)** - 推理链
   - 客户心理推理链
   - 销售流程推理链
   - 价格-质量推理链
   - 等等...

7. **tactics (26)** - 策略方法
   - 零售销售延期保修合同策略
   - 稀缺促销策略
   - 登门槛技巧
   - 等等...

8. **action_steps (44)** - 行动步骤
   - scarcity-promotion-step-1
   - good-cop-step-1
   - 等等...

9. **scripts (25)** - 话术模板
   - 初次拜访建立融洽开场白话术
   - 演示停顿对比话术
   - 等等...

10. **scenarios (42)** - 应用场景
    - ToB销售场景
    - ToC销售场景
    - 价格异议处理场景
    - 等等...

11. **persons (136)** - 相关人物
    - 研究者
    - 案例主角
    - 等等...

### 实体字段结构

每个实体包含以下字段（部分为可选）：

- **id**: 唯一标识符
- **name**: 显示名称
- **type**: 实体类型
- **description**: 详细描述
- **summary**: 内容摘要
- **core_mechanism**: 核心机制（原则类）
- **social_function**: 社会功能（原则类）
- **keywords**: 关键词列表
- **chapter**: 所属章节
- **characters**: 涉及人物（案例类）
- **principle**: 关联原则（案例/策略类）
- **trigger**: 触发条件
- **behavior**: 行为表现
- **outcome**: 结果效果
- **source_text**: 原文引用
"""

# 升级的系统提示词
ENHANCED_SYSTEM_PROMPT = """你是一个基于《影响力（经典版）》一书的资深销售教练和影响力专家。你的任务是帮助销售人员运用影响力原则解决实际问题。

## 知识库结构

我们的知识库包含 602 个实体，分为 11 大类：principles（原则）、concepts（概念）、terms（术语）、scenarios（场景）、cases（案例）、experiments（实验）、reasoning_chains（推理链）、tactics（策略）、action_steps（行动步骤）、scripts（话术）、persons（人物）。

## 如何利用各类知识（重要）

回答时按下列方式调用各类知识，而不是空谈理论：

- **核心原则（principles）**：理论根基。问"什么是 X"时，给 定义 → 核心机制 → 社会功能 → 常见误用
- **概念/术语（concepts/terms）**：解释专业词汇时使用，避免概念混淆
- **推理链（reasoning_chains）**：剖析客户心理、销售流程时使用，让回答有逻辑层次
- **策略方法（tactics）**：问"怎么做/如何应对"时优先引用，给出策略名 + 步骤
- **话术模板（scripts）**：问"该怎么说"时直接引用，可逐字使用
- **应用场景（scenarios）**：描述具体场景时，匹配标准应对路径
- **案例/实验（cases/experiments）**：作为说服支撑，证明原理有效
- **行动步骤（action_steps）**：给出具体可执行的步骤序列
- **人物（persons）**：引用研究者/案例主角，增强说服力

## 查询理解指南

当用户提问时，请识别以下信息：

### 1. 意图类型
- **理解型**："什么是X"、"X的原理" → 解释概念和机制
- **应用型**："如何应用X"、"X怎么用" → 给出具体步骤和案例
- **对比型**："X vs Y"、"X和Y的区别" → 对比分析
- **举例型**："X的例子"、"关于X的案例" → 提供案例
- **场景型**："遇到Y情况怎么办" → 场景化建议

### 2. 关键要素
用户查询可能包含以下要素，请优先识别：
- **原则名称**：互惠原理、稀缺原理、对比原理等
- **场景描述**：价格异议、初次拜访、客户拖延、建立信任等
- **行为动词**：应对、建立、推进、制造、处理等
- **对象描述**：客户、销售、产品、价格等
- **目标导向**：成交、信任、紧迫感、决策等

### 3. 结构化知识映射

用户提到以下词汇时，优先映射到对应实体类型：

**原则相关词汇**：
- 互惠、回报、恩惠 → 互惠原理相关
- 稀缺、紧缺、有限、不多 → 稀缺原理相关
- 权威、专家、认证 → 权威原理相关
- 对比、参照、比较 → 对比原理相关
- 承诺、一致、坚持 → 承诺一致原理相关
- 别人、他人、大家 → 社会认同原理相关
- 喜欢、关系、朋友 → 喜好原理相关
- 价格贵、质量好 → 价格质量原理相关

**场景相关词汇**：
- 嫌贵、价格高、太贵 → 价格异议场景
- 初次、第一次、见面 → 初次拜访场景
- 拖延、考虑、犹豫 → 拖延决策场景
- 建立信任、信任 → 关系建立场景
- 推进、成交、决策 → 推进成交场景
- 丢单、失败、拒绝 → 关系维护场景

**行为相关词汇**：
- 应对、处理、解决 → 应对策略
- 建立、增强、提升 → 建立方法
- 制造、创造、营造 → 制造技巧
- 推进、促成、加速 → 推进方法

## 回答结构建议

### 理解型问题
1. 定义和核心机制
2. 社会功能和作用
3. 关键特征
4. 常见误区

### 应用型问题
1. 直接回答（明确是否或具体步骤）
2. 策略方法（2-3个）
3. 具体话术（可直接使用）
4. 案例佐证（增强说服力）
5. 注意事项（避免错误）

### 对比型问题
1. 对比表格（维度清晰）
2. 各自优势
3. 适用场景
4. 选择建议

### 场景型问题
1. 场景分析（问题本质）
2. 原则匹配（适用哪些原则）
3. 具体步骤（分步指导）
4. 话术示例（可直接使用）
5. 应变处理（特殊情况）

## 使用知识库的最佳实践

1. **优先引用"核心实体"**（系统会专门标记）—— 这是用户直接问到的，必须充分展开
2. **利用"多跳扩展"知识丰富层次**—— 推理链让回答有逻辑，案例让回答有说服力，话术让回答可执行
3. **结构化呈现信息**：使用标题、列表分隔内容；重要关键词加粗；话术用代码块标记
4. **案例驱动**：每个原则至少配一个案例，说明如何应用到当前场景
5. **避免空泛**：不要只谈理论不谈实践，不要给出"加强沟通"这类无信息量建议

## 特别提醒

- 如果匹配到的实体description较简短，请基于你的知识进行适当展开
- 如果没有匹配到相关实体，明确告知用户，并基于你的《影响力》知识库经验给出建议
- 保持专业但友好的语气，像一位有经验的销售教练
- 回答要具体、可操作，避免空泛

现在，请基于以上指导，结合系统提供的相关知识实体，为用户提供专业、实用的建议。
"""

_TYPE_LABEL_MAP = {
    'principle': '原则', 'concept': '概念', 'term': '术语',
    'scenario': '场景', 'case': '案例', 'experiment': '实验',
    'reasoning_chain': '推理链', 'tactic': '策略',
    'action_step': '行动步骤', 'script': '话术', 'person': '人物',
}


def _type_label(t):
    return _TYPE_LABEL_MAP.get(t, t)


_SELF_REPETITION_PREFIXES = (
    '概念: ', '术语: ', '话术: ', '推理链: ', '案例: ', '实验: ',
    '策略: ', '场景: ', '行动步骤: ', '人物: ', '原则: ',
)


def _is_self_repetition(name, desc):
    """检测 description 是不是"类型: name"这种无价值重复"""
    if not desc or not name:
        return False
    if not isinstance(desc, str):
        return False
    desc_stripped = desc.strip()
    for prefix in _SELF_REPETITION_PREFIXES:
        if desc_stripped.startswith(prefix):
            rest = desc_stripped[len(prefix):].strip()
            if rest == name.strip() or rest.startswith(name.strip() + '\n'):
                return True
    if desc_stripped == name.strip():
        return True
    return False


def _clean_desc(name, desc):
    """清掉自我重复格式，返回真实内容；非字符串字段一律返回空"""
    if not isinstance(desc, str) or not desc:
        return ''
    if _is_self_repetition(name, desc):
        return ''
    return desc.strip()


def _smart_description(e):
    """按类型智能取最有价值的描述字段，过滤"类型: name"自我重复"""
    name = e.get('name', '')
    etype = e.get('type', '')

    if etype == 'principle':
        return _clean_desc(name, e.get('description'))

    if etype in ('concept', 'term'):
        for field in ('definition', 'summary', 'description'):
            v = _clean_desc(name, e.get(field))
            if v:
                return v
        return ''

    if etype == 'reasoning_chain':
        parts = []
        for field in ('premises', 'reasoning', 'trigger', 'behavior', 'consequence'):
            v = _clean_desc(name, e.get(field))
            if v:
                parts.append(v)
        if e.get('evidence'):
            ev = e['evidence']
            parts.append(f"证据: {', '.join(ev) if isinstance(ev, list) else ev}")
        return ' | '.join(parts)

    if etype == 'tactic':
        for field in ('summary', 'description', 'steps'):
            v = _clean_desc(name, e.get(field))
            if v:
                return v
        return ''

    if etype == 'script':
        ctx = _clean_desc(name, e.get('context'))
        text = _clean_desc(name, e.get('text'))
        if ctx and text:
            return f"适用场景: {ctx} | 话术: {text}"
        if text:
            return text
        if ctx:
            return f"适用场景: {ctx}"
        return _clean_desc(name, e.get('description'))

    if etype == 'case':
        for field in ('summary', 'description'):
            v = _clean_desc(name, e.get(field))
            if v:
                return v
        return ''

    if etype == 'experiment':
        parts = []
        for field in ('hypothesis', 'method'):
            v = _clean_desc(name, e.get(field))
            if v:
                parts.append(v)
        con = _clean_desc(name, e.get('conclusion'))
        if con:
            parts.append(f"结论: {con}")
        return ' | '.join(parts)

    if etype == 'scenario':
        for field in ('description', 'trigger', 'behavior', 'outcome'):
            v = _clean_desc(name, e.get(field))
            if v:
                return v
        return ''

    return _clean_desc(name, e.get('description'))


def _format_core_entity(e):
    etype = e.get('type', '')
    name = e.get('name', e.get('id', ''))
    out = f"### [{_type_label(etype)}] {name}\n"

    desc = _smart_description(e)
    if desc:
        out += f"**定义**: {desc}\n"

    if etype == 'principle':
        if e.get('core_mechanism'):
            out += f"**核心机制**: {e['core_mechanism']}\n"
        if e.get('social_function'):
            out += f"**社会功能**: {e['social_function']}\n"
    elif etype == 'reasoning_chain':
        if e.get('confidence'):
            out += f"**置信度**: {e['confidence']}\n"
    elif etype == 'experiment':
        if e.get('principle'):
            out += f"**关联原则**: {e['principle']}\n"
    elif etype == 'script':
        if e.get('principle_id'):
            out += f"**关联原则**: {e['principle_id']}\n"
        if e.get('source_case'):
            out += f"**来源案例**: {e['source_case']}\n"
    elif etype == 'case':
        if e.get('principle'):
            out += f"**关联原则**: {e['principle']}\n"
        if e.get('characters'):
            ch = e['characters']
            out += f"**人物**: {', '.join(ch) if isinstance(ch, list) else ch}\n"

    if e.get('keywords'):
        kw = e['keywords']
        if isinstance(kw, list):
            out += f"**关键词**: {', '.join(str(k) for k in kw)}\n"
        else:
            out += f"**关键词**: {kw}\n"

    return out + "\n"


def _format_brief_entity(e, max_desc=150):
    name = e.get('name', e.get('id', ''))
    etype = e.get('type', '')
    desc = _smart_description(e)
    if len(desc) > max_desc:
        desc = desc[:max_desc] + '...'
    label = _type_label(etype)
    if desc:
        return f"- **{name}** [{label}]: {desc}\n"
    return f"- **{name}** [{label}]\n"


HOP_LABEL_ORDER = [
    ('principles', '相关原则'),
    ('reasoning_chains', '相关推理链'),
    ('concepts', '相关概念'),
    ('terms', '相关术语'),
    ('tactics', '相关策略'),
    ('scripts', '相关话术'),
    ('scenarios', '相关场景'),
    ('cases', '相关案例'),
    ('experiments', '相关实验'),
    ('action_steps', '相关行动步骤'),
]


def get_structured_prompt(search_result, legacy_entities=None):
    """构建结构化系统提示词：核心实体 + 多跳扩展 + 多词匹配 + 兼容引擎匹配

    search_result: kg.search() 返回值
    legacy_entities: 旧版 search_ontology 的 top-K 实体列表（可空，用于并行展示）
    """
    prompt = ENHANCED_SYSTEM_PROMPT

    core = search_result.get('core_entities', [])
    hop_groups = search_result.get('hop_groups', {})
    layer3 = search_result.get('layer3_multiword', [])

    # 1. 核心实体（用户直接问到）
    if core:
        prompt += "\n\n## 本次查询的核心实体（用户直接命中，权重最高）\n\n"
        prompt += "以下是通过精确名称匹配（Layer 1）或同义词命中（Layer 2）找到的核心实体，必须充分引用：\n\n"
        for e in core:
            prompt += _format_core_entity(e)

    # 2. 多跳扩展
    if hop_groups:
        prompt += "\n\n## 通过知识图谱关系扩展的相关知识（1 跳）\n\n"
        prompt += "以下是核心实体通过本体内置 relations 自动扩展的相关知识，按类型分组：\n\n"
        for type_plural, label in HOP_LABEL_ORDER:
            lst = hop_groups.get(type_plural, [])
            if not lst:
                continue
            prompt += f"### {label}\n\n"
            for e in lst:
                prompt += _format_brief_entity(e)
            prompt += "\n"

    # 3. 新引擎 Layer3 多词匹配
    new_multi = [entry['entity'] for entry in layer3 if entry.get('entity')]
    # 去重：去掉已经在 core 或 hop 中的
    seen_names = {e.get('name') for e in core}
    for lst in hop_groups.values():
        for e in lst:
            seen_names.add(e.get('name'))
    new_multi = [e for e in new_multi if e.get('name') not in seen_names]
    if new_multi:
        prompt += "\n\n## 新引擎多词匹配的补充知识\n\n"
        prompt += "以下是通过多词匹配找到的相关实体（适合模糊场景查询），作为补充参考：\n\n"
        for e in new_multi[:5]:
            prompt += _format_brief_entity(e)

    # 4. 旧引擎结果（并行展示）
    if legacy_entities:
        # 去重
        legacy_unique = [e for e in legacy_entities
                         if e.get('name') not in seen_names
                         and e.get('name') not in {x.get('name') for x in new_multi}]
        if legacy_unique:
            prompt += "\n\n## 兼容引擎的补充匹配（旧版多词匹配，与新引擎结果并行参考）\n\n"
            for e in legacy_unique[:5]:
                prompt += _format_brief_entity(e)

    return prompt

def get_enhanced_system_prompt(relevant_entities):
    """生成增强的系统提示词（包含相关实体信息）"""

    prompt = ENHANCED_SYSTEM_PROMPT + "\n\n## 本次查询的相关知识\n\n"

    if relevant_entities:
        for i, entity in enumerate(relevant_entities, 1):
            entity_type = entity.get('type', 'Unknown')
            name = entity.get('name', entity.get('id', ''))
            description = entity.get('description', '')
            summary = entity.get('summary', '')

            # 根据类型格式化
            if entity_type == 'principle':
                core_mechanism = entity.get('core_mechanism', '')
                social_function = entity.get('social_function', '')
                keywords = entity.get('keywords', [])

                prompt += f"### 原则{i}: {name}\n"
                if description:
                    prompt += f"**定义**: {description}\n"
                if core_mechanism:
                    prompt += f"**核心机制**: {core_mechanism}\n"
                if social_function:
                    prompt += f"**社会功能**: {social_function}\n"
                if keywords:
                    prompt += f"**关键词**: {', '.join(keywords)}\n"

            elif entity_type == 'case':
                prompt += f"### 案例{i}: {name}\n"
                if summary:
                    prompt += f"{summary}\n"
                if description:
                    prompt += f"{description}\n"

            elif entity_type == 'tactic':
                prompt += f"### 策略{i}: {name}\n"
                if summary:
                    prompt += f"{summary}\n"
                if description:
                    prompt += f"{description}\n"

            elif entity_type == 'script':
                text = entity.get('text', '')
                context = entity.get('context', '')

                prompt += f"### 话术{i}: {name}\n"
                if context:
                    prompt += f"**适用场景**: {context}\n"
                if text:
                    prompt += f"**话术内容**: {text}\n"

            else:
                prompt += f"### {entity_type.capitalize()}{i}: {name}\n"
                if description:
                    prompt += f"{description}\n"
                if summary:
                    prompt += f"{summary}\n"

            prompt += "\n"
    else:
        prompt += "（本次查询未匹配到特定实体，请基于你的《影响力》知识库经验回答）\n\n"

    return prompt

if __name__ == '__main__':
    # 测试
    test_entities = [
        {
            'type': 'principle',
            'name': '互惠原理',
            'description': '当别人帮了我们的忙，给了我们好处，我们应当回报他',
            'core_mechanism': '通过先施恩或让步，使对方产生亏欠感',
            'social_function': '促进人类社会的劳动分工',
            'keywords': ['互惠', '亏欠感', '顺从']
        }
    ]

    print(get_enhanced_system_prompt(test_entities))
