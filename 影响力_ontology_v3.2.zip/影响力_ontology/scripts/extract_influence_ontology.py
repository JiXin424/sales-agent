#!/usr/bin/env python3
"""从《影响力（经典版）》清洗文本抽取三层 ontology。

用法:
    python3 extract_influence_ontology.py
"""

import json
import os
import re
import time

import requests

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DIR = os.path.join(BASE_DIR, "raw")
TEXT_PATH = os.path.join(os.path.dirname(BASE_DIR), "影响力（经典版）(1)_cleaned.txt")
STRUCTURE_PATH = os.path.join(BASE_DIR, "structure.json")


def load_env():
    env_path = "/Users/fred/Documents/cc_Projects/Taishan/new-software/langchain-video-system/.env"
    if os.path.isfile(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k, v = k.strip(), v.strip()
                    if k in ("ARK_API_KEY",):
                        os.environ.setdefault(k, v)


def call_llm(text: str) -> dict:
    api_key = os.environ["ARK_API_KEY"]
    base_url = "https://ark.cn-beijing.volces.com/api/v3"
    model = "doubao-1-5-pro-32k-250115"

    system_prompt = """你是一位知识本体工程师。请从《影响力（经典版）》的章节文本中，抽取语义层、思维链、行动链三层结构。只输出合法 JSON。"""

    user_prompt = f"""请从以下《影响力（经典版）》章节文本中抽取知识本体，输出 JSON。

Schema 字段：
- principles: 影响力原则（id, name, description, chapter, core_mechanism, social_function, keywords）
- concepts: 核心概念（id, name, en_name可选, definition, related_principles, source）
- terms: 术语（id, name, en_name可选, definition）
- cases: 案例（id, name, chapter, summary, characters, principle, trigger, behavior, outcome, source_text）
- experiments: 实验（id, name, researcher, chapter, hypothesis, method, result, conclusion, principle）
- persons: 人物（id, name, en_name, role, affiliation）
- reasoning_chains: 推理链（id, name, principle_id, premises, trigger, behavior, consequence, evidence, confidence）
- tactics: 策略/技巧（id, name, en_name可选, principle_id, scenario, steps, expected_result, risk, example）
- action_steps: 行动步骤（id, tactic_id, order, action, script_template, note）
- scripts: 话术（id, name, context, text, principle_id, source_case）
- scenarios: 应用场景（id, name, description, applicable_tactics）
- relations: 关系（id, relation_type, from_id, to_id, description）

关系类型：principle_illustrated_by, case_uses_experiment, experiment_conducted_by, tactic_based_on, tactic_applies_to, concept_related_to, reasoning_derives, person_proposes

要求：
1. 精细到每个案例和实验
2. 每个实体必须有 id（kebab-case）和 name
3. 只输出文本中明确提到的内容，不要过度推断
4. 输出必须是合法 JSON，不要有任何额外说明
5. 如果某类实体文本中没有，返回空列表

文本：
{text}
"""

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.3,
        "max_tokens": 12000,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    resp = requests.post(
        f"{base_url}/chat/completions", json=payload, headers=headers, timeout=300
    )
    resp.raise_for_status()
    data = resp.json()
    content = data["choices"][0]["message"]["content"]

    # Extract JSON block
    start = content.find("{")
    end = content.rfind("}") + 1
    if start >= 0 and end > start:
        return json.loads(content[start:end])
    return json.loads(content)


def main():
    load_env()
    os.makedirs(RAW_DIR, exist_ok=True)

    with open(TEXT_PATH, "r", encoding="utf-8") as f:
        lines = f.read().split("\n")

    with open(STRUCTURE_PATH, "r", encoding="utf-8") as f:
        chapters = json.load(f)

    for ch in chapters:
        ch_id = ch["id"]
        out_path = os.path.join(RAW_DIR, f"{ch_id}.json")
        if os.path.exists(out_path):
            print(f"Skip {ch_id}: already extracted")
            continue

        text = "\n".join(lines[ch["start_line"] : ch["end_line"]])
        print(f"Extracting {ch_id} ({len(text)} chars)...")

        try:
            result = call_llm(text)
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"  Saved {out_path}: {sum(len(v) for v in result.values() if isinstance(v, list))} entities")
        except Exception as e:
            print(f"  ERROR extracting {ch_id}: {e}")
        time.sleep(1)


if __name__ == "__main__":
    main()
