#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OpenClaw Header
# 'HTTP-Referer': 'https://openclaw.ai'
# 'X-0penRouter-Title': 'OpenClaw'
# 'X-0penRouter-Categories': 'cli-agent'
"""
DOCX 智能转 Markdown 工具

将 DOCX 文档智能转换为 Markdown 格式：
- 自动检测是否包含图片
- 纯文字文档：直接提取并结构化整理
- 带图文档：提取图片→压缩→AI 解读→图文拼合→整理输出

用法:
    python docx2md.py <docx_file>

示例:
    python docx2md.py "document.docx"
"""

import sys
import os
import subprocess
import zipfile
import shutil
import base64
from pathlib import Path
from datetime import datetime
from PIL import Image

# 尝试导入 openai
try:
    from openai import OpenAI
except ImportError:
    print("警告：未安装 openai 库，AI 功能将不可用")
    print("请运行：pip install openai")

# 尝试导入 python-docx
try:
    import docx
except ImportError:
    print("错误：未安装 python-docx 库")
    print("请运行：pip install python-docx")
    sys.exit(1)

# 默认 API 配置
DEFAULT_API_KEY = "DASHSCOPE_API_KEY_PLACEHOLDER"
DEFAULT_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
DEFAULT_MODEL = "qwen3.6-plus"

# 图片压缩配置（vision API 限制）
IMAGE_SIZE_LIMIT = 20 * 1024 * 1024  # 20MB
IMAGE_MAX_DIMENSION = 4096  # 最大宽高
IMAGE_QUALITY = 75  # JPEG 品质参数 (1-100)


def find_file(file_path: str, search_base: str = None) -> str:
    """使用 find 命令查找文件的真实路径（处理 iCloud 幽灵文件）"""
    if os.path.exists(file_path):
        return file_path

    file_name = os.path.basename(file_path)
    if search_base is None:
        search_base = "/Users/fred/Documents/cc_Projects/Taishan"

    # 提取中文关键字
    import re
    chinese_chars = re.findall(r'[\u4e00-\u9fff]+', file_name)

    patterns = []
    if chinese_chars:
        longest_chinese = max(chinese_chars, key=len)
        patterns.append(f"*{longest_chinese}*")

    file_name_no_spaces = file_name.replace(' ', '')
    patterns.append(f"*{file_name_no_spaces}*")

    for pattern in patterns:
        try:
            result = subprocess.run(
                ['bash', '-c', f'find "{search_base}" -maxdepth 5 -name {pattern} 2>/dev/null'],
                capture_output=True,
                text=True,
                timeout=10,  # 防止大目录搜索卡住
            )
            if result.stdout.strip():
                return result.stdout.strip().split('\n')[0].strip()
        except subprocess.TimeoutExpired:
            print(f"    find 命令超时，跳过 pattern: {pattern}")
            continue

    return None


def verify_file_access(file_path: str) -> tuple[bool, int]:
    """验证文件是否可访问"""
    result = subprocess.run(
        ['bash', '-c', f'ls -la "{file_path}"'],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return False, 0

    try:
        file_size = int(result.stdout.split()[4])
        if file_size < 1024:
            print(f"警告：文件小于 1KB ({file_size} bytes)，可能是 iCloud 占位符")
            return False, file_size
        return True, file_size
    except (IndexError, ValueError):
        return False, 0


def detect_images_in_docx(docx_path: str) -> tuple[bool, list[str]]:
    """
    检测 DOCX 是否包含图片

    Returns:
        tuple: (是否有图，图片文件列表)
    """
    image_files = []

    try:
        # 使用 subprocess 处理中文路径
        result = subprocess.run(
            ['bash', '-c', f'unzip -l "{docx_path}" 2>/dev/null | grep -i "word/media/" | grep -iE "\\.(png|jpg|jpeg|gif|bmp|webp)$"'],
            capture_output=True,
            text=True
        )

        if result.stdout.strip():
            for line in result.stdout.strip().split('\n'):
                parts = line.split()
                if len(parts) >= 4:
                    image_files.append(parts[-1])

        has_images = len(image_files) > 0
        return has_images, sorted(image_files)

    except Exception as e:
        print(f"图片检测失败：{e}")
        return False, []


def extract_text_from_docx(docx_path: str) -> list[dict]:
    """
    从 DOCX 提取文本内容（保留结构）

    Returns:
        list: 段落列表，每个段落包含文本和类型信息
    """
    elements = []

    # 使用 os.path.join 处理中文路径
    full_path = os.path.join(os.path.dirname(docx_path), os.path.basename(docx_path))

    try:
        doc = docx.Document(full_path)

        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue

            # 判断段落类型
            style_name = para.style.name if para.style else ''

            if 'Heading' in style_name or '标题' in style_name:
                # 提取标题级别
                level = 1
                for i in range(1, 10):
                    if str(i) in style_name or f'标题{i}' in style_name:
                        level = i
                        break
                elements.append({
                    'type': 'heading',
                    'level': level,
                    'text': text
                })
            elif style_name == 'List Paragraph' or 'List' in style_name:
                elements.append({
                    'type': 'list_item',
                    'text': text
                })
            else:
                elements.append({
                    'type': 'paragraph',
                    'text': text
                })

        # 提取表格
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = []
                for cell in row.cells:
                    row_data.append(cell.text.strip())
                if any(row_data):
                    table_data.append(row_data)

            if table_data:
                elements.append({
                    'type': 'table',
                    'data': table_data
                })

    except Exception as e:
        print(f"提取文本失败：{e}")
        return []

    return elements


def extract_images(docx_path: str, output_dir: str) -> list[str]:
    """
    从 DOCX 提取图片到指定目录

    Returns:
        list: 图片文件路径列表
    """
    os.makedirs(output_dir, exist_ok=True)
    image_paths = []

    try:
        # 先用 subprocess 检查文件
        result = subprocess.run(
            ['bash', '-c', f'ls -la "{docx_path}"'],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            print(f"无法访问 DOCX 文件：{docx_path}")
            return []

        # 使用 zipfile 读取（docx 本质是 zip）
        # 需要复制到临时文件以避免中文路径问题
        import tempfile
        temp_fd, temp_docx = tempfile.mkstemp(suffix='.docx')
        os.close(temp_fd)

        subprocess.run(
            ['bash', '-c', f'cat "{docx_path}" > "{temp_docx}"'],
            capture_output=True
        )

        with zipfile.ZipFile(temp_docx, 'r') as zip_ref:
            for name in sorted(zip_ref.namelist()):
                if name.startswith('word/media/') and not name.endswith('/'):
                    # 读取图片数据
                    content = zip_ref.read(name)

                    # 生成输出路径
                    image_name = os.path.basename(name)
                    if not image_name:
                        continue
                    output_path = os.path.join(output_dir, image_name)

                    # 保存图片
                    with open(output_path, 'wb') as f:
                        f.write(content)

                    image_paths.append(output_path)
                    print(f"  提取：{image_name}")

        # 清理临时文件
        os.remove(temp_docx)

    except Exception as e:
        print(f"提取图片失败：{e}")
        return []

    return image_paths


def compress_image(image_path: str) -> tuple[str, bool]:
    """
    压缩图片（如果需要）

    Args:
        image_path: 图片路径

    Returns:
        tuple: (压缩后的路径，是否压缩)
    """
    # 检查文件大小
    file_size = os.path.getsize(image_path)
    need_compress = file_size > IMAGE_SIZE_LIMIT

    if not need_compress:
        print(f"  跳过压缩：{os.path.basename(image_path)} ({file_size/1024:.1f}KB)")
        return image_path, False

    print(f"  压缩：{os.path.basename(image_path)} ({file_size/1024:.1f}KB)")

    try:
        # 打开图片
        img = Image.open(image_path)
        width, height = img.size

        # 转换为 RGB（处理 PNG 透明通道）
        if img.mode in ('RGBA', 'LA', 'P'):
            img = img.convert('RGB')

        # 计算缩放比例
        if width > IMAGE_MAX_DIMENSION or height > IMAGE_MAX_DIMENSION:
            scale = IMAGE_MAX_DIMENSION / max(width, height)
            width = int(width * scale)
            height = int(height * scale)
            img = img.resize((width, height), Image.Resampling.LANCZOS)
            print(f"    缩放：{img.size[0]}x{img.size[1]}")

        # 生成输出路径
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_path = os.path.join(os.path.dirname(image_path), f"{base_name}_compressed.jpg")

        # 保存为 JPG（品质 8/12 ≈ 67%）
        img.save(output_path, 'JPEG', quality=IMAGE_QUALITY * 10, optimize=True)

        new_size = os.path.getsize(output_path)
        print(f"    结果：{new_size/1024:.1f}KB (压缩比：{100-new_size/file_size*100:.1f}%)")

        return output_path, True

    except Exception as e:
        print(f"    压缩失败：{e}，使用原图")
        return image_path, False


def _prepare_image_for_vision(image_path: str, max_side: int = 4096, quality: int = 75) -> tuple[str, str]:
    """
    准备图片用于 vision API。
    - 最长边超过 max_side 则等比缩放（内存中，不修改原文件）
    - 返回 (base64_string, mime_type)
    """
    from PIL import Image
    import io

    # 预检查：PIL 是否能识别此格式
    try:
        img = Image.open(image_path)
    except Exception as e:
        ext = os.path.splitext(image_path)[1].lower()
        raise ValueError(f"不支持的图片格式 '{ext}'：{e}")

    w, h = img.size

    # 限制最长边
    longest = max(w, h)
    if longest > max_side:
        ratio = max_side / longest
        new_w = int(w * ratio)
        new_h = int(h * ratio)
        print(f"    [缩放] {w}x{h} -> {new_w}x{new_h} (API 限制 {max_side})")
        img = img.resize((new_w, new_h), Image.LANCZOS)

    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')

    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=quality, optimize=True)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return b64, "image/jpeg"


def encode_image_to_base64(image_path: str) -> str:
    """将图片编码为 Base64（保持原始分辨率）"""
    result = subprocess.run(
        ['bash', '-c', f'cat "{image_path}" | base64'],
        capture_output=True,
        text=True
    )
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    raise FileNotFoundError(f"无法读取文件：{image_path}")


def get_image_mime_type(image_path: str) -> str:
    """获取图片 MIME 类型"""
    ext = os.path.splitext(image_path)[1].lower().lstrip('.')
    mime_types = {
        'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
        'gif': 'image/gif', 'webp': 'image/webp', 'bmp': 'image/bmp',
    }
    return mime_types.get(ext, 'image/jpeg')


def analyze_image(image_path: str, api_key: str, model: str, verbose: bool = True) -> str:
    """
    AI 分析图片（qwen3.6-plus vision，高精度模式）

    Args:
        image_path: 图片路径
        api_key: API Key
        model: 模型名称
        verbose: 是否打印详细输出

    Returns:
        str: 图片解读文本
    """
    IMAGE_ANALYSIS_PROMPT = """请仔细阅读这张图片，直接输出为结构清晰的 Markdown。

**严禁做的事情**：
- **严禁修改任何文字内容**，包括错别字、病句、数字、标点等——看到什么就输出什么
- 不要改写、扩写、或添加原文没有的内容
- 不要纠正任何你觉得"不对"的文字
- 不要删除任何内容，包括看似重复的部分——保留所有文字
- 不要添加任何说明、总结或分析

**输出格式要求**：
1. **标题**：用 # ## ### 标记明显的标题层级
2. **表格**：如果图片中有网格/多列布局，**必须**用 Markdown 表格输出
   - 表格列数必须与原图一致
   - 表格内每格的文字必须完整保留，严禁截断、省略、缩写
   - 跨行单元格用 `<br>` 换行保留全部文字
   - 不确定的列边界时，宁可多列也不要少列
3. **列表**：用 - 或 1. 标记列表项
4. **内容完整性**：每一行文字都必须出现在输出中，严禁省略任何一行

请直接输出 Markdown，不要加任何说明。"""

    import time

    # 跳过不支持的格式（如 SVG、EMF、WMF）
    ext = os.path.splitext(image_path)[1].lower()
    UNSUPPORTED_EXTS = {'.svg', '.emf', '.wmf'}
    if ext in UNSUPPORTED_EXTS:
        print(f"  跳过 {ext.upper()}：{os.path.basename(image_path)}")
        return f"[{ext.upper()} 矢量图/格式，跳过识别]"

    # 重试配置
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # 秒

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            b64, mime_type = _prepare_image_for_vision(image_path)
            image_data_uri = f"data:{mime_type};base64,{b64}"

            client = OpenAI(api_key=api_key, base_url=DEFAULT_BASE_URL)

            if verbose:
                print(f"  读图 [{attempt}/{MAX_RETRIES}]：{os.path.basename(image_path)}")

            completion = client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "image_url", "image_url": {"url": image_data_uri}},
                            {"type": "text", "text": IMAGE_ANALYSIS_PROMPT},
                        ],
                    },
                ],
                extra_body={"vl_high_resolution_images": True},
                temperature=0.2,
            )

            result = completion.choices[0].message.content

            if verbose:
                # 打印读图结果摘要
                print(f"    类型：{extract_first_line(result, '【图片类型】')}")
                print(f"    内容：{extract_first_line(result, '【图片内容】')[:60]}...")

            return result

        except Exception as e:
            err_type = type(e).__name__
            err_msg = str(e)[:120]
            if verbose:
                print(f"    第 {attempt}/{MAX_RETRIES} 次失败 ({err_type})：{err_msg}")

            if attempt < MAX_RETRIES:
                # 重试前等待（指数退避）
                wait = RETRY_DELAY * attempt
                if verbose:
                    print(f"    {wait}s 后重试...")
                time.sleep(wait)
            else:
                # 最终失败，打印完整 traceback 到 stderr
                import traceback
                traceback.print_exc()
                return f"【图片分析失败】{os.path.basename(image_path)} ({err_type})"

    # 理论上不会到达这里
    return f"【图片分析失败】{os.path.basename(image_path)} (未知错误)"


def extract_first_line(text: str, marker: str) -> str:
    """提取指定标记后的第一行内容"""
    for line in text.split('\n'):
        if marker in line:
            return line.split(marker, 1)[-1].strip()
    return ""


def analyze_and_organize_text(text_content: str, has_images: bool, api_key: str, model: str) -> str:
    """
    AI 分析并整理文本内容

    Returns:
        str: 整理后的 Markdown
    """
    ORGANIZE_PROMPT = """你是一个文档合并助手。以下是从 DOCX 文档提取的内容。

**任务：只做三件事，不要重新组织内容**
1. 去除明显的重复内容（如页眉页脚等）
2. 按原文档顺序拼接内容
3. 修正明显的 OCR/提取错字（如错别字、缺失标点），但**严禁改写原文意思**

**严禁做的事情：**
- 不要调整内容顺序
- 不要合并段落或改变段落结构
- 不要把分散的内容归类汇总
- 不要修改标题层级
- 不要"优化"表述或扩写缩写，保持转录的原样
- **表格保留 Markdown 表格格式，不要改成文字描述**

请直接输出整理后的完整 Markdown 内容，不要加任何说明文字。
"""

    try:
        client = OpenAI(api_key=api_key, base_url=DEFAULT_BASE_URL)

        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "你是专业的文档整理专家。"},
                {"role": "user", "content": f"{ORGANIZE_PROMPT}\n\n{text_content}"},
            ],
        )

        return completion.choices[0].message.content

    except Exception as e:
        print(f"AI 整理失败：{e}")
        # 回退到直接输出
        return text_content


def process_pure_text_docx(elements: list, output_path: str, api_key: str, model: str) -> bool:
    """
    处理纯文字 DOCX

    Returns:
        bool: 是否成功
    """
    print("\n检测到纯文字文档，开始提取...")

    # 组装原始内容
    raw_content = []
    for elem in elements:
        if elem['type'] == 'heading':
            level = elem['level']
            prefix = '#' * level
            raw_content.append(f"{prefix} {elem['text']}")
        elif elem['type'] == 'list_item':
            raw_content.append(f"1. {elem['text']}")
        elif elem['type'] == 'table':
            # 保留 Markdown 表格格式
            data = elem['data']
            if data:
                md_table = []
                headers = data[0]
                md_table.append('| ' + ' | '.join(str(h) if h else '' for h in headers) + ' |')
                md_table.append('|' + '|'.join(['---'] * len(headers)) + '|')
                for row in data[1:]:
                    md_table.append('| ' + ' | '.join(str(c) if c else '' for c in row) + ' |')
                raw_content.append('\n'.join(md_table))
            else:
                raw_content.append('表格数据为空')
        else:
            raw_content.append(elem['text'])

    raw_text = '\n\n'.join(raw_content)

    # AI 整理
    print("正在 AI 结构化整理...")
    organized_md = analyze_and_organize_text(raw_text, has_images=False, api_key=api_key, model=model)

    # 保存
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(organized_md)

    print(f"已保存：{output_path}")
    return True


def process_image_docx(docx_path: str, elements: list, image_paths: list,
                       extracted_dir: str, output_path: str, api_key: str, model: str) -> bool:
    """
    处理带图 DOCX

    Returns:
        bool: 是否成功
    """
    import time

    # 过滤掉过小的图片（< 5KB，通常是图标/装饰）
    filtered_paths = []
    skipped_small = 0
    for img_path in image_paths:
        size = os.path.getsize(img_path)
        if size < 5 * 1024:
            skipped_small += 1
            continue
        filtered_paths.append(img_path)

    if skipped_small:
        print(f"\n检测到带图文档 ({len(image_paths)} 张图片，跳过 {skipped_small} 张过小图标，实际处理 {len(filtered_paths)} 张)")
    else:
        print(f"\n检测到带图文档 ({len(image_paths)} 张图片)，开始提取...")

    # 压缩图片
    print("\n处理图片压缩...")
    compressed_images = []
    for img_path in filtered_paths:
        compressed_path, is_compressed = compress_image(img_path)
        compressed_images.append((compressed_path, is_compressed))

    # AI 分析图片（带限流保护 + 进度输出）
    print(f"\nAI 分析图片... 预计每张 ~20-30 秒，总计约 {len(compressed_images) * 25 // 60} 分钟")
    image_descriptions = []
    start_time = time.time()
    for idx, (img_path, _) in enumerate(compressed_images):
        elapsed = time.time() - start_time
        avg = elapsed / idx if idx > 0 else 25
        remain = (len(compressed_images) - idx) * avg
        print(f"\n  [{idx+1}/{len(compressed_images)}] 预计剩余 {remain//60:.0f}分{remain%60:.0f}秒")
        desc = analyze_image(img_path, api_key, model, verbose=True)
        image_descriptions.append(desc)
        # 限流保护：非最后一张时等待 0.5 秒
        if idx < len(compressed_images) - 1:
            time.sleep(0.5)

    # 组装图文内容
    print("\n拼合图文内容...")
    content_blocks = []

    # 简单策略：先放所有文字，再放所有图片解读
    # 更复杂的策略需要解析 document.xml 中的位置关系
    for elem in elements:
        if elem['type'] == 'heading':
            level = elem['level']
            prefix = '#' * level
            content_blocks.append(f"{prefix} {elem['text']}")
        elif elem['type'] == 'list_item':
            content_blocks.append(f"1. {elem['text']}")
        elif elem['type'] == 'table':
            # 保留 Markdown 表格格式
            data = elem['data']
            if data:
                md_table = []
                headers = data[0]
                md_table.append('| ' + ' | '.join(str(h) if h else '' for h in headers) + ' |')
                md_table.append('|' + '|'.join(['---'] * len(headers)) + '|')
                for row in data[1:]:
                    md_table.append('| ' + ' | '.join(str(c) if c else '' for c in row) + ' |')
                content_blocks.append('\n'.join(md_table))
            else:
                content_blocks.append('表格数据为空')
        else:
            content_blocks.append(elem['text'])

    # 插入图片解读
    for i, (img_path, desc) in enumerate(zip(compressed_images, image_descriptions), 1):
        content_blocks.append(f"\n\n---\n\n### 图片 {i}\n\n**【图片解读】**\n{desc}\n")

    raw_content = '\n\n'.join(content_blocks)

    # AI 整理
    print("正在 AI 整理最终文档...")
    final_md = analyze_and_organize_text(raw_content, has_images=True, api_key=api_key, model=model)

    # 保存
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(final_md)

    print(f"已保存：{output_path}")

    # 提示临时目录
    print(f"\n临时目录（可删除）：{extracted_dir}")

    return True


def docx_to_md(docx_path: str, api_key: str = None, model: str = None) -> bool:
    """
    主流程：将 DOCX 转换为 Markdown

    Args:
        docx_path: DOCX 文件路径
        api_key: API Key
        model: 模型名称

    Returns:
        bool: 是否成功
    """
    print("=" * 60)
    print("DOCX 智能转 Markdown 工具")
    print("=" * 60)

    # 配置
    api_key = api_key or os.getenv("DASHSCOPE_API_KEY") or DEFAULT_API_KEY
    model = model or DEFAULT_MODEL

    print(f"使用模型：{model}")
    print(f"API 地址：{DEFAULT_BASE_URL}")

    # 查找文件
    real_path = find_file(docx_path)
    if not real_path:
        print(f"错误：找不到文件：{docx_path}")
        return False

    docx_path = real_path

    # 验证文件
    is_valid, file_size = verify_file_access(docx_path)
    if not is_valid:
        return False

    print(f"文件大小：{file_size / 1024:.1f}KB")

    # 确定输出路径
    file_name = os.path.splitext(os.path.basename(docx_path))[0]
    output_dir = os.path.dirname(docx_path)
    output_path = os.path.join(output_dir, f"{file_name}.md")

    # 步骤 1: 检测图片
    print("\n" + "=" * 60)
    print("步骤 1: 检测图片")
    print("=" * 60)

    has_images, image_files = detect_images_in_docx(docx_path)

    if has_images:
        print(f"检测到 {len(image_files)} 张图片:")
        for f in image_files:
            print(f"  - {os.path.basename(f)}")
    else:
        print("未检测到图片，纯文字文档")

    # 提取文本
    print("\n" + "=" * 60)
    print("步骤 2: 提取文本")
    print("=" * 60)

    elements = extract_text_from_docx(docx_path)
    print(f"提取到 {len(elements)} 个文本元素")

    # 分支处理
    if not has_images:
        # 纯文字处理
        success = process_pure_text_docx(elements, output_path, api_key, model)
    else:
        # 带图处理
        extracted_dir = os.path.join(output_dir, f"{file_name}_extracted")

        # 提取图片
        print("\n" + "=" * 60)
        print("步骤 3: 提取图片")
        print("=" * 60)

        image_paths = extract_images(docx_path, extracted_dir)

        if not image_paths:
            print("警告：图片提取失败，降级为纯文字处理")
            success = process_pure_text_docx(elements, output_path, api_key, model)
        else:
            success = process_image_docx(
                docx_path, elements, image_paths,
                extracted_dir, output_path, api_key, model
            )

    print("\n" + "=" * 60)
    if success:
        print("处理完成!")
        print(f"  输出文件：{output_path}")
    else:
        print("处理失败!")
    print("=" * 60)

    return success


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("\n用法:")
        print("  python docx2md.py <docx_file>")
        print("\n示例:")
        print('  python docx2md.py "document.docx"')
        sys.exit(1)

    docx_path = sys.argv[1]

    try:
        success = docx_to_md(docx_path)
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n处理失败：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
