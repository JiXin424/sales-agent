"""评测结果对比工具 — 比较两次9轮评测的差异"""

from typing import Any


def compare_results(old: dict, new: dict) -> dict[str, dict[str, float]]:
    """对比两次评测结果，返回各维度差异（new - old）

    返回结构: {"基础认知": {"score_pct": +2.9, ...}, "整体": {...}}
    """
    diff = {}

    old_by_set = {r["set"]: r for r in old.get("rounds_summary", [])}
    new_by_set = {r["set"]: r for r in new.get("rounds_summary", [])}

    all_sets = set(old_by_set.keys()) | set(new_by_set.keys())

    for set_name in all_sets:
        o = old_by_set.get(set_name, {})
        n = new_by_set.get(set_name, {})
        diff[set_name] = {}
        for key in ("score_pct", "pass_rate", "intent_accuracy"):
            old_val = o.get(key, 0)
            new_val = n.get(key, 0)
            diff[set_name][key] = round(new_val - old_val, 1)

    # 整体（加权平均）
    metrics = ("score_pct", "pass_rate", "intent_accuracy")
    diff["整体"] = {}
    for key in metrics:
        values = [diff[s][key] for s in all_sets if s in diff]
        diff["整体"][key] = round(sum(values) / len(values), 1) if values else 0

    return diff


def format_diff_report(diff: dict, old_label: str, new_label: str) -> str:
    """格式化差异报告为可读文本"""
    lines = [f"=== 评测对比: {old_label} → {new_label} ===\n"]

    for set_name in diff:
        if set_name == "整体":
            continue
        d = diff[set_name]
        score_sign = "+" if d["score_pct"] >= 0 else ""
        lines.append(
            f"  {set_name}: 分数{score_sign}{d['score_pct']}pp | "
            f"通过率{'+' if d['pass_rate']>=0 else ''}{d['pass_rate']}pp | "
            f"意图{'+' if d['intent_accuracy']>=0 else ''}{d['intent_accuracy']}pp"
        )

    d = diff["整体"]
    score_sign = "+" if d["score_pct"] >= 0 else ""
    lines.append(f"\n  整体: 分数{score_sign}{d['score_pct']}pp | "
                 f"通过率{'+' if d['pass_rate']>=0 else ''}{d['pass_rate']}pp | "
                 f"意图{'+' if d['intent_accuracy']>=0 else ''}{d['intent_accuracy']}pp")

    return "\n".join(lines)
