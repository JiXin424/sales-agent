#!/usr/bin/env python3
"""批量镜像转换：把源目录中的文件按文件夹结构转换到目标目录，支持断点续传"""
import os
import sys
import json
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

SOURCE = "/root/Project/apps/Ontology-clean/docs/ProductX_batch1/materials"
TARGET = "/root/Project/apps/Ontology-clean/docs/ProductX_batch1/md"
CONVERT_DIR = "/root/Project/apps/ready/AFC2md"
STATE_FILE = os.path.join(TARGET, "_convert_state.json")

SUPPORTED = {'.pdf','.pptx','.docx','.doc','.xlsx','.jpg','.jpeg','.png','.webp','.gif','.bmp','.heic','.heif'}


def find_files(src):
    files = []
    for root, dirs, filenames in os.walk(src):
        dirs[:] = [d for d in dirs if '_extracted' not in d and '_images' not in d]
        for f in filenames:
            if f.startswith('.') or f == '.DS_Store':
                continue
            ext = os.path.splitext(f)[1].lower()
            if ext in SUPPORTED:
                files.append(os.path.join(root, f))
    return sorted(files)


def load_state():
    """加载转换状态"""
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}


def save_state(state):
    """保存转换状态"""
    os.makedirs(TARGET, exist_ok=True)
    with open(STATE_FILE, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def print_summary(state, files):
    """打印当前进度摘要"""
    done = [k for k, v in state.items() if v['status'] == 'done']
    failed = [k for k, v in state.items() if v['status'] == 'failed']
    pending = [k for k, v in state.items() if v['status'] == 'pending']
    new = [os.path.relpath(f, SOURCE) for f in files if os.path.relpath(f, SOURCE) not in state]

    print(f"  已完成: {len(done)}  失败: {len(failed)}  待处理: {len(pending) + len(new)}")
    return done, failed, pending, new


def init_state(files):
    """初始化/更新状态文件：扫描所有文件，检测已有 .md 自动标记 done"""
    state = load_state()
    for src_path in files:
        rel = os.path.relpath(src_path, SOURCE)
        if rel not in state:
            base = os.path.splitext(rel)[0]
            expected_md = os.path.join(TARGET, f"{base}.md")
            if os.path.exists(expected_md):
                state[rel] = {'status': 'done', 'src': src_path, 'completed_at': 'detected'}
            else:
                state[rel] = {'status': 'pending', 'src': src_path}
    # 校验已标记 done 的 .md 是否真的存在
    for rel, info in state.items():
        if info['status'] == 'done':
            base = os.path.splitext(rel)[0]
            expected_md = os.path.join(TARGET, f"{base}.md")
            if not os.path.exists(expected_md):
                info['status'] = 'pending'
                print(f"⚠️  {rel}: 标记为完成但 .md 不存在，重置为待处理")
    save_state(state)
    return state


def main():
    files = find_files(SOURCE)
    state = init_state(files)

    # 支持 --status 参数只查看状态
    if len(sys.argv) > 1 and sys.argv[1] == '--status':
        print("=" * 60)
        print("转换状态")
        print("=" * 60)
        done, failed, pending, new = print_summary(state, files)
        if done:
            print("\n✅ 已完成:")
            for k in done:
                print(f"   {k}")
        if failed:
            print("\n❌ 失败:")
            for k in failed:
                print(f"   {k} — {state[k].get('error', '')}")
        if pending:
            print("\n⏳ 待处理:")
            for k in pending:
                print(f"   {k}")
        if new:
            print("\n🆕 新文件:")
            for k in new:
                print(f"   {k}")
        print(f"\n状态文件: {STATE_FILE}")
        return

    print(f"源目录: {SOURCE}")
    print(f"目标目录: {TARGET}")
    print(f"状态文件: {STATE_FILE}")
    print(f"转换脚本目录: {CONVERT_DIR}")

    print(f"\n找到 {len(files)} 个文件\n")
    done, failed, pending, _ = print_summary(state, files)

    to_process = [rel for rel, info in state.items() if info['status'] == 'pending']
    if not to_process:
        print("\n所有文件已处理完毕！")
        return

    print(f"\n开始处理 {len(to_process)} 个待转换文件...\n")

    success = len(done)
    fail = len(failed)

    for i, rel in enumerate(to_process, 1):
        src_path = state[rel]['src']
        dst_dir = os.path.join(TARGET, os.path.dirname(rel))
        dst_file = os.path.join(dst_dir, os.path.basename(src_path))
        base_name = os.path.splitext(os.path.basename(src_path))[0]
        expected_md = os.path.join(dst_dir, f"{base_name}.md")

        # 双重检查：如果 .md 已存在，跳过
        if os.path.exists(expected_md):
            state[rel]['status'] = 'done'
            state[rel]['completed_at'] = datetime.now().isoformat()
            save_state(state)
            print(f"[{i}/{len(to_process)}] ⏭️  跳过（.md 已存在）: {rel}")
            success += 1
            continue

        os.makedirs(dst_dir, exist_ok=True)

        print(f"[{i}/{len(to_process)}] 🔄 {rel}  [{datetime.now().strftime('%H:%M:%S')}]")

        # 复制到镜像位置
        shutil.copy2(src_path, dst_file)

        try:
            proc = subprocess.run(
                [sys.executable, "convert.py", dst_file],
                cwd=CONVERT_DIR,
                capture_output=True,
                text=True,
                timeout=1800,
            )

            if os.path.exists(expected_md):
                print(f"   ✅ 成功 → {rel}  [{datetime.now().strftime('%H:%M:%S')}]")
                state[rel]['status'] = 'done'
                state[rel]['completed_at'] = datetime.now().isoformat()
                success += 1
                # 清理副本和中间文件
                if os.path.exists(dst_file):
                    os.remove(dst_file)
                for suffix in ['_images', '_extracted']:
                    tmp_dir = os.path.join(dst_dir, f"{base_name}{suffix}")
                    if os.path.isdir(tmp_dir):
                        shutil.rmtree(tmp_dir)
            else:
                err_msg = proc.stderr[-300:] if proc.stderr else 'unknown'
                print(f"   ❌ 未生成 MD: {err_msg}")
                state[rel]['status'] = 'failed'
                state[rel]['error'] = err_msg
                fail += 1
                if os.path.exists(dst_file):
                    os.remove(dst_file)
        except subprocess.TimeoutExpired:
            print(f"   ❌ 超时（30分钟）")
            state[rel]['status'] = 'failed'
            state[rel]['error'] = 'timeout'
            fail += 1
            if os.path.exists(dst_file):
                os.remove(dst_file)
        except Exception as e:
            print(f"   ❌ 异常: {e}")
            state[rel]['status'] = 'failed'
            state[rel]['error'] = str(e)
            fail += 1
            if os.path.exists(dst_file):
                os.remove(dst_file)

        # 每完成一个就保存状态，支持随时中断恢复
        save_state(state)

    print(f"\n{'='*60}")
    print(f"完成: 成功 {success}/{len(files)}，失败 {fail}/{len(files)}")
    print(f"状态文件: {STATE_FILE}")
    if fail > 0:
        print("重新运行将自动重试失败的文件。")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
