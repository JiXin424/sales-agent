"""拜访准备 — 基于本体知识生成拜访方案"""

import json
import logging

from sqlalchemy.ext.asyncio import AsyncSession

from backend.reasoning.intent import classify_intent
from backend.reasoning.engine import ReasoningEngine
from backend.llm import chat_pro

logger = logging.getLogger(__name__)

PREP_PROMPT = """你是资深销售教练，帮销售人员准备拜访方案。

基于以下知识：
{context}

客户/场景信息：
- 关键实体：{entities}
- 相关关系：{relations}

用户请求：{request}

请生成拜访准备方案，包含：
1. 客户背景分析
2. 产品匹配建议
3. 关键话术要点
4. 可能的问题和应对
5. 拜访目标设定

输出 JSON：
{{"plan": "完整拜访方案（Markdown格式）", "key_points": ["要点1", "要点2"], "evidence": ["依据1", "依据2"], "risk_warnings": ["风险提示"]}}"""


async def generate_prep_plan(request: str, session: AsyncSession) -> dict:
    """生成拜访准备方案"""
    # 1. 意图分析
    intent_result = await classify_intent(request)
    entity_names = intent_result.get("entities", [])

    # 2. 推理收集上下文
    engine = ReasoningEngine(session)
    context_data = await engine.reason(request, intent_result)

    entities = json.dumps(
        [{"name": e["name"], "type": e["type"]} for e in context_data.get("entities", [])],
        ensure_ascii=False,
    )
    relations = json.dumps(context_data.get("relations", []), ensure_ascii=False)

    # 3. 生成拜访方案
    prompt = PREP_PROMPT.format(
        context="九峰医疗产品知识库",
        entities=entities,
        relations=relations,
        request=request,
    )

    result_text = await chat_pro(
        messages=[{"role": "user", "content": prompt}],
        max_tokens=3000,
        response_format={"type": "json_object"},
    )

    try:
        result = json.loads(result_text)
    except json.JSONDecodeError:
        result = {"plan": result_text, "key_points": [], "evidence": [], "risk_warnings": []}

    return {
        "plan": result.get("plan", ""),
        "key_points": result.get("key_points", []),
        "evidence": result.get("evidence", []),
        "risk_warnings": result.get("risk_warnings", []),
    }
