#!/usr/bin/env python3
"""批量注入 42 个优化文件到 PostgreSQL 本体后端"""
import os, sys, time, requests
from pathlib import Path

UPLOAD_DIR = Path("/root/Project/apps/Ontology-clean/data/uploads")
API = "http://localhost:8000/api/v1/documents/upload"

files = sorted(UPLOAD_DIR.glob("*.md"))
print(f"共 {len(files)} 个文件\n")

ok, fail = 0, 0
start = time.time()

for i, fp in enumerate(files, 1):
    name = fp.name[:60]
    print(f"[{i:2d}/{len(files)}] {name} ...", end=" ", flush=True)
    try:
        with open(fp, "rb") as f:
            resp = requests.post(API, files={"file": (fp.name, f, "text/markdown")}, timeout=300)
        data = resp.json()
        if data.get("status") == "success":
            d = data["data"]
            print(f"✅ {d['objects_count']} entities, {d['links_count']} links")
            ok += 1
        else:
            print(f"❌ {data}")
            fail += 1
    except Exception as e:
        print(f"❌ {e}")
        fail += 1

elapsed = time.time() - start
print(f"\n✅ 完成: {ok} 成功, {fail} 失败 ({elapsed:.0f}s)")
