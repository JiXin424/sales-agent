#!/usr/bin/env python3
"""基于影响力本体生成 10 个销售教练场景的完整对话、分析与结论 HTML。"""

import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "scenario_htmls"

# 场景数据
SCENARIOS = [
    {
        "id": "scenario-01-first-meeting",
        "number": 1,
        "title": "大客户初次拜访",
        "background": "销售代表第一次拜访一家大型制造企业的采购总监王总。客户时间紧张，对陌生销售有天然戒备。销售需要在 30 分钟内让客户放下戒备、进入真正的需求对话。",
        "roles": {"sales": "李航（销售代表）", "customer": "王总（采购总监）"},
        "dialogue": [
            {"speaker": "sales", "text": "王总，感谢您抽时间。我今天不是来推销产品的，是想先了解贵公司在智能制造升级上遇到的最大挑战。", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "开场先降低索取感，把「推销」转化为「了解」，减少客户的防御心理。"},
            {"speaker": "customer", "text": "你们这类销售我见多了，都说不是来推销的。我只有二十分钟。"},
            {"speaker": "sales", "text": "明白。我注意到贵公司上个月刚拿了省级数字化示范工厂的称号，和我服务的另一家标杆企业——同行业的 A 集团——路径很像。他们最头疼的不是设备，而是数据孤岛。", "principle": "喜好原理", "tactic": "先建立关系再谈需求策略", "note": "提及客户近期成就+同行业相似案例，建立相似性和专业关联。"},
            {"speaker": "customer", "text": "A 集团？他们确实和我们情况有点像。你们做了什么？"},
            {"speaker": "sales", "text": "我带了一份他们三个月前的数据打通复盘摘要，里面有三条踩过的坑，我觉得对您可能有参考价值。您方便的话，我可以发给您，不需要交换任何资料。", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "无偿给予具体、可验证的洞察，触发回报压力。"},
            {"speaker": "customer", "text": "可以，你发我邮箱。"},
            {"speaker": "sales", "text": "好。另外，我能不能占用您两分钟，问一个具体的问题：目前您这边最希望供应商帮您解决、但现有方案一直没能解决的事是什么？", "principle": "承诺与一致原理", "tactic": "获取小承诺推进下一步策略", "note": "将对话引导到具体问题，让客户做出「愿意回答」的小承诺。"},
            {"speaker": "customer", "text": "说实话，供应商太多，报价单都长得差不多，我们真正想看的是实施后的真实数据。"},
            {"speaker": "sales", "text": "这正是我想和您深入聊的。下周三或周四下午，我可以带一份同行业 6 个月投产后的真实 ROI 数据过来，专门看实施风险和数据兑现。您哪个时间更方便？", "principle": "稀缺原理", "tactic": "获取小承诺推进下一步策略", "note": "提供稀缺资源（真实数据）并给出二选一时间，推动明确下一步。"},
            {"speaker": "customer", "text": "周四下午三点吧。"},
            {"speaker": "sales", "text": "周四下午三点，我带案例和数据过来。感谢您今天的坦诚，对我非常有价值。"},
        ],
        "analysis": ["**喜好原理**：通过提及客户近期成就（省级示范工厂）和同行业标杆案例（A 集团），迅速建立相似性与专业认同，让客户从「又一个推销」转变为「这人懂我行业」。", "**互惠原理**：开场声明「不是来推销」，并主动提供无偿的行业复盘摘要，降低索取感，触发客户的回报心理。", "**承诺与一致原理**：通过具体问题的提问，让客户做出回答的小承诺，逐步引导进入需求对话。", "**稀缺原理**：以「真实 ROI 数据」作为稀缺资源，并给出二选一的时间选项，推动客户给出明确的下次会面承诺。"],
        "conclusion": ["初次拜访的核心不是展示产品，而是让客户愿意开口。", "先通过相似点和成就认可建立好感，再通过无偿洞察降低戒备。", "用具体问题和二选一选项，把模糊的「再联系」变成明确的下一步。", "所有话术都应围绕客户的行业语言和真实痛点设计，避免通用推销腔。"],
    },
    {
        "id": "scenario-02-price-objection",
        "number": 2,
        "title": "价格异议处理",
        "background": "客户对方案整体认可，但在报价环节提出「比竞品贵 30%」的异议。销售需要在维护价格体系的同时，让客户理解价值差异，避免陷入纯价格博弈。",
        "roles": {"sales": "李航（销售代表）", "customer": "赵总（财务总监）"},
        "dialogue": [
            {"speaker": "customer", "text": "你们方案不错，但价格比 B 公司贵了将近 30%，这个差距太大了。"},
            {"speaker": "sales", "text": "赵总，我理解价格是关键考量。在解释差异之前，我想先确认一件事：您对比 B 公司时，是按三年总拥有成本算的，还是只看首年采购价？", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "用提问把客户从「单价对比」引导到「总成本对比」，改变比较框架。"},
            {"speaker": "customer", "text": "目前主要看的是首年报价。"},
            {"speaker": "sales", "text": "这就解释了差异。我们服务的同行业 12 家客户，有 9 家最初也是按首年价选了低价方案，但第二年因为实施返工和接口改造，平均多花了 22%。", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用同行业真实数据建立「低价方案的真实代价」共识。"},
            {"speaker": "customer", "text": "真有这么多返工？"},
            {"speaker": "sales", "text": "是的。我手上有一份脱敏的对比表，列出了这 9 家客户第二年的隐藏成本项。我可以现场给您看，您判断一下哪些风险在贵司可能复现。", "principle": "权威原理", "tactic": "用数据建立专业权威策略", "note": "用脱敏数据建立专业可信度，避免空泛的「我们更好」。"},
            {"speaker": "customer", "text": "那你讲讲，哪些是低价方案常见的坑。"},
            {"speaker": "sales", "text": "最常见的三个：第一，接口数量按低价报，后期扩容按次收费；第二，运维响应不写进 SLA，故障时按紧急工单加价；第三，数据迁移费单列，常常超出预算 30% 以上。我们的报价里这三项是包含的。", "principle": "稀缺原理", "tactic": "用数据建立专业权威策略", "note": "具体列出隐藏成本项，让客户感受到信息的稀缺与专业。"},
            {"speaker": "customer", "text": "这些确实是我们之前没细看的。"},
            {"speaker": "sales", "text": "赵总，我建议这样：我们把三年总成本拉一张表，把您关心的 B 公司方案和我们的方案并排对比，您看完再决定。如果三年总成本我们仍然更高，我愿意帮您争取折扣。这样公平吗？", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "用「公平对比」让客户做出承诺，把决策建立在总价值而非单价上。"},
            {"speaker": "customer", "text": "可以，你下周把三年对比表发我。"},
        ],
        "analysis": ["**承诺与一致原理**：通过提问让客户承认「只看首年价」，再用「三年总成本」框架重新定义比较标准，让客户在逻辑上自我说服。", "**社会认同原理**：引用 9 家同行业客户的真实返工数据，让客户感到「别人已经替我付过学费」，降低对高价的抵触。", "**权威原理**：用脱敏对比表和具体成本项建立专业权威，让客户信任销售对行业的深度理解。", "**稀缺原理**：揭示低价方案的隐藏成本，让客户感到这些信息是稀缺且关键的决策依据。"],
        "conclusion": ["价格异议的本质往往是「比较框架」错了，而非价格本身高了。", "用提问引导客户承认现有比较方式的局限，再提供更全面的框架。", "用同行业真实数据和具体成本项建立专业权威，避免空泛的「我们更值」。", "用「公平对比 + 条件承诺」收尾，让客户在总价值层面做决策。"],
    },
    {
        "id": "scenario-03-stakeholder-mapping",
        "number": 3,
        "title": "多方决策人梳理",
        "background": "客户内部决策链复杂，涉及采购、IT、业务、财务四方。销售只对接了采购方，项目卡在 IT 部门迟迟不推进。需要快速识别关键决策人并建立多线关系。",
        "roles": {"sales": "李航（销售代表）", "customer": "王总（采购总监）"},
        "dialogue": [
            {"speaker": "sales", "text": "王总，上次提交方案后，我想确认一下推进节奏。您看目前内部还有哪些部门需要在决策前对齐？", "principle": "承诺与一致原理", "tactic": "获取小承诺推进下一步策略", "note": "用开放式提问让客户主动暴露决策链，避免直接追问敏感的「谁是决策人」。"},
            {"speaker": "customer", "text": "主要是 IT 部门的老周，他那边一直没反馈。"},
            {"speaker": "sales", "text": "理解。IT 老周的顾虑通常集中在接口稳定性和运维负担上。我能不能提一个建议：我准备一份针对 IT 视角的技术答疑清单，您方便的话帮忙转给老周，让他直接圈出最关心的三个问题，我来准备答复。", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "主动为客户的内部协调减负，让采购方愿意帮忙引荐。"},
            {"speaker": "customer", "text": "这个可以，我转给他。"},
            {"speaker": "sales", "text": "另外，业务部门的张总这边，方案上线后他用的最多。我想确认一下，他目前对方案的预期是什么样的？有没有特别在意的业务指标？", "principle": "喜好原理", "tactic": "先建立关系再谈需求策略", "note": "通过业务方关心点建立多线关系，避免单点依赖采购。"},
            {"speaker": "customer", "text": "张总最在意的是订单交付周期，他希望系统能把周期压到 7 天以内。"},
            {"speaker": "sales", "text": "这是个很关键的指标。我服务过的 C 集团，上线半年后交付周期从 11 天降到 6.8 天。我可以把他们的实施路径整理一份给张总看，让他判断是否符合预期。您方便引荐一下吗？", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用业务方关心的指标+同类案例，建立与业务方的直接对话机会。"},
            {"speaker": "customer", "text": "张总那边我可以约，但他时间紧。"},
            {"speaker": "sales", "text": "我理解。我会准备一份 15 分钟的精简版，只讲交付周期这件事，不涉及其他。这样他更容易安排时间。您觉得下周二上午或者周四下午哪个更合适？", "principle": "稀缺原理", "tactic": "获取小承诺推进下一步策略", "note": "用「精简到 15 分钟」降低门槛，用二选一推动具体时间。"},
            {"speaker": "customer", "text": "周四下午吧，我帮他约。"},
            {"speaker": "sales", "text": "好。那 IT 老周和业务张总这两条线，我分别准备材料。您这边如果有任何一方反馈，随时告诉我，我来配合。"},
        ],
        "analysis": ["**承诺与一致原理**：通过开放式提问让采购方主动暴露决策链，避免直接追问敏感信息，让客户在「愿意协调」的承诺中逐步推进。", "**互惠原理**：主动为客户准备 IT 视角的技术答疑清单，减轻其内部协调负担，触发其愿意引荐的回报心理。", "**喜好原理**：通过业务方关心的核心指标（交付周期）建立共鸣，为多线关系奠定基础。", "**社会认同原理**：用 C 集团的真实数据建立业务方对方案的信心，降低对新方案的抵触。", "**稀缺原理**：用「15 分钟精简版」和二选一时间，降低会面门槛并推动明确承诺。"],
        "conclusion": ["多方决策的核心是「不要把鸡蛋放在采购这一个篮子里」。", "通过提问让采购方主动暴露决策链，再为每个关键人准备专属价值点。", "主动为客户减负（准备材料、精简时间），让客户愿意帮忙引荐。", "对每个决策人都要建立独立的关系和价值主张，避免单点卡死。"],
    },
    {
        "id": "scenario-04-competitor-displacement",
        "number": 4,
        "title": "替换在用竞品",
        "background": "客户已经在使用竞品方案两年，整体运行稳定但存在若干未解决的痛点。销售需要在不贬低竞品的前提下，让客户愿意评估替换的可行性。",
        "roles": {"sales": "李航（销售代表）", "customer": "陈总（运营总监）"},
        "dialogue": [
            {"speaker": "customer", "text": "我们现在用的 D 公司方案，整体还行，没必要换。换系统太折腾了。"},
            {"speaker": "sales", "text": "陈总，我完全理解。系统稳定运行两年，替换的成本和风险都不小，没必要为了换而换。", "principle": "喜好原理", "tactic": "先建立关系再谈需求策略", "note": "先认同客户的判断，避免直接否定现状，建立共识起点。"},
            {"speaker": "customer", "text": "对，能用就行。"},
            {"speaker": "sales", "text": "我想请教一下，D 公司方案这两年用下来，有没有哪件事是您一直希望改善、但一直没解决的？不一定是大问题，日常小摩擦也算。", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "用开放式提问引导客户自己说出痛点，比销售直接指出更有效。"},
            {"speaker": "customer", "text": "小问题倒是有，比如报表导出经常卡，月底对账要手动调。"},
            {"speaker": "sales", "text": "月底对账手动调，这个我服务过的几家企业都遇到过，平均每月要多花 8 个人时。我想确认一下，贵司这边大概是什么量级？", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用同类企业的数据量化痛点，让客户感到「原来这是个普遍问题」。"},
            {"speaker": "customer", "text": "差不多，每个月大概 10 个人时吧。"},
            {"speaker": "sales", "text": "一年就是 120 个人时，相当于半个人力。陈总，我不是说一定要换，而是这件事值得评估一下：如果有一个方案能在不动现有系统的前提下，先把对账这件事自动化，您愿不愿意看一眼？", "principle": "稀缺原理", "tactic": "用数据建立专业权威策略", "note": "把「替换」降级为「增量改善」，降低客户的决策门槛。"},
            {"speaker": "customer", "text": "不动现有系统？怎么做到？"},
            {"speaker": "sales", "text": "我们可以做一层轻量集成，先只接报表和对账两个模块，两周内能跑通 PoC。您不用做任何迁移决定，先看效果。如果跑下来对账时间能降到 2 小时以内，再讨论下一步。", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "用低门槛 PoC 让客户无风险体验价值，触发后续推进的回报心理。"},
            {"speaker": "customer", "text": "两周 PoC？这个可以聊聊。"},
            {"speaker": "sales", "text": "好。我下周一带一份 PoC 的范围说明过来，咱们把对账场景的输入输出确认清楚，您看周一下午方便吗？", "principle": "承诺与一致原理", "tactic": "获取小承诺推进下一步策略", "note": "用具体的下一步时间锁定推进节奏。"},
            {"speaker": "customer", "text": "周一下午可以。"},
        ],
        "analysis": ["**喜好原理**：开场先认同客户「没必要为了换而换」的判断，避免直接攻击竞品，建立共识起点。", "**承诺与一致原理**：用开放式提问引导客户自己说出痛点（报表卡、对账手动调），客户自己说出的问题比销售指出的更有说服力。", "**社会认同原理**：用「服务过的几家企业都遇到」量化痛点，让客户感到这是普遍问题而非个案。", "**稀缺原理**：把「替换系统」降级为「增量改善」，用低门槛 PoC 让客户无风险体验。", "**互惠原理**：主动提供两周免费 PoC，让客户在零成本下体验价值，触发后续推进的回报压力。"],
        "conclusion": ["替换竞品的核心不是证明竞品差，而是找到竞品没解决的「日常小摩擦」。", "让客户自己说出痛点，比销售直接指出更有效。", "把「替换」降级为「增量改善」，大幅降低决策门槛。", "用低门槛 PoC 让客户无风险体验价值，是撬动替换决策的最佳切入点。"],
    },
    {
        "id": "scenario-05-rfp-response",
        "number": 5,
        "title": "招标书响应策略",
        "background": "客户发出正式招标书（RFP），要求两周内提交方案。销售需要在不掌握全部内部信息的情况下，制定差异化响应策略，避免陷入纯参数比拼。",
        "roles": {"sales": "李航（销售代表）", "customer": "刘经理（采购经理）"},
        "dialogue": [
            {"speaker": "sales", "text": "刘经理，感谢发来招标书。在正式响应前，我想确认一下评分权重：技术分和价格分的占比，以及是否有「同行业案例」这一项的加分？", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "通过提问了解评分逻辑，避免盲目堆砌参数。"},
            {"speaker": "customer", "text": "技术分占 60%，价格 30%，案例占 10%。案例需要同行业且实施满一年。"},
            {"speaker": "sales", "text": "明白。我们这边有 3 家同行业案例实施超过一年，其中一家 E 集团和贵司规模接近。我想确认一下，招标书第 4.2 节提到的「数据迁移」是必须项还是加分项？", "principle": "权威原理", "tactic": "用数据建立专业权威策略", "note": "通过具体条款提问展现专业度，同时精准识别必选项与加分项。"},
            {"speaker": "customer", "text": "数据迁移是加分项，不是必须。"},
            {"speaker": "sales", "text": "这就很关键了。我们在数据迁移上有独家的零停机方案，E 集团实施时业务零中断。我建议在响应里重点突出这一点，争取加分。另外，技术分 60% 里，评审最看重的是哪几个维度？", "principle": "稀缺原理", "tactic": "用数据建立专业权威策略", "note": "用独家能力锁定加分项，再进一步挖掘评分细节。"},
            {"speaker": "customer", "text": "技术分主要看架构合理性和实施风险控制。"},
            {"speaker": "sales", "text": "架构合理性和实施风险，正好是我们的强项。我服务过的 E 集团，实施期间零事故，审计报告可以脱敏后作为附件。刘经理，您看这样行不行：我们在响应里专门做一个「实施风险控制」章节，用 E 集团的真实数据佐证。", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用真实案例数据强化技术分维度的可信度。"},
            {"speaker": "customer", "text": "可以，这样有说服力。"},
            {"speaker": "sales", "text": "好。另外，价格分占 30%，我想确认一下，是最低价得满分，还是有基准价？", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "精准了解价格评分逻辑，避免无谓的低价竞争。"},
            {"speaker": "customer", "text": "有基准价，越接近基准价分越高。"},
            {"speaker": "sales", "text": "这我们就有了定价空间。刘经理，最后确认一下：响应文件里，我们重点突出三块——数据迁移加分项、实施风险控制、同行业案例。您觉得这个方向对吗？", "principle": "承诺与一致原理", "tactic": "获取小承诺推进下一步策略", "note": "用总结确认让客户对响应方向做出承诺。"},
            {"speaker": "customer", "text": "方向对的，就这么准备。"},
        ],
        "analysis": ["**承诺与一致原理**：通过一系列提问精准了解评分逻辑（权重、必选/加分、基准价），让客户在回答中逐步对响应方向做出承诺。", "**权威原理**：通过引用招标书具体条款（4.2 节）展现专业度，建立「这家供应商懂规则」的印象。", "**稀缺原理**：用独家能力（零停机数据迁移）锁定加分项，避免陷入参数比拼。", "**社会认同原理**：用 E 集团的真实数据强化技术分维度的可信度，降低评审对实施风险的顾虑。"],
        "conclusion": ["招标响应的核心不是「参数全」，而是「踩准评分点」。", "通过提问精准了解评分逻辑，避免盲目堆砌。", "用独家能力和真实案例锁定加分项和高权重维度。", "价格分要了解评分机制，避免无谓的低价竞争。"],
    },
    {
        "id": "scenario-06-champion-development",
        "number": 6,
        "title": "培养内部支持者",
        "background": "客户内部有一位业务骨干张工对方案认可，但缺乏推动决策的影响力。销售需要把张工从「认可者」培养成「内部倡导者」，借其之力影响决策层。",
        "roles": {"sales": "李航（销售代表）", "customer": "张工（业务骨干）"},
        "dialogue": [
            {"speaker": "sales", "text": "张工，上次技术交流后，您提到的几个业务痛点，我整理了一份内部材料，把我们方案怎么对应解决做了详细说明。这份材料我先发给您，您看看有没有需要调整的地方。", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "主动为支持者提供「弹药」，降低其在内部推动的难度。"},
            {"speaker": "customer", "text": "这个好，我正需要一份能跟领导讲清楚的材料。"},
            {"speaker": "sales", "text": "太好了。张工，我想请教一下：您在内部汇报时，领导通常最关心哪三个问题？我想把材料调整成最契合领导视角的版本。", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "通过提问让支持者主动提供内部决策视角的关键信息。"},
            {"speaker": "customer", "text": "领导最关心投入产出、实施风险、还有对现有 KPI 的影响。"},
            {"speaker": "sales", "text": "这三点我重点强化。投入产出方面，我服务过的 F 集团，6 个月回本，我可以把他们的 ROI 模型脱敏后放进材料。实施风险方面，我们有一份「风险清单 + 应对措施」的标准模板，对领导来说很直观。", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用真实案例和标准模板为支持者提供有说服力的弹药。"},
            {"speaker": "customer", "text": "ROI 模型和风险清单这两个最有用。"},
            {"speaker": "sales", "text": "张工，这份材料最终是要您去汇报的，我希望它真正帮您在内部建立专业形象。我有一个建议：材料里我会留出「贵司业务数据」的填空位置，您填完后就是一份完全贴合贵司的定制版，领导看了会觉得是您主导的成果。", "principle": "喜好原理", "tactic": "先建立关系再谈需求策略", "note": "把成果归给支持者，强化其在内部的归属感和推动意愿。"},
            {"speaker": "customer", "text": "这个想法好，这样我就有底气去推了。"},
            {"speaker": "sales", "text": "另外，如果您方便的话，我也可以陪您一起做一次内部预演，把领导可能问的问题提前过一遍。这样您汇报时更有把握。您觉得下周三或者周四哪个时间合适？", "principle": "稀缺原理", "tactic": "获取小承诺推进下一步策略", "note": "用陪练服务深化合作关系，同时锁定下一步接触。"},
            {"speaker": "customer", "text": "周四吧，我们过一遍。"},
            {"speaker": "sales", "text": "好。那张工，咱们一起把这件事推上去。材料我这两天改完发您，周四预演时咱们再细化。"},
        ],
        "analysis": ["**互惠原理**：主动为支持者提供汇报材料和定制化模板，降低其在内部推动的难度，触发其更积极的推动意愿。", "**承诺与一致原理**：通过提问让支持者主动提供内部决策视角的关键信息，同时让其在对材料和预演的承诺中逐步加深投入。", "**社会认同原理**：用 F 集团的 ROI 模型和标准风险模板，为支持者提供有说服力的外部佐证。", "**喜好原理**：把成果归属给支持者（留填空位让其主导），强化其在内部的归属感和推动意愿。", "**稀缺原理**：用陪练服务和二选一时间，深化合作关系并锁定下一步。"],
        "conclusion": ["培养内部支持者的核心是「为他赋能」，而非「让他帮我卖」。", "主动提供弹药（材料、案例、模板），降低支持者在内部推动的难度。", "把成果归属给支持者，强化其归属感和推动意愿。", "用陪练等增值服务深化合作关系，让支持者从「认可」升级为「主导」。"],
    },
    {
        "id": "scenario-07-negotiation-closing",
        "number": 7,
        "title": "商务谈判收尾",
        "background": "方案、价格、实施都已谈妥，客户在最后签约前提出额外要求（免费延长保修、赠送培训）。销售需要在守住底线的同时，用条件交换达成双赢收尾。",
        "roles": {"sales": "李航（销售代表）", "customer": "赵总（财务总监）"},
        "dialogue": [
            {"speaker": "customer", "text": "方案我们认可了，但签约前希望你们能把保修从一年延长到三年，另外再送 10 场培训。"},
            {"speaker": "sales", "text": "赵总，感谢您对方案的认可。保修延长和培训这两块，我都很重视。在回应之前，我想先确认：这两项对您来说，是同等重要，还是有优先级？", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "通过提问识别客户真实优先级，避免在低价值项上让步。"},
            {"speaker": "customer", "text": "保修更重要，培训是锦上添花。"},
            {"speaker": "sales", "text": "明白。赵总，我跟您坦诚说一下：三年保修超出标准包，公司有明确审批线。但我可以做到一件事——把保修从一年延长到两年，条件是签约时间从月底提前到本周。这样对您和对我都有价值，您看公平吗？", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "用条件交换让客户感到「让步是换来的」，而非单方面索取。"},
            {"speaker": "customer", "text": "提前到本周？这个我得问问业务部门。"},
            {"speaker": "sales", "text": "我理解。赵总，我服务过的 G 集团，当时也是卡在保修上，最后用「两年保修 + 提前签约」组合达成。提前签约对他们还有一个好处——赶上了季度实施排期，比月底签约的客户早一个月上线。", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用同类案例展示提前签约对客户的额外价值。"},
            {"speaker": "customer", "text": "早一个月上线，这个确实有意义。"},
            {"speaker": "sales", "text": "那关于培训，我建议这样：标准包含的 5 场不变，额外 5 场我们不做免费赠送，但可以按成本价给您，相当于市场价的 4 折。这样您既有了培训覆盖，我们也能合规处理。", "principle": "稀缺原理", "tactic": "用数据建立专业权威策略", "note": "用「成本价 4 折」让客户感到获得了稀缺优惠，同时守住商业底线。"},
            {"speaker": "customer", "text": "4 折可以接受。"},
            {"speaker": "sales", "text": "赵总，我总结一下：保修从一年延长到两年，条件是本周签约；培训额外 5 场按 4 折成本价；同时为您锁定季度实施排期，早一个月上线。这套方案，您认可的话，我今天就走内部审批，明天给您正式版本。", "principle": "承诺与一致原理", "tactic": "获取小承诺推进下一步策略", "note": "用总结确认让客户对整体方案做出承诺，锁定收尾。"},
            {"speaker": "customer", "text": "可以，你走审批吧。"},
        ],
        "analysis": ["**承诺与一致原理**：通过提问识别客户真实优先级（保修>培训），避免在低价值项上让步；用总结确认锁定整体承诺。", "**互惠原理**：用「条件交换」让客户感到让步是换来的（保修延长换取提前签约），而非单方面索取。", "**社会认同原理**：用 G 集团的案例展示提前签约对客户的额外价值（早一个月上线），让交换更公平。", "**稀缺原理**：用「4 折成本价」让客户感到获得了稀缺优惠，同时守住商业底线。"],
        "conclusion": ["谈判收尾的核心是「条件交换」，而非单方面让步。", "通过提问识别客户真实优先级，把让步用在刀刃上。", "每一次让步都要换取对等价值（时间、规模、排期等）。", "用总结确认锁定整体承诺，避免客户反复加码。"],
    },
    {
        "id": "scenario-08-revival-dormant",
        "number": 8,
        "title": "唤醒沉睡客户",
        "background": "一个半年前接触过的客户，因内部人事变动项目搁置。销售需要在不显得「追单」的前提下，重新激活对话并找到新的切入点。",
        "roles": {"sales": "李航（销售代表）", "customer": "周总（新任运营副总）"},
        "dialogue": [
            {"speaker": "sales", "text": "周总，恭喜您近期升任运营副总。我看到贵司上个月发布了新一年度的数字化战略，其中提到「全链路可视化」是重点方向，这个方向我正好服务过几家同行业客户，有些观察想跟您分享。", "principle": "喜好原理", "tactic": "先建立关系再谈需求策略", "note": "结合客户新职位+战略方向，建立 relevance，避免突兀追单。"},
            {"speaker": "customer", "text": "谢谢。全链路可视化确实是今年的重点，你有什么观察？"},
            {"speaker": "sales", "text": "我服务过的 H 集团，去年这个时候也在推全链路可视化，他们踩的最大一个坑是：先上了可视化大屏，但底层数据没打通，最后大屏上的数字对不上业务系统。我想确认一下，贵司今年的规划里，数据打通是排在可视化之前还是之后？", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "主动分享同行业的「踩坑经验」，提供无偿价值。"},
            {"speaker": "customer", "text": "我们目前是先做可视化，数据打通排在后面。"},
            {"speaker": "sales", "text": "这正是 H 集团当年的顺序，后来他们回炉重做，多花了 4 个月。周总，我不是说贵司一定会踩这个坑，而是这件事值得在启动前评估一下。我有一份 H 集团的复盘摘要，列出了「先可视化后打通」会出现的三个典型问题，方便的话我发给您参考。", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用真实案例提供预警价值，建立专业信任。"},
            {"speaker": "customer", "text": "发我看看，这个角度我们内部确实没讨论过。"},
            {"speaker": "sales", "text": "好。周总，另外我想请教一下：今年全链路可视化这个项目，主要牵头的是运营部门还是 IT 部门？这决定了数据打通的推进方式。", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "通过提问了解新决策链，同时展现对推进逻辑的理解。"},
            {"speaker": "customer", "text": "运营牵头，IT 配合。"},
            {"speaker": "sales", "text": "运营牵头的话，数据打通的优先级通常会被业务方推得更快。周总，我建议这样：我把复盘摘要发您，同时附一份「运营视角的数据打通优先级清单」，您可以在内部讨论时作为参考。如果您觉得有价值，我们再约一次面对面的交流，不涉及任何产品推销，纯做规划层面的探讨。您看下周方便吗？", "principle": "稀缺原理", "tactic": "获取小承诺推进下一步策略", "note": "用「纯规划探讨」降低会面门槛，用二选一推动下一步。"},
            {"speaker": "customer", "text": "下周可以，你把材料先发我，看完再约时间。"},
            {"speaker": "sales", "text": "好，我今天就发。周总，恭喜 again，也希望这次的交流能为您新官上任提供一些参考。"},
        ],
        "analysis": ["**喜好原理**：结合客户新职位+战略方向建立 relevance，避免突兀追单，让客户感到「这人懂我现在的处境」。", "**互惠原理**：主动分享同行业的踩坑经验，提供无偿价值，降低「销售又来追单」的抵触。", "**社会认同原理**：用 H 集团的真实复盘案例建立专业信任，让客户感到这些观察有据可依。", "**承诺与一致原理**：通过提问了解新决策链和推进方式，让客户在回答中逐步重新投入。", "**稀缺原理**：用「纯规划探讨」降低会面门槛，用二选一推动下一步。"],
        "conclusion": ["唤醒沉睡客户的核心是「找到新的 relevance」，而非追旧单。", "结合客户新职位、新战略、新人事，找到当下最相关的切入点。", "主动提供同行业踩坑经验，用预警价值建立信任。", "用「纯规划探讨」降低会面门槛，避免客户感到销售压力。"],
    },
    {
        "id": "scenario-09-upscope-expansion",
        "number": 9,
        "title": "存量客户扩Scope",
        "background": "客户已使用基础模块一年，运行良好。销售希望推动客户扩展到高级模块（数据中台、AI 预测），但客户对新模块的 ROI 存在疑虑。需要用现有合作成果建立扩展信心。",
        "roles": {"sales": "李航（销售代表）", "customer": "孙总（信息中心总监）"},
        "dialogue": [
            {"speaker": "sales", "text": "孙总，基础模块上线一年了，我整理了一份年度运行报告，几个关键数据：系统可用性 99.8%，月均处理订单 12 万单，业务方满意度 4.6/5。您看看有没有需要补充的维度？", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "主动用现有成果建立价值基线，为扩展讨论奠定信心。"},
            {"speaker": "customer", "text": "这几个数据挺准的，运行确实稳定。"},
            {"speaker": "sales", "text": "孙总，基于这一年的数据，我想请教一下：目前系统产生的数据，除了支撑日常运营，有没有被进一步用于业务决策或者预测？", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "通过提问引导客户自己意识到数据的未开发价值。"},
            {"speaker": "customer", "text": "说实话，目前主要用来出报表，预测和决策支持还没做。"},
            {"speaker": "sales", "text": "这正是我想跟您聊的。我服务过的 J 集团，基础模块跑了一年后，上了数据中台和 AI 预测，他们用预测模型把库存周转提升了 18%，呆滞库存下降了 23%。我想确认一下，贵司目前库存周转这块，有没有改善的诉求？", "principle": "社会认同原理", "tactic": "用同类案例降低风险感知策略", "note": "用 J 集团的真实数据建立对扩展模块的信心。"},
            {"speaker": "customer", "text": "库存周转确实是今年的 KPI 之一。"},
            {"speaker": "sales", "text": "那这件事值得评估。孙总，我建议这样：我们先做一个数据中台的免费 PoC，用贵司现有的一年数据，跑一个库存预测模型，您看预测准确率能不能达到业务可用水平。如果达到，再讨论扩展；如果达不到，至少您知道现有数据的潜力边界。", "principle": "稀缺原理", "tactic": "先给予价值降低戒备策略", "note": "用免费 PoC 让客户无风险验证扩展价值。"},
            {"speaker": "customer", "text": "免费 PoC？这个可以。"},
            {"speaker": "sales", "text": "好。PoC 范围我建议聚焦在库存预测这一个场景，三周内出结果。孙总，您这边能不能协调业务方提供过去 18 个月的历史库存数据？这是 PoC 能否跑通的关键。", "principle": "承诺与一致原理", "tactic": "获取小承诺推进下一步策略", "note": "用具体的资源协调让客户做出承诺，锁定推进。"},
            {"speaker": "customer", "text": "数据我可以协调，业务方那边我来约。"},
            {"speaker": "sales", "text": "太好了。孙总，我下周一带一份 PoC 的技术方案过来，咱们把数据接口和评估指标确认清楚。您看周一上午还是下午方便？", "principle": "稀缺原理", "tactic": "获取小承诺推进下一步策略", "note": "用二选一时间锁定下一步接触。"},
            {"speaker": "customer", "text": "周一下午吧。"},
        ],
        "analysis": ["**互惠原理**：主动用现有合作的年度运行报告建立价值基线，为扩展讨论奠定信心。", "**承诺与一致原理**：通过提问引导客户自己意识到数据的未开发价值，并在资源协调中让其做出承诺。", "**社会认同原理**：用 J 集团的真实数据（库存周转提升 18%）建立对扩展模块的信心。", "**稀缺原理**：用免费 PoC 让客户无风险验证扩展价值，用二选一时间锁定下一步。"],
        "conclusion": ["存量客户扩 Scope 的核心是「用现有成果建立扩展信心」。", "用年度运行报告等客观数据，让客户对现有合作有清晰的价值认知。", "通过提问引导客户自己意识到未开发的价值，比销售主动推销更有效。", "用免费 PoC 让客户无风险验证扩展价值，是推动扩展的最佳切入点。"],
    },
    {
        "id": "scenario-10-loss-recovery",
        "number": 10,
        "title": "丢单后挽回关系",
        "background": "客户最终选择了竞品方案，销售在丢单后需要维护关系，为未来的二次机会（竞品出问题、新需求出现）埋下伏笔，避免一锤子买卖心态。",
        "roles": {"sales": "李航（销售代表）", "customer": "王总（采购总监）"},
        "dialogue": [
            {"speaker": "sales", "text": "王总，感谢您通知我最终决定。虽然这次没有合作成功，但整个交流过程对我非常有价值，让我更深入理解了贵司的需求。", "principle": "喜好原理", "tactic": "先建立关系再谈需求策略", "note": "用真诚感谢维护关系，避免表现出失落或不满。"},
            {"speaker": "customer", "text": "你们方案其实也不错，主要是综合评分差了一点。"},
            {"speaker": "sales", "text": "我理解。王总，我想请教一下：这次评审中，我们最大的差距在哪几个维度？这对我后续改进非常重要，也希望未来能有更好的方案服务贵司。", "principle": "承诺与一致原理", "tactic": "引导客户自我说服策略", "note": "通过复盘提问让客户感到销售的专业态度，同时获取改进情报。"},
            {"speaker": "customer", "text": "主要是在实施本地化支持上，对方承诺了驻场团队。"},
            {"speaker": "sales", "text": "明白了，这个反馈很重要。王总，不管这次结果如何，我希望保持长期联系。我服务同行业的几家企业，定期会有一份「行业实施风险季报」，专门跟踪各方案商在实施阶段出现的共性问题。如果您方便，我可以每季度发给您一份，作为贵司项目实施的参考。", "principle": "互惠原理", "tactic": "先给予价值降低戒备策略", "note": "用持续的价值提供维护关系，为二次机会埋下伏笔。"},
            {"speaker": "customer", "text": "这个有用，你发我吧。"},
            {"speaker": "sales", "text": "好。王总，还有一件事想提醒您：新方案上线前三个月是风险高发期，尤其是数据迁移和接口对接。如果实施过程中遇到任何问题，不管是技术层面还是项目管理层面，您随时可以找我，我免费提供一份独立视角的评估，不涉及任何商业关系。", "principle": "稀缺原理", "tactic": "先给予价值降低戒备策略", "note": "用「免费独立评估」建立长期信任，为二次机会创造触点。"},
            {"speaker": "customer", "text": "这个我会记住的。"},
            {"speaker": "sales", "text": "王总，最后我想说，无论这次结果如何，我都希望我们能保持行业层面的长期交流。我这边会定期更新行业案例和风险情报给您，您有任何需要也随时找我。未来如果有新需求，我们再有机会合作，我也会带着更成熟的方案来。", "principle": "承诺与一致原理", "tactic": "获取小承诺推进下一步策略", "note": "用长期关系定位收尾，避免一锤子买卖心态。"},
            {"speaker": "customer", "text": "好的，保持联系。"},
            {"speaker": "sales", "text": "一定。王总，祝贵司这次项目实施顺利，有任何需要随时找我。"},
        ],
        "analysis": ["**喜好原理**：用真诚感谢和「交流对我有价值」维护关系，避免表现出失落或不满，让客户感到销售的专业与大度。", "**承诺与一致原理**：通过复盘提问让客户感到销售的专业态度，同时获取改进情报；用长期关系定位收尾。", "**互惠原理**：用持续的价值提供（行业实施风险季报）维护关系，为二次机会埋下伏笔。", "**稀缺原理**：用「免费独立评估」建立长期信任，为二次机会创造触点。"],
        "conclusion": ["丢单后的核心是「维护关系，为二次机会埋伏笔」，而非一锤子买卖。", "用真诚感谢和复盘提问展现专业态度，避免表现出失落。", "用持续的价值提供（行业情报、季报）维护关系，保持触点。", "用「免费独立评估」等服务，为竞品出问题时的二次机会创造切入点。"],
    },
]

def render_html(scenario):
    """渲染单个场景的HTML页面"""
    title = f"场景 {scenario['number']}：{scenario['title']}"
    dialogue_html = ""
    for turn in scenario["dialogue"]:
        speaker = turn["speaker"]
        role_name = scenario["roles"][speaker]
        bubble_class = "bubble-sales" if speaker == "sales" else "bubble-customer"
        meta = ""
        if "principle" in turn:
            meta = f"""
            <div class="turn-meta">
                <span class="tag principle">{turn['principle']}</span>
                <span class="tag tactic">{turn['tactic']}</span>
                <p class="note">{turn['note']}</p>
            </div>
            """
        dialogue_html += f"""
        <div class="turn {speaker}">
            <div class="speaker">{role_name}</div>
            <div class="bubble {bubble_class}">{turn['text']}</div>
            {meta}
        </div>
        """

    analysis_html = "".join(f"<li>{item}</li>" for item in scenario["analysis"])
    conclusion_html = "".join(f"<li>{item}</li>" for item in scenario["conclusion"])

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | 影响力销售教练场景</title>
    <style>
        :root {{
            --primary: #1e3a5f;
            --secondary: #4a90a4;
            --accent: #d4a373;
            --bg: #f8f9fa;
            --card: #ffffff;
            --text: #333333;
            --muted: #666666;
            --border: #e0e0e0;
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.7;
            margin: 0;
            padding: 0;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            padding: 24px 16px 64px;
        }}
        header {{
            text-align: center;
            padding: 32px 0;
            border-bottom: 2px solid var(--primary);
            margin-bottom: 32px;
        }}
        header h1 {{ color: var(--primary); margin: 0 0 8px; font-size: 1.8rem; }}
        header .subtitle {{ color: var(--muted); font-size: 0.95rem; }}
        .card {{
            background: var(--card);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }}
        .card h2 {{
            color: var(--primary);
            font-size: 1.25rem;
            margin: 0 0 16px;
            padding-bottom: 8px;
            border-bottom: 1px solid var(--border);
        }}
        .background {{
            background: #eef4f7;
            border-left: 4px solid var(--secondary);
            padding: 16px;
            border-radius: 8px;
            color: var(--text);
        }}
        .turn {{
            margin-bottom: 24px;
        }}
        .speaker {{
            font-size: 0.85rem;
            color: var(--muted);
            margin-bottom: 4px;
            font-weight: 600;
        }}
        .bubble {{
            padding: 14px 18px;
            border-radius: 16px;
            max-width: 85%;
            position: relative;
        }}
        .bubble-sales {{
            background: var(--primary);
            color: #fff;
            margin-left: auto;
            border-bottom-right-radius: 4px;
        }}
        .bubble-customer {{
            background: #e9ecef;
            color: var(--text);
            border-bottom-left-radius: 4px;
        }}
        .turn-meta {{
            margin-top: 8px;
            font-size: 0.85rem;
            color: var(--muted);
        }}
        .tag {{
            display: inline-block;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 0.78rem;
            margin-right: 6px;
            margin-bottom: 4px;
        }}
        .tag.principle {{ background: #e3f2fd; color: #1565c0; }}
        .tag.tactic {{ background: #fff3e0; color: #e65100; }}
        .note {{ margin: 8px 0 0; font-style: italic; }}
        ul {{ padding-left: 20px; }}
        li {{ margin-bottom: 10px; }}
        .nav {{
            display: flex;
            justify-content: space-between;
            margin-top: 32px;
            padding-top: 16px;
            border-top: 1px solid var(--border);
        }}
        .nav a {{
            color: var(--secondary);
            text-decoration: none;
            font-weight: 600;
        }}
        .nav a:hover {{ text-decoration: underline; }}
        footer {{
            text-align: center;
            color: var(--muted);
            font-size: 0.85rem;
            margin-top: 48px;
        }}
        @media (max-width: 600px) {{
            .container {{ padding: 16px 12px 40px; }}
            header h1 {{ font-size: 1.5rem; }}
            .bubble {{ max-width: 92%; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>{title}</h1>
            <div class="subtitle">基于《影响力》原则的销售教练场景</div>
        </header>

        <div class="card">
            <h2>背景</h2>
            <div class="background">{scenario['background']}</div>
        </div>

        <div class="card">
            <h2>完整对话</h2>
            {dialogue_html}
        </div>

        <div class="card">
            <h2>分析</h2>
            <ul>{analysis_html}</ul>
        </div>

        <div class="card">
            <h2>结论</h2>
            <ul>{conclusion_html}</ul>
        </div>

        <div class="nav">
            <a href="{'index.html' if scenario['number'] == 1 else f'scenario-{scenario['number']-1:02d}.html'}">← 上一个场景</a>
            <a href="index.html">返回目录</a>
            <a href="{'index.html' if scenario['number'] == 10 else f'scenario-{scenario['number']+1:02d}.html'}">下一个场景 →</a>
        </div>

        <footer>影响力销售教练场景 · 生成于 2026-06-24</footer>
    </div>
</body>
</html>"""

def render_index(scenarios):
    """渲染索引页面"""
    links = "\\n".join(
        f"""<a class="scene-link" href="{s['id']}.html">
            <div class="scene-number">{s['number']}</div>
            <div class="scene-info">
                <div class="scene-title">{s['title']}</div>
                <div class="scene-desc">{s['background'][:60]}...</div>
            </div>
        </a>"""
        for s in scenarios
    )

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>影响力销售教练场景 | 目录</title>
    <style>
        :root {{
            --primary: #1e3a5f;
            --secondary: #4a90a4;
            --accent: #d4a373;
            --bg: #f8f9fa;
            --card: #ffffff;
            --text: #333333;
            --muted: #666666;
            --border: #e0e0e0;
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.7;
            margin: 0;
            padding: 0;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            padding: 24px 16px 64px;
        }}
        header {{
            text-align: center;
            padding: 40px 0 32px;
        }}
        header h1 {{ color: var(--primary); margin: 0 0 12px; font-size: 2rem; }}
        header .subtitle {{ color: var(--muted); font-size: 1rem; max-width: 600px; margin: 0 auto; }}
        .scene-link {{
            display: flex;
            align-items: center;
            background: var(--card);
            border-radius: 12px;
            padding: 18px 20px;
            margin-bottom: 14px;
            text-decoration: none;
            color: inherit;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            transition: transform 0.15s, box-shadow 0.15s;
        }}
        .scene-link:hover {{
            transform: translateY(-2px);
            box-shadow: 0 4px 14px rgba(0,0,0,0.1);
        }}
        .scene-number {{
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--primary);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.1rem;
            flex-shrink: 0;
            margin-right: 16px;
        }}
        .scene-title {{
            font-weight: 600;
            font-size: 1.1rem;
            color: var(--primary);
            margin-bottom: 4px;
        }}
        .scene-desc {{
            font-size: 0.9rem;
            color: var(--muted);
        }}
        footer {{
            text-align: center;
            color: var(--muted);
            font-size: 0.85rem;
            margin-top: 48px;
        }}
        @media (max-width: 600px) {{
            header h1 {{ font-size: 1.6rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>影响力销售教练场景</h1>
            <div class="subtitle">10 个真实销售场景，每个场景包含完整对话、影响力原则分析与可落地的结论。基于《影响力》本体系统构建。</div>
        </header>

        {links}

        <footer>影响力销售教练场景 · 生成于 2026-06-24</footer>
    </div>
</body>
</html>"""

def main():
    OUTPUT_DIR.mkdir(exist_ok=True)

    for s in SCENARIOS:
        html = render_html(s)
        out_path = OUTPUT_DIR / f"scenario-{s['number']:02d}.html"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"Generated: {out_path}")

    index_path = OUTPUT_DIR / "index.html"
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(render_index(SCENARIOS))
    print(f"Generated: {index_path}")

if __name__ == "__main__":
    main()
