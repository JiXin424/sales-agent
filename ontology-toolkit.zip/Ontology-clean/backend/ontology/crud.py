"""本体 CRUD 操作"""

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.ontology.models import (
    ObjectType,
    Object,
    LinkType,
    Link,
    Document,
    DEFAULT_OBJECT_TYPES,
    DEFAULT_LINK_TYPES,
)


async def ensure_default_types(session: AsyncSession) -> None:
    """确保默认实体类型和关系类型存在"""
    for name, desc in DEFAULT_OBJECT_TYPES:
        result = await session.execute(select(ObjectType).where(ObjectType.name == name))
        if not result.scalar_one_or_none():
            session.add(ObjectType(name=name, description=desc))

    for name, desc in DEFAULT_LINK_TYPES:
        result = await session.execute(select(LinkType).where(LinkType.name == name))
        if not result.scalar_one_or_none():
            session.add(LinkType(name=name, description=desc))

    await session.commit()


async def get_or_create_object_type(session: AsyncSession, name: str) -> ObjectType:
    result = await session.execute(select(ObjectType).where(ObjectType.name == name))
    ot = result.scalar_one_or_none()
    if ot:
        return ot
    ot = ObjectType(name=name)
    session.add(ot)
    await session.flush()
    return ot


async def get_or_create_link_type(session: AsyncSession, name: str) -> LinkType:
    result = await session.execute(select(LinkType).where(LinkType.name == name))
    lt = result.scalar_one_or_none()
    if lt:
        return lt
    lt = LinkType(name=name)
    session.add(lt)
    await session.flush()
    return lt


async def create_object(
    session: AsyncSession,
    type_name: str,
    name: str,
    properties: dict | None = None,
    source_document_id: int | None = None,
    version_date: datetime | None = None,
) -> Object:
    """创建实体，若同名同类型已存在则按版本规则合并。版本不明时记录冲突待人工确认。"""
    from backend.ontology.models import Conflict

    ot = await get_or_create_object_type(session, type_name)

    existing = await session.execute(
        select(Object).where(Object.name == name, Object.type_id == ot.id)
    )
    obj = existing.scalars().first()

    if obj:
        # 有明确版本信息时：按版本比较
        if version_date and obj.version_date:
            if version_date <= obj.version_date:
                return obj  # 旧版不覆盖新版
            # 新版覆盖旧版
            if properties:
                obj.properties = properties
            obj.version_date = version_date
            obj.version = (obj.version or 0) + 1
            await session.flush()
            return obj

        # 版本不明确但属性有差异时：记录冲突待人工确认
        if properties and obj.properties:
            old_props = obj.properties
            conflicting_keys = [k for k in properties if k in old_props and old_props[k] != properties[k]]
            if conflicting_keys:
                conflict = Conflict(
                    object_id=obj.id,
                    conflict_type="property_mismatch",
                    old_value={k: old_props.get(k) for k in conflicting_keys},
                    new_value={k: properties.get(k) for k in conflicting_keys},
                    source_document_id=source_document_id,
                )
                session.add(conflict)
                # 暂时保留旧值，等人工确认
                await session.flush()
                return obj

        # 无冲突，合并新属性
        if properties:
            merged = dict(obj.properties or {})
            merged.update(properties)
            obj.properties = merged
        await session.flush()
        return obj

    obj = Object(
        type_id=ot.id,
        name=name,
        properties=properties or {},
        source_document_id=source_document_id,
        version_date=version_date,
    )
    session.add(obj)
    await session.flush()
    return obj


async def create_link(
    session: AsyncSession,
    source_name: str,
    target_name: str,
    type_name: str,
) -> Link | None:
    """按名称查找实体并创建关系（去重：已存在则跳过）"""
    src_result = await session.execute(select(Object).where(Object.name == source_name))
    source = src_result.scalars().first()
    tgt_result = await session.execute(select(Object).where(Object.name == target_name))
    target = tgt_result.scalars().first()

    if not source or not target:
        return None

    lt = await get_or_create_link_type(session, type_name)

    # 去重: 检查是否已存在相同关系
    existing = await session.execute(
        select(Link).where(
            Link.source_id == source.id,
            Link.target_id == target.id,
            Link.type_id == lt.id,
        )
    )
    if existing.scalars().first():
        return None

    link = Link(type_id=lt.id, source_id=source.id, target_id=target.id)
    session.add(link)
    await session.flush()
    return link


async def query_objects_by_type(session: AsyncSession, type_name: str) -> list[Object]:
    result = await session.execute(
        select(Object)
        .join(ObjectType)
        .where(ObjectType.name == type_name)
    )
    return list(result.scalars().all())


async def query_all_objects(session: AsyncSession) -> list[Object]:
    result = await session.execute(select(Object))
    return list(result.scalars().all())


async def query_all_links(session: AsyncSession) -> list[Link]:
    result = await session.execute(select(Link))
    return list(result.scalars().all())


async def create_document(
    session: AsyncSession,
    filename: str,
    file_type: str,
    md_content: str,
    status: str = "completed",
    version_date: datetime | None = None,
) -> Document:
    doc = Document(
        filename=filename,
        file_type=file_type,
        md_content=md_content,
        status=status,
        version_date=version_date,
    )
    session.add(doc)
    await session.flush()
    return doc
