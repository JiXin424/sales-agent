#!/usr/bin/env python3
"""补充销售教练场景的低分问题覆盖：新增 ReasoningChain / Tactic / Script / Scenario / Relation。"""

import json
import shutil
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
JSON_PATH = BASE_DIR / "influence_ontology.json"
BACKUP_PATH = BASE_DIR / "influence_ontology.json.bak"


def load_json():
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(data):
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def ensure_id_unique(existing_ids, new_entities):
    for e in new_entities:
        if e["id"] in existing_ids:
            raise ValueError(f"Duplicate id: {e['id']}")


def main():
    # 备份
    shutil.copy2(JSON_PATH, BACKUP_PATH)
    print(f"Backup created: {BACKUP_PATH}")

    data = load_json()

    existing_ids = set()
    for key in data:
        if isinstance(data[key], list):
            for e in data[key]:
                if isinstance(e, dict) and "id" in e:
                    existing_ids.add(e["id"])

    # ───────────────────────── 1. 新增推理链 ─────────────────────────
    new_reasoning_chains = [
        {
            "id": "first-meeting-rapport-chain",
            "name": "初次见面建立融洽关系推理链",
            "principle_id": "liking-principle",
            "premises": "人们更容易对与自己相似、表达真诚好感的人敞开心扉。",
            "trigger": "销售与客户第一次见面",
            "behavior": "客户放下戒备，愿意进行需求对话",
            "consequence": "建立初步信任，获得深入交流机会",
            "evidence": "相似性实验、外表魅力实验、赞美与合作效应",
            "confidence": "高",
        },
        {
            "id": "reduce-defensiveness-trust-chain",
            "name": "降低戒备建立信任推理链",
            "principle_id": "reciprocity-principle",
            "premises": "当人们先获得有价值的东西时，会产生回报压力并降低防御。",
            "trigger": "客户对销售有戒备心理",
            "behavior": "客户愿意接受销售提供的信息和帮助",
            "consequence": "初步信任建立，抵触情绪下降",
            "evidence": "克利须那协会送礼物、互惠可信度策略",
            "confidence": "高",
        },
        {
            "id": "re-engage-cold-prospect-chain",
            "name": "重新唤起冷漠客户兴趣推理链",
            "principle_id": "reciprocity-principle",
            "premises": "提供高度相关且低压力的洞察价值，能重新激活客户的注意力。",
            "trigger": "客户说\"我没时间\"或\"不需要\"",
            "behavior": "客户愿意重新评估自己的判断",
            "consequence": "从拒绝转为愿意继续对话",
            "evidence": "互惠影响推理链、拒绝—后撤术",
            "confidence": "中",
        },
        {
            "id": "upward-influence-chain",
            "name": "向上影响关键决策者推理链",
            "principle_id": "authority-principle",
            "premises": "高层决策者更关注战略价值和权威背书，而非功能细节。",
            "trigger": "接触的人不是最终决策者",
            "behavior": "通过中层引荐并提供适合高管的权威证据",
            "consequence": "关键决策者认可并推动项目",
            "evidence": "米尔格拉姆实验、权威顺从推理链",
            "confidence": "中",
        },
        {
            "id": "stakeholder-priority-mapping-chain",
            "name": "识别多方利益相关者优先级推理链",
            "principle_id": "social-identity-principle",
            "premises": "决策委员会成员会参考同行的判断，并优先考虑与自己身份相关的问题。",
            "trigger": "决策涉及多方人员",
            "behavior": "识别每个成员的社会身份和顾虑来源",
            "consequence": "精准定位每个人的优先级和支持/反对原因",
            "evidence": "社会认同原理推理链",
            "confidence": "中",
        },
        {
            "id": "overcome-internal-resistance-chain",
            "name": "化解内部反对争取同盟推理链",
            "principle_id": "reciprocity-principle",
            "premises": "公开反对者若被真诚倾听并获得针对性价值，可能转化为同盟。",
            "trigger": "客户内部有人明确反对",
            "behavior": "主动了解反对理由，提供解决其顾虑的专属价值",
            "consequence": "反对者转为支持者或至少不再阻挠",
            "evidence": "互惠影响推理链、好警察/坏警察审讯策略",
            "confidence": "中",
        },
        {
            "id": "re-activate-silent-deal-chain",
            "name": "重新激活沉默商机推理链",
            "principle_id": "scarcity-principle",
            "premises": "当人们意识到可能失去一个有价值的机会时，会重新评估拖延行为。",
            "trigger": "客户已读不回或长时间沉默",
            "behavior": "以非催促方式呈现机会的稀缺性或时间窗口",
            "consequence": "客户重新参与对话并给出明确反馈",
            "evidence": "稀缺吸引推理链、最后期限战术",
            "confidence": "中",
        },
        {
            "id": "demo-attention-engagement-chain",
            "name": "演示中抓住注意力推理链",
            "principle_id": "principle-contrast",
            "premises": "强烈的对比和意外停顿能打破自动化的注意力分散状态。",
            "trigger": "演示时客户心不在焉",
            "behavior": "通过对比、提问或互动让客户从走神中恢复专注",
            "consequence": "客户主动参与演示过程",
            "evidence": "对比原理实验、水温对比实验",
            "confidence": "中",
        },
        {
            "id": "expand-product-line-chain",
            "name": "从单一产品扩展到多产品线推理链",
            "principle_id": "commitment-and-consistency-principle",
            "premises": "人们倾向于与之前的选择保持一致，并会参考同行的扩展行为。",
            "trigger": "客户只购买单一产品",
            "behavior": "将扩展包装为对既有选择的自然延伸和价值放大",
            "consequence": "客户接受增购或升级方案",
            "evidence": "一致性动机推理链、特百惠销售推理链",
            "confidence": "中",
        },
        {
            "id": "prioritize-internal-project-chain",
            "name": "推动内部项目优先级推理链",
            "principle_id": "scarcity-principle",
            "premises": "内部资源稀缺时，能获得支持和关注的项目往往具有明显的窗口期或竞争压力。",
            "trigger": "内部对项目优先级有分歧",
            "behavior": "展示资源窗口的稀缺性和不行动的代价",
            "consequence": "项目获得足够重视和资源投入",
            "evidence": "稀缺吸引推理链、对稀缺资源的竞争",
            "confidence": "中",
        },
        {
            "id": "move-from-consideration-to-next-step-chain",
            "name": "从考虑推进到下一步推理链",
            "principle_id": "commitment-and-consistency-principle",
            "premises": "小的具体承诺比抽象的\"考虑\"更容易让人进入一致性的行动轨道。",
            "trigger": "客户说\"我要考虑一下\"",
            "behavior": "将模糊考虑转化为一个低风险、具体的小承诺",
            "consequence": "客户同意明确的下一步行动",
            "evidence": "登门槛技巧推理链、书面宣言推理链",
            "confidence": "高",
        },
        {
            "id": "bid-evaluation-advantage-chain",
            "name": "招标比价中提升中标概率推理链",
            "principle_id": "principle-contrast",
            "premises": "评标者通过对比评估选项，权威背书和社会认同能显著影响评分。",
            "trigger": "客户进行招标或比价",
            "behavior": "以清晰对比框架呈现差异化价值，并辅以权威和社会证据",
            "consequence": "提升中标概率",
            "evidence": "对比原理推理链、权威顺从推理链、社会认同原理推理链",
            "confidence": "中",
        },
    ]

    # ───────────────────────── 2. 新增策略 ─────────────────────────
    new_tactics = [
        {
            "id": "rapport-first-tactic",
            "name": "先建立关系再谈需求策略",
            "en_name": "Rapport-First Tactic",
            "principle_id": "liking-principle",
            "scenario": "大客户初次拜访",
            "steps": [
                "找到与客户的相似点或共同目标",
                "给予真诚的赞美或认可",
                "用开放式问题引导客户表达",
                "倾听并复述关键信息",
                "自然过渡到需求对话",
            ],
            "expected_result": "客户放下戒备，愿意进入真正的需求对话",
            "risk": "过度寒暄可能浪费时间",
            "example": "销售在拜访前研究客户背景，发现共同认识的人，开场时提及并自然引到业务",
        },
        {
            "id": "value-first-tactic",
            "name": "先给予价值降低戒备策略",
            "en_name": "Value-First Tactic",
            "principle_id": "reciprocity-principle",
            "scenario": "客户对销售有戒备",
            "steps": [
                "识别客户可能的痛点",
                "提供一个免费且有价值的洞察/工具/数据",
                "不附带任何索取要求",
                "等待客户主动询问",
                "顺势引入解决方案",
            ],
            "expected_result": "客户降低抵触，愿意接受进一步沟通",
            "risk": "给予的价值若不够相关，会被视为推销话术",
            "example": "销售分享一份行业趋势报告，帮助客户发现潜在风险",
        },
        {
            "id": "small-commitment-tactic",
            "name": "获取小承诺推进下一步策略",
            "en_name": "Small-Commitment Tactic",
            "principle_id": "commitment-and-consistency-principle",
            "scenario": "客户犹豫或拖延",
            "steps": [
                "确认客户的真实顾虑",
                "提出一个低风险的小请求",
                "让客户公开或书面确认",
                "逐步升级承诺",
                "最终达成明确下一步",
            ],
            "expected_result": "客户从\"考虑\"进入具体行动",
            "risk": "承诺过小可能导致推进缓慢",
            "example": "请客户同意在一个具体日期前提供反馈，而非模糊地说\"再考虑\"",
        },
        {
            "id": "executive-alignment-tactic",
            "name": "高管对齐策略",
            "en_name": "Executive Alignment Tactic",
            "principle_id": "authority-principle",
            "scenario": "需要影响最终决策者",
            "steps": [
                "了解高管的战略优先级",
                "准备简洁的权威背书证据",
                "通过中层引荐或正式会议接触",
                "用商业语言而非技术细节沟通",
                "获取明确的决策支持",
            ],
            "expected_result": "关键决策者认可项目价值",
            "risk": "绕过中层可能引发关系问题",
            "example": "销售准备同行业标杆案例和第三方数据，通过现有联系人安排高管简报",
        },
        {
            "id": "objection-mapping-tactic",
            "name": "利益相关者反对意见映射策略",
            "en_name": "Objection Mapping Tactic",
            "principle_id": "social-identity-principle",
            "scenario": "决策委员会有多方参与",
            "steps": [
                "列出所有决策相关人",
                "识别每个人的角色和社会身份",
                "判断其支持/反对倾向",
                "针对反对者设计个性化价值主张",
                "争取内部同盟共同推进",
            ],
            "expected_result": "每个人的顾虑被识别并针对性处理",
            "risk": "过度政治化可能破坏客户关系",
            "example": "制作利益相关者地图，标注技术、采购、使用部门的关注点",
        },
        {
            "id": "demo-contrast-tactic",
            "name": "演示对比抓注意力策略",
            "en_name": "Demo Contrast Tactic",
            "principle_id": "principle-contrast",
            "scenario": "方案演示中客户心不在焉",
            "steps": [
                "在演示中制造意外停顿或强烈对比",
                "提出一个与客户利益直接相关的问题",
                "邀请客户操作或决策",
                "用前后对比展示变化",
                "将注意力锚定在客户痛点上",
            ],
            "expected_result": "客户从被动听讲转为主动参与",
            "risk": "对比过于戏剧化可能显得不专业",
            "example": "先展示客户当前流程的成本数据，再展示使用方案后的对比",
        },
        {
            "id": "cross-sell-social-proof-tactic",
            "name": "增购社会认同策略",
            "en_name": "Cross-Sell Social Proof Tactic",
            "principle_id": "social-identity-principle",
            "scenario": "老客户增购扩展",
            "steps": [
                "识别与客户相似的标杆客户",
                "展示这些客户的扩展路径和收益",
                "将扩展包装为行业最佳实践",
                "提供低风险的试用或试点",
                "获取客户对扩展方案的承诺",
            ],
            "expected_result": "客户从单一产品自然扩展到更多产品线",
            "risk": "案例不匹配可能适得其反",
            "example": "分享同行业客户从基础版升级到完整套件后的ROI数据",
        },
        {
            "id": "internal-scarcity-tactic",
            "name": "内部资源稀缺推动优先级策略",
            "en_name": "Internal Scarcity Tactic",
            "principle_id": "scarcity-principle",
            "scenario": "内部资源有限、优先级分歧",
            "steps": [
                "量化资源窗口的稀缺性",
                "展示竞争对手或市场变化带来的时间压力",
                "争取关键高管背书",
                "将项目与战略机会绑定",
                "要求明确的资源承诺",
            ],
            "expected_result": "项目获得足够重视和资源",
            "risk": "过度使用稀缺可能被视为内部政治操纵",
            "example": "向管理层说明该客户窗口期仅剩两个月，错过将影响季度目标",
        },
    ]

    # ───────────────────────── 3. 新增话术 ─────────────────────────
    new_scripts = [
        {
            "id": "rapport-opening-script",
            "name": "初次拜访建立融洽开场白话术",
            "context": "第一次见面，客户时间紧张",
            "text": "王总，我注意到贵公司在智能制造领域的最新布局，和我们服务的另一家标杆企业非常相似。今天我想先听听您目前最关注的一个挑战，而不是直接介绍产品。",
            "principle_id": "liking-principle",
        },
        {
            "id": "value-insight-script",
            "name": "提供洞察价值降低戒备话术",
            "context": "客户对销售有戒备",
            "text": "张主任，这次过来我不急着推销。我们刚完成一份行业成本分析报告，发现类似规模的企业普遍存在一个被忽视的合规风险，我发给您看看，是否有帮助。",
            "principle_id": "reciprocity-principle",
        },
        {
            "id": "next-step-commitment-script",
            "name": "下一步具体承诺话术",
            "context": "客户说\"我要考虑一下\"",
            "text": "理解，这个决定确实需要内部评估。为了帮您推进，我们能否约定本周五下午三点，您给我十五分钟的反馈，告诉我哪些点需要进一步澄清？",
            "principle_id": "commitment-and-consistency-principle",
        },
        {
            "id": "executive-briefing-script",
            "name": "高管简报话术",
            "context": "需要向上影响关键决策者",
            "text": "李总，基于贵公司今年降本20%的战略目标，我们整理了同行业三家头部企业的实施路径和第三方审计数据。希望能占用您十五分钟，展示这个项目如何支撑您的目标。",
            "principle_id": "authority-principle",
        },
        {
            "id": "resistance-empathy-script",
            "name": "反对意见共情话术",
            "context": "客户内部有人明确反对",
            "text": "我完全理解您的顾虑，如果换作是我，面对现有系统的稳定性也会谨慎。能否告诉我，您最担心的三个风险是什么？我们可以针对性地设计验证方案。",
            "principle_id": "reciprocity-principle",
        },
        {
            "id": "demo-pause-contrast-script",
            "name": "演示停顿对比话术",
            "context": "演示时客户心不在焉",
            "text": "各位，在继续之前，我想请大家看一组数字：这是贵公司目前流程的平均处理成本，这里是同行采用我们方案后的成本。请问这个差距对您的业务意味着什么？",
            "principle_id": "principle-contrast",
        },
        {
            "id": "cross-sell-peer-case-script",
            "name": "增购同行案例话术",
            "context": "老客户扩展产品线",
            "text": "赵总，和您同行业的A公司在使用基础模块六个月后，扩展到完整套件，季度运营效率提升了34%。我想了解一下，您是否有类似的增长目标？",
            "principle_id": "social-identity-principle",
        },
        {
            "id": "resource-window-script",
            "name": "资源窗口话术",
            "context": "内部优先级分歧",
            "text": "这个项目如果不在本月启动售前支持，客户很可能会在Q3招标中转向竞品。我们需要在本周内确定售前资源投入，否则窗口期就关闭了。",
            "principle_id": "scarcity-principle",
        },
    ]

    # ───────────────────────── 4. 新增场景 ─────────────────────────
    new_scenarios = [
        {
            "id": "scenario-first-meeting",
            "name": "大客户初次拜访场景",
            "description": "销售第一次拜访潜在客户，需要快速建立信任并进入需求对话",
            "applicable_tactics": ["rapport-first-tactic", "value-first-tactic"],
        },
        {
            "id": "scenario-cold-objection",
            "name": "客户冷淡异议场景",
            "description": "客户以没时间、不需要等理由推脱，需要重新唤起兴趣",
            "applicable_tactics": ["value-first-tactic", "small-commitment-tactic"],
        },
        {
            "id": "scenario-multi-stakeholder",
            "name": "多方利益相关者决策场景",
            "description": "销售需要识别和影响决策委员会中的多个角色",
            "applicable_tactics": ["executive-alignment-tactic", "objection-mapping-tactic"],
        },
        {
            "id": "scenario-demo-engagement",
            "name": "方案演示注意力管理场景",
            "description": "产品演示中需要抓住客户注意力并促进参与",
            "applicable_tactics": ["demo-contrast-tactic"],
        },
        {
            "id": "scenario-cross-sell",
            "name": "老客户增购扩展场景",
            "description": "在现有客户基础上扩展到更多产品线或更高版本",
            "applicable_tactics": ["cross-sell-social-proof-tactic"],
        },
        {
            "id": "scenario-internal-priority",
            "name": "内部资源优先级争取场景",
            "description": "销售需要在组织内部争取售前、高管等资源支持",
            "applicable_tactics": ["internal-scarcity-tactic"],
        },
    ]

    # ───────────────────────── 5. 校验 ID 唯一性 ─────────────────────────
    all_new = new_reasoning_chains + new_tactics + new_scripts + new_scenarios
    ensure_id_unique(existing_ids, all_new)

    # ───────────────────────── 6. 追加到数据 ─────────────────────────
    data["reasoning_chains"].extend(new_reasoning_chains)
    data["tactics"].extend(new_tactics)
    data["scripts"].extend(new_scripts)
    data["scenarios"].extend(new_scenarios)

    # ───────────────────────── 7. 新增关系 ─────────────────────────
    new_relations = []

    def add_relation(relation_type, from_id, to_id, description=""):
        new_relations.append({
            "id": f"rel-{relation_type}-{from_id}-{to_id}",
            "relation_type": relation_type,
            "from_id": from_id,
            "to_id": to_id,
            "description": description,
        })

    # reasoning_chain -> principle
    for rc in new_reasoning_chains:
        add_relation("reasoning_derives", rc["id"], rc["principle_id"], f"{rc['name']}基于{rc['principle_id']}")

    # tactic -> principle
    for t in new_tactics:
        add_relation("tactic_based_on", t["id"], t["principle_id"], f"{t['name']}基于{t['principle_id']}")

    # script -> principle
    for s in new_scripts:
        add_relation("script_based_on", s["id"], s["principle_id"], f"{s['name']}基于{s['principle_id']}")

    # scenario -> tactic
    for sc in new_scenarios:
        for tid in sc["applicable_tactics"]:
            add_relation("tactic_applies_to", tid, sc["id"], f"{tid}适用于{sc['id']}")

    # reasoning_chain -> tactic/script (suggests)
    reasoning_to_tactic = {
        "first-meeting-rapport-chain": "rapport-first-tactic",
        "reduce-defensiveness-trust-chain": "value-first-tactic",
        "re-engage-cold-prospect-chain": "value-first-tactic",
        "upward-influence-chain": "executive-alignment-tactic",
        "stakeholder-priority-mapping-chain": "objection-mapping-tactic",
        "overcome-internal-resistance-chain": "value-first-tactic",
        "re-activate-silent-deal-chain": "internal-scarcity-tactic",
        "demo-attention-engagement-chain": "demo-contrast-tactic",
        "expand-product-line-chain": "cross-sell-social-proof-tactic",
        "prioritize-internal-project-chain": "internal-scarcity-tactic",
        "move-from-consideration-to-next-step-chain": "small-commitment-tactic",
        "bid-evaluation-advantage-chain": "demo-contrast-tactic",
    }
    for rid, tid in reasoning_to_tactic.items():
        add_relation("reasoning_suggests_tactic", rid, tid, f"{rid}建议使用{tid}")

    reasoning_to_script = {
        "first-meeting-rapport-chain": "rapport-opening-script",
        "reduce-defensiveness-trust-chain": "value-insight-script",
        "re-engage-cold-prospect-chain": "value-insight-script",
        "upward-influence-chain": "executive-briefing-script",
        "overcome-internal-resistance-chain": "resistance-empathy-script",
        "demo-attention-engagement-chain": "demo-pause-contrast-script",
        "expand-product-line-chain": "cross-sell-peer-case-script",
        "prioritize-internal-project-chain": "resource-window-script",
        "move-from-consideration-to-next-step-chain": "next-step-commitment-script",
    }
    for rid, sid in reasoning_to_script.items():
        add_relation("reasoning_suggests_script", rid, sid, f"{rid}建议使用{sid}")

    # scenario -> reasoning_chain
    scenario_to_reasoning = {
        "scenario-first-meeting": ["first-meeting-rapport-chain", "reduce-defensiveness-trust-chain"],
        "scenario-cold-objection": ["re-engage-cold-prospect-chain", "move-from-consideration-to-next-step-chain"],
        "scenario-multi-stakeholder": ["upward-influence-chain", "stakeholder-priority-mapping-chain", "overcome-internal-resistance-chain"],
        "scenario-demo-engagement": ["demo-attention-engagement-chain", "bid-evaluation-advantage-chain"],
        "scenario-cross-sell": ["expand-product-line-chain"],
        "scenario-internal-priority": ["prioritize-internal-project-chain", "re-activate-silent-deal-chain"],
    }
    for sc_id, rids in scenario_to_reasoning.items():
        for rid in rids:
            add_relation("scenario_addressed_by", sc_id, rid, f"{sc_id}可由{rid}解决")

    # 校验关系唯一性（简单按 id；部分旧关系可能缺失 id，跳过）
    existing_relation_ids = {r["id"] for r in data["relations"] if "id" in r}
    for r in new_relations:
        if r["id"] in existing_relation_ids:
            raise ValueError(f"Duplicate relation id: {r['id']}")
        existing_relation_ids.add(r["id"])

    data["relations"].extend(new_relations)

    # ───────────────────────── 8. 保存 ─────────────────────────
    save_json(data)

    # 统计
    print("\n新增实体统计：")
    print(f"  ReasoningChain: {len(new_reasoning_chains)}")
    print(f"  Tactic: {len(new_tactics)}")
    print(f"  Script: {len(new_scripts)}")
    print(f"  Scenario: {len(new_scenarios)}")
    print(f"  Relation: {len(new_relations)}")
    print("\n更新后数据基线：")
    for key in ["principles", "concepts", "terms", "scenarios", "cases", "experiments", "persons", "reasoning_chains", "tactics", "action_steps", "scripts", "relations"]:
        print(f"  {key}: {len(data[key])}")


if __name__ == "__main__":
    main()
