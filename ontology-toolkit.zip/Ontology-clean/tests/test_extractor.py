"""测试实体/关系抽取"""

import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.document.extractor import extract_objects, extract_relations

SAMPLE_MD = """江西中科九峰智慧医疗科技有限公司

九峰医疗成立于2015年5月，专注于基层医疗，以DR医学影像数据为基础，利用人工智能技术全流程赋能基层医疗机构。

主要产品：
1. 肺结核X射线影像辅助评估软件 — 国内第一张肺部X线影像人工智能三类证
2. 5G+AI基层呼吸系统传染病监测预警系统
3. 常见肺部疾病医学影像AI筛查系统

公司拥有ISO13485国际标准体系认证、ISO27001信息安全管理体系认证以及公安部三级等保测评。

服务覆盖全国上千家乡镇医疗卫生机构，业务次数近400万次。
"""


@pytest.mark.asyncio
async def test_extract_objects():
    """测试实体抽取"""
    objects = await extract_objects(SAMPLE_MD)

    assert isinstance(objects, list)
    assert len(objects) > 0

    # 应至少包含公司实体
    names = [o["name"] for o in objects]
    assert any("九峰" in n for n in names)

    # 每个实体应有 type 和 name
    for obj in objects:
        assert "type" in obj
        assert "name" in obj


@pytest.mark.asyncio
async def test_extract_relations():
    """测试关系抽取"""
    objects = await extract_objects(SAMPLE_MD)
    assert len(objects) > 0

    relations = await extract_relations(SAMPLE_MD, objects)

    assert isinstance(relations, list)
    if len(relations) > 0:
        for rel in relations:
            assert "source" in rel
            assert "target" in rel
            assert "type" in rel


@pytest.mark.asyncio
async def test_extract_relations_empty_objects():
    """空实体列表应返回空关系"""
    relations = await extract_relations(SAMPLE_MD, [])
    assert relations == []
