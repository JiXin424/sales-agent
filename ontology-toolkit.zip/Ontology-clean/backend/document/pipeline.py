"""文档处理流水线：解析 → 抽取 → 存储"""

import logging
import re
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from backend.document.parser import parse_document
from backend.document.extractor import extract_objects, extract_relations
from backend.ontology.crud import (
    ensure_default_types,
    create_object,
    create_link,
    create_document,
)

logger = logging.getLogger(__name__)


def extract_version_date(filename: str) -> datetime | None:
    """从文件名中提取版本日期，格式如 _20250520_ 或 _2025-05-20_"""
    # 匹配 _YYYYMMDD 或 _YYYY-MM-DD
    match = re.search(r'[_\-](\d{4})[\-]?(\d{2})[\-]?(\d{2})[_\-v]', filename)
    if match:
        try:
            return datetime(
                int(match.group(1)), int(match.group(2)), int(match.group(3)),
                tzinfo=timezone.utc,
            )
        except ValueError:
            pass
    return None


async def process_document(file_path: str, session: AsyncSession) -> dict:
    """完整流水线：解析文档 → 抽取实体/关系 → 存储到数据库"""
    import os

    # 1. 解析文档
    logger.info(f"解析文档: {file_path}")
    md_content = await parse_document(file_path)
    filename = os.path.basename(file_path)
    file_type = os.path.splitext(file_path)[1].lstrip(".")
    version_date = extract_version_date(filename)

    # 2. 创建文档记录
    doc = await create_document(session, filename, file_type, md_content, version_date=version_date)

    # 3. 确保默认类型存在
    await ensure_default_types(session)

    # 4. 抽取实体
    logger.info(f"抽取实体: {filename}")
    objects_data = await extract_objects(md_content)

    # 5. 存储实体
    created_objects = []
    for obj_data in objects_data:
        obj = await create_object(
            session,
            type_name=obj_data.get("type", "Company"),
            name=obj_data.get("name", ""),
            properties=obj_data.get("properties", {}),
            source_document_id=doc.id,
            version_date=version_date,
        )
        created_objects.append(obj)

    # 5.5 为实体生成向量embedding（直接调用阿里云API，避免模块导入缓存问题）
    try:
        from backend.llm import embed as _embed_raw
        embed_batch_data = []
        for obj in created_objects:
            embed_text = obj.name
            if obj.properties:
                props_str = " ".join(f"{k}:{v}" for k, v in obj.properties.items() if v)
                embed_text = f"{obj.name} {props_str}"
            embed_batch_data.append((obj.id, embed_text))

        # 每批最多10个（阿里云限制）
        for i in range(0, len(embed_batch_data), 10):
            batch = embed_batch_data[i:i + 10]
            texts = [t for _, t in batch]
            try:
                vectors = await _embed_raw(texts)
                for j, (obj_id, _) in enumerate(batch):
                    if j < len(vectors):
                        from sqlalchemy import text as sqlt
                        vector_str = str(vectors[j])
                        await session.execute(
                            sqlt("UPDATE objects SET embedding = :vec WHERE id = :id"),
                            {"vec": vector_str, "id": obj_id},
                        )
                await session.flush()
            except Exception as e:
                logger.warning(f"Embedding batch 失败 (ids={[bid for bid, _ in batch]}): {e}")
    except Exception as e:
        logger.warning(f"Embedding 模块导入失败: {e}")

    # 6. 抽取关系
    logger.info(f"抽取关系: {filename}")
    relations_data = await extract_relations(md_content, objects_data)

    # 7. 存储关系
    created_links = []
    for rel_data in relations_data:
        link = await create_link(
            session,
            source_name=rel_data.get("source", ""),
            target_name=rel_data.get("target", ""),
            type_name=rel_data.get("type", ""),
        )
        if link:
            created_links.append(link)

    # 收集结果（用原始数据避免 lazy load）
    objects_summary = [
        {"type": o.get("type", "?"), "name": o.get("name", "?")}
        for o in objects_data
    ]

    await session.commit()

    return {
        "document_id": doc.id,
        "filename": filename,
        "objects_count": len(created_objects),
        "links_count": len(created_links),
        "objects": objects_summary,
    }
