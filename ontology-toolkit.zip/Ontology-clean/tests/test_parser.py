"""测试 AFC2md 文档解析"""

import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.document.parser import parse_document, get_supported_extensions

TEST_DIR = "/Users/fred/Documents/cc_Projects/Taishan/一期库/九峰/raw/九峰_公司产品"


@pytest.mark.asyncio
async def test_supported_extensions():
    """验证支持的文件格式"""
    exts = get_supported_extensions()
    assert ".docx" in exts
    assert ".pdf" in exts
    assert ".xlsx" in exts
    assert ".png" in exts


@pytest.mark.asyncio
async def test_parse_docx():
    """测试 DOCX 文件解析"""
    file_path = os.path.join(TEST_DIR, "九峰_公司介绍_20250520_v1_方铭.docx")
    if not os.path.exists(file_path):
        pytest.skip("测试文件不存在")

    md = await parse_document(file_path)

    assert md is not None
    assert len(md) > 100
    assert "九峰" in md


@pytest.mark.asyncio
async def test_parse_unsupported():
    """测试不支持的格式应抛异常"""
    with pytest.raises(ValueError, match="不支持的文件格式"):
        await parse_document("/tmp/test.xyz")


@pytest.mark.asyncio
async def test_parse_nonexistent():
    """测试不存在的文件应抛异常"""
    with pytest.raises(FileNotFoundError):
        await parse_document("/tmp/nonexistent_abc123.docx")
