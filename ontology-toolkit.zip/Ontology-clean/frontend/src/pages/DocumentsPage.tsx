import { useState, useEffect } from 'react';
import { Table, Button, Upload, message, Card, Tag, Space } from 'antd';
import { UploadOutlined, DeleteOutlined, FileOutlined } from '@ant-design/icons';
import type { UploadProps } from 'antd';
import { listDocuments, uploadDocument, deleteDocument } from '../services/api';

interface Doc {
  id: number;
  filename: string;
  file_type: string;
  status: string;
  created_at: string;
}

export default function DocumentsPage() {
  const [docs, setDocs] = useState<Doc[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  const fetchDocs = async () => {
    setLoading(true);
    try {
      const res = await listDocuments();
      setDocs(res.data || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocs();
  }, []);

  const handleDelete = async (id: number) => {
    try {
      await deleteDocument(id);
      message.success('文档已删除');
      fetchDocs();
    } catch {
      message.error('删除失败');
    }
  };

  const uploadProps: UploadProps = {
    name: 'file',
    multiple: true,
    showUploadList: false,
    customRequest: async ({ file, onSuccess, onError }) => {
      setUploading(true);
      try {
        await uploadDocument(file as File);
        message.success(`${(file as File).name} 上传成功`);
        fetchDocs();
        onSuccess?.(null);
      } catch {
        onError?.(new Error('Upload failed'));
        message.error('上传失败');
      } finally {
        setUploading(false);
      }
    },
  };

  const statusColor = (status: string) => {
    switch (status) {
      case 'completed':
      case 'processed':
        return 'green';
      case 'pending':
      case 'processing':
        return 'blue';
      case 'failed':
        return 'red';
      default:
        return 'default';
    }
  };

  const columns = [
    {
      title: '文件名',
      dataIndex: 'filename',
      key: 'filename',
      render: (name: string) => (
        <span>
          <FileOutlined style={{ marginRight: 8 }} />
          {name}
        </span>
      ),
    },
    {
      title: '类型',
      dataIndex: 'file_type',
      key: 'file_type',
      width: 120,
      render: (t: string) => <Tag>{t}</Tag>,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 120,
      render: (s: string) => <Tag color={statusColor(s)}>{s}</Tag>,
    },
    {
      title: '创建时间',
      dataIndex: 'created_at',
      key: 'created_at',
      width: 180,
      render: (d: string) => (d ? new Date(d).toLocaleString() : '-'),
    },
    {
      title: '操作',
      key: 'action',
      width: 80,
      render: (_: unknown, record: Doc) => (
        <Button
          danger
          size="small"
          icon={<DeleteOutlined />}
          onClick={() => handleDelete(record.id)}
        />
      ),
    },
  ];

  return (
    <div>
      <h2 style={{ color: '#e6edf3', marginBottom: 24 }}>文档管理</h2>

      <Upload.Dragger {...uploadProps} style={{ marginBottom: 24 }}>
        <p className="ant-upload-drag-icon">
          <UploadOutlined style={{ fontSize: 32, color: '#58a6ff' }} />
        </p>
        <p style={{ color: '#e6edf3' }}>点击或拖拽文件上传</p>
        <p style={{ color: '#8b949e', fontSize: 12 }}>支持 PDF、DOCX、TXT 等格式</p>
      </Upload.Dragger>

      {uploading && (
        <Card size="small" style={{ marginBottom: 16, textAlign: 'center', color: '#8b949e' }}>
          正在上传并处理...
        </Card>
      )}

      <Space direction="vertical" style={{ width: '100%' }}>
        <Table
          columns={columns}
          dataSource={docs}
          rowKey="id"
          loading={loading}
          pagination={{ pageSize: 10 }}
          size="middle"
        />
      </Space>
    </div>
  );
}
