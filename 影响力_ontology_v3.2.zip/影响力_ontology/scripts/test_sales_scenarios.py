#!/usr/bin/env python3
"""将 10 个销售教练场景的 30 个问题在《影响力》本体系统上测试并生成报告。"""

import json
import os
import re
from collections import Counter
from pathlib import Path

# 导入运行时系统
import sys

runtime_dir = Path(__file__).resolve().parent.parent / "ontology_runtime"
sys.path.insert(0, str(runtime_dir))

from influence_ontology_runtime import load
from influence_ontology_runtime.models import (
    Case,
    Concept,
    Principle,
    ReasoningChain,
    Script,
    Tactic,
)

# 关键词到影响力原则的启发式映射
PRINCIPLE_KEYWORDS = {
    "reciprocity-principle": ["互惠", "礼物", "给予", "免费", "人情", "回报", "恩惠", "先给", "小恩小惠", "样品"],
    "commitment-and-consistency-principle": ["承诺", "一致", "公开", "书面", "言行一致", "保持一致", "承诺一致", "写下来"],
    "consistency-principle": ["一致", "承诺", "公开", "言行"],
    "social-identity-principle": ["社会认同", "从众", "他人", "大家都", "别人", "同行", "案例", "社会证明"],
    "liking-principle": ["喜好", "相似", "赞美", "合作", "关系", "喜欢", "朋友", "共同"],
    "authority-principle": ["权威", "专家", "认证", "头衔", "医生", "教授", "数据", "证明", "专业"],
    "scarcity-principle": ["稀缺", "限时", "限量", "最后", "机会", "紧迫", " deadline", "仅剩", " deadline"],
    "principle-contrast": ["对比", "锚定", "比较", "相对", "先高后低"],
    "principle-price-quality": ["价格", "贵", "便宜", "价值", "质量", "一分钱一分货"],
}


def parse_scenarios(path: Path) -> list[dict]:
    """解析 scenarios_10_sales_coaching.md，返回场景和问题列表。"""
    text = path.read_text(encoding="utf-8")
    scenarios = []
    current = None

    for line in text.split("\n"):
        m = re.match(r"^## 场景 (\d+)：(.+)$", line.strip())
        if m:
            if current:
                scenarios.append(current)
            current = {
                "id": int(m.group(1)),
                "title": m.group(2),
                "background": "",
                "questions": [],
            }
            continue
        if current is None:
            continue
        qm = re.match(r"^(\d+)\.\s*(.+)$", line.strip())
        if qm:
            current["questions"].append(qm.group(2))
        elif line.strip().startswith("**背景**："):
            current["background"] = line.strip().replace("**背景**：", "")

    if current:
        scenarios.append(current)
    return scenarios


def detect_principles(question: str) -> list[str]:
    """根据关键词检测问题可能涉及的原则。"""
    matched = []
    q = question.lower()
    for pid, kws in PRINCIPLE_KEYWORDS.items():
        for kw in kws:
            if kw in q:
                matched.append(pid)
                break
    return matched


# 销售场景关键词词典（用于更精准地搜索本体）
SALES_KEYWORDS = [
    # 场景1
    "信任", "戒备", "初次拜访", "第一次见面", "敞开心扉", "下一次沟通",
    # 场景2
    "价格", "贵", "便宜", "折扣", "报价", "锚定", "比价", "价值",
    # 场景3
    "异议", "拒绝", "不需要", "没时间", "考虑一下", "说服", "唤起兴趣",
    # 场景4
    "决策者", "关键人", "优先级", "反对", "内部", "向上影响",
    # 场景5
    "拖延", "紧迫感", "激活", "签约", "考虑", "不回消息",
    # 场景6
    "演示", "注意力", "试用", "POC", "社会认同", "价值呈现",
    # 场景7
    "竞品", "供应商", "差异化", "招标", "比价", "incumbent",
    # 场景8
    "老客户", "增购", "扩展", "离职", "新采购", "关系",
    # 场景9
    "解约", "挽回", "投诉", "流失", "低价", "修复信任",
    # 场景10
    "售前", "高管", "资源", "优先级", "内部协调", "老板",
]


# 停用词
STOPWORDS = set(
    "的 了 在 是 我 有 和 就 不 人 都 一 一个 上 也 很 到 说 要 去 你 会 着 没有 看 好 自己 这 那 什么 为什么 如何 怎么 怎样 吗 呢 吧 啊 一下 让 把 被 为 而 及 与 或 但 如果 因为 所以 虽然 然而 因此 但是 并且 以及 可以 应该 需要 能够 可能 应该 将 能 会 要 做 看 让 给 对 向 从 到 于 关于 对于 为 给 跟 同 比 与 和 或 而 而且 或者 但是 然而 因此 于是 然后 接着 最后 首先 其次 再次 第一 第二 第三 第 个 种 些 位 件 次 回 张 条 根 块 片 只 支 台 部 家 间 处 份 项 套 群 帮 伙 批".split()
)


def extract_keywords(question: str) -> list[str]:
    """从问题中提取候选关键词（优先销售关键词词典，再补 2-4 字短语）。"""
    q = re.sub(r"[，。？！；：\"\"''（）、\.\?\!\;\:\(\)]", " ", question)

    # 1. 优先命中销售关键词词典（按长度降序，避免短词先匹配）
    matched = []
    for kw in sorted(SALES_KEYWORDS, key=len, reverse=True):
        if kw in question and kw not in matched:
            matched.append(kw)

    # 2. 补充 2-4 字短语
    extra = []
    for length in range(4, 1, -1):
        for i in range(len(q) - length + 1):
            token = q[i : i + length].strip()
            if " " in token or len(token) != length:
                continue
            if token in STOPWORDS:
                continue
            if token not in matched and token not in extra:
                extra.append(token)

    return matched + extra[:20]


def evaluate_question(store, question: str) -> dict:
    """评估单个问题在本体系统中的查询效果。"""
    # 1. 检测涉及原则
    principle_ids = detect_principles(question)
    principle_hits = [store.get_by_id(pid) for pid in principle_ids if store.get_by_id(pid)]

    # 2. 原则相关实体
    principle_related = []
    for pid in principle_ids:
        principle_related.extend(store._principle_index.get(pid, []))

    # 3. 关键词搜索
    keywords = extract_keywords(question)
    keyword_results: dict[str, Any] = {}
    for kw in keywords:
        for r in store.search(kw):
            keyword_results[r.id] = r

    # 4. 合并搜索结果：原则相关实体 + 关键词搜索结果
    all_results = {r.id: r for r in principle_related}
    all_results.update(keyword_results)

    # 移除原则自身（如果搜索结果中有）
    all_results = {k: v for k, v in all_results.items() if k not in principle_ids}

    search_results = list(all_results.values())

    # 5. 按类型统计
    type_counts = Counter(type(r).__name__ for r in search_results)

    # 6. 获取前 5 个最相关结果
    top_results = []
    for r in search_results[:5]:
        name = getattr(r, "name", r.id) or r.id
        top_results.append({
            "id": r.id,
            "type": type(r).__name__,
            "name": name,
        })

    # 7. 简单帮助度评分
    score = 0
    score += min(len(search_results), 5) * 1.5  # 搜索结果数量
    score += len(principle_hits) * 4            # 命中原则
    score += min(len(principle_related), 5)     # 原则相关实体
    if any(isinstance(r, Tactic) for r in search_results[:15]):
        score += 2
    if any(isinstance(r, Script) for r in search_results[:15]):
        score += 2
    if any(isinstance(r, Case) for r in search_results[:15]):
        score += 2
    if any(isinstance(r, ReasoningChain) for r in search_results[:15]):
        score += 1

    return {
        "question": question,
        "principle_ids": principle_ids,
        "principle_names": [p.name for p in principle_hits],
        "search_count": len(search_results),
        "type_counts": dict(type_counts),
        "top_results": top_results,
        "principle_related_count": len(principle_related),
        "keywords": keywords[:10],
        "score": round(score, 1),
        "help_level": _help_level(score),
    }


def _help_level(score: float) -> str:
    if score >= 16:
        return "高"
    if score >= 9:
        return "中"
    if score >= 4:
        return "低"
    return "微弱"


def main():
    base_dir = Path(__file__).resolve().parent.parent
    scenarios_path = base_dir / "scenarios_10_sales_coaching.md"
    json_path = base_dir / "influence_ontology.json"

    scenarios = parse_scenarios(scenarios_path)
    store = load(json_path)

    report = {
        "metadata": {
            "total_scenarios": len(scenarios),
            "total_questions": sum(len(s["questions"]) for s in scenarios),
            "ontology_stats": store.stats(),
        },
        "scenarios": [],
    }

    all_scores = []
    all_help_levels = Counter()

    for s in scenarios:
        scenario_report = {
            "id": s["id"],
            "title": s["title"],
            "background": s["background"],
            "questions": [],
        }
        for q in s["questions"]:
            result = evaluate_question(store, q)
            scenario_report["questions"].append(result)
            all_scores.append(result["score"])
            all_help_levels[result["help_level"]] += 1
        report["scenarios"].append(scenario_report)

    report["summary"] = {
        "average_score": round(sum(all_scores) / len(all_scores), 2) if all_scores else 0,
        "max_score": max(all_scores) if all_scores else 0,
        "min_score": min(all_scores) if all_scores else 0,
        "help_level_distribution": dict(all_help_levels),
    }

    # 保存 JSON
    output_json = base_dir / "scenario_test_report.json"
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"Saved JSON report: {output_json}")

    # 保存 Markdown 报告
    output_md = base_dir / "scenario_test_report.md"
    with open(output_md, "w", encoding="utf-8") as f:
        f.write(_render_markdown(report))
    print(f"Saved Markdown report: {output_md}")

    print(f"\nSummary: avg_score={report['summary']['average_score']}, "
          f"help_levels={dict(all_help_levels)}")


def _render_markdown(report: dict) -> str:
    lines = ["# 《影响力》本体系统对销售教练场景的帮助度测试报告", ""]

    # 概述
    lines.append("## 一、测试概述")
    lines.append("")
    lines.append(f"- **测试场景数**：{report['metadata']['total_scenarios']}")
    lines.append(f"- **测试问题数**：{report['metadata']['total_questions']}")
    lines.append(f"- **平均帮助度得分**：{report['summary']['average_score']}")
    lines.append(f"- **得分区间**：{report['summary']['min_score']} - {report['summary']['max_score']}")
    lines.append("")
    lines.append("### 帮助度分布")
    lines.append("")
    for level, count in report['summary']['help_level_distribution'].items():
        lines.append(f"- {level}：{count} 个问题")
    lines.append("")

    # 本体统计
    lines.append("## 二、本体数据基线")
    lines.append("")
    for k, v in report['metadata']['ontology_stats'].items():
        lines.append(f"- {k}：{v}")
    lines.append("")

    # 每个场景
    lines.append("## 三、逐场景测试结果")
    lines.append("")
    for s in report["scenarios"]:
        lines.append(f"### 场景 {s['id']}：{s['title']}")
        if s["background"]:
            lines.append(f"**背景**：{s['background']}")
        lines.append("")
        for idx, q in enumerate(s["questions"], 1):
            lines.append(f"#### 问题 {idx}：{q['question']}")
            lines.append(f"- **判断涉及原则**：{', '.join(q['principle_names']) if q['principle_names'] else '无明确匹配'}")
            lines.append(f"- **提取关键词**：{', '.join(q['keywords'])}")
            lines.append(f"- **全文搜索命中数**：{q['search_count']}")
            lines.append(f"- **涉及实体类型**：{q['type_counts']}")
            lines.append(f"- **原则相关实体数**：{q['principle_related_count']}")
            lines.append(f"- **帮助度得分**：{q['score']}（{q['help_level']}）")
            if q["top_results"]:
                lines.append("- **Top 5 相关实体**：")
                for r in q["top_results"]:
                    lines.append(f"  - `{r['id']}` ({r['type']})：{r['name']}")
            lines.append("")

    # 结论
    lines.append("## 四、总体结论与建议")
    lines.append("")
    lines.append("1. **高帮助度问题**：通常包含明确的影响力原则关键词（如互惠、稀缺、权威），或能直接对应到书中的案例/策略。")
    lines.append("2. **中帮助度问题**：搜索能返回相关实体，但需要销售教练进一步解读和映射到具体场景。")
    lines.append("3. **低帮助度问题**：多为内部协调、组织政治等《影响力》一书未直接覆盖的主题，系统提供的直接帮助有限。")
    lines.append("4. **改进建议**：")
    lines.append("   - 补充销售场景专属的 `Scenario` 和 `Button` 实体，把影响力原则与销售流程步骤绑定。")
    lines.append('   - 增加"问题 → 原则 → 策略 → 话术"的推理链，降低销售教练的解读成本。')
    lines.append("   - 对低分问题引入外部销售方法论（如 SPIN、MEDDIC、Challenger Sale）作为补充。")
    lines.append("")

    return "\n".join(lines)


if __name__ == "__main__":
    main()
