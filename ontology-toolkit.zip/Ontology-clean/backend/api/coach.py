"""教练 API — 拜访准备/异议处理/竞品对比"""

import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from backend.db import async_session
from backend.reasoning.intent import classify_intent
from backend.coach.prep import generate_prep_plan
from backend.coach.objection import handle_objection
from backend.coach.comparison import generate_comparison
from backend.coach.review import analyze_visit

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/coach", tags=["coach"])


class CoachRequest(BaseModel):
    question: str


class ReviewRequest(BaseModel):
    visit_notes: str


async def get_session():
    async with async_session() as session:
        yield session


@router.post("/prep")
async def prep(request: CoachRequest, session: AsyncSession = Depends(get_session)):
    """拜访准备"""
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="问题不能为空")
    result = await generate_prep_plan(request.question, session)
    return result


@router.post("/objection")
async def objection(request: CoachRequest, session: AsyncSession = Depends(get_session)):
    """异议处理"""
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="问题不能为空")
    result = await handle_objection(request.question, session)
    return result


@router.post("/comparison")
async def comparison(request: CoachRequest, session: AsyncSession = Depends(get_session)):
    """竞品对比"""
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="问题不能为空")
    result = await generate_comparison(request.question, session)
    return result


@router.post("/review")
async def review(request: ReviewRequest, session: AsyncSession = Depends(get_session)):
    """访后复盘"""
    if not request.visit_notes.strip():
        raise HTTPException(status_code=400, detail="拜访记录不能为空")
    result = await analyze_visit(request.visit_notes, session)
    return result
