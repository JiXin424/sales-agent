"""反馈 API — 用户评价与统计"""

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from backend.db import async_session
from backend.ontology.models import Feedback

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/feedback", tags=["feedback"])


# ── Pydantic schemas ──────────────────────────────────────────


class FeedbackCreate(BaseModel):
    question: str
    answer: str | None = None
    intent: str | None = None
    rating: int = Field(ge=1, le=5, description="评分 1-5")
    comment: str | None = None
    entities: list[str] | None = None


class FeedbackOut(BaseModel):
    id: int
    question: str
    answer: str | None
    intent: str | None
    rating: int
    comment: str | None
    entities: list[str]
    created_at: datetime | None

    class Config:
        from_attributes = True


class FeedbackStats(BaseModel):
    total_count: int
    average_rating: float | None
    rating_distribution: dict[str, int]  # {"1": count, "2": count, ...}
    recent_low_rated: list[FeedbackOut]


# ── Dependency ────────────────────────────────────────────────


async def get_session():
    async with async_session() as session:
        yield session


# ── Endpoints ─────────────────────────────────────────────────


@router.post("/", response_model=FeedbackOut)
async def create_feedback(
    body: FeedbackCreate, session: AsyncSession = Depends(get_session)
):
    """提交反馈"""
    fb = Feedback(
        question=body.question,
        answer=body.answer,
        intent=body.intent,
        rating=body.rating,
        comment=body.comment,
        entities=body.entities or [],
    )
    session.add(fb)
    await session.commit()
    await session.refresh(fb)
    logger.info(f"收到反馈: rating={fb.rating}, question={fb.question[:30]}")
    return fb


@router.get("/stats", response_model=FeedbackStats)
async def feedback_stats(session: AsyncSession = Depends(get_session)):
    """反馈统计：总数、平均分、分布、近期低分"""
    # 总数 + 平均分
    agg = await session.execute(
        select(
            func.count(Feedback.id).label("total"),
            func.avg(Feedback.rating).label("avg_rating"),
        )
    )
    row = agg.one()
    total_count = row.total
    average_rating = round(row.avg_rating, 2) if row.avg_rating else None

    # 各评分分布
    dist = await session.execute(
        select(Feedback.rating, func.count(Feedback.id).label("cnt"))
        .group_by(Feedback.rating)
        .order_by(Feedback.rating)
    )
    rating_distribution = {str(r): 0 for r in range(1, 6)}
    for rating, cnt in dist.all():
        rating_distribution[str(rating)] = cnt

    # 近期低分（rating <= 2，最近 20 条）
    low_q = (
        select(Feedback)
        .where(Feedback.rating <= 2)
        .order_by(desc(Feedback.created_at))
        .limit(20)
    )
    low_result = (await session.execute(low_q)).scalars().all()
    recent_low_rated = [
        FeedbackOut(
            id=fb.id,
            question=fb.question,
            answer=fb.answer,
            intent=fb.intent,
            rating=fb.rating,
            comment=fb.comment,
            entities=fb.entities or [],
            created_at=fb.created_at,
        )
        for fb in low_result
    ]

    return FeedbackStats(
        total_count=total_count,
        average_rating=average_rating,
        rating_distribution=rating_distribution,
        recent_low_rated=recent_low_rated,
    )
