import { useState, useEffect, useRef, useCallback } from 'react';
import { Input, Tag, Spin, Empty, Modal, Button, Space } from 'antd';
import { SearchOutlined, ZoomInOutlined, ZoomOutOutlined, FullscreenOutlined } from '@ant-design/icons';
import { Graph } from '@antv/g6';
import { getGraph } from '../services/api';
import type { GraphData, IEvent } from '@antv/g6';

interface GraphNode {
  id: number;
  data: { name: string; type?: string; properties?: Record<string, string> };
}

interface GraphEdge {
  source: number;
  target: number;
  data: { type?: string };
}

interface ApiGraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

interface SelectedNode {
  label: string;
  type?: string;
  properties?: Record<string, string>;
}

const TYPE_COLORS: Record<string, string> = {
  Company: '#58a6ff',
  Product: '#3fb950',
  Competitor: '#f85149',
  CustomerSegment: '#f778ba',
  Partner: '#e3b341',
  Feature: '#79c0ff',
  Spec: '#7ee787',
  Equipment: '#a5d6ff',
  Pricing: '#d29922',
  Certification: '#d2a8ff',
  Award: '#56d364',
  Scenario: '#ffa657',
  Solution: '#db61a2',
  Disease: '#ff7b72',
  Industry: '#8957e5',
  Objection: '#f85149',
  SalesScript: '#56d364',
  Case: '#a5d6ff',
  Advantage: '#d2a8ff',
  Policy: '#58a6ff',
  Contact: '#e3b341',
  Institution: '#8957e5',
};

const getTypeColor = (type?: string) => TYPE_COLORS[type || ''] || '#30363d';

export default function GraphPage() {
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [selected, setSelected] = useState<SelectedNode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const graphRef = useRef<Graph | null>(null);
  const rawDataRef = useRef<ApiGraphData>({ nodes: [], edges: [] });

  const buildGraph = useCallback((data: ApiGraphData, searchTerm: string) => {
    if (!containerRef.current) return;
    if (graphRef.current) {
      graphRef.current.destroy();
      graphRef.current = null;
    }

    const term = searchTerm.toLowerCase();
    const filteredNodes = term
      ? data.nodes.filter((n) =>
          n.data.name.toLowerCase().includes(term) ||
          (n.data.type && n.data.type.toLowerCase().includes(term))
        )
      : data.nodes;

    const nodeIds = new Set(filteredNodes.map((n) => String(n.id)));
    const filteredEdges = data.edges.filter(
      (e) => nodeIds.has(String(e.source)) && nodeIds.has(String(e.target))
    );

    const nodes = filteredNodes.map((n) => ({
      id: String(n.id),
      data: { name: n.data.name, type: n.data.type || 'Unknown', properties: n.data.properties },
      style: { fill: getTypeColor(n.data.type), stroke: getTypeColor(n.data.type) },
    }));

    const edges = filteredEdges.map((e, i) => ({
      id: `e-${i}`,
      source: String(e.source),
      target: String(e.target),
      data: { type: e.data.type },
    }));

    const graph = new Graph({
      container: containerRef.current,
      autoFit: 'view',
      data: { nodes, edges } as GraphData,
      layout: { type: 'd3-force' },
      node: {
        style: {
          size: 26,
          labelText: (d: Record<string, unknown>) => (d.data as { name?: string })?.name || '',
          labelFontSize: 10,
          labelFill: '#e6edf3',
          labelPlacement: 'bottom',
          fill: (d: Record<string, unknown>) => getTypeColor((d.data as { type?: string })?.type),
          stroke: (d: Record<string, unknown>) => getTypeColor((d.data as { type?: string })?.type),
          strokeOpacity: 0.3,
          lineWidth: 3,
        },
      },
      edge: {
        style: {
          endArrow: true,
          stroke: '#484f58',
          labelText: (d: Record<string, unknown>) => (d.data as { type?: string })?.type || '',
          labelFontSize: 9,
          labelFill: '#8b949e',
        },
      },
      behaviors: ['drag-canvas', 'zoom-canvas', 'drag-element', 'click-select'],
    });

    graph.on('node:click', (evt: IEvent) => {
      const e = evt as unknown as { target: { id: () => string }; targetType: string };
      if (e.targetType !== 'node') return;
      const id = e.target.id();
      const node = data.nodes.find((n) => String(n.id) === id);
      if (node) {
        setSelected({
          label: node.data.name,
          type: node.data.type,
          properties: node.data.properties,
        });
      }
    });

    graph.render();
    graphRef.current = graph;
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await getGraph();
        rawDataRef.current = res.data || { nodes: [], edges: [] };
        buildGraph(rawDataRef.current, filter);
      } catch {
        // graph data unavailable
      } finally {
        setLoading(false);
      }
    })();
    return () => {
      if (graphRef.current) {
        graphRef.current.destroy();
        graphRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!loading && rawDataRef.current.nodes.length > 0) {
      buildGraph(rawDataRef.current, filter);
    }
  }, [filter, loading, buildGraph]);

  const handleZoomIn = () => graphRef.current?.zoomBy(1.2);
  const handleZoomOut = () => graphRef.current?.zoomBy(0.8);
  const handleFit = () => graphRef.current?.fitView();

  if (loading) {
    return <Spin size="large" style={{ display: 'block', margin: '100px auto' }} />;
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2 style={{ color: '#e6edf3', margin: 0 }}>知识图谱</h2>
        <Space>
          <Input
            prefix={<SearchOutlined />}
            placeholder="搜索实体..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            style={{ width: 240 }}
            allowClear
          />
          <Button icon={<ZoomInOutlined />} onClick={handleZoomIn} />
          <Button icon={<ZoomOutOutlined />} onClick={handleZoomOut} />
          <Button icon={<FullscreenOutlined />} onClick={handleFit} />
        </Space>
      </div>

      {rawDataRef.current.nodes.length === 0 ? (
        <Empty description="暂无图谱数据" />
      ) : (
        <div ref={containerRef} style={{ width: '100%', height: 'calc(100vh - 160px)', background: '#0d1117', borderRadius: 8 }} />
      )}

      <Modal
        title={selected?.label}
        open={!!selected}
        onCancel={() => setSelected(null)}
        footer={null}
        styles={{ body: { background: '#161b22', color: '#e6edf3' } }}
      >
        {selected && (
          <div>
            {selected.type && (
              <p>
                <strong>类型：</strong>{' '}
                <Tag color={getTypeColor(selected.type)}>{selected.type}</Tag>
              </p>
            )}
            {selected.properties && Object.keys(selected.properties).length > 0 && (
              <div>
                <strong>属性：</strong>
                <pre style={{ background: '#0d1117', padding: 12, borderRadius: 6, overflow: 'auto', color: '#e6edf3' }}>
                  {JSON.stringify(selected.properties, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
