"""实体/关系抽取 — DeepSeek V4 Pro"""

import asyncio
import json
import logging

from openai import AsyncOpenAI

from backend.config import DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL, DEEPSEEK_MODEL_PRO
from backend.knowledge.context import load_context_text

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_DELAY = 5

CONTEXT_BLOCK = """
## 背景知识（已有实体和关系的概览）
以下是知识库中已存在的实体和关系，帮助你理解上下文、消歧和准确分类：

{context}

请参考以上背景知识来理解和分类当前文档中的实体。如果文档中提到与背景知识相同的实体，请使用完全一致的名称。
"""

EXTRACT_OBJECTS_PROMPT = """你是一个销售知识本体抽取专家。从以下文档中抽取所有销售相关的实体。

请按以下 JSON 格式输出：

{{
  "objects": [
    {{"type": "实体类型", "name": "实体名称", "properties": {{"key": "value"}}}}
  ]
}}

实体类型说明（22种）：
- Company: 公司/组织
- Product: 产品/服务
- Competitor: 竞争对手公司
- CustomerSegment: 客户群体
- Partner: 代理商/渠道/合作伙伴
- Feature: 产品功能/特性
- Spec: 技术规格参数
- Equipment: 硬件设备/器械
- Pricing: 价格/报价信息
- Certification: 资质认证
- Award: 奖项/荣誉
- Scenario: 应用场景
- Solution: 解决方案
- Disease: 疾病/病种
- Industry: 行业分类
- Objection: 客户异议
- SalesScript: 推荐应对话术/销售技巧
- Case: 成功案例
- Advantage: 竞争优势/独特价值
- Policy: 政策/法规/红头文件
- Contact: 联系人/决策者
- Institution: 机构/组织

区分规则：
- 竞品文档中的公司 → Competitor
- 硬件设备 → Equipment（非 Product）
- 政策法规 → Policy（非 Scenario）
- 独特价值 → Advantage（非 Feature）
- 目标疾病 → Disease（非 Scenario）
- 奖项荣誉 → Award（非 Certification）

Properties 抽取要求（关键！必须抽取具体数据）：
- Company: 成立时间、注册资本、英文名、核心定位
- Product: 注册证编号、类别（几类）、型号
- Spec: 标准化 key — sensitivity（敏感度）、specificity（特异性）、accuracy（准确度）、processing_time（处理时间）、throughput（日处理量）
- Pricing: price（价格）、price_range（价格区间）、unit（单位）
- Certification: 注册证编号、类别
- Award: time（获奖时间）、achievement（成绩）
- Case: coverage（覆盖范围）、people_count（筛查人数）、time（时间）、result（结果数据）
- Advantage: description（具体描述）、ratio（如效益比）
- Policy: 文号、发布机构、time（发布日期）、key_points（关键条款摘要）
- Objection: description（异议详情）
- SalesScript: script（话术原文）
- Contact: 职位、background（背景）
- Scenario: description（场景描述）

示例：
{{"type": "Spec", "name": "敏感度94.2%", "properties": {{"sensitivity": "94.2%", "metric": "肺结核检出敏感度"}}}}
{{"type": "Case", "name": "南昌航空大学新生筛查", "properties": {{"people_count": "4830人", "time": "2019年", "result": "AI检出XX例，复核确认XX例"}}}}
{{"type": "Advantage", "name": "投资回报比1:94", "properties": {{"ratio": "1:94", "description": "每投入1元结核病防治，可节省94元治疗费用"}}}}
{{"type": "Policy", "name": "99元基本公卫补贴", "properties": {{"文号": "国卫基层发〔2025〕XX号", "发布机构": "国家卫健委", "key_points": "人均基本公共卫生服务经费补助标准提高至99元，含老年人体检"}}}}

只抽取文档中明确提到的信息。每个实体必须有 type、name，properties 尽可能丰富。
{context_section}
文档内容：
---
{content}
---

请输出 JSON："""

EXTRACT_RELATIONS_PROMPT = """你是一个销售知识本体抽取专家。基于以下文档和已抽取的实体，抽取实体之间的关系。

已知实体：
{objects_json}

请按以下 JSON 格式输出：

{{
  "relations": [
    {{"source": "源实体名", "target": "目标实体名", "type": "关系类型"}}
  ]
}}

关系类型说明（22种）：
- produces: 公司生产产品（九峰→肺结核AI评估软件）
- competes_with: 竞争关系（九峰→智影）
- targets: 面向客户/场景（产品→基层医院）
- includes: 包含特性（产品→AI辅助诊断）
- priced_at: 定价（产品→40-60万）
- certified_for: 获得认证（产品→监管机构A三类证）
- solves: 解决场景（产品→高校筛查）
- has_spec: 技术规格（产品→敏感度94.2%）
- detects: 检测疾病（产品→肺结核）
- component_of: 硬件组件（DR探测器→智能工作站）
- part_of: 属于方案（产品→移动体检车方案）
- demonstrated_in: 案例体现（AI辅助→南昌航空大学案例）
- uses: 案例使用（南昌案例→体检车）
- triggers: 触发异议（场景→客户异议）
- handled_by: 话术处理（异议→应对话术）
- supported_by: 证据支撑优势（三类证→合规优势）
- mandates: 政策驱动场景（99元文件→老年人体检场景）
- belongs_to: 属于行业/上级（产品→医疗影像AI）
- contact_at: 联系人位置（检验科主任→基层医院）
- distributes: 代理分销（省级代理→九峰产品）
- awarded_to: 奖项授予（斯坦福冠军→九峰医疗）
- cooperates_with: 合作关系（九峰→中科院）

只抽取文档中明确提到的关系。
{context_section}
文档内容：
---
{content}
---

请输出 JSON："""


def _get_context_section() -> str:
    """加载背景知识并格式化为 prompt 片段"""
    context = load_context_text()
    if not context:
        return ""
    return CONTEXT_BLOCK.format(context=context[:6000])


def _get_client() -> AsyncOpenAI:
    return AsyncOpenAI(api_key=DEEPSEEK_API_KEY, base_url=DEEPSEEK_BASE_URL)


async def _call_with_retry(client, **kwargs) -> str:
    """带重试的 LLM 调用"""
    for attempt in range(MAX_RETRIES):
        try:
            resp = await client.chat.completions.create(**kwargs)
            content = resp.choices[0].message.content
            if content:
                return content
            logger.warning(f"LLM 返回空 content (attempt {attempt+1})")
        except Exception as e:
            logger.warning(f"LLM 调用失败 (attempt {attempt+1}): {e}")
        if attempt < MAX_RETRIES - 1:
            await asyncio.sleep(RETRY_DELAY * (attempt + 1))
    raise RuntimeError(f"LLM 调用失败，已重试 {MAX_RETRIES} 次")


def _repair_json(text: str) -> str:
    """尝试修复截断的 JSON：找到最后一个完整的 } 或 ] 并闭合"""
    import re
    # 去掉尾部不完整内容
    text = text.strip()
    # 尝试找到最后一个完整的数组/对象结尾
    for pattern in [r'\}\s*\]$', r'\}\s*$', r'"\s*\]$', r'"\s*$']:
        m = list(re.finditer(pattern, text))
        if m:
            last_match = m[-1]
            truncated = text[:last_match.end()]
            # 统计未闭合的括号
            open_brackets = truncated.count('[') - truncated.count(']')
            open_braces = truncated.count('{') - truncated.count('}')
            truncated += ']' * max(0, open_brackets)
            truncated += '}' * max(0, open_braces)
            return truncated
    return text


def _safe_parse_json(text: str) -> dict:
    """安全解析 JSON，解析失败时尝试修复"""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    try:
        repaired = _repair_json(text)
        return json.loads(repaired)
    except json.JSONDecodeError:
        pass
    # 最后尝试提取 JSON 块
    import re
    m = re.search(r'\{[\s\S]*\}', text)
    if m:
        try:
            repaired = _repair_json(m.group())
            return json.loads(repaired)
        except json.JSONDecodeError:
            pass
    return {}


async def extract_objects(md_content: str) -> list[dict]:
    """从 Markdown 抽取实体（自动注入背景知识）"""
    client = _get_client()
    content = md_content[:4000]
    context_section = _get_context_section()

    prompt = EXTRACT_OBJECTS_PROMPT.format(content=content, context_section=context_section)

    result_text = await _call_with_retry(
        client,
        model=DEEPSEEK_MODEL_PRO,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=12000,
        response_format={"type": "json_object"},
    )

    result = _safe_parse_json(result_text)
    return result.get("objects", [])


async def extract_relations(md_content: str, objects: list[dict]) -> list[dict]:
    """从 Markdown + 已知实体抽取关系（自动注入背景知识）"""
    if not objects:
        return []

    client = _get_client()
    content = md_content[:4000]
    objects_json = json.dumps(objects, ensure_ascii=False, indent=2)
    context_section = _get_context_section()

    prompt = EXTRACT_RELATIONS_PROMPT.format(
        content=content, objects_json=objects_json, context_section=context_section
    )

    result_text = await _call_with_retry(
        client,
        model=DEEPSEEK_MODEL_PRO,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=12000,
        response_format={"type": "json_object"},
    )

    result = _safe_parse_json(result_text)
    return result.get("relations", [])
