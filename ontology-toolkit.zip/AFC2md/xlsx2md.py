#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OpenClaw Header
# 'HTTP-Referer': 'https://openclaw.ai'
# 'X-0penRouter-Title': 'OpenClaw'
# 'X-0penRouter-Categories': 'cli-agent'
"""
XLSX 智能转 Markdown 工具

将 XLSX Excel 文件智能转换为 Markdown 格式：
- 分析每个工作表的数据结构
- 将表格数据转换为文字描述或数字列表
- 输出不含表格和制表符的纯 Markdown 文档

用法:
    python xlsx2md.py <xlsx_file>

示例:
    python xlsx2md.py "data.xlsx"
    python xlsx2md.py "数据表.xlsx" --output "output.md"
"""

import sys
import os
import subprocess
from datetime import datetime
from typing import List, Dict, Any, Optional

# 尝试导入 openpyxl
try:
    import openpyxl
    from openpyxl import load_workbook
except ImportError:
    print("错误：未安装 openpyxl 库")
    print("请运行：pip install openpyxl")
    sys.exit(1)

# 尝试导入 openai
try:
    from openai import OpenAI
except ImportError:
    print("警告：未安装 openai 库，AI 功能将不可用")
    print("请运行：pip install openai")

# 默认 API 配置
DEFAULT_API_KEY = "DASHSCOPE_API_KEY_PLACEHOLDER"
DEFAULT_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
DEFAULT_MODEL = "qwen3.6-plus"


def find_file(file_path: str, search_base: str = None) -> str:
    """
    查找文件的真实路径（处理 iCloud 幽灵文件和中文路径）

    Args:
        file_path: 文件路径
        search_base: 搜索基础目录

    Returns:
        str: 真实文件路径
    """
    # 先尝试原始路径
    if os.path.exists(file_path):
        try:
            size = os.path.getsize(file_path)
            if size >= 1024:
                return file_path
        except OSError:
            pass

    # 移除路径中的空格后重试
    file_path_nospace = file_path.replace(' ', '')
    if file_path_nospace != file_path and os.path.exists(file_path_nospace):
        try:
            size = os.path.getsize(file_path_nospace)
            if size >= 1024:
                return file_path_nospace
        except OSError:
            pass

    file_name = os.path.basename(file_path)
    if search_base is None:
        search_base = "/Users/fred/Documents/cc_Projects/Taishan"

    # 提取关键字
    keyword = file_name.replace('.xlsx', '').replace('.xls', '')

    result = subprocess.run(
        ['bash', '-c', f'find "{search_base}" -name "*{keyword}*" -type f 2>/dev/null | head -5'],
        capture_output=True,
        text=True
    )

    if result.stdout.strip():
        files = result.stdout.strip().split('\n')
        for f in files:
            if keyword in f.replace(' ', ''):
                return f

    return None


def verify_file_access(file_path: str) -> tuple:
    """
    验证文件是否可访问且不是 iCloud 占位符

    Returns:
        tuple: (是否有效，文件大小)
    """
    try:
        size = os.path.getsize(file_path)
        if size < 1024:
            print(f"警告：文件小于 1KB ({size} bytes)，可能是 iCloud 占位符")
            return False, size
        return True, size
    except OSError:
        return False, 0


def load_excel_data(xlsx_path: str) -> Dict[str, List[List[Any]]]:
    """
    加载 Excel 文件数据

    Args:
        xlsx_path: XLSX 文件路径

    Returns:
        Dict: 工作表名 -> 二维数据列表
    """
    try:
        # 使用 subprocess 复制文件到临时位置（处理中文路径）
        import tempfile
        temp_fd, temp_xlsx = tempfile.mkstemp(suffix='.xlsx')
        os.close(temp_fd)

        subprocess.run(
            ['bash', '-c', f'cat "{xlsx_path}" > "{temp_xlsx}"'],
            capture_output=True
        )

        # 加载工作簿
        wb = load_workbook(filename=temp_xlsx, data_only=True)

        data = {}
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            sheet_data = []

            for row in ws.iter_rows(values_only=True):
                # 过滤空行
                if any(cell is not None for cell in row):
                    sheet_data.append(list(row))

            data[sheet_name] = sheet_data
            print(f"  工作表：{sheet_name} ({len(sheet_data)} 行)")

        # 清理临时文件
        os.remove(temp_xlsx)

        return data

    except Exception as e:
        print(f"加载 Excel 失败：{e}")
        return {}


def analyze_sheet_structure(sheet_name: str, data: List[List[Any]]) -> Dict[str, Any]:
    """
    分析工作表的数据结构

    Args:
        sheet_name: 工作表名称
        data: 二维数据列表

    Returns:
        Dict: 分析结果
    """
    if not data:
        return {
            'sheet_name': sheet_name,
            'row_count': 0,
            'col_count': 0,
            'headers': [],
            'data_types': [],
            'is_table': False,
            'summary': '空工作表'
        }

    row_count = len(data)
    col_count = max(len(row) for row in data) if data else 0

    # 检测表头（第一行）
    headers = data[0] if data else []

    # 分析每列的数据类型
    data_types = []
    for col_idx in range(col_count):
        col_values = [row[col_idx] if col_idx < len(row) else None
                      for row in data[1:] if row[col_idx] is not None]

        if not col_values:
            data_types.append('empty')
        elif all(isinstance(v, (int, float)) for v in col_values):
            data_types.append('numeric')
        elif all(isinstance(v, datetime) for v in col_values):
            data_types.append('datetime')
        else:
            data_types.append('text')

    # 判断是否为结构化表格
    is_table = len(headers) > 0 and all(h is not None and str(h).strip() for h in headers)

    # 生成摘要
    summary_parts = []
    summary_parts.append(f"共 {row_count} 行")
    summary_parts.append(f"共 {col_count} 列")
    if is_table:
        summary_parts.append(f"包含表头：{', '.join(str(h) for h in headers[:5])}")
        if len(headers) > 5:
            summary_parts.append(f"等{len(headers)}个字段")

    return {
        'sheet_name': sheet_name,
        'row_count': row_count,
        'col_count': col_count,
        'headers': headers,
        'data_types': data_types,
        'is_table': is_table,
        'summary': '，'.join(summary_parts)
    }


def convert_sheet_to_text(sheet_name: str, data: List[List[Any]],
                          structure: Dict[str, Any]) -> str:
    """
    将工作表数据转换为文字描述（不使用表格格式）

    Args:
        sheet_name: 工作表名称
        data: 二维数据列表
        structure: 结构分析结果

    Returns:
        str: 转换后的文字描述
    """
    if not data:
        return f"## {sheet_name}\n\n空工作表\n"

    lines = []
    lines.append(f"## {sheet_name}")
    lines.append("")
    lines.append(f"数据概览：{structure['summary']}")
    lines.append("")

    headers = structure['headers']
    is_table = structure['is_table']

    if data:
        # 保留 Markdown 表格格式
        md_table = []
        if is_table and len(headers) > 0:
            # 有表头：标准 Markdown 表格
            md_table.append('| ' + ' | '.join(str(h) if h is not None else '' for h in headers) + ' |')
            md_table.append('|' + '|'.join(['---'] * len(headers)) + '|')
            for row in data[1:]:
                if not any(cell is not None for cell in row):
                    continue
                row_strs = []
                for cell in row:
                    if cell is None:
                        row_strs.append('')
                    elif isinstance(cell, datetime):
                        row_strs.append(cell.strftime('%Y-%m-%d %H:%M:%S'))
                    else:
                        row_strs.append(str(cell))
                md_table.append('| ' + ' | '.join(row_strs) + ' |')
        else:
            # 无表头：直接用数据生成表格
            max_cols = max(len(row) for row in data)
            for row in data:
                if not any(cell is not None for cell in row):
                    continue
                row_strs = []
                for cell in row:
                    if cell is None:
                        row_strs.append('')
                    elif isinstance(cell, datetime):
                        row_strs.append(cell.strftime('%Y-%m-%d %H:%M:%S'))
                    else:
                        row_strs.append(str(cell))
                # 补齐列数
                while len(row_strs) < max_cols:
                    row_strs.append('')
                md_table.append('| ' + ' | '.join(row_strs) + ' |')

        lines.append("数据详情：")
        lines.append("")
        lines.extend(md_table)
        lines.append("")
    else:
        lines.append("空工作表")
        lines.append("")

    return '\n'.join(lines)


def analyze_and_organize_sheets(all_sheets_text: str, api_key: str, model: str) -> str:
    """
    AI 分析并整理所有工作表内容

    Args:
        all_sheets_text: 所有工作表的文字描述
        api_key: API Key
        model: 模型名称

    Returns:
        str: 整理后的 Markdown
    """
    ORGANIZE_PROMPT = """你是一个 Excel 文档整理助手。以下是从 XLSX 文件提取的内容。

**任务：只做三件事，不要重新组织内容**
1. 去除明显的重复内容
2. 按原工作表顺序拼接内容
3. 修正明显的错字，但**严禁改写原文意思**

**严禁做的事情：**
- 不要调整工作表顺序
- 不要合并数据行或改变数据结构
- 不要把数据归类汇总
- 不要"优化"表述
- **保留 Markdown 表格格式，不要改成文字描述**

请直接输出整理后的完整 Markdown 内容，不要加任何说明文字。
"""

    try:
        client = OpenAI(api_key=api_key, base_url=DEFAULT_BASE_URL)

        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "你是专业的 Excel 数据分析专家。"},
                {"role": "user", "content": f"{ORGANIZE_PROMPT}\n\n{all_sheets_text}"},
            ],
        )

        return completion.choices[0].message.content

    except Exception as e:
        print(f"AI 整理失败：{e}")
        # 回退到直接输出
        return all_sheets_text


def xlsx_to_md(xlsx_path: str, output_path: str = None,
               api_key: str = None, model: str = None,
               use_ai: bool = True) -> bool:
    """
    主流程：将 XLSX 转换为 Markdown

    Args:
        xlsx_path: XLSX 文件路径
        output_path: 输出文件路径（可选）
        api_key: API Key
        model: 模型名称
        use_ai: 是否使用 AI 整理

    Returns:
        bool: 是否成功
    """
    print("=" * 60)
    print("XLSX 智能转 Markdown 工具")
    print("=" * 60)

    # 配置
    api_key = api_key or os.getenv("DASHSCOPE_API_KEY") or DEFAULT_API_KEY
    model = model or DEFAULT_MODEL

    print(f"\n使用模型：{model}")
    print(f"API 地址：{DEFAULT_BASE_URL}")

    # 查找文件
    print("\n[1/4] 查找文件...")
    real_path = find_file(xlsx_path)
    if not real_path:
        print(f"错误：找不到文件：{xlsx_path}")
        return False

    xlsx_path = real_path
    print(f"  找到：{os.path.basename(xlsx_path)}")

    # 验证文件
    print("\n[2/4] 验证文件...")
    is_valid, file_size = verify_file_access(xlsx_path)
    if not is_valid:
        print("错误：无法访问文件或文件太小")
        return False
    print(f"  文件大小：{file_size / 1024:.1f} KB")

    # 确定输出路径
    file_name = os.path.splitext(os.path.basename(xlsx_path))[0]
    if output_path is None:
        output_dir = os.path.dirname(xlsx_path)
        output_path = os.path.join(output_dir, f"{file_name}.md")

    print(f"\n[3/4] 输出配置:")
    print(f"  输出文件：{output_path}")

    # 加载数据
    print(f"\n[4/4] 开始转换...")
    print("-" * 60)

    print("\n加载 Excel 数据...")
    data = load_excel_data(xlsx_path)

    if not data:
        print("错误：未能加载任何数据")
        return False

    print(f"\n共加载 {len(data)} 个工作表")

    # 分析并转换每个工作表
    print("\n分析并转换每个工作表...")
    all_sheets_text = []

    for sheet_name, sheet_data in data.items():
        print(f"\n  处理：{sheet_name}")

        # 分析结构
        structure = analyze_sheet_structure(sheet_name, sheet_data)
        print(f"    {structure['summary']}")

        # 转换为文字
        sheet_text = convert_sheet_to_text(sheet_name, sheet_data, structure)
        all_sheets_text.append(sheet_text)

    # 合并所有内容
    combined_text = "\n\n---\n\n".join(all_sheets_text)

    # AI 整理（可选）
    if use_ai:
        print("\nAI 整理文档...")
        print("-" * 60)
        final_md = analyze_and_organize_sheets(combined_text, api_key, model)
    else:
        print("\n跳过 AI 整理")
        final_md = combined_text

    # 添加文件头
    header = f"# {file_name}\n\n> 数据来源：{os.path.basename(xlsx_path)}\n> 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n> 共 {len(data)} 个工作表\n\n---\n\n"
    final_md = header + final_md

    # 保存文件
    print(f"\n保存 Markdown 文件...")
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(final_md)
        print(f"  已保存：{output_path}")
    except Exception as e:
        print(f"  保存失败：{e}")
        return False

    print("\n" + "=" * 60)
    print("转换完成！")
    print(f"  输出文件：{output_path}")
    print(f"  工作表数：{len(data)}")
    print("=" * 60)

    return True


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("\n用法:")
        print("  python xlsx2md.py <xlsx_file> [output_file]")
        print("\n示例:")
        print('  python xlsx2md.py "data.xlsx"')
        print('  python xlsx2md.py "数据表.xlsx" "output.md"')
        print("\n可选参数:")
        print("  --no-ai    跳过 AI 整理")
        print("  --api-key  指定 API Key")
        print("  --model    指定模型名称")
        sys.exit(1)

    args = sys.argv[1:]

    # 解析参数
    xlsx_path = None
    output_path = None
    api_key = None
    model = None
    use_ai = True

    i = 0
    while i < len(args):
        if args[i] == '--no-ai':
            use_ai = False
            i += 1
        elif args[i] == '--api-key':
            if i + 1 < len(args):
                api_key = args[i + 1]
                i += 2
            else:
                print("错误：--api-key 需要指定值")
                sys.exit(1)
        elif args[i] == '--model':
            if i + 1 < len(args):
                model = args[i + 1]
                i += 2
            else:
                print("错误：--model 需要指定模型名称")
                sys.exit(1)
        elif args[i].startswith('-'):
            print(f"未知参数：{args[i]}")
            sys.exit(1)
        else:
            if xlsx_path is None:
                xlsx_path = args[i]
            elif output_path is None:
                output_path = args[i]
            i += 1

    if not xlsx_path:
        print("错误：请指定 XLSX 文件路径")
        sys.exit(1)

    try:
        success = xlsx_to_md(xlsx_path, output_path, api_key, model, use_ai)
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n处理失败：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
