# 《影响力》Ontology 导入准备包

> 本目录包含将《影响力》抽取结果接入下一版 Ontology-Taishan 所需的知识 markdown 和导入脚本模板。

---

## 目录结构

```
for-import/
├── README.md                          # 本文件
├── knowledge/                         # Ontology-Taishan 风格的知识 markdown
│   ├── 00-影响力本体定义.md
│   ├── 02-影响力案例人物实验库.md
│   ├── 04-影响力方法论框架库.md
│   └── 06-影响力销售实战场景库.md
└── scripts/                           # 待完成的导入脚本
    └── import_to_ontology_taishan.py  # 导入脚本模板
```

---

## 使用方式

1. 将 `knowledge/` 下的文件复制到新版本 Ontology-Taishan 的 `knowledge/` 目录。
2. 根据新版本类型定义，调整字段映射。
3. 实现并运行 `scripts/import_to_ontology_taishan.py`。
4. 人工抽检导入结果。
5. 在 `db_operate/` 留下变更 SQL。

---

## 数据映射速查

| 影响力类型 | 目标 Ontology-Taishan 类型 | 目标文件 |
|-----------|--------------------------|---------|
| Principle | Methodology / SalesPrinciple | knowledge/04-影响力方法论框架库.md |
| ReasoningChain | Methodology.argument / ReasoningChain | knowledge/04-影响力方法论框架库.md |
| Concept | Concept / SalesConcept | （待补充） |
| Term | Term / Glossary | （待补充） |
| Case | Case / SalesCase | knowledge/02-影响力案例人物实验库.md |
| Experiment | Experiment / ResearchStudy | knowledge/02-影响力案例人物实验库.md |
| Person | Person / Expert | knowledge/02-影响力案例人物实验库.md |
| Tactic | Button / ScenarioButton | knowledge/06-影响力销售实战场景库.md |
| ActionStep | ButtonStep / ActionStep | knowledge/06-影响力销售实战场景库.md |
| Script | Script / SalesScript | knowledge/06-影响力销售实战场景库.md |
| Scenario | SalesScenario / Scenario | knowledge/06-影响力销售实战场景库.md |

---

*生成时间：2026-06-24*
