"""V2: 验证阿里云 Embedding + Vision API 连通性"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openai import AsyncOpenAI
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))


async def main():
    api_key = os.getenv("DASHSCOPE_API_KEY")
    base_url = os.getenv("DASHSCOPE_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")

    if not api_key:
        print("❌ DASHSCOPE_API_KEY 未配置")
        return

    client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    # 测试 Embedding
    print("测试阿里云 text-embedding-v4...")
    try:
        resp = await client.embeddings.create(
            model="text-embedding-v4",
            input=["九峰医疗肺结核AI筛查产品介绍"],
            dimensions=1024,
        )
        dim = len(resp.data[0].embedding)
        print(f"  ✅ Embedding 维度: {dim}")
        print(f"  Usage: {resp.usage.total_tokens} tokens")
    except Exception as e:
        print(f"  ❌ Embedding 失败: {e}")

    # 测试 Vision
    print("\n测试阿里云 qwen3-vl-plus...")
    try:
        resp = await client.chat.completions.create(
            model="qwen3-vl-plus",
            messages=[{"role": "user", "content": "你好，请确认你能正常工作"}],
            max_tokens=50,
        )
        print(f"  ✅ Vision: {resp.choices[0].message.content}")
    except Exception as e:
        print(f"  ❌ Vision 失败: {e}")

    print("\n✅ 阿里云 DashScope API 连通性验证完成")


if __name__ == "__main__":
    asyncio.run(main())
