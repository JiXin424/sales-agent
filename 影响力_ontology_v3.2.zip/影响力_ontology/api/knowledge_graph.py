#!/usr/bin/env python3
"""影响力知识图谱引擎

三层检索 + 1 跳扩展：
- Layer 1：实体 name 精确命中（权重 1000）
- Layer 2：synonyms.json 同义词命中（权重 500）
- Layer 3：多词命中（保留旧逻辑，权重 1×N，作为补充）
- Hop：用本体内置 281 条 relations 做核心实体 1 跳扩展，按类型分组
"""

import json
import re
from pathlib import Path
from collections import defaultdict

BASE_DIR = Path(__file__).resolve().parent.parent
ONTOLOGY_PATH = BASE_DIR / "influence_ontology_cleaned.json"
SYNONYMS_PATH = BASE_DIR / "synonyms.json"

ENTITY_TYPES = ['principles', 'concepts', 'terms', 'scenarios', 'cases',
                'experiments', 'reasoning_chains', 'tactics', 'action_steps',
                'scripts', 'persons']

HOP_TYPE_ORDER = ['principles', 'reasoning_chains', 'concepts', 'terms', 'tactics',
                  'scripts', 'scenarios', 'cases', 'experiments', 'action_steps']

HOP_TYPE_LABELS = {
    'principles': '相关原则',
    'reasoning_chains': '相关推理链',
    'concepts': '相关概念',
    'terms': '相关术语',
    'tactics': '相关策略',
    'scripts': '相关话术',
    'scenarios': '相关场景',
    'cases': '相关案例',
    'experiments': '相关实验',
    'action_steps': '相关行动步骤',
}

PUNCT_RE = re.compile(r'[，。？！；：""''（）、.\?\!\;\:\(\)]')


class KnowledgeGraph:
    def __init__(self):
        self.loaded = False
        self.entities_by_id = {}
        self.name_to_entity = {}
        self.synonym_to_standard = {}
        self.standard_to_entities = defaultdict(list)
        self.relations_from = defaultdict(list)
        self.relations_to = defaultdict(list)

    def load(self):
        if self.loaded:
            return
        with open(ONTOLOGY_PATH, 'r', encoding='utf-8') as f:
            ontology = json.load(f)

        for type_plural in ENTITY_TYPES:
            for entity in ontology.get(type_plural, []):
                e = dict(entity)
                e['type'] = type_plural.rstrip('s')
                eid = e.get('id') or e.get('name')
                if not eid:
                    continue
                e['id'] = eid
                self.entities_by_id[eid] = e
                name = e.get('name')
                if name:
                    self.name_to_entity[name] = e

        for r in ontology.get('relations', []):
            f_id = r.get('from_id')
            t_id = r.get('to_id')
            if f_id:
                self.relations_from[f_id].append(r)
            if t_id:
                self.relations_to[t_id].append(r)

        with open(SYNONYMS_PATH, 'r', encoding='utf-8') as f:
            syn_data = json.load(f)

        for category, term_dict in syn_data.items():
            for standard, syn_list in term_dict.items():
                self.synonym_to_standard[standard] = standard
                for syn in syn_list:
                    if syn and syn not in self.synonym_to_standard:
                        self.synonym_to_standard[syn] = standard
                for e in self.entities_by_id.values():
                    if e.get('name') == standard:
                        self.standard_to_entities[standard].append(e)

        self.loaded = True

    def search(self, query, history=None, top_k_layer3=8, hop_depth=1, max_per_hop_type=3):
        self.load()

        from keyword_extractor import extract as llm_extract
        llm_keywords, kw_source = llm_extract(query, history=history)

        layer1 = self._layer1_direct(query)

        matched_standards = self._match_synonyms(query)
        base_keywords = self._extract_keywords(query)
        standard_tokens = self._split_standard_tokens(matched_standards)
        keywords = list(set(base_keywords + list(matched_standards) + standard_tokens + llm_keywords))

        layer3_raw = self._layer3_multiword(query, keywords,
                                             exclude_ids={e['id'] for e in layer1},
                                             top_k=top_k_layer3 + 5)

        layer2, layer3 = [], []
        standards_lower = {s.lower() for s in matched_standards}
        for e, score, matched in layer3_raw:
            triggered_by_syn = any(kw.lower() in standards_lower for kw in matched)
            if triggered_by_syn and len(layer2) < 5:
                layer2.append(e)
            else:
                layer3.append((e, score, matched))
        layer3 = layer3[:top_k_layer3]

        # 兜底：当 L1+L2 都空（synonym standard 在本体里没有对应实体时的常见情况），
        # 把 L3 top-3 提升为 core，让 hop 扩展至少能跑起来
        promoted_from_l3 = []
        if not layer1 and not layer2 and layer3:
            for e, score, matched in layer3[:3]:
                promoted_from_l3.append(e)
            layer3 = layer3[3:]

        core_entities = layer1 + layer2 + promoted_from_l3
        core_ids = {e['id'] for e in core_entities}
        hop_groups = self._hop_expand([e['id'] for e in core_entities],
                                       depth=hop_depth,
                                       max_per_type=max_per_hop_type,
                                       exclude_ids=core_ids)

        return {
            'query': query,
            'keywords': keywords,
            'llm_keywords': llm_keywords,
            'keyword_source': kw_source,
            'matched_synonym_standards': sorted(matched_standards),
            'layer1_direct': [self._brief(e, source='name') for e in layer1],
            'layer2_synonym': [self._brief(e, source='synonym') for e in layer2],
            'layer3_multiword': [{'score': s, 'matched_keywords': m,
                                   'entity': self._brief(e, source='multiword')}
                                  for e, s, m in layer3],
            'core_entities': [self._brief(e, source='core' if e not in promoted_from_l3 else 'l3_promoted') for e in core_entities],
            'hop_groups': hop_groups,
        }

    def _layer1_direct(self, query):
        hits = []
        seen = set()
        for name, entity in self.name_to_entity.items():
            if name and name in query:
                if entity['id'] not in seen:
                    hits.append(entity)
                    seen.add(entity['id'])
        priority = {'principle': 0, 'scenario': 1, 'concept': 2, 'term': 3,
                    'tactic': 4, 'reasoning_chain': 5, 'script': 6,
                    'case': 7, 'experiment': 8, 'action_step': 9, 'person': 10}
        hits.sort(key=lambda e: priority.get(e.get('type'), 99))
        return hits

    def _layer2_synonym(self, query, exclude):
        exclude_ids = {e['id'] for e in exclude}
        matched_standards = set()
        for syn, standard in self.synonym_to_standard.items():
            if syn and syn in query:
                matched_standards.add(standard)
        hits = []
        seen = set()
        for standard in matched_standards:
            for e in self.standard_to_entities.get(standard, []):
                if e['id'] in exclude_ids or e['id'] in seen:
                    continue
                hits.append(e)
                seen.add(e['id'])
        return hits

    def _match_synonyms(self, query):
        matched = set()
        for syn, standard in self.synonym_to_standard.items():
            if syn and syn in query:
                matched.add(standard)
        return matched

    def _split_standard_tokens(self, standards):
        tokens = set()
        for s in standards:
            if not s or len(s) < 2:
                continue
            if len(s) >= 3:
                tokens.add(s)
            for i in range(len(s) - 1):
                tok = s[i:i + 2]
                if len(tok) == 2:
                    tokens.add(tok)
        return list(tokens)

    def _extract_keywords(self, query):
        clean = PUNCT_RE.sub('', query)
        result = set()
        for name in self.name_to_entity.keys():
            if name and len(name) >= 2 and name in clean:
                result.add(name)
        for syn in self.synonym_to_standard.keys():
            if syn and len(syn) >= 2 and syn in clean:
                result.add(syn)
        stop = {'的', '了', '是', '我', '有', '和', '就', '不', '人', '都',
                '一', '个', '在', '你', '会', '着', '吗', '呢', '吧', '啊',
                '这', '那', '什么', '怎么', '如何', '怎样', '客户', '问题'}
        if len(result) < 3:
            for length in range(4, 1, -1):
                for i in range(len(clean) - length + 1):
                    w = clean[i:i + length]
                    if w not in stop and w not in result:
                        result.add(w)
                        if len(result) >= 5:
                            break
                if len(result) >= 5:
                    break
        return list(result)

    def _layer3_multiword(self, query, keywords, exclude_ids, top_k):
        clean = PUNCT_RE.sub('', query).lower()
        results = []
        for e in self.entities_by_id.values():
            if e['id'] in exclude_ids:
                continue
            text = json.dumps(e, ensure_ascii=False).lower()
            matched = [kw for kw in keywords if kw.lower() in text]
            if matched:
                results.append((e, len(matched), matched))
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]

    def _hop_expand(self, entity_ids, depth=1, max_per_type=3, exclude_ids=None):
        exclude_ids = set(exclude_ids or [])
        neighbor_ids = set()
        for eid in entity_ids:
            for r in self.relations_from.get(eid, []):
                t = r.get('to_id')
                if t and t not in exclude_ids:
                    neighbor_ids.add(t)
            for r in self.relations_to.get(eid, []):
                f = r.get('from_id')
                if f and f not in exclude_ids:
                    neighbor_ids.add(f)
        groups = defaultdict(list)
        for nid in neighbor_ids:
            e = self.entities_by_id.get(nid)
            if not e:
                continue
            groups[e.get('type', '') + 's'].append(e)
        limited = {}
        for type_plural in HOP_TYPE_ORDER:
            lst = groups.get(type_plural, [])
            if lst:
                limited[type_plural] = [self._brief(e, source='hop') for e in lst[:max_per_type]]
        return limited

    def _brief(self, entity, source=''):
        """提取实体的展示信息，按类型保留关键字段"""
        etype = entity.get('type', '')
        base = {
            'id': entity.get('id'),
            'type': etype,
            'name': entity.get('name', entity.get('id')),
            'source': source,
        }
        # 按类型保留有价值的字段
        type_fields = {
            'principle': ['description', 'core_mechanism', 'social_function', 'keywords', 'chapter'],
            'concept': ['definition', 'summary', 'description', 'related_principles', 'source'],
            'term': ['definition', 'summary', 'description'],
            'reasoning_chain': ['premises', 'trigger', 'behavior', 'consequence',
                                'evidence', 'confidence', 'principle_id', 'reasoning'],
            'tactic': ['summary', 'description', 'steps', 'principle_id'],
            'script': ['context', 'text', 'description', 'principle_id', 'source_case'],
            'case': ['summary', 'description', 'characters', 'principle', 'source_text'],
            'experiment': ['hypothesis', 'method', 'result', 'conclusion',
                           'principle', 'researcher', 'description'],
            'scenario': ['description', 'trigger', 'behavior', 'outcome'],
            'action_step': ['description', 'step', 'principle_id'],
            'person': ['description', 'role', 'contribution'],
        }
        for field in type_fields.get(etype, ['description']):
            if field in entity and entity[field]:
                base[field] = entity[field]
        return base


_kg = None


def get_knowledge_graph():
    global _kg
    if _kg is None:
        _kg = KnowledgeGraph()
        _kg.load()
    return _kg


if __name__ == '__main__':
    kg = get_knowledge_graph()
    for q in ['什么是互惠原理', '客户嫌贵怎么办', '如何用稀缺原理制造紧迫感']:
        print('=' * 60)
        print(f'Query: {q}')
        r = kg.search(q)
        print(f"keywords: {r['keywords']}")
        print(f"L1 direct: {[e['name'] for e in r['layer1_direct']]}")
        print(f"L2 synonym: {[e['name'] for e in r['layer2_synonym']]}")
        print(f"L3 multiword: {[(e['entity']['name'], e['score']) for e in r['layer3_multiword'][:5]]}")
        print(f"Hop groups:")
        for t, lst in r['hop_groups'].items():
            print(f"  {t}: {[e['name'] for e in lst]}")
