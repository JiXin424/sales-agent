"""测试配置 — 共享 fixtures"""

import asyncio
import os
import sys

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.ontology.models import Base

TEST_DB_URL = "postgresql+asyncpg://ontology:ontology_dev_2026@localhost:5432/ontology"


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def db_session():
    """每个测试用独立的数据库 session，测试后回滚"""
    engine = create_async_engine(TEST_DB_URL, echo=False)

    session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with session_factory() as session:
        yield session
        await session.rollback()

    await engine.dispose()
