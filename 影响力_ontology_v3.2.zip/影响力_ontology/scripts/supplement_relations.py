#!/usr/bin/env python3
"""影响力本体 - 关系自动补充工具

功能：
1. 基于文本相似度自动发现实体间关系
2. 支持多种关系类型补充
3. 提供人工审核接口
4. 批量生成关系JSON
"""

import json
from pathlib import Path
from typing import List, Dict, Tuple
from collections import defaultdict
import re

# 配置
ONTOLOGY_PATH = Path(__file__).parent.parent / "influence_ontology_enriched.json"
OUTPUT_PATH = Path(__file__).parent.parent / "relations_supplemented.json"
THRESHOLD = 0.25  # 相似度阈值（较低以增加召回）

class RelationDiscoverer:
    """关系发现器"""

    def __init__(self, ontology_path: Path):
        self.ontology_path = ontology_path
        self.ontology = None
        self.entity_index = {}  # ID → entity
        self.entities_by_type = defaultdict(list)  # type → [entities]

    def load_ontology(self):
        """加载本体数据"""
        print(f"📖 加载本体: {self.ontology_path}")
        with open(self.ontology_path, 'r', encoding='utf-8') as f:
            self.ontology = json.load(f)

        # 构建索引
        all_types = ['principles', 'concepts', 'terms', 'cases', 'experiments', 'persons',
                    'reasoning_chains', 'tactics', 'action_steps', 'scripts', 'scenarios']

        for type_plural in all_types:
            type_name = type_plural.rstrip('s')
            if type_plural not in self.ontology:
                continue

            for entity in self.ontology[type_plural]:
                entity_id = entity.get('id', entity.get('name', ''))
                self.entity_index[entity_id] = entity
                entity['type'] = type_name
                self.entities_by_type[type_name].append(entity)

        print(f"✅ 加载完成: {len(self.entity_index)} 个实体")

    def get_text_similarity(self, text1: str, text2: str) -> float:
        """计算文本相似度（基于关键词重叠）"""
        if not text1 or not text2:
            return 0.0

        # 简单的关键词重叠算法
        words1 = set(text1)
        words2 = set(text2)

        if not words1 or not words2:
            return 0.0

        intersection = len(words1 & words2)
        union = len(words1 | words2)

        return intersection / union if union > 0 else 0.0

    def get_entity_text(self, entity: Dict) -> str:
        """获取实体的完整文本（用于相似度计算）"""
        text_parts = []

        # 优先级字段
        priority_fields = ['name', 'summary', 'description', 'outcome',
                          'core_mechanism', 'social_function', 'text']

        for field in priority_fields:
            value = entity.get(field, '')
            if value:
                # 分词（简单的按字符分割）
                words = re.findall(r'[一-龥]+', value)
                text_parts.extend(words)

        # 去重并返回
        return ' '.join(set(text_parts))

    def discover_case_to_tactic(self, threshold: float = THRESHOLD) -> List[Dict]:
        """发现 case → tactic 关系 (case_demonstrates)"""
        print("\n🔍 发现 case → tactic 关系...")

        candidates = []
        cases = self.entities_by_type['case']
        tactics = self.entities_by_type['tactic']

        for case in cases:
            case_text = self.get_entity_text(case)

            for tactic in tactics:
                tactic_text = self.get_entity_text(tactic)

                # 计算相似度
                similarity = self.get_text_similarity(case_text, tactic_text)

                if similarity >= threshold:
                    candidates.append({
                        'from_id': case['id'],
                        'to_id': tactic['id'],
                        'relation_type': 'case_demonstrates',
                        'confidence': similarity,
                        'reason': f'案例"{case.get("name", "")}"与策略"{tactic.get("name", "")}"相似度={similarity:.2f}'
                    })

        print(f"   发现 {len(candidates)} 个候选关系")
        return candidates

    def discover_case_to_script(self, threshold: float = THRESHOLD) -> List[Dict]:
        """发现 case → script 关系 (case_illustrates)"""
        print("\n🔍 发现 case → script 关系...")

        candidates = []
        cases = self.entities_by_type['case']
        scripts = self.entities_by_type['script']

        for case in cases:
            case_text = self.get_entity_text(case)

            for script in scripts:
                script_text = self.get_entity_text(script)

                similarity = self.get_text_similarity(case_text, script_text)

                if similarity >= threshold:
                    candidates.append({
                        'from_id': case['id'],
                        'to_id': script['id'],
                        'relation_type': 'case_illustrates',
                        'confidence': similarity,
                        'reason': f'案例"{case.get("name", "")}"与话术"{script.get("name", "")}"相似度={similarity:.2f}'
                    })

        print(f"   发现 {len(candidates)} 个候选关系")
        return candidates

    def discover_experiment_to_tactic(self, threshold: float = THRESHOLD) -> List[Dict]:
        """发现 experiment → tactic 关系 (experiment_validates)"""
        print("\n🔍 发现 experiment → tactic 关系...")

        candidates = []
        experiments = self.entities_by_type['experiment']
        tactics = self.entities_by_type['tactic']

        for experiment in experiments:
            exp_text = self.get_entity_text(experiment)

            for tactic in tactics:
                tactic_text = self.get_entity_text(tactic)

                similarity = self.get_text_similarity(exp_text, tactic_text)

                if similarity >= threshold:
                    candidates.append({
                        'from_id': experiment['id'],
                        'to_id': tactic['id'],
                        'relation_type': 'experiment_validates',
                        'confidence': similarity,
                        'reason': f'实验"{experiment.get("name", "")}"与策略"{tactic.get("name", "")}"相似度={similarity:.2f}'
                    })

        print(f"   发现 {len(candidates)} 个候选关系")
        return candidates

    def discover_tactic_to_script(self, threshold: float = THRESHOLD) -> List[Dict]:
        """发现 tactic → script 关系 (tactic_uses)"""
        print("\n🔍 发现 tactic → script 关系...")

        candidates = []
        tactics = self.entities_by_type['tactic']
        scripts = self.entities_by_type['script']

        for tactic in tactics:
            tactic_text = self.get_entity_text(tactic)

            for script in scripts:
                script_text = self.get_entity_text(script)

                similarity = self.get_text_similarity(tactic_text, script_text)

                if similarity >= threshold:
                    candidates.append({
                        'from_id': tactic['id'],
                        'to_id': script['id'],
                        'relation_type': 'tactic_uses',
                        'confidence': similarity,
                        'reason': f'策略"{tactic.get("name", "")}"与话术"{script.get("name", "")}"相似度={similarity:.2f}'
                    })

        print(f"   发现 {len(candidates)} 个候选关系")
        return candidates

    def discover_principle_to_concept(self, threshold: float = THRESHOLD) -> List[Dict]:
        """发现 principle → concept 关系 (principle_explains)"""
        print("\n🔍 发现 principle → concept 关系...")

        candidates = []
        principles = self.entities_by_type['principle']
        concepts = self.entities_by_type['concept']

        for principle in principles:
            principle_text = self.get_entity_text(principle)

            for concept in concepts:
                concept_text = self.get_entity_text(concept)

                similarity = self.get_text_similarity(principle_text, concept_text)

                if similarity >= threshold:
                    candidates.append({
                        'from_id': principle['id'],
                        'to_id': concept['id'],
                        'relation_type': 'principle_explains',
                        'confidence': similarity,
                        'reason': f'原则"{principle.get("name", "")}"与概念"{concept.get("name", "")}"相似度={similarity:.2f}'
                    })

        print(f"   发现 {len(candidates)} 个候选关系")
        return candidates

    def discover_all(self) -> List[Dict]:
        """发现所有新关系"""
        all_candidates = []

        # 高优先级
        all_candidates.extend(self.discover_case_to_tactic())
        all_candidates.extend(self.discover_case_to_script())
        all_candidates.extend(self.discover_experiment_to_tactic())

        # 中优先级
        all_candidates.extend(self.discover_tactic_to_script())
        all_candidates.extend(self.discover_principle_to_concept())

        # 按置信度排序
        all_candidates.sort(key=lambda x: x['confidence'], reverse=True)

        return all_candidates

    def generate_relation_id(self, relation_type: str, index: int) -> str:
        """生成关系ID"""
        # 去掉特殊字符，转kebab-case
        rel_type_clean = relation_type.replace('_', '-')
        return f"{rel_type_clean}-{index}"

    def save_candidates(self, candidates: List[Dict], output_path: Path):
        """保存候选关系到文件"""
        # 为每个候选关系生成ID
        relation_counts = defaultdict(int)

        for candidate in candidates:
            rel_type = candidate['relation_type']
            relation_counts[rel_type] += 1
            candidate['id'] = self.generate_relation_id(rel_type, relation_counts[rel_type])

        # 保存
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(candidates, f, ensure_ascii=False, indent=2)

        print(f"\n💾 保存到: {output_path}")
        print(f"📊 总计 {len(candidates)} 个候选关系")

    def show_sample(self, candidates: List[Dict], n: int = 10):
        """显示前N个候选关系示例"""
        print(f"\n📋 前 {n} 个候选关系示例:\n")

        for i, candidate in enumerate(candidates[:n], 1):
            from_entity = self.entity_index.get(candidate['from_id'], {})
            to_entity = self.entity_index.get(candidate['to_id'], {})

            print(f"{i}. {candidate['relation_type']}")
            print(f"   From: {from_entity.get('name', candidate['from_id'])} ({from_entity.get('type', 'unknown')})")
            print(f"   To: {to_entity.get('name', candidate['to_id'])} ({to_entity.get('type', 'unknown')})")
            print(f"   置信度: {candidate['confidence']:.2f}")
            print(f"   原因: {candidate['reason']}")
            print()

def main():
    """主函数"""
    print("=" * 60)
    print("影响力本体 - 关系自动补充")
    print("=" * 60)

    # 初始化发现器
    discoverer = RelationDiscoverer(ONTOLOGY_PATH)

    # 加载本体
    discoverer.load_ontology()

    # 发现所有关系
    print("\n🚀 开始关系发现...")
    candidates = discoverer.discover_all()

    # 显示示例
    discoverer.show_sample(candidates, n=15)

    # 保存结果
    discoverer.save_candidates(candidates, OUTPUT_PATH)

    print("\n✅ 完成!")
    print(f"\n📝 下一步:")
    print(f"1. 查看 {OUTPUT_PATH}")
    print(f"2. 抽样审核候选关系")
    print(f"3. 合并到本体: scripts/merge_relations.py")

if __name__ == '__main__':
    main()
