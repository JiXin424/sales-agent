"""本体抽取纯函数库 — 从文档抽取实体+关系，生成结构化背景知识。

从 Ontology Sales Copilot 移植并改造：
- 移除 AsyncOpenAI 依赖 → 用 v2 的 OpenAIClient（urllib）
- 移除 SQLAlchemy session → 纯 list/dict 输入输出
- Prompt 模板从 yaml 动态渲染，不硬编码类型清单

依赖：
- yaml（PyYAML）
- OpenAIClient（v2 项目内）
"""

from __future__ import annotations

import io
import json
import re
import time
from contextlib import redirect_stdout
from pathlib import Path
from typing import Optional

import yaml


# ──────────────────────────────────────────────────────────────
# 默认配置
# ──────────────────────────────────────────────────────────────

_SCRIPT_DIR = Path(__file__).parent.resolve()
DEFAULT_TYPES_PATH = _SCRIPT_DIR / "ontology_types.yaml"

# 摘要中保留每个类型的最大实体数（避免主体文件过长）
MAX_ENTITIES_PER_TYPE = 30
# 摘要中保留的最大关系数
MAX_LINKS_IN_SUMMARY = 200
# 主体文件总字符上限（防止 system prompt 撑爆）
MAX_SUBJECT_CHARS = 8000
# 单文档抽取内容截断
MAX_DOC_CHARS = 4000


# ──────────────────────────────────────────────────────────────
# 类型配置加载
# ──────────────────────────────────────────────────────────────

def load_type_config(
    preset: str = "general",
    yaml_path: Optional[Path] = None,
) -> dict:
    """加载 yaml 返回类型配置。

    Args:
        preset: 预设名（general / sales / 自定义）
        yaml_path: 自定义 yaml 路径（None 时用默认 ontology_types.yaml）

    Returns:
        {
            "title": str,
            "description": str,
            "objects": [{"name", "desc"}, ...],
            "relations": [{"name", "desc"}, ...],
            "prompt_extras": {type_name: hint, ...},
            "object_types": [str],      # 仅类型名
            "relation_types": [str],
        }
    """
    yaml_path = Path(yaml_path) if yaml_path else DEFAULT_TYPES_PATH
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    presets = data.get("presets", {})
    if preset not in presets:
        raise ValueError(
            f"未知预设 '{preset}'，可选：{list(presets.keys())}"
        )

    cfg = presets[preset]
    return {
        "title": cfg.get("title", "知识本体背景知识"),
        "description": cfg.get("description", ""),
        "objects": cfg.get("objects", []),
        "relations": cfg.get("relations", []),
        "prompt_extras": cfg.get("prompt_extras", {}),
        "object_types": [o["name"] for o in cfg.get("objects", []) if "name" in o],
        "relation_types": [r["name"] for r in cfg.get("relations", []) if "name" in r],
    }


# ──────────────────────────────────────────────────────────────
# Prompt 构建（从 yaml 动态渲染）
# ──────────────────────────────────────────────────────────────

def _render_types_block(type_config: dict) -> str:
    """渲染实体/关系类型说明 block"""
    lines = ["实体类型说明："]
    for obj in type_config["objects"]:
        lines.append(f"- {obj['name']}: {obj.get('desc', '')}")
    lines.append("")
    lines.append("关系类型说明：")
    for rel in type_config["relations"]:
        lines.append(f"- {rel['name']}: {rel.get('desc', '')}")
    return "\n".join(lines)


def _render_properties_hint(type_config: dict) -> str:
    """渲染 properties 抽取提示（按类型）"""
    extras = type_config.get("prompt_extras", {})
    if not extras:
        return ""
    lines = ["Properties 抽取要求（关键！必须抽取具体数据）："]
    for type_name, hint in extras.items():
        lines.append(f"- {type_name}: {hint}")
    return "\n".join(lines)


def build_objects_prompt(
    type_config: dict,
    md_content: str,
    context_text: str = "",
) -> str:
    """构建实体抽取 prompt（直接拼接，不用 .format 避免 JSON 花括号冲突）"""
    content = md_content[:MAX_DOC_CHARS]
    parts = [
        "你是一个知识本体抽取专家。从以下文档中抽取所有相关实体。",
        "",
        "请按以下 JSON 格式输出：",
        "",
        '{"objects": [{"type": "实体类型", "name": "实体名称", "properties": {"key": "value"}}]}',
        "",
        _render_types_block(type_config),
    ]

    hint = _render_properties_hint(type_config)
    if hint:
        parts.extend(["", hint])

    parts.extend([
        "",
        "只抽取文档中明确提到的信息。每个实体必须有 type、name，properties 尽可能丰富。",
        "如果文档中提到与背景知识相同的实体，请使用完全一致的名称。",
    ])

    if context_text:
        parts.extend([
            "",
            "## 背景知识（已有实体的概览）",
            context_text[:6000],
            "",
            "请参考以上背景知识来理解和分类当前文档中的实体。",
        ])

    parts.extend([
        "",
        "文档内容：",
        "---",
        content,
        "---",
        "",
        "请输出 JSON：",
    ])
    return "\n".join(parts)


def build_relations_prompt(
    type_config: dict,
    md_content: str,
    objects_json: str,
    context_text: str = "",
) -> str:
    """构建关系抽取 prompt（直接拼接）"""
    content = md_content[:MAX_DOC_CHARS]
    parts = [
        "你是一个知识本体抽取专家。基于以下文档和已抽取的实体，抽取实体之间的关系。",
        "",
        "已知实体：",
        objects_json,
        "",
        "请按以下 JSON 格式输出：",
        "",
        '{"relations": [{"source": "源实体名", "target": "目标实体名", "type": "关系类型"}]}',
        "",
        "关系类型可选：",
        ", ".join(type_config["relation_types"]),
        "",
        "只抽取文档中明确提到的关系。",
    ]

    if context_text:
        parts.extend([
            "",
            "## 背景知识",
            context_text[:6000],
        ])

    parts.extend([
        "",
        "文档内容：",
        "---",
        content,
        "---",
        "",
        "请输出 JSON：",
    ])
    return "\n".join(parts)


# ──────────────────────────────────────────────────────────────
# JSON 修复（直接移植自 Ontology/extractor.py L173-213）
# ──────────────────────────────────────────────────────────────

def _repair_json(text: str) -> str:
    """尝试修复截断的 JSON：找到最后一个完整的 } 或 ] 并闭合"""
    text = text.strip()
    for pattern in [r'\}\s*\]$', r'\}\s*$', r'"\s*\]$', r'"\s*$']:
        m = list(re.finditer(pattern, text))
        if m:
            last_match = m[-1]
            truncated = text[:last_match.end()]
            open_brackets = truncated.count('[') - truncated.count(']')
            open_braces = truncated.count('{') - truncated.count('}')
            truncated += ']' * max(0, open_brackets)
            truncated += '}' * max(0, open_braces)
            return truncated
    return text


def _safe_parse_json(text: str) -> dict:
    """安全解析 JSON，失败时尝试修复"""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    try:
        return json.loads(_repair_json(text))
    except json.JSONDecodeError:
        pass
    m = re.search(r'\{[\s\S]*\}', text)
    if m:
        try:
            return json.loads(_repair_json(m.group()))
        except json.JSONDecodeError:
            pass
    return {}


# ──────────────────────────────────────────────────────────────
# LLM 调用（复用 v2 OpenAIClient）
# ──────────────────────────────────────────────────────────────

def _call_llm_quiet(
    client,
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 12000,
    temperature: float = 0.1,
) -> str:
    """静音调用 chat_stream（屏蔽思考过程 stdout 输出）"""
    import sys as _sys
    _sys.stderr.write(f"    [DEBUG] _call_llm_quiet: prompt={len(user_prompt)}chars max_tokens={max_tokens}\n")
    _sys.stderr.flush()

    t0 = time.time()
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        try:
            text = client.chat_stream(
                system=system_prompt,
                user=user_prompt,
                temperature=temperature,
                extra_body={
                    "max_tokens": max_tokens,
                    "reasoning_effort": "medium",
                },
            )
        except Exception as e:
            _sys.stderr.write(f"    [DEBUG] chat_stream exception: {e}\n")
            _sys.stderr.flush()
            raise

    elapsed = time.time() - t0
    _sys.stderr.write(f"    [DEBUG] _call_llm_quiet done: {len(text)}chars, {elapsed:.1f}s\n")
    _sys.stderr.flush()
    return text


def extract_objects(
    client,
    md_content: str,
    type_config: dict,
    context_text: str = "",
    max_tokens: int = 12000,
) -> list[dict]:
    """从 Markdown 抽取实体

    Args:
        client: v2 OpenAIClient 实例
        md_content: 文档内容
        type_config: 类型配置
        context_text: 背景知识（可选）
        max_tokens: 输出 token 上限

    Returns:
        [{"type":..., "name":..., "properties":{...}}, ...]
    """
    prompt = build_objects_prompt(type_config, md_content, context_text)

    import sys as _sys
    _sys.stderr.write(f"    [DEBUG] extract_objects: prompt={len(prompt)}chars, content={len(md_content)}chars\n")
    _sys.stderr.flush()

    text = _call_llm_quiet(
        client,
        system_prompt="你是一个专业的知识本体抽取助手。",
        user_prompt=prompt,
        max_tokens=max_tokens,
    )
    result = _safe_parse_json(text)
    return result.get("objects", [])


def extract_relations(
    client,
    md_content: str,
    objects: list[dict],
    type_config: dict,
    context_text: str = "",
    max_tokens: int = 12000,
) -> list[dict]:
    """从 Markdown + 已知实体抽取关系"""
    if not objects:
        return []

    objects_json = json.dumps(objects, ensure_ascii=False, indent=2)
    prompt = build_relations_prompt(type_config, md_content, objects_json, context_text)

    import sys as _sys
    _sys.stderr.write(f"    [DEBUG] extract_relations: prompt={len(prompt)}chars, objects={len(objects)}\n")
    _sys.stderr.flush()

    text = _call_llm_quiet(
        client,
        system_prompt="你是一个专业的知识本体抽取助手。",
        user_prompt=prompt,
        max_tokens=max_tokens,
    )
    result = _safe_parse_json(text)
    return result.get("relations", [])


# ──────────────────────────────────────────────────────────────
# 合并去重
# ──────────────────────────────────────────────────────────────

def merge_objects(all_objects: list[list[dict]]) -> list[dict]:
    """跨文档实体合并去重。

    主 key: name.lower().strip()
    同名不同 type: first-wins（保留首次出现的 type）
    properties: 取并集（后者补充前者已有 key 不覆盖）
    source_files: 取并集（保留所有来源文档路径）
    aliases: 取并集
    """
    merged: dict[str, dict] = {}
    for objs in all_objects:
        for o in objs:
            name = (o.get("name") or "").strip()
            if not name:
                continue
            key = name.lower()
            # 收集 source（可能是 source_file 单值或 source_files 列表）
            sources = []
            if o.get("source_files"):
                sources.extend(o["source_files"])
            if o.get("source_file"):
                sources.append(o["source_file"])
            aliases = list(o.get("aliases") or [])

            if key not in merged:
                merged[key] = {
                    "name": name,
                    "type": o.get("type", "Unknown"),
                    "properties": dict(o.get("properties") or {}),
                    "source_files": list(dict.fromkeys(sources)),  # 保序去重
                    "aliases": aliases,
                }
            else:
                existing = merged[key]
                # properties 并集
                for k, v in (o.get("properties") or {}).items():
                    if k not in existing["properties"] and v:
                        existing["properties"][k] = v
                # source_files 并集
                for s in sources:
                    if s not in existing["source_files"]:
                        existing["source_files"].append(s)
                # aliases 并集
                for a in aliases:
                    if a and a not in existing["aliases"]:
                        existing["aliases"].append(a)
    return list(merged.values())


def merge_links(
    all_links: list[list[dict]],
    valid_names: set,
) -> list[dict]:
    """跨文档关系合并去重。

    key: (source.lower(), target.lower(), type)
    悬挂过滤：source/target 不在 valid_names 中则丢弃
    """
    seen: set = set()
    merged: list[dict] = []
    for links in all_links:
        for link in links:
            src = (link.get("source") or "").strip()
            tgt = (link.get("target") or "").strip()
            rel = (link.get("type") or "").strip()
            if not src or not tgt or not rel:
                continue
            if src.lower() not in valid_names or tgt.lower() not in valid_names:
                continue
            key = (src.lower(), tgt.lower(), rel)
            if key in seen:
                continue
            seen.add(key)
            merged.append({"source": src, "target": tgt, "type": rel})
    return merged


# ──────────────────────────────────────────────────────────────
# 摘要生成（Ontology/knowledge/context.py 移植）
# ──────────────────────────────────────────────────────────────

def group_by_type(
    objects: list[dict],
    type_config: dict,
) -> dict[str, list[dict]]:
    """按 type 分组，按 type_config 顺序排序"""
    groups: dict[str, list[dict]] = {}
    for o in objects:
        t = o.get("type", "Unknown")
        groups.setdefault(t, []).append(o)

    # 按 type_config 顺序排序，未知类型放最后
    ordered: dict[str, list[dict]] = {}
    for o_cfg in type_config["objects"]:
        name = o_cfg["name"]
        if name in groups:
            ordered[name] = groups.pop(name)
    for t, items in groups.items():
        ordered[t] = items
    return ordered


def build_summary_text(
    groups: dict[str, list[dict]],
    links: list[dict],
    title: str = "知识本体背景知识",
) -> str:
    """将实体和关系格式化为可读 markdown 文本（不含顶层标题，由调用者包装）"""
    lines = []

    for t, items in groups.items():
        if not items:
            continue
        # 每类型最多保留 MAX_ENTITIES_PER_TYPE 个
        truncated = items[:MAX_ENTITIES_PER_TYPE]
        lines.append(f"## {t} ({len(items)})")
        for item in truncated:
            name = item.get("name", "?")
            props = item.get("properties", {})
            if props:
                prop_str = ", ".join(f"{k}: {v}" for k, v in props.items() if v)
                lines.append(f"- {name} ({prop_str})")
            else:
                lines.append(f"- {name}")
        if len(items) > MAX_ENTITIES_PER_TYPE:
            lines.append(f"- ... (共 {len(items)} 个，已截断)")
        lines.append("")

    if links:
        shown = links[:MAX_LINKS_IN_SUMMARY]
        lines.append(f"## 关系 ({len(links)})")
        for link in shown:
            lines.append(
                f"- {link.get('source', '?')} —[{link.get('type', '?')}]→ "
                f"{link.get('target', '?')}"
            )
        if len(links) > MAX_LINKS_IN_SUMMARY:
            lines.append(f"- ... (共 {len(links)} 条)")
        lines.append("")

    return "\n".join(lines)


def score_entity_importance(entity: dict) -> int:
    """给实体打重要性分数（用于按相关性裁剪）。

    分数构成：
    - source_files 数 × 3（跨文档出现 = 高重要性）
    - properties 数 × 1（属性丰富 = 信息密度高）
    - 核心类型加权（Company/Product = 10，Certification/Award = 5，其他 = 1）

    Returns:
        int 重要性分数
    """
    type_weights = {
        "Company": 10, "Organization": 10,
        "Product": 8,
        "Competitor": 7,
        "Certification": 5, "Award": 5,
        "Policy": 5,
        "CustomerSegment": 5, "Scenario": 4, "Solution": 4,
        "Person": 3, "Contact": 3,
        "Feature": 3, "Spec": 2, "Equipment": 2, "Pricing": 3,
        "Case": 3, "Advantage": 4,
        "Objection": 2, "SalesScript": 2,
        "Disease": 2, "Industry": 2, "Partner": 2, "Institution": 2,
        "Document": 2, "Process": 2, "Metric": 2, "Standard": 2,
        "Concept": 1, "Term": 1, "Location": 1, "Date": 1, "Event": 1,
    }
    type_score = type_weights.get(entity.get("type", ""), 1)
    source_score = len(entity.get("source_files", [])) * 3
    prop_score = len([v for v in entity.get("properties", {}).values() if v])
    return type_score + source_score + prop_score


def prune_by_relevance(
    objects: list[dict],
    max_entities: int = 100,
) -> list[dict]:
    """按重要性分数裁剪实体列表。

    保留 Top N（按分数降序），同分时按名字字典序保序。

    Args:
        objects: 实体列表
        max_entities: 最大保留数

    Returns:
        裁剪后的实体列表（保持原字段，添加 _importance 分数）
    """
    if len(objects) <= max_entities:
        return objects

    scored = [(score_entity_importance(o), o) for o in objects]
    scored.sort(key=lambda x: (-x[0], x[1].get("name", "")))
    return [o for _, o in scored[:max_entities]]


def render_subject_markdown(
    ontology: dict,
    type_config: dict,
    max_chars: int = MAX_SUBJECT_CHARS,
) -> str:
    """把 ontology 摘要包装成主体文件格式。

    改进点：
    1. 按 max_chars 自适应裁剪（迭代增加 max_entities 直到接近上限）
    2. 实体按重要性分数排序（不是按字典序），高重要性优先保留
    3. 不再硬截断字符，而是减少实体数量

    与 主体文件-模板.md 章节结构兼容，便于 load_subject_context 解析。
    """
    objects = ontology.get("objects", [])
    links = ontology.get("links", [])

    # 头尾固定开销（标题+描述+章节标题）
    header_lines = [
        f"# {type_config['title']}",
        "",
        f"> {type_config.get('description', '从项目文档中自动抽取的实体和关系摘要')}",
        "",
        "## 知识本体摘要",
        "",
    ]
    header = "\n".join(header_lines)
    footer = ""

    # 二分搜索最佳 max_entities_per_type
    # 思路：从大到小试，找到不超过 max_chars 的最大值
    def try_render(max_per_type: int, max_total: int) -> tuple[str, int]:
        pruned = prune_by_relevance(objects, max_entities=max_total)
        groups = group_by_type(pruned, type_config)
        # 限制每类型条数
        for t in groups:
            if len(groups[t]) > max_per_type:
                groups[t] = groups[t][:max_per_type]
        summary = build_summary_text(groups, links, type_config["title"])
        text = header + summary.strip() + footer
        return text, len(pruned)

    # 默认尝试：每类型最多 30，总数最多 200
    candidates = [
        (50, 300),  # 大限制
        (30, 200),  # 默认
        (20, 150),
        (15, 100),
        (10, 80),
        (8, 60),
        (5, 40),
        (3, 20),
    ]

    text = None
    for max_per_type, max_total in candidates:
        candidate_text, kept = try_render(max_per_type, max_total)
        if len(candidate_text) <= max_chars:
            text = candidate_text
            break

    if text is None:
        # 全部候选都超限，用最小的
        text, _ = try_render(3, 20)
        # 硬截断保命
        if len(text) > max_chars:
            text = text[:max_chars] + "\n\n（已截断至 {} 字符）".format(max_chars)

    # 如果有实体被裁剪掉，加一行说明
    total_objects = len(objects)
    # 统计 text 中实际保留的实体数（粗略：数 "- " 开头的行）
    kept_objects = sum(1 for line in text.split("\n") if line.startswith("- "))
    if kept_objects < total_objects:
        text += f"\n\n（共 {total_objects} 实体，已按重要性保留 {kept_objects} 个核心实体）"

    return text
