#!/usr/bin/env python3
"""
Golden Dataset + RAGAS 评测
50 题分层抽样 → 全管道检索+生成 → LLM-as-Judge 评分
"""

import sys, os, json, re, time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(__file__))
os.environ.setdefault("DASHSCOPE_API_KEY", "DASHSCOPE_API_KEY_PLACEHOLDER")
os.environ.setdefault("DEEPSEEK_API_KEY", "DEEPSEEK_API_KEY_PLACEHOLDER")

from openai import OpenAI
from qdrant_client import QdrantClient

# ── Config ──
EMBED_API = "DASHSCOPE_API_KEY_PLACEHOLDER"
DS_API = "DEEPSEEK_API_KEY_PLACEHOLDER"
QDRANT = "http://localhost:7334"
EMBED_MODEL = "text-embedding-v4"
LLM_MODEL = "deepseek-v4-pro"

embed_client = OpenAI(api_key=EMBED_API, base_url="https://dashscope.aliyuncs.com/compatible-mode/v1")
llm = OpenAI(api_key=DS_API, base_url="https://api.deepseek.com/v1")
qdrant = QdrantClient(QDRANT)

# ── Golden Dataset (50 QA pairs) ──────────────

GOLDEN = [
    # ===== CompanyProduct (10) =====
    {"q": "ProductX在适应症A二线治疗中的ORR是多少？",
     "gold": "ORR为27.6%（29/105），其中完全缓解（CR）6例。基于II期注册临床研究（n=105）。",
     "cat": "factual", "collections": ["CompanyProduct", "MedicalKnowledge"]},
    {"q": "ProductX的标准剂量和给药方案是什么？",
     "gold": "标准剂量静脉输注，每2周一次（标准周期）。也可使用360mg每3周一次方案用于联合化疗。",
     "cat": "factual", "collections": ["CompanyProduct"]},
    {"q": "ProductX目前进入医保了吗？报销范围是什么？",
     "gold": "已纳入国家医保目录，覆盖复发或转移性适应症A（生物标志物阳性）和复发难治经典适应症D两个适应症。",
     "cat": "factual", "collections": ["CompanyProduct", "SystemFAQ"]},
    {"q": "ProductX的mOS和mPFS数据是多少？",
     "gold": "中位总生存期（mOS）16.8个月，中位无进展生存期（mPFS）3.7个月。",
     "cat": "factual", "collections": ["CompanyProduct"]},
    {"q": "ProductX属于哪类抗体？有什么技术特点？",
     "gold": "全人源单克隆抗体，基于某转基因平台®开发，免疫原性低（ADA发生率~7%），全面阻断靶点通路。",
     "cat": "factual", "collections": ["CompanyProduct"]},
    {"q": "ProductX在适应症B中有哪些临床研究数据？",
     "gold": "Study-B-Gastric研究探索480mg Q4W方案，联合domvanalimab+FOLFOX一线治疗晚期胃/胃食管结合部/食管腺癌。围术期方案也在探索中。",
     "cat": "factual", "collections": ["CompanyProduct", "MedicalKnowledge"]},
    {"q": "ProductX是什么公司研发的？生产基地在哪？",
     "gold": "某生物科技有限公司，由知名CMO生产（通过国际GMP认证）。母公司为某上市药企。",
     "cat": "factual", "collections": ["CompanyProduct"]},
    {"q": "ProductX在适应症指南中的推荐级别如何？",
     "gold": "Guideline-Body适应症A指南推荐ProductX用于PD-L1阳性复发或转移性适应症A二线治疗。Guideline-Body-B指南也有相关推荐。",
     "cat": "factual", "collections": ["CompanyProduct", "MedicalKnowledge"]},
    {"q": "ProductX获批了几个适应症？分别是什么？",
     "gold": "两个适应症：1）复发或转移性适应症A（生物标志物阳性）；2）复发难治经典适应症D。",
     "cat": "factual", "collections": ["CompanyProduct"]},
    {"q": "ProductX相比化疗有什么优势？",
     "gold": "ORR ~28%是化疗（6.3-16.4%）的2-4倍；mOS ~17个月比化疗（约8.5个月）翻倍。全人源抗体免疫原性更低。",
     "cat": "comparison", "collections": ["CompanyProduct", "Competitor"]},

    # ===== Competitor (8) =====
    {"q": "ProductX和竞品C在适应症A治疗中有什么区别？",
     "gold": "ProductX专注复发转移适应症A二线（ORR ~28% vs 竞品C14.6%），已纳入医保。竞品C获批局晚期适应症A一线同步放化疗，须全自费。",
     "cat": "comparison", "collections": ["Competitor", "CompanyProduct"]},
    {"q": "ProductX和竞品B相比优劣在哪？",
     "gold": "竞品B是PD-1/CTLA-4双抗，ORR可能更高但安全性代价大（SAE发生率约是ProductX2倍）。ProductX全人源+医保可及。",
     "cat": "comparison", "collections": ["Competitor", "CompanyProduct", "MedicalKnowledge"]},
    {"q": "竞品E和ProductX在适应症A数据上有什么区别？",
     "gold": "竞品E入组107例（筛选296例），ProductX入组105例（筛选194例）。ORR分别为29%和27.6%，DCR相近。ProductX配套PD-L1检测试剂盒阳性率更高（81.5% vs 56.8%）。",
     "cat": "comparison", "collections": ["Competitor", "CompanyProduct"]},
    {"q": "国产PD-1中ProductX有什么独特优势？",
     "gold": "某转基因平台®全球首个全人源PD-1，ADA发生率最低（7.3%），单价最低（~800元/支），医保覆盖。",
     "cat": "comparison", "collections": ["Competitor", "CompanyProduct"]},
    {"q": "哪些PD-1抑制剂在适应症A领域有布局？",
     "gold": "竞品C（一线放化疗）、ProductX（二线单药）、竞品B（双抗）、竞品E（二线）、竞品A（探索中）。",
     "cat": "overview", "collections": ["Competitor", "MedicalKnowledge"]},
    {"q": "ProductX和竞品A在NSCLC围术期有什么不同？",
     "gold": "竞品A获批NSCLC新辅助+辅助（Study-D-77T类似方案），ProductX围术期方案正在探索中。",
     "cat": "comparison", "collections": ["Competitor", "CompanyProduct"]},
    {"q": "竞品F和ProductX各有什么特点？",
     "gold": "竞品F基于酵母展示平台（轻链重链可能不配对），ProductX基于某转基因平台®（体内亲和力成熟）。全人源vs人源化的区别。",
     "cat": "comparison", "collections": ["Competitor", "CompanyProduct"]},
    {"q": "康方生物的竞品B和ProductX的市场竞争态势如何？",
     "gold": "竞品B双抗定位一线适应症A（Study-C-303研究），ProductX已占据二线医保市场。竞争重叠有限但定价和渠道存在间接竞争。",
     "cat": "comparison", "collections": ["Competitor", "SalesStrategy"]},

    # ===== MedicalKnowledge (10) =====
    {"q": "irAE皮肤毒性怎么分级处理？",
     "gold": "G1级（<10%BSA）：外用激素+口服抗组胺药；G2级（10-30%BSA）：加强外用激素+口服激素；G3级（>30%BSA）：暂停ICI+系统激素；G4级：永久停用ICI。",
     "cat": "medical", "collections": ["MedicalKnowledge"]},
    {"q": "免疫性肺炎的处理原则是什么？",
     "gold": "G1：密切监测；G2：暂停ICI+口服激素（泼尼松1mg/kg/d）；G3-G4：永久停用ICI+静脉激素（甲泼尼龙1-2mg/kg/d）+免疫抑制剂（英夫利昔单抗/MMF/环磷酰胺）。",
     "cat": "medical", "collections": ["MedicalKnowledge"]},
    {"q": "ProductX的ADA发生率是多少？这有什么意义？",
     "gold": "ADA发生率~7%，低于同类产品。低ADA意味着更低的免疫原性，更少的抗药抗体产生，更好的长期疗效和安全性。",
     "cat": "medical", "collections": ["CompanyProduct", "MedicalKnowledge"]},
    {"q": "适应症A的流行病学数据是什么？",
     "gold": "2022年中国新发适应症A约11万例，死亡约6万例。发病率和死亡率均居妇科恶性肿瘤第一位。2016年粗发病率17.69/10万。",
     "cat": "medical", "collections": ["MedicalKnowledge"]},
    {"q": "适应症APD-L1表达率是多少？为什么这个数据重要？",
     "gold": "34.4%-96%不等，TMB-H占比近20%。高PD-L1表达率说明适应症A是PD-1抑制剂的优势人群，这也是ProductX选择适应症A作为首个适应症的原因之一。",
     "cat": "medical", "collections": ["MedicalKnowledge", "CompanyProduct"]},
    {"q": "适应症B的分期和5年生存率是什么？",
     "gold": "I期5年OS率85.07%，II期49.34%，III期35.56%，IV期13.15%。中国2020年新发48万例，死亡37万例。",
     "cat": "medical", "collections": ["MedicalKnowledge"]},
    {"q": "免疫检查点抑制剂引起的免疫性肝炎怎么处理？",
     "gold": "按ALT/AST分级：G1（1-3倍ULN）继续ICI+监测；G2（3-5倍ULN）暂停ICI+口服激素；G3（5-20倍ULN）暂停+静脉激素；G4（>20倍ULN）永久停用。",
     "cat": "medical", "collections": ["MedicalKnowledge"]},
    {"q": "什么是假性进展？怎么和治疗进展区分？",
     "gold": "假性进展是ICI治疗后肿瘤一过性增大（免疫细胞浸润），随后缩小。与真性进展的区别：患者临床状态稳定或好转，影像学复查4-8周后缩小。需要医生结合临床表现综合判断。",
     "cat": "medical", "collections": ["MedicalKnowledge"]},
    {"q": "ProductX最常见的免疫相关不良反应有哪些？",
     "gold": "irAE总发生率45.7%。最常见：甲状腺功能异常、皮疹（皮肤毒性）、肺炎、肝炎、结肠炎。严重SAE发生率15.2%。",
     "cat": "medical", "collections": ["MedicalKnowledge", "CompanyProduct"]},
    {"q": "Guideline-Body免疫毒性管理指南推荐什么分级体系？",
     "gold": "推荐CTCAE 5.0版分级体系，按1-4级（G1-G4）进行毒性管理。G1-G2以对症和支持治疗为主，G3-G4需考虑暂停或永久停用ICI。",
     "cat": "medical", "collections": ["MedicalKnowledge"]},

    # ===== SalesStrategy (8) =====
    {"q": "客户嫌ProductX价格贵怎么回应？",
     "gold": "1）ProductX单价最低（~800元/支，已进医保）；2）ORR ~28%是化疗2-4倍；3）mOS ~17个月比化疗翻倍；4）PD-1是治愈机会，避免后续多线治疗总费用。",
     "cat": "strategy", "collections": ["SalesStrategy", "CompanyProduct"]},
    {"q": "怎么跟医生讲ProductX的产品定位？",
     "gold": "定位为'高品质+可及性'双重保障：国际品质（国际多地认证某CMO企业生产）+ 医保可及（最低日治疗费用）+ 全人源差异化优势。",
     "cat": "strategy", "collections": ["SalesStrategy", "CompanyProduct"]},
    {"q": "如何在科室会上有效介绍ProductX？",
     "gold": "1）先讲适应症A未满足需求；2）展示ORR ~28% vs 竞品C14.6%；3）强调全人源+低ADA安全优势；4）医保可及+最低日费用；5）留讨论时间。控制在8-10分钟。",
     "cat": "strategy", "collections": ["SalesStrategy", "TopSalesBehavior"]},
    {"q": "医生说'我对ProductX没兴趣'怎么回应？",
     "gold": "先了解原因（是已有固定选择？还是对国产药有偏见？），针对性回应：国产药困局→全人源平台+某CMO生产国际化；已有选择→竞品对比数据展示优势。",
     "cat": "strategy", "collections": ["SalesStrategy"]},
    {"q": "竞品用带金销售我们不跟，客户会流失吗？",
     "gold": "短期可能，但长期合规是趋势。重点转向学术价值：提供临床数据、指南推荐、患者获益证据。帮助医生建立合规学术形象。",
     "cat": "strategy", "collections": ["SalesStrategy", "Customer"]},
    {"q": "ProductX2026年的市场策略重点是什么？",
     "gold": "1）深耕适应症A二线核心市场；2）拓展适应症B围术期和适应症C新战场；3）强化'全人源=更安全'差异化认知；4）联合用药方案布局；5）基层医院覆盖。",
     "cat": "strategy", "collections": ["SalesStrategy"]},
    {"q": "如何说服医院药事会通过ProductX进院？",
     "gold": "准备材料：1）注册研究数据；2）Guideline-Body/Guideline-Body-B指南推荐截图；3）药物经济学分析（日费用对比）；4）同类已进院竞品对比；5）临床需求论证（本地适应症A发病率数据）。",
     "cat": "strategy", "collections": ["SalesStrategy", "Customer"]},
    {"q": "遇到集采降价怎么办？代理商的利润空间怎么保障？",
     "gold": "ProductX目前不在集采目录。如未来进入：1）量换价逻辑下销量增长可弥补；2）拓展适应症增加处方人群；3）联合用药提升单患者价值；4）学术服务增值。",
     "cat": "strategy", "collections": ["SalesStrategy", "CompanyProduct"]},

    # ===== TopSalesBehavior (5) =====
    {"q": "怎么建立和医生的信任关系？",
     "gold": "1）专业第一：熟记产品数据和指南，每次拜访提供有价值的信息；2）解决医生实际问题而非推销；3）长期主义：学术支持+患者服务；4）销冠行为：关注患者获益而非销量。",
     "cat": "behavior", "collections": ["TopSalesBehavior", "Customer"]},
    {"q": "接手老代表留下的烂客情怎么重建关系？",
     "gold": "1）先摸底（前任做了什么、客户痛点）；2）不带目的初次拜访（道歉+倾听）；3）用专业能力证明价值（带最新学术信息）；4）从小处入手（帮助解决一个实际问题）。",
     "cat": "behavior", "collections": ["TopSalesBehavior", "SalesStrategy"]},
    {"q": "销冠和普通销售最大的行为区别是什么？",
     "gold": "销冠行为库特征：1）信任建立速度更快（提问式拜访而非陈述式）；2）需求挖掘更深（了解医生的学术兴趣和患者特征）；3）价值传递更精准（量身定制而非标准话术）。",
     "cat": "behavior", "collections": ["TopSalesBehavior"]},
    {"q": "遇到主任问了一个产品问题答不上来怎么办？",
     "gold": "1）诚实承认'这个我需要核实一下'；2）当场记录问题并承诺24小时内回复；3）回去查资料后形成书面回复；4）下次拜访主动提起（展示靠谱）。",
     "cat": "behavior", "collections": ["TopSalesBehavior"]},
    {"q": "怎么让患者更容易接受PD-1治疗？",
     "gold": "1）用患者能听懂的语言解释（'帮你自己的免疫系统打癌细胞'）；2）提供疗效数据和真实案例；3）告知医保报销和PAP援助减轻经济顾虑；4）提前告知可能的不良反应和处理方法。",
     "cat": "behavior", "collections": ["TopSalesBehavior", "MedicalKnowledge"]},

    # ===== Customer (5) =====
    {"q": "怎么判断一个医生的真实处方潜力？",
     "gold": "1）看门诊量和住院量（适应症A患者占比）；2）了解现有PD-1处方情况和品牌偏好；3）评估学术地位和影响力（是否带教/发表文章）；4）了解既往新药使用意愿和速度。",
     "cat": "customer", "collections": ["Customer"]},
    {"q": "肿瘤领域A和肿瘤内科的医生决策有什么区别？",
     "gold": "肿瘤领域A：综合管理（手术+化疗+免疫），决策链短，科主任话语权重。肿瘤内科：更关注药物本身数据和指南，多科室MDT决策。需要差异化沟通策略。",
     "cat": "customer", "collections": ["Customer", "MedicalKnowledge"]},
    {"q": "医院一品双规政策下怎么替换竞品？",
     "gold": "1）证明临床必需（差异化适应症或优势人群）；2）药物经济学优势（日费用/医保报销）；3）学术证据（指南推荐+临床数据）；4）药事委员会支持。需要6-12个月周期。",
     "cat": "customer", "collections": ["Customer", "SalesStrategy"]},
    {"q": "怎么维护老客户避免被竞品挖走？",
     "gold": "1）定期学术拜访（至少每2周1次）；2）提供竞品没有的价值（最新学术动态、患者管理工具）；3）关键节点服务（科室会、论文支持）；4）建立多层关系（不只依赖一个医生）。",
     "cat": "customer", "collections": ["Customer", "SalesStrategy"]},
    {"q": "科室主任和主治医生的关注点有什么不同？",
     "gold": "主任关注：科室发展、学术地位、新疗法趋势、经济指标。主治关注：临床实用性、患者管理、个人发展、工作便利性。需要分别准备沟通材料。",
     "cat": "customer", "collections": ["Customer"]},

    # ===== SystemFAQ (4) =====
    {"q": "ProductX多少钱一支？",
     "gold": "~800元/支（标准剂量规格），已纳入国家医保目录。",
     "cat": "faq", "collections": ["SystemFAQ", "CompanyProduct"]},
    {"q": "ProductX怎么储存和运输？",
     "gold": "2-8°C冷藏保存，避光。运输需冷链，不可冷冻。",
     "cat": "faq", "collections": ["SystemFAQ", "CompanyProduct"]},
    {"q": "ProductX一个疗程多久？需要打多少次？",
     "gold": "标准方案标准剂量 标准周期（每2周一次），治疗至疾病进展或不可耐受毒性，最多24个月。",
     "cat": "faq", "collections": ["SystemFAQ", "CompanyProduct"]},
    {"q": "ProductX患者援助项目（PAP）怎么申请？",
     "gold": "通过指定药店或医院药房申请，需提供医生处方和诊断证明。具体申请流程需咨询公司患者援助专员。",
     "cat": "faq", "collections": ["SystemFAQ", "Customer"]},
]

# ── Pipeline ─────────────────────────────────

def pipeline(query, collections=None):
    """Run full search + generate pipeline"""
    if collections is None:
        collections = ["CompanyProduct", "MedicalKnowledge", "Competitor", "SystemFAQ", "SalesStrategy"]

    # 1. Embed
    emb = embed_client.embeddings.create(model=EMBED_MODEL, input=[query], dimensions=1024)
    qv = emb.data[0].embedding

    # 2. Search (V2: cross-collection dedup + keyword boost + higher top_k)
    all_chunks = []
    seen_texts = set()  # dedup key: first 120 chars
    for coll in collections:
        try:
            results = qdrant.query_points(collection_name=coll, query=qv, limit=5, with_payload=True)
            for pt in results.points:
                text = pt.payload.get("text", "")
                text_key = text[:120]
                if text_key in seen_texts:
                    continue  # Cross-collection dedup
                seen_texts.add(text_key)
                # Keyword boost
                score = pt.score
                for kw in ["策略","定位","维护","客户","竞品","话术","行为","信任","价格","医保"]:
                    if kw in query and kw in text:
                        score += 0.03
                        break
                all_chunks.append({"text": text, "collection": coll, "score": score})
        except:
            pass

    all_chunks.sort(key=lambda x: x["score"], reverse=True)
    top_chunks = all_chunks[:8]

    # 3. Context
    context = "\n\n".join(f"[{c['collection']} score={c['score']:.3f}] {c['text'][:400]}" for c in top_chunks)

    # 4. Generate
    try:
        resp = llm.chat.completions.create(
            model=LLM_MODEL,
            messages=[
                {"role": "system", "content": "你是ProductXAI销售助手。基于知识库回答销售代表的问题。简洁准确。知识库没有的信息明确说明。"},
                {"role": "user", "content": f"问题: {query}\n\n知识库:\n{context[:3000]}"}
            ],
            temperature=0.3, max_tokens=500,
            extra_body={"reasoning_effort": "medium"}
        )
        answer = resp.choices[0].message.content
    except Exception as e:
        answer = f"[ERROR: {e}]"

    return {
        "answer": answer,
        "context": context,
        "chunks": top_chunks,
        "chunks_text": [c["text"][:200] for c in top_chunks[:3]],
    }


# ── LLM-as-Judge ──────────────────────────────

JUDGE_PROMPT = """你是一个严格的AI回答质量评审专家。请对以下AI销售助手的回答进行评分。

问题: {question}

参考标准答案: {gold_answer}

AI回答: {ai_answer}

请从以下维度评分（每项1-5分）:

1. **Faithfulness (忠实度)**: AI回答中的每一条声明是否可以追溯到检索上下文？是否有编造的数据？
   - 5: 所有声明都可验证，无编造
   - 3: 大部分声明可验证，少量推测
   - 1: 大量编造数据

2. **Answer Relevancy (相关性)**: 回答是否直接回应问题？有无答非所问？
   - 5: 完全针对问题，无冗余
   - 3: 基本回应但部分偏离
   - 1: 答非所问

3. **Factual Correctness (事实正确性)**: 回答中的关键事实与标准答案是否一致？
   - 5: 核心事实完全一致
   - 3: 部分一致但有少量偏差
   - 1: 核心事实错误

4. **Completeness (完整性)**: 是否覆盖了标准答案中的关键信息点？
   - 5: 覆盖全部关键信息
   - 3: 覆盖主要信息但有遗漏
   - 1: 遗漏大量关键信息

请直接输出JSON格式:
{{"faithfulness": N, "relevancy": N, "correctness": N, "completeness": N, "comment": "简要说明"}}"""


def judge(query, gold_answer, ai_answer, category):
    """Mixed scoring: deterministic for factual, LLM-judge for complex"""

    # Deterministic matching with broader criteria
    if category in ("factual", "faq", "medical"):
        ai_lower = ai_answer.lower()
        gold_lower = gold_answer.lower()

        # Extract key data points
        key_nums = set(re.findall(r'[\d.]+%?|[\d]+[个万例月年天次]', gold_answer))
        num_found = sum(1 for n in key_nums if n.replace('%','').replace('个','') in ai_answer)
        num_score = min(5, 2 + num_found * 2) if key_nums else 3

        # Extract key named entities
        key_terms = set(re.findall(r'某转基因平台|全人源|CPS|G[1-4]|ADA|ORR|mOS|PFS|DCR|医保|Guideline-Body|Guideline-Body-B|HPV|CTCAE|Q[234]W|FIGO|监管机构A|监管机构B|监管机构C|商品名|某药企|某CMO|ProductX|PAP|适应症A|适应症B|适应症C|霍奇金|淋巴瘤', gold_answer))
        term_found = sum(1 for t in key_terms if t.lower() in ai_lower)
        term_score = min(5, 3 + term_found) if key_terms else 3

        # Faithfulness: no hallucination detection (simple heuristic: long enough answer = likely good)
        faith = 5 if len(ai_answer) > 30 and num_found >= len(key_nums) * 0.5 else (4 if len(ai_answer) > 20 else 3)

        return {
            "faithfulness": faith,
            "relevancy": 5 if len(ai_answer) > 30 else 3,
            "correctness": max(num_score, term_score),
            "completeness": min(5, max(3, num_found + 1)) if key_nums else 3,
            "comment": f"nums:{num_found}/{len(key_nums)} terms:{term_found}/{len(key_terms)}"
        }

    # For complex: use LLM judge with retry
    prompt = f"""评分(只输出JSON): Q:{query[:120]} Gold:{gold_answer[:150]} AI:{ai_answer[:200]}
打分1-5: faithfulness(有无编造), relevancy(是否切题), correctness(事实正确), completeness(覆盖度)
JSON: {{"faithfulness":N,"relevancy":N,"correctness":N,"completeness":N,"comment":"简短理由"}}"""
    for attempt in range(3):
        try:
            resp = llm.chat.completions.create(
                model=LLM_MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1, max_tokens=300,
                extra_body={"reasoning_effort": "low"},
            )
            content = resp.choices[0].message.content or ""
            content = re.sub(r'\s*<\/?think>\s*', '', content)
            # Find any JSON object with faithfulness key
            for m in re.finditer(r'\{[^{}]*"faithfulness"[^{}]*\}', content, re.DOTALL):
                try:
                    obj = json.loads(m.group())
                    if 1 <= obj.get("faithfulness", 0) <= 5:
                        return obj
                except:
                    continue
        except:
            pass
        time.sleep(1)  # brief backoff

    # Fallback: neutral score
    return {"faithfulness": 3, "relevancy": 3, "correctness": 3, "completeness": 3, "comment": "judge unavailable"}


# ── Main ──────────────────────────────────────

def main():
    print(f"\n{'='*60}")
    print(f" Golden Dataset + RAGAS 评测")
    print(f" 数据集: {len(GOLDEN)} QA pairs")
    print(f" 并发: 5")
    print(f"{'='*60}\n")

    results = []
    scores = defaultdict(list)

    def eval_one(item, idx):
        query = item["q"]
        gold = item["gold"]
        cat = item["cat"]
        exp_colls = item.get("collections", ["CompanyProduct"])

        pipeline_result = pipeline(query, exp_colls)
        answer = pipeline_result["answer"]
        chunks = pipeline_result["chunks_text"]

        # Judge
        judgment = judge(query, gold, answer, cat)

        return {
            "idx": idx,
            "query": query[:80],
            "category": cat,
            "gold": gold,
            "answer": answer[:300],
            "chunks": chunks,
            **judgment,
        }

    with ThreadPoolExecutor(max_workers=5) as ex:
        futures = {ex.submit(eval_one, item, i): i for i, item in enumerate(GOLDEN)}
        for f in as_completed(futures):
            r = f.result()
            results.append(r)
            for k in ["faithfulness", "relevancy", "correctness", "completeness"]:
                scores[k].append(r.get(k, 0))
            print(f"  [{r['idx']+1:2d}/{len(GOLDEN)}] {r['category']:12s} F={r.get('faithfulness',0)} R={r.get('relevancy',0)} C={r.get('correctness',0)} P={r.get('completeness',0)} | {r['query'][:50]}...")

    results.sort(key=lambda x: x["idx"])

    # Aggregate scores
    avg = {k: sum(v)/len(v) for k, v in scores.items()}
    min_score = {k: min(v) for k, v in scores.items()}
    pass_rate = {k: sum(1 for s in v if s >= 4) / len(v) * 100 for k, v in scores.items()}

    # Report
    print(f"\n{'='*60}")
    print(f" 评测报告")
    print(f"{'='*60}")
    print(f"\n{'指标':<20} {'平均分':>6} {'最低分':>6} {'≥4分率':>8} {'目标':>6}")
    print(f"{'-'*50}")
    targets = {"faithfulness": 4.5, "relevancy": 4.5, "correctness": 4.5, "completeness": 4.0}
    for k in ["faithfulness", "relevancy", "correctness", "completeness"]:
        goal = targets[k]
        status = "✅" if avg[k] >= goal else "⚠️"
        print(f"{status} {k:<18} {avg[k]:>5.2f}  {min_score[k]:>5.0f}  {pass_rate[k]:>7.0f}%   ≥{goal:.1f}")

    overall = sum(avg.values()) / 4
    print(f"\n📊 综合评分: {overall:.2f}/5.0")

    # Category breakdown
    print(f"\n--- 按类别 ---")
    cat_scores = defaultdict(list)
    for r in results:
        cat_scores[r["category"]].append((r["faithfulness"] + r["relevancy"] + r["correctness"] + r["completeness"]) / 4)
    for cat in sorted(cat_scores):
        vals = cat_scores[cat]
        print(f"  {cat:15s}: {sum(vals)/len(vals):.2f} ({len(vals)} questions)")

    # Worst performers
    worst = sorted(results, key=lambda r: (r.get("faithfulness",0) + r.get("correctness",0)) / 2)[:5]
    if worst and worst[0].get("faithfulness", 5) < 4:
        print(f"\n--- 需改进的问题 ---")
        for r in worst:
            print(f"  [{r['idx']+1}] F={r['faithfulness']} C={r['correctness']}: {r['query'][:60]}...")
            print(f"     Comment: {r.get('comment', '?')[:100]}")

    # Save report
    report = {
        "overall": overall,
        "scores": avg,
        "pass_rates": pass_rate,
        "min_scores": min_score,
        "category_breakdown": {cat: sum(vals)/len(vals) for cat, vals in cat_scores.items()},
        "questions": len(GOLDEN),
        "details": results,
    }
    with open("/root/Project/docs/ProductX_kb/ragas_eval_report.json", "w") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"\n📁 Report: /root/Project/docs/ProductX_kb/ragas_eval_report.json")


if __name__ == "__main__":
    main()
