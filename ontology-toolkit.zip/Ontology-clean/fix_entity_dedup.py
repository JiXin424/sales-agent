#!/usr/bin/env python3
"""修复 PostgreSQL 本体中的实体重复问题 — 全角/半角括号导致的同义变体"""

import psycopg2

DB = {
    "host": "localhost", "port": 5535,
    "dbname": "ontology", "user": "ontology",
    "password": "ontology_dev_2026",
}

conn = psycopg2.connect(**DB)
conn.autocommit = False
cur = conn.cursor()

# ── 1. 扫描重复 ────────────────────────────────
cur.execute("""
    SELECT o.type_id, o.id, o.name, o.properties,
           regexp_replace(o.name, '[（）()®™\s]', '', 'g') as norm_name
    FROM objects o
    ORDER BY type_id, norm_name, id
""")
rows = cur.fetchall()

# 分组：同 type + 同 norm_name
groups = {}
for row in rows:
    tid, oid, name, props, norm = row
    key = (tid, norm.lower())
    groups.setdefault(key, []).append((oid, name, props or {}))

dups = {k: v for k, v in groups.items() if len(v) > 1}
print(f"找到 {len(dups)} 组重复 (同type+同标准化名)")

# ── 2. 合并 ────────────────────────────────────
merged_count = 0
for (tid, norm), entries in dups.items():
    # 保留 name 最长的、properties 合并
    best = max(entries, key=lambda e: len(e[1]))
    best_id, best_name, best_props = best

    for oid, name, props in entries:
        if oid == best_id:
            continue
        # 合并 properties
        for k, v in props.items():
            if k not in best_props or best_props[k] is None:
                best_props[k] = v

        # 更新 links 指向旧 entity → best entity
        cur.execute("UPDATE links SET source_id = %s WHERE source_id = %s", (best_id, oid))
        cur.execute("UPDATE links SET target_id = %s WHERE target_id = %s", (best_id, oid))
        # 删除重复的 links
        cur.execute("DELETE FROM links WHERE id IN (SELECT id FROM links WHERE source_id=%s AND target_id=%s AND id NOT IN (SELECT min(id) FROM links WHERE source_id=%s AND target_id=%s GROUP BY source_id, target_id, type_id))",
                   (best_id, best_id, best_id, best_id))
        # 删除旧 entity
        cur.execute("DELETE FROM objects WHERE id = %s", (oid,))
        merged_count += 1
        print(f"  合并: '{name}' → '{best_name}' (type_id={tid})")

    # 更新最佳实体的 properties
    import json
    cur.execute("UPDATE objects SET properties = %s WHERE id = %s",
               (json.dumps(best_props, ensure_ascii=False), best_id))

# ── 3. 去重 links（同 source+target+type 去重）─
cur.execute("""
    DELETE FROM links WHERE id NOT IN (
        SELECT min(id) FROM links GROUP BY source_id, target_id, type_id
    )
""")
dup_links = cur.rowcount

conn.commit()

# ── 4. 统计 ────────────────────────────────────
cur.execute("SELECT count(*) FROM objects")
objs = cur.fetchone()[0]
cur.execute("SELECT count(*) FROM links")
links = cur.fetchone()[0]

print(f"\n✅ 完成: 合并 {merged_count} 个实体, 删除 {dup_links} 条重复关系")
print(f"   实体: {objs} | 关系: {links}")

cur.close()
conn.close()
