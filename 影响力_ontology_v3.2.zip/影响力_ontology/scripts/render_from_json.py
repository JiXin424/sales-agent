#!/usr/bin/env python3
"""从 influence_ontology.json 重新渲染 markdown 主体文件。"""

import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JSON_PATH = os.path.join(BASE_DIR, "influence_ontology.json")
OUT_MD = os.path.join(BASE_DIR, "主体文件-影响力.md")

ENTITY_KEYS = [
    "principles", "concepts", "terms", "cases", "experiments",
    "persons", "reasoning_chains", "tactics", "action_steps",
    "scripts", "scenarios"
]


def to_yaml_like_value(v):
    if v is None:
        return ""
    if isinstance(v, list):
        if not v:
            return ""
        return "; ".join(str(x) for x in v)
    return str(v)


def render_markdown(data):
    lines = ["# 《影响力（经典版）》知识本体", ""]
    lines.append("> 从清洗文本自动抽取的语义层、思维链、行动链三层结构。")
    lines.append("> 生成时间：自动生成，待人工抽检。")
    lines.append("")

    lines.append("## 统计摘要")
    lines.append("")
    for key in ENTITY_KEYS:
        lines.append(f"- {key}: {len(data.get(key, []))}")
    lines.append(f"- relations: {len(data.get('relations', []))}")
    lines.append("")

    for key in ENTITY_KEYS:
        if not data.get(key):
            continue
        cn_name = {
            "principles": "影响力原则",
            "concepts": "核心概念",
            "terms": "术语",
            "cases": "案例",
            "experiments": "实验",
            "persons": "人物",
            "reasoning_chains": "推理链",
            "tactics": "策略/技巧",
            "action_steps": "行动步骤",
            "scripts": "话术",
            "scenarios": "应用场景",
        }[key]
        lines.append(f"## {cn_name} ({len(data[key])})")
        lines.append("")
        for item in data[key]:
            name = item.get("name", item.get("id", ""))
            item_id = item.get("id", "")
            lines.append(f"### {name} (`{item_id}`)")
            for k, v in item.items():
                if k in ("id", "name"):
                    continue
                val = to_yaml_like_value(v)
                if val:
                    lines.append(f"- **{k}**: {val}")
            lines.append("")

    lines.append(f"## 关系 ({len(data.get('relations', []))})")
    lines.append("")
    for r in data.get("relations", []):
        rel_type = r.get("relation_type", "")
        from_id = r.get("from_id", "")
        to_id = r.get("to_id", "")
        desc = r.get("description", "")
        line = f"- `{from_id}` —[{rel_type}]→ `{to_id}`"
        if desc:
            line += f": {desc}"
        lines.append(line)
    lines.append("")

    return "\n".join(lines)


def main():
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    md = render_markdown(data)
    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"Saved {OUT_MD}")


if __name__ == "__main__":
    main()
