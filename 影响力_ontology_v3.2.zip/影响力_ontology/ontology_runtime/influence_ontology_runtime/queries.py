"""简单查询 DSL 解析器。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class Query:
    entity_type: Optional[str] = None
    principle_id: Optional[str] = None
    name_contains: Optional[str] = None
    relation_from: Optional[str] = None
    relation_to: Optional[str] = None
    relation_type: Optional[str] = None
    free_text: Optional[str] = None


class QueryParser:
    """解析形如 `type=Case principle=reciprocity-principle` 的查询字符串。"""

    @staticmethod
    def parse(query_str: str) -> Query:
        q = Query()
        tokens = [t.strip() for t in query_str.split() if t.strip()]
        for token in tokens:
            if "=" in token:
                key, value = token.split("=", 1)
                key = key.strip().lower()
                value = value.strip()
                if key in ("type", "t"):
                    q.entity_type = value
                elif key in ("principle", "p"):
                    q.principle_id = value
                elif key in ("name", "n"):
                    q.name_contains = value
                elif key in ("from", "f"):
                    q.relation_from = value
                elif key in ("to", "t"):
                    q.relation_to = value
                elif key in ("relation", "r"):
                    q.relation_type = value
            else:
                q.free_text = token if q.free_text is None else q.free_text + " " + token
        return q


def execute(store: Any, query: Query) -> List[Any]:
    """在 store 上执行 Query，返回实体列表。"""
    results: List[Any] = []

    # 原则-centric 查询
    if query.principle_id and query.entity_type:
        t = store.resolve_type(query.entity_type)
        if t == "case":
            results = store.get_cases_by_principle(query.principle_id)
        elif t == "experiment":
            results = store.get_experiments_by_principle(query.principle_id)
        elif t == "tactic":
            results = store.get_tactics_by_principle(query.principle_id)
        elif t == "concept":
            results = store.get_concepts_by_principle(query.principle_id)
        elif t == "reasoning_chain":
            results = store.get_reasoning_chains_by_principle(query.principle_id)
        elif t == "script":
            results = store.get_scripts_by_principle(query.principle_id)
    elif query.principle_id:
        # 未指定类型，返回所有相关实体
        results = store._principle_index.get(query.principle_id, [])
    elif query.entity_type:
        t = store.resolve_type(query.entity_type)
        results = store.get_by_type(t) if t else []
    elif query.name_contains:
        results = store.get_by_name(query.name_contains, fuzzy=True)
    elif query.free_text:
        results = store.search(query.free_text)
    else:
        return []

    # 二次过滤：name_contains
    if query.name_contains:
        q = query.name_contains.lower()
        results = [e for e in results if e.name and q in e.name.lower()]

    return results
