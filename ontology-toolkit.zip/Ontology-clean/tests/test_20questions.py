"""Sprint 2 — 20问标准测试集

基于九峰医疗本体知识的标准问答对，验证推理引擎准确率。
"""

import asyncio
import json
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import select, text
from sqlalchemy.orm import selectinload

from backend.db import engine, async_session
from backend.ontology.models import Base, Object, Link
from backend.ontology.crud import ensure_default_types
from backend.document.pipeline import process_document
from backend.reasoning.intent import classify_intent
from backend.reasoning.engine import ReasoningEngine
from backend.reasoning.response import generate_response


# 20 标准问答对
TEST_QUESTIONS = [
    # 实体查询 (entity_info) - 6题
    {"q": "九峰医疗有哪些产品？", "intent": "entity_info", "keywords": ["肺结核", "AI", "5G", "预警", "影像"]},
    {"q": "九峰医疗获得了哪些资质认证？", "intent": "entity_info", "keywords": ["ISO", "等保", "三类", "二类", "认证"]},
    {"q": "医学影像AI筛查系统是什么？", "intent": "entity_info", "keywords": ["影像", "AI", "筛查"]},
    {"q": "远程医疗移动车载平台有什么功能？", "intent": "entity_info", "keywords": ["远程", "车载", "5G"]},
    {"q": "基层传染病预警系统包括什么？", "intent": "entity_info", "keywords": ["传染病", "预警", "基层"]},
    {"q": "九峰医疗的目标客户群体是谁？", "intent": "entity_info", "keywords": ["基层", "医院", "医疗"]},

    # 关系查询 (relation_query) - 4题
    {"q": "肺结核AI软件属于哪个公司？", "intent": "relation_query", "keywords": ["九峰", "肺结核"]},
    {"q": "哪些产品获得了资质认证？", "intent": "relation_query", "keywords": ["认证", "资质"]},
    {"q": "5G+AI预警平台和远程医疗平台的关系是什么？", "intent": "relation_query", "keywords": ["5G", "远程", "AI"]},
    {"q": "九峰医疗的产品面向哪些客户？", "intent": "relation_query", "keywords": ["基层", "医院", "客户"]},

    # 场景 (scenario) - 3题
    {"q": "5G+AI预警平台用在什么场景？", "intent": "scenario", "keywords": ["5G", "场景", "预警"]},
    {"q": "肺结核AI软件解决什么问题？", "intent": "scenario", "keywords": ["肺结核", "筛查", "诊断"]},
    {"q": "基层传染病预警系统适用于哪些场景？", "intent": "scenario", "keywords": ["基层", "传染病", "预警"]},

    # 比较 (comparison) - 2题
    {"q": "九峰医疗和竞品相比有什么优势？", "intent": "comparison", "keywords": ["优势", "竞品", "AI"]},
    {"q": "肺结核AI软件和传统筛查方法比怎么样？", "intent": "comparison", "keywords": ["AI", "传统", "筛查"]},

    # 拜访准备 (prep) - 2题
    {"q": "帮我准备拜访基层医院的材料", "intent": "prep", "keywords": ["基层", "医院", "拜访"]},
    {"q": "我要去见客户，帮我准备产品介绍要点", "intent": "prep", "keywords": ["产品", "介绍", "客户"]},

    # 异议处理 (objection) - 2题
    {"q": "客户说你们的系统太贵了怎么回应？", "intent": "objection", "keywords": ["价格", "贵", "回应"]},
    {"q": "客户问你们的AI诊断靠谱吗？怎么回答", "intent": "objection", "keywords": ["AI", "诊断", "可靠"]},

    # 一般 (general) - 1题
    {"q": "你好", "intent": "general", "keywords": []},
]


async def run_test_set():
    """运行20问测试"""
    print("=== 20问标准测试集 ===\n")

    # 1. 准备数据
    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)

    async with async_session() as session:
        await ensure_default_types(session)

        # 导入九峰数据
        test_file = "/Users/fred/Documents/cc_Projects/Taishan/一期库/九峰/raw/九峰_公司产品/九峰_公司介绍_20250520_v1_方铭.docx"
        if os.path.exists(test_file):
            print(f"导入文档: {os.path.basename(test_file)}")
            result = await process_document(test_file, session)
            print(f"  实体: {result['objects_count']}, 关系: {result['links_count']}\n")
        else:
            print("⚠ 测试文件不存在，跳过数据导入\n")

        await session.commit()

    # 2. 运行测试
    results = []
    correct_intent = 0
    answer_quality = 0
    total_time = 0

    async with async_session() as session:
        for i, test in enumerate(TEST_QUESTIONS):
            q = test["q"]
            expected_intent = test["intent"]
            keywords = test["keywords"]

            start = time.time()

            # 意图分类
            intent_result = await classify_intent(q)
            intent = intent_result["intent"]

            # 推理
            rengine = ReasoningEngine(session)
            context = await rengine.reason(q, intent_result)

            # 生成回答
            if intent != "general":
                response = await generate_response(q, context)
                answer = response["answer"]
                evidence = response.get("evidence", [])
                confidence = response.get("confidence", 0)
            else:
                answer = "一般性问候"
                evidence = []
                confidence = 1.0

            elapsed = time.time() - start
            total_time += elapsed

            # 评估
            intent_ok = intent == expected_intent
            keyword_hit = sum(1 for kw in keywords if kw in answer) if keywords else 0
            quality_ok = keyword_hit >= 1 or intent == "general"

            if intent_ok:
                correct_intent += 1
            if quality_ok:
                answer_quality += 1

            status = "✅" if intent_ok and quality_ok else ("⚠" if intent_ok else "❌")
            results.append({
                "idx": i + 1,
                "status": status,
                "intent_ok": intent_ok,
                "quality_ok": quality_ok,
                "intent": f"{intent}(expect:{expected_intent})",
                "time": f"{elapsed:.1f}s",
                "answer_preview": answer[:80],
            })

            print(f"  Q{i+1:02d} {status} [{elapsed:.1f}s] {intent:12s} | {answer[:60]}")

    # 3. 统计
    print(f"\n=== 统计 ===")
    print(f"  意图准确率: {correct_intent}/{len(TEST_QUESTIONS)} = {correct_intent/len(TEST_QUESTIONS)*100:.0f}%")
    print(f"  回答质量:   {answer_quality}/{len(TEST_QUESTIONS)} = {answer_quality/len(TEST_QUESTIONS)*100:.0f}%")
    print(f"  平均耗时:   {total_time/len(TEST_QUESTIONS):.1f}s")
    print(f"  总耗时:     {total_time:.1f}s")

    intent_pct = correct_intent / len(TEST_QUESTIONS) * 100
    quality_pct = answer_quality / len(TEST_QUESTIONS) * 100

    print(f"\n=== 验收 ===")
    print(f"  意图准确率 > 80%: {'✅' if intent_pct > 80 else '❌'} ({intent_pct:.0f}%)")
    print(f"  回答质量 > 70%:   {'✅' if quality_pct > 70 else '❌'} ({quality_pct:.0f}%)")
    print(f"  平均耗时 < 5s:    {'✅' if total_time/len(TEST_QUESTIONS) < 5 else '❌'} ({total_time/len(TEST_QUESTIONS):.1f}s)")

    await engine.dispose()

    return {
        "intent_accuracy": intent_pct,
        "answer_quality": quality_pct,
        "avg_time": total_time / len(TEST_QUESTIONS),
    }


if __name__ == "__main__":
    asyncio.run(run_test_set())
