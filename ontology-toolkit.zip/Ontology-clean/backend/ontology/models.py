"""SQLAlchemy 数据模型 — 本体存储"""

from datetime import datetime, timezone

from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    DateTime,
    ForeignKey,
    JSON,
    Index,
)
from sqlalchemy.orm import DeclarativeBase, relationship
from pgvector.sqlalchemy import Vector


class Base(DeclarativeBase):
    pass


class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    file_type = Column(String(20))
    md_content = Column(Text)
    status = Column(String(20), default="pending")
    version_date = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    objects = relationship("Object", back_populates="source_document")


class ObjectType(Base):
    __tablename__ = "object_types"

    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)
    description = Column(Text)

    objects = relationship("Object", back_populates="type")


class Object(Base):
    __tablename__ = "objects"

    id = Column(Integer, primary_key=True)
    type_id = Column(Integer, ForeignKey("object_types.id"))
    name = Column(String(255), nullable=False)
    properties = Column(JSON, default=dict)
    embedding = Column(Vector(1024))
    source_document_id = Column(Integer, ForeignKey("documents.id"))
    version = Column(Integer, default=1)
    version_date = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    type = relationship("ObjectType", back_populates="objects")
    source_document = relationship("Document", back_populates="objects")
    source_links = relationship("Link", foreign_keys="Link.source_id", back_populates="source")
    target_links = relationship("Link", foreign_keys="Link.target_id", back_populates="target")

    __table_args__ = (
        Index("ix_objects_name", "name"),
        Index("ix_objects_type_id", "type_id"),
    )


class LinkType(Base):
    __tablename__ = "link_types"

    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)
    description = Column(Text)

    links = relationship("Link", back_populates="type")


class Link(Base):
    __tablename__ = "links"

    id = Column(Integer, primary_key=True)
    type_id = Column(Integer, ForeignKey("link_types.id"))
    source_id = Column(Integer, ForeignKey("objects.id"))
    target_id = Column(Integer, ForeignKey("objects.id"))
    properties = Column(JSON, default=dict)
    version = Column(Integer, default=1)
    version_date = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    type = relationship("LinkType", back_populates="links")
    source = relationship("Object", foreign_keys=[source_id], back_populates="source_links")
    target = relationship("Object", foreign_keys=[target_id], back_populates="target_links")

    __table_args__ = (
        Index("ix_links_source_id", "source_id"),
        Index("ix_links_target_id", "target_id"),
    )


class Feedback(Base):
    __tablename__ = "feedbacks"

    id = Column(Integer, primary_key=True)
    question = Column(Text, nullable=False)
    answer = Column(Text)
    intent = Column(String(50))
    rating = Column(Integer)  # 1-5
    comment = Column(Text)
    entities = Column(JSON, default=list)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Conflict(Base):
    """版本冲突记录 — 无法自动判断版本时的待人工确认项"""
    __tablename__ = "conflicts"

    id = Column(Integer, primary_key=True)
    object_id = Column(Integer, ForeignKey("objects.id"), nullable=True)
    link_id = Column(Integer, ForeignKey("links.id"), nullable=True)
    conflict_type = Column(String(50))  # property_mismatch, version_unknown, duplicate_entity
    old_value = Column(JSON)
    new_value = Column(JSON)
    status = Column(String(20), default="pending")  # pending / resolved / dismissed
    resolution = Column(Text)  # 人工确认结果
    source_document_id = Column(Integer, ForeignKey("documents.id"))
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


# 默认实体类型 (22种)
DEFAULT_OBJECT_TYPES = [
    # --- 核心商业 ---
    ("Company", "公司/组织"),
    ("Product", "产品/服务"),
    ("Competitor", "竞争对手"),
    ("CustomerSegment", "客户群体/目标市场"),
    ("Partner", "代理商/渠道/合作伙伴"),
    # --- 产品详情 ---
    ("Feature", "产品特性/功能"),
    ("Spec", "技术规格参数"),
    ("Equipment", "硬件设备/器械"),
    ("Pricing", "定价/价格信息"),
    ("Certification", "资质/认证"),
    ("Award", "奖项/荣誉/认可"),
    # --- 场景与方案 ---
    ("Scenario", "应用场景/客户场景"),
    ("Solution", "解决方案（产品+服务组合）"),
    ("Disease", "疾病/病种（AI检测目标）"),
    ("Industry", "行业分类"),
    # --- 销售策略 ---
    ("Objection", "客户异议"),
    ("SalesScript", "推荐应对话术"),
    ("Case", "成功案例/参考案例"),
    ("Advantage", "竞争优势/独特价值"),
    # --- 政策与生态 ---
    ("Policy", "政策/法规/红头文件"),
    ("Contact", "联系人/决策者"),
    ("Institution", "机构/组织（非公司，如WHO/防痨协会）"),
]

# 默认关系类型 (22种)
DEFAULT_LINK_TYPES = [
    # --- 产品关系 ---
    ("produces", "公司生产产品"),
    ("competes_with", "竞争关系"),
    ("targets", "面向客户/场景"),
    ("includes", "包含特性"),
    ("priced_at", "定价"),
    ("certified_for", "获得认证"),
    ("solves", "解决场景/问题"),
    ("has_spec", "产品有规格参数"),
    ("detects", "产品检测疾病"),
    ("component_of", "硬件是产品组件"),
    # --- 方案关系 ---
    ("part_of", "产品属于解决方案"),
    ("demonstrated_in", "特性在案例中体现"),
    ("uses", "案例使用产品/话术"),
    # --- 销售策略关系 ---
    ("triggers", "场景触发异议"),
    ("handled_by", "异议由话术处理"),
    ("supported_by", "优势由证据支撑"),
    ("mandates", "政策驱动场景/要求"),
    # --- 组织关系 ---
    ("belongs_to", "属于行业/上级"),
    ("contact_at", "联系人在客户处"),
    ("distributes", "代理商分销产品"),
    ("awarded_to", "奖项授予公司/产品"),
    ("cooperates_with", "合作关系"),
]
