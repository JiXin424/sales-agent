#!/usr/bin/env python3
"""按块抽取剩余章节的 ontology。"""

import json
import os
import time

import requests

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DIR = os.path.join(BASE_DIR, "raw")
TEXT_PATH = os.path.join(os.path.dirname(BASE_DIR), "影响力（经典版）(1)_cleaned.txt")

CHUNKS = {
    "commitment": [325, 440, 520, 599],
    "social-proof": [599, 720, 843],
    "scarcity": [1197, 1280, 1412],
}


def load_env():
    env_path = "/Users/fred/Documents/cc_Projects/Taishan/new-software/langchain-video-system/.env"
    if os.path.isfile(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k, v = k.strip(), v.strip()
                    if k in ("ARK_API_KEY",):
                        os.environ.setdefault(k, v)


def call_llm(text: str) -> dict:
    api_key = os.environ["ARK_API_KEY"]
    model = "doubao-1-5-pro-32k-250115"

    system_prompt = """你是一位知识本体工程师。请从《影响力（经典版）》的章节文本片段中，抽取语义层、思维链、行动链三层结构。只输出合法 JSON。"""

    user_prompt = f"""请从以下《影响力（经典版）》章节片段中抽取知识本体，输出 JSON。

Schema：principles, concepts, terms, cases, experiments, persons, reasoning_chains, tactics, action_steps, scripts, scenarios, relations
每个实体必须有 id（kebab-case）和 name。relations 包含 relation_type, from_id, to_id。
只输出文本中明确提到的内容。输出必须是合法 JSON，不要有任何额外说明。

文本：
{text}
"""

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.3,
        "max_tokens": 12000,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    resp = requests.post(
        "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
        json=payload,
        headers=headers,
        timeout=300,
    )
    resp.raise_for_status()
    data = resp.json()
    content = data["choices"][0]["message"]["content"]
    start = content.find("{")
    end = content.rfind("}") + 1
    return json.loads(content[start:end])


def merge_chunks(parts):
    merged = {}
    for part in parts:
        for key, items in part.items():
            if not isinstance(items, list):
                continue
            merged.setdefault(key, []).extend(items)
    return merged


def main():
    load_env()
    os.makedirs(RAW_DIR, exist_ok=True)

    with open(TEXT_PATH, "r", encoding="utf-8") as f:
        lines = f.read().split("\n")

    for ch_id, boundaries in CHUNKS.items():
        out_path = os.path.join(RAW_DIR, f"{ch_id}.json")
        if os.path.exists(out_path):
            print(f"Skip {ch_id}: already exists")
            continue

        parts = []
        for i in range(len(boundaries) - 1):
            start_line, end_line = boundaries[i], boundaries[i + 1]
            text = "\n".join(lines[start_line:end_line])
            print(f"Extracting {ch_id} part {i + 1}/{len(boundaries) - 1} ({len(text)} chars)...")
            try:
                result = call_llm(text)
                parts.append(result)
                print(f"  OK: {sum(len(v) for v in result.values() if isinstance(v, list))} entities")
            except Exception as e:
                print(f"  ERROR: {e}")
            time.sleep(1)

        if parts:
            merged = merge_chunks(parts)
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(merged, f, ensure_ascii=False, indent=2)
            print(f"Saved {out_path}\n")


if __name__ == "__main__":
    main()
