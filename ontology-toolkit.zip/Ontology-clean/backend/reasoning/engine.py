"""多跳推理引擎 — 图遍历 + 向量搜索 + 类型感知"""

import logging
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.ontology.models import Object, Link, ObjectType
from backend.ontology.graph import OntologyGraph
from backend.ontology.embedding import search_similar
from backend.llm import embed

logger = logging.getLogger(__name__)

# 意图到实体类型的映射
INTENT_TYPE_MAP = {
    "entity_info": None,       # 不限类型
    "relation_query": None,
    "comparison": ["Product", "Competitor", "Feature", "Spec", "Equipment", "Pricing", "Certification", "Award"],
    "scenario": ["Scenario", "Product", "Solution", "Policy", "Disease"],
    "prep": ["Company", "Product", "Scenario", "CustomerSegment", "Contact", "Policy", "Partner", "Advantage"],
    "objection": ["Objection", "SalesScript", "Advantage", "Case", "Policy", "Certification", "Pricing"],
}

# 实体类型关键词映射（用于从实体名推断类型）
TYPE_KEYWORDS = {
    "Product": ["产品", "软件", "系统", "平台", "服务", "彩超", "DR", "CT", "AI", "试剂盒"],
    "Certification": ["认证", "证书", "资质", "等保", "ISO", "注册证", "监管机构A", "CE", "监管机构B"],
    "Scenario": ["场景", "应用", "用途", "筛查", "体检", "诊断", "防治"],
    "Company": ["公司", "企业", "九峰", "推想", "智影", "数坤", "掌引", "健乃喜"],
    "CustomerSegment": ["客户", "医院", "机构", "卫生院", "三甲", "基层", "体检中心", "高校", "疾控"],
    "Objection": ["异议", "贵", "太贵", "价格高", "品牌", "不信任", "不需要", "怕出事", "怕风险"],
    "SalesScript": ["话术", "回应", "应对", "怎么说", "回复", "卖点", "推荐"],
    "Case": ["案例", "成功案例", "客户案例", "参考案例", "标杆", "落地"],
    "Spec": ["规格", "参数", "分辨率", "速度", "精度", "尺寸", "重量", "敏感度", "特异性"],
    "Industry": ["行业", "领域", "医疗", "影像", "AI诊断", "体外诊断", "IVD"],
    "Contact": ["主任", "院长", "科长", "经理", "负责人", "决策", "领导", "局长"],
    "Solution": ["解决方案", "方案", "打包", "整体", "一体化"],
    "Policy": ["政策", "法规", "文件", "通知", "规划", "管理办法", "红头文件", "指南", "国卫"],
    "Advantage": ["优势", "独特价值", "壁垒", "差异化", "核心竞争", "为什么选"],
    "Disease": ["肺结核", "结核", "肺炎", "结节", "肿瘤", "骨折", "气胸", "慢阻肺", "COPD"],
    "Equipment": ["设备", "硬件", "探测器", "服务器", "显示器", "高压发生器", "球管", "路由器"],
    "Partner": ["代理商", "渠道", "经销商", "合作伙伴", "代理", "分销"],
    "Award": ["奖项", "冠军", "推荐", "荣誉", "认可", "科技进步", "大赛"],
    "Institution": ["WHO", "防痨协会", "疾控中心", "疾控局", "卫健委", "NIH", "FIND"],
}


class ReasoningEngine:
    """多跳推理引擎"""

    def __init__(self, session: AsyncSession):
        self.session = session
        self.graph = OntologyGraph()
        self._graph_built = False

    async def _build_graph(self):
        if not self._graph_built:
            await self.graph.build_from_db(self.session)
            self._graph_built = True

    async def find_entities(self, names: list[str], intent: str = "entity_info") -> list[dict]:
        """多策略实体查找：名称匹配 → 关键词拆分 → 类型推断 → 向量搜索"""
        # 策略1: ILIKE 名称匹配
        results = await self._find_by_name(names)
        if len(results) >= 3:
            return results

        # 策略2: 关键词拆分匹配（处理"九峰医疗" vs "九峰智慧医疗"）
        keyword_results = await self._find_by_keywords(names)
        existing_ids = {r["id"] for r in results}
        for r in keyword_results:
            if r["id"] not in existing_ids:
                results.append(r)
                existing_ids.add(r["id"])
        if len(results) >= 2:
            return results

        # 策略3: 类型推断匹配
        type_results = await self._find_by_type_from_names(names)
        for r in type_results:
            if r["id"] not in existing_ids:
                results.append(r)
                existing_ids.add(r["id"])
        if len(results) >= 1:
            return results

        # 策略4: 向量相似度搜索（仅用于 comparison，且只补充距离<0.4的高相关结果）
        if intent == "comparison":
            vector_results = await self._find_by_vector(" ".join(names))
            for r in vector_results:
                if r["id"] not in existing_ids:
                    dist = r.get("distance", 1.0)
                    if dist < 0.4 and len(results) < 6:
                        results.append(r)
                        existing_ids.add(r["id"])

        return results

    async def _find_by_name(self, names: list[str]) -> list[dict]:
        """ILIKE 名称模糊匹配"""
        stmt = (
            select(Object)
            .options(selectinload(Object.type))
            .where(or_(*[Object.name.ilike(f"%{n}%") for n in names]))
        )
        results = (await self.session.execute(stmt)).scalars().all()
        return [self._object_to_dict(o) for o in results]

    async def _find_by_keywords(self, names: list[str]) -> list[dict]:
        """关键词拆分匹配：将实体名拆成2字片段"""
        keywords = set()
        for name in names:
            keywords.add(name)
            # 2字滑动窗口
            for i in range(len(name) - 1):
                keywords.add(name[i:i+2])
            # 保留核心部分（去掉常见后缀）
            for suffix in ["医疗", "公司", "软件", "系统", "平台", "服务"]:
                if name.endswith(suffix) and len(name) > len(suffix):
                    keywords.add(name[:len(name)-len(suffix)])

        conditions = [Object.name.ilike(f"%{kw}%") for kw in keywords if len(kw) >= 2]
        if not conditions:
            return []

        stmt = (
            select(Object)
            .options(selectinload(Object.type))
            .where(or_(*conditions))
        )
        results = (await self.session.execute(stmt)).scalars().all()
        return [self._object_to_dict(o) for o in results]

    async def _find_by_type_from_names(self, names: list[str]) -> list[dict]:
        """从实体名推断类型并查找"""
        target_types = set()
        for name in names:
            for type_name, keywords in TYPE_KEYWORDS.items():
                for kw in keywords:
                    if kw in name:
                        target_types.add(type_name)

        if not target_types:
            return []

        stmt = (
            select(Object)
            .options(selectinload(Object.type), selectinload(Object.type))
        )
        all_objects = (await self.session.execute(stmt)).scalars().all()

        return [
            self._object_to_dict(o)
            for o in all_objects
            if o.type and o.type.name in target_types
        ]

    async def _find_by_vector(self, query: str, top_k: int = 5) -> list[dict]:
        """向量相似度搜索"""
        try:
            query_embedding = (await embed([query]))[0]
            results = await search_similar(self.session, query_embedding, limit=top_k)
            return [
                {
                    "id": r["id"],
                    "name": r["name"],
                    "type": r["type"],
                    "properties": r.get("properties", {}),
                }
                for r in results
            ]
        except Exception as e:
            logger.warning(f"向量搜索失败: {e}")
            return []

    def _object_to_dict(self, o: Object) -> dict:
        return {
            "id": o.id,
            "name": o.name,
            "type": o.type.name if o.type else "?",
            "properties": o.properties or {},
        }

    async def gather_context(
        self,
        entity_names: list[str],
        intent: str = "entity_info",
        max_hops: int = 2,
    ) -> dict:
        """收集回答所需上下文：实体 + 关系 + 多跳邻居"""
        await self._build_graph()

        # 1. 多策略查找实体
        entities = await self.find_entities(entity_names, intent=intent)

        # 2. 如果意图有类型约束，追加该类型实体
        target_types = INTENT_TYPE_MAP.get(intent)
        if target_types:
            type_entities = await self._find_by_types(target_types)
            existing_ids = {e["id"] for e in entities}
            for e in type_entities:
                if e["id"] not in existing_ids:
                    entities.append(e)
                    existing_ids.add(e["id"])

        # 3. comparison 专用：确保双方实体都找到
        if intent == "comparison":
            entities = await self._enrich_comparison_entities(entity_names, entities)

        # 4. objection 专用：查找异议→话术链及相关证据（限制数量避免prompt过长）
        if intent == "objection":
            existing_ids = {e["id"] for e in entities}
            for type_name in ["Objection", "SalesScript", "Advantage", "Case", "Policy"]:
                type_entities = await self._find_by_types([type_name])
                added = 0
                for e in type_entities:
                    if e["id"] not in existing_ids and added < 5:
                        entities.append(e)
                        existing_ids.add(e["id"])
                        added += 1

        # 5. 收集相关实体 ID
        center_ids = {e["id"] for e in entities}
        all_entity_ids = set(center_ids)

        # 6. 多跳遍历
        hop_entities = {}
        for cid in list(center_ids)[:10]:  # 限制中心节点数
            hops = self.graph.multi_hop_neighbors(cid, max_hops=max_hops)
            for hop_level, neighbors in hops.items():
                hop_entities[hop_level] = hop_entities.get(hop_level, [])
                for n in neighbors[:20]:  # 每跳最多20个邻居
                    all_entity_ids.add(n["id"])
                    hop_entities[hop_level].append(n)

        # 7. 加载所有相关实体详情
        if all_entity_ids:
            stmt = (
                select(Object)
                .options(selectinload(Object.type))
                .where(Object.id.in_(all_entity_ids))
            )
            all_objects = (await self.session.execute(stmt)).scalars().all()
            entities = [self._object_to_dict(o) for o in all_objects]

        # 8. 收集相关关系
        relations = []
        if all_entity_ids:
            stmt = (
                select(Link)
                .options(selectinload(Link.type), selectinload(Link.source), selectinload(Link.target))
                .where(
                    (Link.source_id.in_(all_entity_ids)) | (Link.target_id.in_(all_entity_ids))
                )
            )
            links = (await self.session.execute(stmt)).scalars().all()
            for link in links:
                relations.append({
                    "source": link.source.name if link.source else "?",
                    "target": link.target.name if link.target else "?",
                    "type": link.type.name if link.type else "?",
                })

        # 9. 收集子图（用于复杂意图）
        subgraph = None
        if intent in ("comparison", "scenario", "prep") and center_ids:
            center_id = next(iter(center_ids))
            subgraph = self.graph.get_subgraph(center_id, radius=2)

        return {
            "entities": entities,
            "relations": relations,
            "hop_entities": hop_entities,
            "subgraph": subgraph,
            "center_ids": list(center_ids),
        }

    async def _enrich_comparison_entities(self, names: list[str], existing: list[dict]) -> list[dict]:
        """对比意图：确保竞品/对比对象也被检索到"""
        # 竞品名关键词映射
        COMPETITOR_MAP = {
            "智影": ["智影", "I-Sight"],
            "推想": ["推想", "InferRead"],
            "健乃喜": ["健乃喜"],
            "掌引": ["掌引"],
            "数坤": ["数坤"],
        }
        existing_ids = {e["id"] for e in existing}
        existing_names = " ".join(e["name"] for e in existing)

        # 检查问题中是否包含竞品关键词
        for name in names:
            for comp_key, comp_aliases in COMPETITOR_MAP.items():
                if comp_key in name or comp_key in existing_names:
                    # 找所有相关竞品实体
                    conditions = [Object.name.ilike(f"%{alias}%") for alias in comp_aliases]
                    stmt = (
                        select(Object)
                        .options(selectinload(Object.type))
                        .where(or_(*conditions))
                    )
                    results = (await self.session.execute(stmt)).scalars().all()
                    for o in results:
                        if o.id not in existing_ids:
                            existing.append(self._object_to_dict(o))
                            existing_ids.add(o.id)

        # 同时加载所有 Competitor 类型实体（确保对比上下文完整）
        competitors = await self._find_by_types(["Competitor", "Company"])
        for c in competitors:
            if c["id"] not in existing_ids:
                existing.append(c)
                existing_ids.add(c["id"])

        return existing

    async def _find_by_types(self, type_names: list[str]) -> list[dict]:
        """按类型查找实体"""
        stmt = (
            select(Object)
            .options(selectinload(Object.type))
            .join(ObjectType)
            .where(ObjectType.name.in_(type_names))
        )
        results = (await self.session.execute(stmt)).scalars().all()
        return [self._object_to_dict(o) for o in results]

    async def reason(self, question: str, intent_result: dict) -> dict:
        """完整推理流程"""
        entity_names = intent_result.get("entities", [])
        intent = intent_result.get("intent", "general")

        if intent == "general":
            return {"entities": [], "relations": [], "hop_entities": {}, "subgraph": None, "center_ids": []}

        # 如果没有提取到实体名，尝试用类型推断
        if not entity_names:
            target_types = INTENT_TYPE_MAP.get(intent)
            if target_types:
                entities = await self._find_by_types(target_types)
                if entities:
                    return await self.gather_context(
                        [], intent, 2
                    )
            return {"entities": [], "relations": [], "hop_entities": {}, "subgraph": None, "center_ids": []}

        max_hops = 3 if intent in ("comparison", "scenario", "prep") else 2
        return await self.gather_context(entity_names, intent, max_hops)
