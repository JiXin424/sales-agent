import { useState, useRef, useEffect } from 'react';
import { Input, Button, Spin, Card, Tag, List, Space, message } from 'antd';
import { SendOutlined, RobotOutlined, UserOutlined, LikeOutlined, DislikeOutlined } from '@ant-design/icons';
import { chatStream, submitFeedback } from '../services/api';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  intent?: string;
  evidence?: string[];
  confidence?: number;
  streaming?: boolean;
  feedbackGiven?: boolean;
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const appendToLast = (updater: (prev: Message) => Message) => {
    setMessages((prev) => {
      const copy = [...prev];
      const last = copy.length - 1;
      if (last >= 0) copy[last] = updater(copy[last]);
      return copy;
    });
  };

  const handleSend = async () => {
    const question = input.trim();
    if (!question || loading) return;

    const userMsg: Message = { role: 'user', content: question };
    const streamMsg: Message = { role: 'assistant', content: '', streaming: true };
    setMessages((prev) => [...prev, userMsg, streamMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await chatStream(question);
      const reader = res.body?.getReader();
      if (!reader) throw new Error('No response body');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data: ')) continue;
          const payload = trimmed.slice(6);
          if (payload === '[DONE]') continue;

          let evt: { type?: string; [k: string]: unknown };
          try { evt = JSON.parse(payload); } catch { continue; }

          if (evt.type === 'intent') {
            appendToLast((m) => ({ ...m, intent: evt.intent as string }));
          } else if (evt.type === 'token') {
            appendToLast((m) => ({ ...m, content: m.content + (evt.content as string) }));
          } else if (evt.type === 'done') {
            appendToLast((m) => ({
              ...m,
              content: (evt.answer as string) || m.content,
              evidence: evt.evidence as string[] || [],
              confidence: evt.confidence as number,
              streaming: false,
            }));
          }
        }
      }

      appendToLast((m) => ({ ...m, streaming: false }));
    } catch {
      appendToLast((m) => ({ ...m, content: '抱歉，发生了错误，请重试。', streaming: false }));
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = async (index: number, rating: number) => {
    const msg = messages[index];
    if (!msg || msg.role !== 'assistant' || msg.feedbackGiven) return;
    const question = index > 0 ? messages[index - 1].content : '';
    try {
      await submitFeedback({ question, answer: msg.content, rating });
    } catch { /* non-critical */ }
    setMessages((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], feedbackGiven: true };
      return copy;
    });
    message.success('感谢你的反馈！');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 48px)' }}>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 0 16px' }}>
        {messages.length === 0 && (
          <div style={{ textAlign: 'center', color: '#8b949e', marginTop: 120, fontSize: 16 }}>
            <RobotOutlined style={{ fontSize: 48, marginBottom: 16, display: 'block' }} />
            输入你的销售相关问题
          </div>
        )}
        {messages.map((msg, i) => (
          <div
            key={i}
            style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: 12 }}
          >
            <Card
              size="small"
              style={{
                maxWidth: '70%',
                background: msg.role === 'user' ? '#1f6feb' : '#161b22',
                borderColor: msg.role === 'user' ? '#1f6feb' : '#30363d',
                color: '#e6edf3',
              }}
            >
              <div style={{ marginBottom: 4, fontSize: 12, color: '#8b949e' }}>
                {msg.role === 'user' ? <UserOutlined /> : <RobotOutlined />}
                {' '}{msg.role === 'user' ? '你' : 'AI'}
              </div>
              {msg.intent && <Tag color="purple" style={{ marginBottom: 6 }}>{msg.intent}</Tag>}
              <div>
                {msg.content}
                {msg.streaming && <span className="typing-cursor" style={{ display: 'inline-block', width: 2, height: 14, background: '#58a6ff', marginLeft: 2, verticalAlign: 'middle', animation: 'blink 1s infinite' }} />}
              </div>
              {msg.evidence && msg.evidence.length > 0 && (
                <div style={{ marginTop: 8 }}>
                  <Tag color="blue">来源</Tag>
                  <List
                    size="small"
                    dataSource={msg.evidence}
                    renderItem={(item) => (
                      <List.Item style={{ border: 'none', padding: '2px 0', color: '#8b949e', fontSize: 12 }}>
                        {item}
                      </List.Item>
                    )}
                  />
                </div>
              )}
              {msg.confidence != null && (
                <Tag color={msg.confidence > 0.7 ? 'green' : msg.confidence > 0.4 ? 'orange' : 'red'}>
                  置信度: {(msg.confidence * 100).toFixed(0)}%
                </Tag>
              )}
              {msg.role === 'assistant' && !msg.streaming && (
                <div style={{ marginTop: 8, borderTop: '1px solid #30363d', paddingTop: 6 }}>
                  <Space size="small">
                    <Button
                      type="text"
                      size="small"
                      icon={<LikeOutlined />}
                      style={{ color: msg.feedbackGiven ? '#238636' : '#8b949e', padding: '0 4px' }}
                      onClick={() => handleFeedback(i, 4)}
                    />
                    <Button
                      type="text"
                      size="small"
                      icon={<DislikeOutlined />}
                      style={{ color: msg.feedbackGiven ? '#da3633' : '#8b949e', padding: '0 4px' }}
                      onClick={() => handleFeedback(i, 2)}
                    />
                    {msg.feedbackGiven && <span style={{ color: '#8b949e', fontSize: 12 }}>已反馈</span>}
                  </Space>
                </div>
              )}
            </Card>
          </div>
        ))}
        {loading && messages[messages.length - 1]?.streaming !== true && (
          <div style={{ textAlign: 'center', padding: 20 }}>
            <Spin tip="思考中..." />
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <style>{`@keyframes blink { 0%,100% { opacity: 1; } 50% { opacity: 0; } }`}</style>

      <div style={{ display: 'flex', gap: 8 }}>
        <Input
          size="large"
          placeholder="输入你的问题..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onPressEnter={handleSend}
          disabled={loading}
        />
        <Button type="primary" size="large" icon={<SendOutlined />} onClick={handleSend} loading={loading} />
      </div>
    </div>
  );
}
