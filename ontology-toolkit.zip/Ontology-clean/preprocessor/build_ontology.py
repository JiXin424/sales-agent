#!/usr/bin/env python3
"""
build_ontology — 项目本体自动构建工具

扫描输入文档（.md），用 DeepSeek Pro 抽取实体和关系，
合并去重后生成结构化主体文件，供 md_optimizer.py 注入 system prompt。

用法：
    python build_ontology.py <input.md|dir> [options]

输出规则：
    - 默认输出 ./主体文件-自动.md
    - 可选导出原始 ontology JSON（--dump-json）

示例：
    python build_ontology.py ./docs
    python build_ontology.py ./docs --types sales
    python build_ontology.py ./docs --dump-json ontology.json --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

# 复用 v2 项目已有模块
from md_optimizer import (
    OpenAIClient,
    _congestion,
    DEFAULT_MODEL,
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
)
from ontology_extractor import (
    load_type_config,
    extract_objects,
    extract_relations,
    merge_objects,
    merge_links,
    group_by_type,
    build_summary_text,
    render_subject_markdown,
)


_SCRIPT_DIR = Path(__file__).parent.resolve()
DEFAULT_OUTPUT_PATH = _SCRIPT_DIR / "主体文件-自动.md"
DEFAULT_TYPES_PRESET = "general"
DEFAULT_MAX_WORKERS = 3
MAX_BATCH_TOKENS = 200_000   # 每批上下文上限（token 估算）


# ──────────────────────────────────────────────────────────────
# Token 估算
# ──────────────────────────────────────────────────────────────

def _estimate_tokens(text: str) -> int:
    """粗略估算 token 数：中文 ~3chars/token，英文 ~4chars/token，混合取 3.5"""
    return max(1, len(text) * 2 // 7)  # ≈ len/3.5


# ──────────────────────────────────────────────────────────────
# 文件扫描
# ──────────────────────────────────────────────────────────────

def collect_md_files(src_path: Path) -> list[Path]:
    """收集所有 .md 文件（单文件或递归目录）"""
    if src_path.is_file():
        if not src_path.name.lower().endswith(".md"):
            return []
        return [src_path]

    files: list[Path] = []
    for root, _, fnames in os.walk(src_path):
        for fname in fnames:
            if fname.lower().endswith(".md"):
                files.append(Path(root) / fname)
    return sorted(files)


# ──────────────────────────────────────────────────────────────
# 单文档抽取
# ──────────────────────────────────────────────────────────────

def extract_from_single_doc(
    client: OpenAIClient,
    md_path: Path,
    type_config: dict,
    context_text: str = "",
) -> tuple[list[dict], list[dict]]:
    """抽取单个文档的实体和关系。

    Returns:
        (objects, links) — 可能是 ([], []) 如果抽取失败
    """
    import sys as _sys
    _sys.stderr.write(f"    [DEBUG] extract_from_single_doc START: {md_path.name}\n")
    _sys.stderr.flush()

    try:
        md_content = md_path.read_text(encoding="utf-8")
        _sys.stderr.write(f"    [DEBUG]   read: {len(md_content)}chars\n")
        _sys.stderr.flush()
    except Exception as e:
        print(f"    ❌ 读取失败 {md_path.name}: {e}")
        return [], []

    try:
        _congestion.wait()
        _sys.stderr.write(f"    [DEBUG]   calling extract_objects...\n")
        _sys.stderr.flush()
        objects = extract_objects(client, md_content, type_config, context_text)
        _congestion.release()
        _sys.stderr.write(f"    [DEBUG]   extract_objects done: {len(objects)} entities\n")
        _sys.stderr.flush()
    except Exception as e:
        _congestion.hit()
        print(f"    ❌ 实体抽取失败 {md_path.name}: {e}")
        return [], []

    if not objects:
        _sys.stderr.write(f"    [DEBUG]   no objects, skip relations\n")
        _sys.stderr.flush()
        return [], []

    try:
        _congestion.wait()
        _sys.stderr.write(f"    [DEBUG]   calling extract_relations...\n")
        _sys.stderr.flush()
        links = extract_relations(
            client, md_content, objects, type_config, context_text
        )
        _congestion.release()
        _sys.stderr.write(f"    [DEBUG]   extract_relations done: {len(links)} links\n")
        _sys.stderr.flush()
    except Exception as e:
        _congestion.hit()
        print(f"    ❌ 关系抽取失败 {md_path.name}: {e}")
        return objects, []

    _sys.stderr.write(f"    [DEBUG] extract_from_single_doc DONE: {md_path.name}\n")
    _sys.stderr.flush()
    return objects, links


# ──────────────────────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────────────────────

def build_ontology_from_path(
    src_path: Path,
    client: Optional[OpenAIClient],
    type_config: dict,
    max_workers: int = DEFAULT_MAX_WORKERS,
    dry_run: bool = False,
    on_progress=None,
    batch_size: int = 5,
    use_iterative_context: bool = True,
    max_subject_chars: int = 8000,
    max_doc_chars: int = 4000,
) -> dict:
    """主流程：扫描 → 并发抽取（含迭代 context 注入）→ 合并去重 → 生成摘要

    Args:
        batch_size: 迭代 context 注入的批次大小
        use_iterative_context: 是否启用迭代 context 注入
        max_subject_chars: 主体文件最大字符数（按相关性裁剪）
        max_doc_chars: 单文档内容截断字符数

    Returns:
        {
            "objects": [...],
            "links": [...],
            "groups": {...},
            "summary_text": "...",
            "subject_markdown": "...",
            "stats": {"docs", "raw_objects", "merged", "raw_links", ...}
        }
    """
    md_files = collect_md_files(src_path)
    if not md_files:
        print(f"❌ 未找到任何 .md 文件: {src_path}")
        sys.exit(1)

    total = len(md_files)
    print(f"\n📁 发现 {total} 个 .md 文件")
    print(f"🔬 本体类型：{type_config['title']}（{len(type_config['object_types'])} 实体 + "
          f"{len(type_config['relation_types'])} 关系）")
    if use_iterative_context:
        print(f"🔁 迭代 context 注入：每 {batch_size} 个文档更新一次背景知识")
    print(f"📏 主体文件上限：{max_subject_chars} 字符 | 单文档截断：{max_doc_chars} 字符")

    if dry_run:
        print("⏹️  dry-run 模式，跳过 LLM 调用")
        for f in md_files:
            print(f"    📄 {f.relative_to(src_path.parent) if src_path.is_dir() else f.name}")
        return {
            "objects": [],
            "links": [],
            "groups": {},
            "summary_text": "",
            "subject_markdown": "",
            "stats": {"docs": total, "raw_objects": 0, "merged": 0, "raw_links": 0},
        }

    if client is None:
        print("❌ client is None 且非 dry_run")
        sys.exit(1)

    print(f"⚡ 并发抽取（workers={max_workers}）...\n")

    start = time.time()
    all_objects: list[list[dict]] = []
    all_links: list[list[dict]] = []
    raw_object_count = 0
    raw_link_count = 0
    done_count = 0

    # 迭代 context 注入：按 batch_size 分批
    if use_iterative_context:
        context_text = ""
        batches = [
            md_files[i:i + batch_size]
            for i in range(0, len(md_files), batch_size)
        ]
        print(f"   分 {len(batches)} 批处理（每批最多 {batch_size} 个文档）\n")

        for batch_idx, batch in enumerate(batches, 1):
            # 估算本批总 token
            batch_content_tokens = sum(
                _estimate_tokens(p.read_text(encoding="utf-8")[:max_doc_chars])
                for p in batch
            )
            context_tokens = _estimate_tokens(context_text)
            total_est = batch_content_tokens + context_tokens

            print(f"   ── 批次 {batch_idx}/{len(batches)}（{len(batch)} 文档）"
                  f" 预估 {total_est:,} tokens（context {context_tokens:,} + 文档 {batch_content_tokens:,}）───")

            if total_est > MAX_BATCH_TOKENS:
                print(f"   ⚠️ 批次 token {total_est:,} > 上限 {MAX_BATCH_TOKENS:,}，"
                      f"建议用 split_large_files.py 拆分大文件后重跑")

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_path = {
                    executor.submit(
                        extract_from_single_doc, client, p, type_config, context_text
                    ): p
                    for p in batch
                }
                for future in as_completed(future_to_path):
                    path = future_to_path[future]
                    try:
                        objects, links = future.result()
                    except Exception as e:
                        print(f"    ❌ {path.name}: {e}")
                        objects, links = [], []

                    all_objects.append(objects)
                    all_links.append(links)
                    raw_object_count += len(objects)
                    raw_link_count += len(links)
                    done_count += 1

                    print(
                        f"    [{done_count}/{total}] {path.name}: "
                        f"{len(objects)} 实体 / {len(links)} 关系"
                    )
                    if on_progress:
                        on_progress(done_count, total, path)

            # 批次结束：更新 context
            if all_objects:
                batch_merged = merge_objects(all_objects)
                valid_names = {o["name"].lower() for o in batch_merged}
                batch_links = merge_links(all_links, valid_names)
                groups = group_by_type(batch_merged, type_config)
                # context 截断到 6000 字符
                context_text = build_summary_text(
                    groups, batch_links, type_config["title"]
                )[:6000]
                print(f"   📝 批次 {batch_idx} 后 context 更新："
                      f"{len(batch_merged)} 实体 / {len(batch_links)} 关系\n")
    else:
        # 一次性并发抽取（无迭代 context）
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_path = {
                executor.submit(
                    extract_from_single_doc, client, p, type_config, ""
                ): p
                for p in md_files
            }
            for future in as_completed(future_to_path):
                path = future_to_path[future]
                try:
                    objects, links = future.result()
                except Exception as e:
                    print(f"    ❌ {path.name}: {e}")
                    objects, links = [], []

                all_objects.append(objects)
                all_links.append(links)
                raw_object_count += len(objects)
                raw_link_count += len(links)
                done_count += 1

                print(
                    f"    [{done_count}/{total}] {path.name}: "
                    f"{len(objects)} 实体 / {len(links)} 关系"
                )
                if on_progress:
                    on_progress(done_count, total, path)

    elapsed = time.time() - start
    print(f"\n⏱️  抽取完成，耗时 {elapsed:.0f}s")

    # 合并去重
    print("🔀 合并去重...")
    merged_objects = merge_objects(all_objects)
    valid_names = {o["name"].lower() for o in merged_objects}
    merged_links = merge_links(all_links, valid_names)

    dedup_rate = (
        (1 - len(merged_objects) / max(raw_object_count, 1)) * 100
        if raw_object_count > 0
        else 0
    )
    print(
        f"✅ 实体：{raw_object_count} → {len(merged_objects)}（去重率 {dedup_rate:.1f}%）"
    )
    print(
        f"✅ 关系：{raw_link_count} → {len(merged_links)}（去重率 "
        f"{(1 - len(merged_links) / max(raw_link_count, 1)) * 100:.1f}%）"
    )

    groups = group_by_type(merged_objects, type_config)
    summary_text = build_summary_text(groups, merged_links, type_config["title"])

    ontology = {
        "objects": merged_objects,
        "links": merged_links,
        "groups": groups,
        "summary_text": summary_text,
        "subject_markdown": render_subject_markdown(
            {"objects": merged_objects, "links": merged_links}, type_config,
            max_chars=max_subject_chars,
        ),
        "stats": {
            "docs": total,
            "raw_objects": raw_object_count,
            "merged_objects": len(merged_objects),
            "raw_links": raw_link_count,
            "merged_links": len(merged_links),
            "elapsed_seconds": elapsed,
        },
    }
    return ontology


# ──────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────

def resolve_api_key(api_key_arg: Optional[str]) -> str:
    """固定使用 DeepSeek API key（与 md_optimizer 一致）"""
    if api_key_arg:
        return api_key_arg
    return "DEEPSEEK_API_KEY_PLACEHOLDER"


def resolve_base_url(base_url_arg: Optional[str], model: str) -> str:
    if base_url_arg:
        return base_url_arg
    m = model.lower()
    if "deepseek" in m:
        return "https://api.deepseek.com"
    if "qwen" in m or "dashscope" in m:
        return "https://dashscope.aliyuncs.com/compatible-mode/v1"
    if "openai" in m or "gpt" in m:
        return "https://api.openai.com"
    return DEFAULT_BASE_URL


def main():
    parser = argparse.ArgumentParser(
        description="项目本体自动构建工具（生成 md_optimizer 的主体文件）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  python build_ontology.py ./docs
  python build_ontology.py ./竞品资料 --types sales
  python build_ontology.py ./docs --dump-json ontology.json
  python build_ontology.py ./docs --dry-run
        """,
    )
    parser.add_argument("input", help="输入的 .md 文件或文件夹路径")
    parser.add_argument(
        "-o", "--output", default=str(DEFAULT_OUTPUT_PATH),
        help=f"主体文件输出路径（默认：{DEFAULT_OUTPUT_PATH}）"
    )
    parser.add_argument(
        "--dump-json", default=None,
        help="同时导出原始 ontology JSON（含完整 objects + links）"
    )
    parser.add_argument(
        "--types", default=DEFAULT_TYPES_PRESET,
        choices=["general", "sales"],
        help=f"本体类型预设（默认：{DEFAULT_TYPES_PRESET}）"
    )
    parser.add_argument(
        "--types-file", default=None,
        help="自定义类型 yaml 路径（覆盖默认 ontology_types.yaml）"
    )
    parser.add_argument(
        "-w", "--workers", type=int, default=DEFAULT_MAX_WORKERS,
        help=f"并发抽取数（默认：{DEFAULT_MAX_WORKERS}）"
    )
    parser.add_argument(
        "-m", "--model", default=DEFAULT_MODEL,
        help=f"DeepSeek 模型（默认：{DEFAULT_MODEL}）"
    )
    parser.add_argument("--api-key", default=None, help="API Key（默认：复用 v2 配置）")
    parser.add_argument("--base-url", default=None, help="API Base URL")
    parser.add_argument(
        "-t", "--timeout", type=int, default=DEFAULT_TIMEOUT,
        help=f"API 超时（默认：{DEFAULT_TIMEOUT}s）"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="不调用 LLM，仅扫描文件"
    )
    parser.add_argument(
        "--max-subject-chars", type=int, default=8000,
        help="主体文件最大字符数（默认：8000，超出按相关性裁剪）"
    )
    parser.add_argument(
        "--max-doc-chars", type=int, default=4000,
        help="单文档内容截断字符数（默认：4000）"
    )
    parser.add_argument(
        "--batch-size", type=int, default=5,
        help="迭代 context 注入的批次大小（默认：5，每处理 N 个文档后更新 context）"
    )
    parser.add_argument(
        "--no-iterative-context", action="store_true",
        help="禁用迭代 context 注入（默认开启）"
    )

    args = parser.parse_args()

    src_path = Path(args.input).resolve()
    if not src_path.exists():
        print(f"❌ 路径不存在: {src_path}")
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print(f"🔬 build_ontology — 项目本体自动构建")
    print(f"{'=' * 60}")
    print(f"  输入: {src_path}")
    print(f"  类型: {args.types}")
    print(f"  模型: {args.model}")
    print(f"  输出: {args.output}")

    # 加载类型配置
    type_config = load_type_config(args.types, args.types_file)

    # 初始化 LLM 客户端
    if args.dry_run:
        client = None
    else:
        api_key = resolve_api_key(args.api_key)
        base_url = resolve_base_url(args.base_url, args.model)
        client = OpenAIClient(
            api_key=api_key,
            base_url=base_url,
            model=args.model,
            timeout=args.timeout,
        )
        print(f"  LLM:  {args.model} @ {base_url}")
    print()

    # 执行
    ontology = build_ontology_from_path(
        src_path=src_path,
        client=client,
        type_config=type_config,
        max_workers=args.workers,
        dry_run=args.dry_run,
        batch_size=args.batch_size,
        use_iterative_context=not args.no_iterative_context,
        max_subject_chars=args.max_subject_chars,
        max_doc_chars=args.max_doc_chars,
    )

    if args.dry_run:
        return

    # 写主体文件
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(ontology["subject_markdown"], encoding="utf-8")
    print(f"\n💾 主体文件已保存: {output_path}")
    print(f"   长度: {len(ontology['subject_markdown'])} 字符")

    # 可选：导出 JSON
    if args.dump_json:
        json_path = Path(args.dump_json)
        json_data = {
            "stats": ontology["stats"],
            "type_config": {
                "title": type_config["title"],
                "object_types": type_config["object_types"],
                "relation_types": type_config["relation_types"],
            },
            "objects": ontology["objects"],
            "links": ontology["links"],
        }
        json_path.write_text(
            json.dumps(json_data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(f"💾 JSON 已保存: {json_path}")

    # 摘要
    stats = ontology["stats"]
    print(f"\n{'=' * 60}")
    print(f"✅ 完成：{stats['docs']} 文档 / "
          f"{stats['merged_objects']} 实体 / "
          f"{stats['merged_links']} 关系 / "
          f"{stats['elapsed_seconds']:.0f}s")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
