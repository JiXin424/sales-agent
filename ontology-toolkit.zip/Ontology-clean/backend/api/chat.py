"""对话 API — 知识问答端点"""

import logging
import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from backend.db import async_session
from backend.reasoning.intent import classify_intent
from backend.reasoning.engine import ReasoningEngine
from backend.reasoning.response import generate_response

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/chat", tags=["chat"])


class ChatRequest(BaseModel):
    question: str


class ChatResponse(BaseModel):
    answer: str
    intent: str
    entities: list[str]
    evidence: list[str]
    confidence: float
    timing: dict[str, float] = {}


async def get_session():
    async with async_session() as session:
        yield session


@router.post("/", response_model=ChatResponse)
async def chat(request: ChatRequest, session: AsyncSession = Depends(get_session)):
    """知识问答主接口"""
    question = request.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="问题不能为空")

    timing = {}

    # 1. 意图分类
    t0 = time.perf_counter()
    intent_result = await classify_intent(question)
    timing["intent_classify"] = time.perf_counter() - t0
    logger.info(f"意图分类: {intent_result}")

    if intent_result["intent"] == "general":
        return ChatResponse(
            answer="您好！我是销售知识助手，可以回答关于产品、客户、竞品等问题。",
            intent="general",
            entities=[],
            evidence=[],
            confidence=1.0,
            timing=timing,
        )

    # 2. 推理引擎收集上下文
    t1 = time.perf_counter()
    engine = ReasoningEngine(session)
    context = await engine.reason(question, intent_result)
    timing["reasoning"] = time.perf_counter() - t1

    # 3. 生成回答 (简单意图用 Flash 加速)
    use_flash = intent_result["intent"] in ("entity_info", "scenario")
    t2 = time.perf_counter()
    response = await generate_response(question, context, intent=intent_result["intent"], use_flash=use_flash)
    timing["response_gen"] = time.perf_counter() - t2

    timing["total"] = sum(timing.values())

    return ChatResponse(
        answer=response["answer"],
        intent=intent_result["intent"],
        entities=intent_result.get("entities", []),
        evidence=response.get("evidence", []),
        confidence=response.get("confidence", 0.5),
        timing=timing,
    )
