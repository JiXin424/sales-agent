"""冲突管理 API — 版本冲突的查看和解决"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backend.db import async_session
from backend.ontology.models import Conflict

router = APIRouter(prefix="/api/v1/conflicts", tags=["conflicts"])


async def get_session():
    async with async_session() as session:
        yield session


@router.get("/")
async def list_conflicts(
    status: str = "pending",
    db: AsyncSession = Depends(get_session),
):
    """列出冲突项（默认只看 pending）"""
    result = await db.execute(
        select(Conflict)
        .where(Conflict.status == status)
        .order_by(Conflict.created_at.desc())
    )
    conflicts = result.scalars().all()
    return {
        "conflicts": [
            {
                "id": c.id,
                "object_id": c.object_id,
                "conflict_type": c.conflict_type,
                "old_value": c.old_value,
                "new_value": c.new_value,
                "status": c.status,
                "source_document_id": c.source_document_id,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in conflicts
        ]
    }


class ResolveRequest(BaseModel):
    resolution: str  # "keep_old" | "use_new" | custom text


@router.post("/{conflict_id}/resolve")
async def resolve_conflict(
    conflict_id: int,
    req: ResolveRequest,
    db: AsyncSession = Depends(get_session),
):
    """人工解决冲突"""
    result = await db.execute(select(Conflict).where(Conflict.id == conflict_id))
    conflict = result.scalar_one_or_none()
    if not conflict:
        raise HTTPException(status_code=404, detail="冲突不存在")

    conflict.status = "resolved"
    conflict.resolution = req.resolution

    # 如果选择使用新值，更新对应实体的属性
    if req.resolution == "use_new" and conflict.object_id and conflict.new_value:
        from backend.ontology.models import Object
        obj_result = await db.execute(select(Object).where(Object.id == conflict.object_id))
        obj = obj_result.scalar_one_or_none()
        if obj and obj.properties:
            merged = dict(obj.properties)
            merged.update(conflict.new_value)
            obj.properties = merged

    await db.commit()
    return {"status": "resolved", "conflict_id": conflict_id, "resolution": req.resolution}
