"""内存图存储与查询服务。"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List, Optional, TypeVar, Union

from .models import (
    ActionStep,
    Case,
    Concept,
    Experiment,
    Ontology,
    Person,
    Principle,
    ReasoningChain,
    Relation,
    Scenario,
    Script,
    Tactic,
    Term,
)

T = TypeVar("T")

ENTITY_TYPE_ATTRS = {
    "principle": "principles",
    "concept": "concepts",
    "term": "terms",
    "case": "cases",
    "experiment": "experiments",
    "person": "persons",
    "reasoning_chain": "reasoning_chains",
    "tactic": "tactics",
    "action_step": "action_steps",
    "script": "scripts",
    "scenario": "scenarios",
}


class OntologyStore:
    """《影响力》本体内存存储，提供索引与查询。"""

    def __init__(self, ontology: Ontology):
        self.ontology = ontology
        self._entity_by_id: Dict[str, Any] = {}
        self._entities_by_type: Dict[str, List[Any]] = defaultdict(list)
        self._name_index: Dict[str, List[Any]] = defaultdict(list)
        self._principle_index: Dict[str, List[Any]] = defaultdict(list)
        self._forward: Dict[str, List[Relation]] = defaultdict(list)
        self._backward: Dict[str, List[Relation]] = defaultdict(list)

        self._build_indexes()

    def _normalize(self, s: str) -> str:
        """用于名称索引的简单归一化。"""
        return s.lower().replace(" ", "").replace("　", "")

    def _build_indexes(self) -> None:
        # 实体索引
        for type_name, attr in ENTITY_TYPE_ATTRS.items():
            for entity in getattr(self.ontology, attr):
                self._entity_by_id[entity.id] = entity
                self._entities_by_type[type_name].append(entity)
                if entity.name:
                    self._name_index[self._normalize(entity.name)].append(entity)

        # 原则索引（用于 Case/Experiment/Tactic/ReasoningChain/Script/Concept）
        for attr in [
            "cases",
            "experiments",
            "tactics",
            "reasoning_chains",
            "scripts",
            "concepts",
        ]:
            for entity in getattr(self.ontology, attr):
                pids = getattr(entity, "principle", None) or getattr(entity, "principle_id", None)
                if pids:
                    if isinstance(pids, str):
                        pids = [pids]
                    for pid in pids:
                        self._principle_index[pid].append(entity)

        # 行动步骤按 tactic_id 索引
        for step in self.ontology.action_steps:
            if step.tactic_id:
                self._principle_index.setdefault(f"_tactic_steps_{step.tactic_id}", []).append(step)

        # 关系邻接表
        for rel in self.ontology.relations:
            self._forward[rel.from_id].append(rel)
            self._backward[rel.to_id].append(rel)

    # ───────────────────────── 基础查询 ─────────────────────────

    def get_by_id(self, entity_id: str) -> Optional[Any]:
        return self._entity_by_id.get(entity_id)

    def get_by_type(self, entity_type: str) -> List[Any]:
        return list(self._entities_by_type.get(entity_type, []))

    def get_by_name(self, name: str, fuzzy: bool = False) -> List[Any]:
        norm = self._normalize(name)
        if not fuzzy:
            return list(self._name_index.get(norm, []))
        results = []
        for key, entities in self._name_index.items():
            if norm in key or key in norm:
                results.extend(entities)
        return results

    def search(self, query: str, entity_types: Optional[List[str]] = None) -> List[Any]:
        """跨所有实体字段的简单子串搜索。"""
        q = query.lower()
        types_to_search = entity_types or list(ENTITY_TYPE_ATTRS.keys())
        results = []
        seen = set()
        for t in types_to_search:
            for entity in self._entities_by_type.get(t, []):
                if entity.id in seen:
                    continue
                text = " ".join(str(v) for v in entity.model_dump().values() if v is not None)
                if q in text.lower():
                    results.append(entity)
                    seen.add(entity.id)
        return results

    # ───────────────────────── 原则-centric 查询 ─────────────────────────

    def get_cases_by_principle(self, principle_id: str) -> List[Case]:
        return [e for e in self._principle_index.get(principle_id, []) if isinstance(e, Case)]

    def get_experiments_by_principle(self, principle_id: str) -> List[Experiment]:
        return [e for e in self._principle_index.get(principle_id, []) if isinstance(e, Experiment)]

    def get_tactics_by_principle(self, principle_id: str) -> List[Tactic]:
        return [e for e in self._principle_index.get(principle_id, []) if isinstance(e, Tactic)]

    def get_concepts_by_principle(self, principle_id: str) -> List[Concept]:
        return [e for e in self._principle_index.get(principle_id, []) if isinstance(e, Concept)]

    def get_reasoning_chains_by_principle(self, principle_id: str) -> List[ReasoningChain]:
        return [e for e in self._principle_index.get(principle_id, []) if isinstance(e, ReasoningChain)]

    def get_scripts_by_principle(self, principle_id: str) -> List[Script]:
        return [e for e in self._principle_index.get(principle_id, []) if isinstance(e, Script)]

    # ───────────────────────── 图遍历 ─────────────────────────

    def get_relations(
        self,
        entity_id: str,
        relation_type: Optional[str] = None,
        direction: str = "both",
    ) -> List[Relation]:
        rels: List[Relation] = []
        if direction in ("both", "out"):
            rels.extend(self._forward.get(entity_id, []))
        if direction in ("both", "in"):
            rels.extend(self._backward.get(entity_id, []))
        if relation_type:
            rels = [r for r in rels if r.relation_type == relation_type]
        return rels

    def get_neighbors(
        self,
        entity_id: str,
        relation_type: Optional[str] = None,
        direction: str = "both",
    ) -> List[Any]:
        rels = self.get_relations(entity_id, relation_type, direction)
        seen = set()
        neighbors = []
        for r in rels:
            target_id = r.to_id if r.from_id == entity_id else r.from_id
            if target_id == entity_id:
                continue
            if target_id in seen:
                continue
            neighbor = self._entity_by_id.get(target_id)
            if neighbor:
                neighbors.append(neighbor)
                seen.add(target_id)
        return neighbors

    def get_steps_for_tactic(self, tactic_id: str) -> List[ActionStep]:
        return [e for e in self._principle_index.get(f"_tactic_steps_{tactic_id}", []) if isinstance(e, ActionStep)]

    def get_scenarios_for_tactic(self, tactic_id: str) -> List[Scenario]:
        scenarios = []
        for sc in self.ontology.scenarios:
            if sc.applicable_tactics and tactic_id in sc.applicable_tactics:
                scenarios.append(sc)
        return scenarios

    # ───────────────────────── 综合解释 ─────────────────────────

    def explain_principle(self, principle_id: str) -> Dict[str, List[Any]]:
        principle = self.get_by_id(principle_id)
        return {
            "principle": [principle] if principle else [],
            "concepts": self.get_concepts_by_principle(principle_id),
            "cases": self.get_cases_by_principle(principle_id),
            "experiments": self.get_experiments_by_principle(principle_id),
            "reasoning_chains": self.get_reasoning_chains_by_principle(principle_id),
            "tactics": self.get_tactics_by_principle(principle_id),
            "scripts": self.get_scripts_by_principle(principle_id),
        }

    # ───────────────────────── 统计 ─────────────────────────

    def stats(self) -> Dict[str, int]:
        return self.ontology.stats()

    # ───────────────────────── 别名/单复数兼容 ─────────────────────────

    def resolve_type(self, entity_type: str) -> Optional[str]:
        t = entity_type.lower().replace(" ", "_").replace("-", "_")
        aliases = {
            "principles": "principle",
            "concepts": "concept",
            "terms": "term",
            "cases": "case",
            "experiments": "experiment",
            "persons": "person",
            "people": "person",
            "reasoning_chains": "reasoning_chain",
            "tactics": "tactic",
            "action_steps": "action_step",
            "scripts": "script",
            "scenarios": "scenario",
        }
        if t in ENTITY_TYPE_ATTRS:
            return t
        return aliases.get(t)
