#!/bin/bash
# 影响力本体问答系统 v3.2 启动脚本

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/api"

# 检查 API Key
if [ -z "$DEEPSEEK_API_KEY" ]; then
    echo "⚠️  DEEPSEEK_API_KEY 环境变量未设置"
    echo "   请先：export DEEPSEEK_API_KEY='sk-xxxxx'"
    echo "   或永久写入 ~/.zshrc / ~/.bashrc"
    echo "   没有也能启动，但 /api/chat 会返回 500"
    echo ""
fi

# 检查依赖
python3 -c "import flask, flask_cors, openai" 2>/dev/null || {
    echo "📦 安装依赖..."
    pip3 install -r requirements.txt
}

# 清理端口
lsof -ti:3000 2>/dev/null | xargs kill -9 2>/dev/null || true

echo "================================================"
echo "  影响力本体问答系统 v3.2"
echo "  本体:    influence_ontology_cleaned.json"
echo "  实体数:  618 (含 16 销售场景)"
echo "  关系数:  328"
echo "  API Key: ${DEEPSEEK_API_KEY:+已设置}${DEEPSEEK_API_KEY:-未设置}"
echo "  地址:    http://localhost:3000"
echo "================================================"
echo ""

exec python3 chat_service.py
