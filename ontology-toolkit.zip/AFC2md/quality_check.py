#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量质量检查：对比源文件与转换后的 md 文件
检查维度：
1. 文件映射完整性（源文件是否有对应 md）
2. md 内容质量（空文件、失败标记、代码块包裹、异常短内容）
3. 多余文件（md_ready 中无对应源文件的文件）
"""

import os
import sys
from pathlib import Path
from datetime import datetime

SRC_DIR = "/Users/fred/Documents/cc_Projects/Taishan/二期库/0515/福多多raw"
MD_DIR  = "/Users/fred/Documents/cc_Projects/Taishan/二期库/0515/福多多md_ready"
OUTPUT  = "/Users/fred/Documents/cc_Projects/Taishan/二期库/0515/质量检查报告.md"

# 中间目录排除（用 endswith 匹配子目录后缀）
def should_skip_dir(dname):
    return dname.endswith("_extracted") or dname.endswith("_images") or dname.startswith(".")
# 支持的源格式
SUPPORTED_EXTS = {".pdf", ".pptx", ".docx", ".doc", ".xlsx", ".xls",
                  ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}


def list_source_files(src_dir):
    """列出所有源文件，排除中间目录"""
    files = []
    for root, dirs, filenames in os.walk(src_dir):
        # 排除中间目录
        dirs[:] = [d for d in dirs if not should_skip_dir(d)]
        for fname in filenames:
            if fname.startswith(".") or fname == ".DS_Store":
                continue
            ext = os.path.splitext(fname)[1].lower()
            if ext in SUPPORTED_EXTS:
                rel = os.path.relpath(os.path.join(root, fname), src_dir)
                files.append(rel)
    return sorted(files)


def list_md_files(md_dir):
    """列出所有 md 文件，排除报告文件"""
    files = []
    for root, dirs, filenames in os.walk(md_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in filenames:
            if fname.endswith(".md") and fname != "_batch_report.md":
                rel = os.path.relpath(os.path.join(root, fname), md_dir)
                files.append(rel)
    return sorted(files)


def find_md_for_source(src_rel, md_files):
    """根据源文件路径找到对应的 md 文件"""
    base = os.path.splitext(src_rel)[0]  # 去掉扩展名
    md_name = base + ".md"
    # 先精确匹配
    if md_name in md_files:
        return md_name
    # 再模糊匹配（处理空格等差异）
    for mf in md_files:
        if os.path.splitext(mf)[0].replace(" ", "") == base.replace(" ", ""):
            return mf
    return None


def check_md_quality(md_path):
    """检查单个 md 文件的质量问题"""
    issues = []

    try:
        with open(md_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        issues.append(f"无法读取: {e}")
        return issues

    size = len(content)
    lines = content.split("\n")
    line_count = len(lines)

    # 1. 空文件或极短
    if size == 0:
        issues.append("文件内容为空")
    elif size < 200:
        issues.append(f"内容极短 ({size} 字符)")
    elif line_count < 5:
        issues.append(f"行数过少 ({line_count} 行)")

    # 2. 图片分析失败标记
    fail_count = content.count("图片分析失败")
    if fail_count > 0:
        issues.append(f"包含 {fail_count} 处【图片分析失败】")

    # 3. 代码块包裹残留
    if "```markdown" in content:
        issues.append("残留 ```markdown 代码块包裹")
    if content.startswith("```") and "```" in content[3:]:
        # 更宽松的检查：开头是代码块标记
        first_line = lines[0].strip()
        if first_line.startswith("```") and not first_line.startswith("```markdown"):
            issues.append(f"开头残留代码块标记: {first_line}")

    # 4. OCR/AI 异常标记
    if "[图片]" in content and content.count("[图片]") > 5:
        issues.append(f"包含 {content.count('[图片]')} 处 [图片] 占位符")

    # 5. 表格格式异常（空表格或单列表格）
    table_lines = [l for l in lines if l.strip().startswith("|")]
    if table_lines:
        # 检查是否有表格只有一列（可能是格式错误）
        single_col = sum(1 for l in table_lines if l.count("|") <= 2)
        if single_col > 3:
            issues.append(f"包含 {single_col} 行单列表格（可能格式异常）")

    # 6. 内容重复率检查（简单：连续重复行）
    repeat_count = 0
    for i in range(1, len(lines)):
        if lines[i].strip() and lines[i].strip() == lines[i - 1].strip():
            repeat_count += 1
    if repeat_count > 10:
        issues.append(f"包含 {repeat_count} 行连续重复内容")

    return issues


def main():
    print("=" * 70)
    print("批量质量检查")
    print("=" * 70)

    src_files = list_source_files(SRC_DIR)
    md_files = list_md_files(MD_DIR)

    print(f"\n源文件: {len(src_files)} 个")
    print(f"md 文件: {len(md_files)} 个")

    # --- 检查 1: 源文件缺失对应的 md ---
    missing_md = []
    src_to_md = {}  # 源文件 -> md 文件映射
    for sf in src_files:
        mf = find_md_for_source(sf, md_files)
        if mf:
            src_to_md[sf] = mf
        else:
            missing_md.append(sf)

    # --- 检查 2: md 内容质量 ---
    quality_issues = []  # (md_rel, [issues])
    for sf, mf in src_to_md.items():
        md_path = os.path.join(MD_DIR, mf)
        issues = check_md_quality(md_path)
        if issues:
            quality_issues.append((mf, issues))

    # --- 检查 3: md_ready 中多余文件 ---
    used_md = set(src_to_md.values())
    extra_md = [mf for mf in md_files if mf not in used_md]

    # --- 检查 4: 源文件中是否有临时/中间文件 ---
    temp_files = [sf for sf in src_files if "_extracted" in sf or "_images" in sf]

    # --- 生成报告 ---
    lines = []
    lines.append("# 批量文档转换质量检查报告")
    lines.append("")
    lines.append(f"**检查时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"**源目录**: `{SRC_DIR}`")
    lines.append(f"**目标目录**: `{MD_DIR}`")
    lines.append("")

    # 汇总
    total_issues = len(missing_md) + len(quality_issues) + len(extra_md) + len(temp_files)
    lines.append("## 汇总")
    lines.append("")
    lines.append(f"| 指标 | 数值 |")
    lines.append(f"|------|------|")
    lines.append(f"| 源文件总数 | {len(src_files)} |")
    lines.append(f"| md 文件总数 | {len(md_files)} |")
    lines.append(f"| 成功映射 | {len(src_to_md)} |")
    lines.append(f"| **缺失 md** | {len(missing_md)} |")
    lines.append(f"| **质量异常** | {len(quality_issues)} |")
    lines.append(f"| **多余 md** | {len(extra_md)} |")
    lines.append(f"| **源目录残留临时文件** | {len(temp_files)} |")
    lines.append(f"| **问题总计** | {total_issues} |")
    lines.append("")

    # 详细问题
    if missing_md:
        lines.append("## 1. 缺失对应 md 的源文件")
        lines.append("")
        for sf in missing_md:
            lines.append(f"- ❌ `{sf}`")
        lines.append("")

    if quality_issues:
        lines.append("## 2. md 文件质量异常")
        lines.append("")
        for mf, issues in quality_issues:
            lines.append(f"### `{mf}`")
            for issue in issues:
                lines.append(f"- ⚠️ {issue}")
            lines.append("")

    if extra_md:
        lines.append("## 3. md_ready 中无对应源文件的文件")
        lines.append("")
        for mf in extra_md:
            # 检查该文件是否有内容
            mf_path = os.path.join(MD_DIR, mf)
            try:
                sz = os.path.getsize(mf_path)
            except:
                sz = 0
            lines.append(f"- 📄 `{mf}` ({sz/1024:.1f} KB)")
        lines.append("")

    if temp_files:
        lines.append("## 4. 源目录中的临时/中间文件")
        lines.append("")
        for sf in temp_files:
            lines.append(f"- 🗂️ `{sf}`")
        lines.append("")

    if total_issues == 0:
        lines.append("## 检查结果")
        lines.append("")
        lines.append("✅ 所有文件检查通过，无异常发现。")
        lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("*报告由 quality_check.py 自动生成*")

    report = "\n".join(lines)
    with open(OUTPUT, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\n{'=' * 70}")
    print(f"检查完成")
    print(f"  缺失 md: {len(missing_md)}")
    print(f"  质量异常: {len(quality_issues)}")
    print(f"  多余 md: {len(extra_md)}")
    print(f"  临时文件: {len(temp_files)}")
    print(f"  报告保存: {OUTPUT}")
    print(f"{'=' * 70}")

    return total_issues == 0


if __name__ == "__main__":
    ok = main()
    sys.exit(0 if ok else 1)
