#!/bin/bash
# Ontology 纯净版 - 一键初始化脚本
# 用法：bash init.sh [客户文档目录]
# 示例：bash init.sh /path/to/客户文档

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

echo "═══════════════════════════════════════════════"
echo "  Ontology 纯净版 - 首次初始化"
echo "═══════════════════════════════════════════════"
echo ""

# ── Step 1: 环境检查 ──
echo "▶ [1/7] 环境检查 ..."
if ! python3 --version 2>&1 | grep -qE "3\.(10|11|12|13|14)\."; then
    echo "  ❌ 需要 Python 3.10+（当前：$(python3 --version 2>&1)）"
    exit 1
fi
echo "  ✅ Python $(python3 --version 2>&1)"

if ! command -v docker &> /dev/null; then
    echo "  ⚠️  Docker 未安装，PostgreSQL 需手动准备"
else
    echo "  ✅ Docker $(docker --version 2>&1 | cut -d' ' -f3 | tr -d ',')"
fi
echo ""

# ── Step 2: 配置 .env ──
echo "▶ [2/7] 配置 .env ..."
if [ ! -f ".env" ] || ! grep -q "DEEPSEEK_API_KEY=sk-" .env 2>/dev/null; then
    echo "  ⚠️  请先编辑 .env 填入真实 API Key"
    echo "     vim .env"
    echo ""
    read -p "  已填写 API Key？继续？(y/N) " confirm
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        echo "  ❌ 请先填写 .env 后重新运行"
        exit 1
    fi
fi
echo "  ✅ .env 配置完成"
echo ""

# ── Step 3: 创建虚拟环境 + 安装依赖 ──
echo "▶ [3/7] 创建虚拟环境 + 安装依赖 ..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
pip install --quiet pyyaml  # 预处理工具依赖
echo "  ✅ Python 依赖安装完成"
echo ""

# ── Step 4: 启动 PostgreSQL（首次会创建 .pgdata）──
echo "▶ [4/7] 启动 PostgreSQL ..."
if command -v docker &> /dev/null; then
    docker compose up -d db
    echo "  ⏳ 等待 PostgreSQL 就绪 ..."
    for i in {1..30}; do
        if docker compose exec -T db pg_isready -U ontology &>/dev/null; then
            echo "  ✅ PostgreSQL 就绪（耗时 ${i}s）"
            break
        fi
        sleep 1
    done
else
    echo "  ⚠️  跳过 PostgreSQL 启动（无 Docker）"
    echo "     请手动启动 PostgreSQL 并配置连接信息"
fi
echo ""

# ── Step 5: 数据库表结构初始化 ──
echo "▶ [5/7] 初始化数据库表结构 ..."
sleep 3  # 等 PostgreSQL 完全就绪
python3 -c "
import asyncio
from backend.db import engine
from backend.ontology.models import Base
from sqlalchemy import text

async def init():
    async with engine.begin() as conn:
        await conn.execute(text('CREATE EXTENSION IF NOT EXISTS vector'))
        await conn.run_sync(Base.metadata.create_all)
        print('  ✅ 数据库表创建完成')

asyncio.run(init())
" 2>&1 || echo "  ⚠️  数据库初始化失败，请检查 PostgreSQL 是否就绪"
echo ""

# ── Step 6: 客户文档预处理（可选）──
CUSTOMER_DOCS="$1"
if [ -n "$CUSTOMER_DOCS" ]; then
    echo "▶ [6/7] 客户文档预处理：$CUSTOMER_DOCS"

    if [ ! -d "$CUSTOMER_DOCS" ] && [ ! -f "$CUSTOMER_DOCS" ]; then
        echo "  ❌ 路径不存在：$CUSTOMER_DOCS"
        exit 1
    fi

    # 6.1 主体文件生成（自动本体抽取）
    echo "  → 生成主体文件（build_ontology）..."
    python3 preprocessor/build_ontology.py "$CUSTOMER_DOCS" \
        --types sales \
        --workers 3 \
        --batch-size 5 \
        -o preprocessor/主体文件.md \
        --dump-json preprocessor/ontology.json || {
        echo "  ⚠️  主体文件生成失败，可稍后手动运行"
    }

    # 6.2 文档优化（注入主体文件）
    echo "  → 优化文档（md_optimizer）..."
    python3 preprocessor/md_optimizer.py "$CUSTOMER_DOCS" \
        --model deepseek-v4-pro \
        --workers 10 \
        --subject preprocessor/主体文件.md || {
        echo "  ⚠️  文档优化失败，可稍后手动运行"
    }

    # 6.3 复制优化后文档到 data/uploads/
    OPT_DIR="${CUSTOMER_DOCS%/}-优化"
    if [ -d "$OPT_DIR" ]; then
        echo "  → 导入优化后文档到 data/uploads/ ..."
        cp -r "$OPT_DIR"/* data/uploads/ 2>/dev/null || true
        echo "  ✅ 已复制优化后文档"
    fi

    # 6.4 入库 + 构建背景知识
    echo "  → 文档入库 + 构建背景知识 ..."
    python3 -c "
import asyncio
from backend.db import async_session
from backend.document.pipeline import process_document
from backend.ontology.crud import ensure_default_types
from pathlib import Path

async def ingest():
    async with async_session() as db:
        await ensure_default_types(db)
        upload_dir = Path('data/uploads')
        count = 0
        for md_file in upload_dir.rglob('*.md'):
            try:
                await process_document(str(md_file), db)
                count += 1
                print(f'    ✅ {md_file.name}')
            except Exception as e:
                print(f'    ❌ {md_file.name}: {e}')
        await db.commit()
        print(f'  ✅ 入库 {count} 篇文档')

asyncio.run(ingest())
" 2>&1 || echo "  ⚠️  入库失败，可启动后端后通过 API 上传"

    # 6.5 重建背景知识上下文
    curl -s -X POST http://localhost:8000/api/v1/documents/build-context 2>/dev/null \
        && echo "  ✅ 背景知识上下文已构建" \
        || echo "  ℹ️  后端启动后请调用 /api/v1/documents/build-context"
else
    echo "▶ [6/7] 跳过文档预处理（未传入客户文档目录）"
    echo "  ℹ️  后续可通过 API 上传文档："
    echo "      curl -F 'file=@xxx.md' http://localhost:8000/api/v1/documents/upload"
fi
echo ""

# ── Step 7: 启动后端 ──
echo "▶ [7/7] 启动后端 ..."
echo ""
echo "═══════════════════════════════════════════════"
echo "  ✅ 初始化完成"
echo "═══════════════════════════════════════════════"
echo ""
echo "🚀 启动后端服务："
echo "   source venv/bin/activate"
echo "   python3 backend/main.py"
echo ""
echo "📖 API 文档：http://localhost:8000/docs"
echo ""
echo "🧪 测试健康检查："
echo "   curl http://localhost:8000/health"
echo ""
echo "📦 启动前端（可选）："
echo "   cd frontend && npm install && npm run dev"
echo ""
echo "═══════════════════════════════════════════════"
