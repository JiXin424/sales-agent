#!/usr/bin/env python3
"""
auto_pipeline_v2 — 增量文件全流程
  Step A: 快速构建增强本体 (含新 4 个访谈整理 + FAQ)
  Step B: 用增强本体上下文重新修复 7 个 ASR 视频文件
  Step C: 全量重建 (Phase 2→3→4)
"""

import os, sys, json, time, re
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent.resolve()
DOCS_DIR = SCRIPT_DIR.parent / "docs" / "ProductX材料第一批"
ASR_DIR = DOCS_DIR / "培训材料md" / "视频培训材料"
TRAINING_MD_DIR = DOCS_DIR / "培训材料md"
SUBJECT_V2 = DOCS_DIR / "主体文件_v2.md"
ONTOLOGY_V2 = DOCS_DIR / "ontology_v2.json"
SUBJECT_FIXED = DOCS_DIR / "主体文件_fixed.md"

sys.path.insert(0, str(SCRIPT_DIR))
from md_optimizer import OpenAIClient

MODEL = "deepseek-v4-pro"
API_KEY = "DEEPSEEK_API_KEY_PLACEHOLDER"
BASE_URL = "https://api.deepseek.com"

LOG = DOCS_DIR / "_pipeline.log"

def log(msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)
    with open(LOG, "a") as f:
        f.write(f"[{ts}] {msg}\n")

def step(label: str):
    log(f"\n{'='*50}")
    log(f"{label}")
    log(f"{'='*50}")


# ═══════════════════════════════════════════
# Step A: Quick ontology build
# ═══════════════════════════════════════════

def stepA_build_enhanced_ontology():
    """快速构建增强本体（含新访谈文件），产出给 Step B 做 ASR 修复上下文"""
    step("Step A: 构建增强本体 (42 文件)")

    import subprocess
    tmp_subject = DOCS_DIR / "主体文件_enhanced.md"
    tmp_json = DOCS_DIR / "ontology_enhanced.json"

    cmd = [
        sys.executable, str(SCRIPT_DIR / "build_ontology.py"),
        str(TRAINING_MD_DIR),
        "--types", "sales", "--workers", "6", "--batch-size", "5",
        "--max-doc-chars", "4000",
        "-o", str(tmp_subject), "--dump-json", str(tmp_json),
    ]
    log(f"  执行 build_ontology (42 文件)...")
    proc = subprocess.run(cmd, cwd=str(SCRIPT_DIR), timeout=1800)
    if proc.returncode != 0:
        log(f"❌ build_ontology 失败")
        return False

    # 提取关键术语字典（金标文件优先：FAQ + 访谈整理）
    with open(tmp_json) as f:
        ontology = json.load(f)

    objects = ontology.get("objects", [])
    glossary = {}
    for obj in objects:
        name = obj["name"]
        props = obj.get("properties", {})
        # 收集产品名、医学术语
        glossary[name] = {
            "type": obj["type"],
            "aliases": [],
            "correct_spelling": name,
        }
        # 常见别名
        for k in ["brand_name", "generic_name", "trade_name", "商品名", "英文名", "abbr"]:
            if k in props and props[k]:
                glossary[name]["aliases"].append(props[k])

    log(f"  增强本体: {len(objects)} 实体, {len(glossary)} 术语条目")
    log(f"  ✅ {tmp_subject} / {tmp_json}")
    return True


# ═══════════════════════════════════════════
# Step B: ASR re-fix with ontology context
# ═══════════════════════════════════════════

ASR_FIX_V2_PROMPT = """你是医学术语校正专家。以下文本来自语音识别(ASR)转写，包含同音字/错别字。

**增强上下文**（以下术语/产品名来自已验证的知识库，优先使用这些标准写法）：
{glossary}

**核心规则**：
1. 只修正语音识别错误，不改变原意、不添加/删除内容
2. 所有数字、百分比、日期、剂量必须原封不动
3. 产品名/医学术语统一使用上述知识库中的标准写法
4. 修正方向：同音/近音字→正确术语（如"适应症A_ASRerr"→"适应症A"，"活性_ASRerr"→"生物活性"）
5. 输出格式与原 Markdown 完全一致

请直接输出修正后的全文。"""


def stepB_refix_asr():
    """用增强本体上下文重新修复 ASR 文件"""
    step("Step B: 增强 ASR 修复 (本体上下文)")

    # 加载增强本体术语
    tmp_json = DOCS_DIR / "ontology_enhanced.json"
    if not tmp_json.exists():
        log("❌ 增强本体不存在")
        return False

    with open(tmp_json) as f:
        ontology = json.load(f)

    # 构建术语表（金标文件实体优先）
    glossary_lines = []
    for obj in ontology.get("objects", []):
        name = obj["name"]
        t = obj["type"]
        props = obj.get("properties", {})
        aliases = []
        for k in ["brand_name", "generic_name", "trade_name", "商品名", "英文名", "abbr"]:
            if k in props and props[k]:
                aliases.append(props[k])
        line = f"- **{name}** ({t})"
        if aliases:
            line += f" 别名: {', '.join(aliases)}"
        glossary_lines.append(line)

    glossary_text = "\n".join(glossary_lines[:200])  # 截断，避免过大
    log(f"  术语表: {len(glossary_lines)} 条 (使用前 200)")

    client = OpenAIClient(api_key=API_KEY, base_url=BASE_URL, model=MODEL)

    # 移除旧的 bak 文件，强制全部重做
    for bak in ASR_DIR.glob("*.asr_orig.bak"):
        orig = bak.with_suffix("").with_suffix(bak.suffix.replace(".asr_orig.bak", ""))
        if not orig.exists():
            bak.rename(orig)
    # 删除旧的 fixed 文件
    for fixed in ASR_DIR.glob("*.fixed.md"):
        fixed.unlink()

    files = sorted(ASR_DIR.glob("*.md"))
    ok = 0
    for f in files:
        log(f"  修复: {f.name}")
        content = f.read_text(encoding="utf-8")
        prompt = ASR_FIX_V2_PROMPT.replace("{glossary}", glossary_text)
        try:
            result = client.chat_stream(
                system="你是专业的医学语音转写校正助手，严格遵循知识库术语。",
                user=f"{prompt}\n\n---\n\n{content}",
                temperature=0.1,
                extra_body={"max_tokens": 16000, "reasoning_effort": "medium"},
            )
            out = f.with_name(f"{f.stem}.fixed.md")
            out.write_text(result, encoding="utf-8")
            ok += 1
            log(f"    ✅ {len(content)}→{len(result)} chars")
        except Exception as e:
            log(f"    ❌ {e}")

    if ok < len(files):
        return False

    # 替换原文件
    for f in files:
        fixed = f.with_name(f"{f.stem}.fixed.md")
        if fixed.exists():
            bak = f.with_suffix(".asr_orig.bak")
            f.rename(bak)
            fixed.rename(f)

    log(f"Step B 完成: {ok}/{len(files)} 修复 (增强上下文)")
    return True


# ═══════════════════════════════════════════
# Step C: Full pipeline Phase 2→3→4
# ═══════════════════════════════════════════

def stepC_full_pipeline():
    """运行 auto_pipeline Phase 2→3→4（Phase 1 跳过）"""
    step("Step C: 全管道重建 (Phase 2→3→4)")

    # 清除旧的 Phase 2-4 输出
    for f in [SUBJECT_V2, ONTOLOGY_V2, SUBJECT_FIXED]:
        if f.exists():
            f.unlink()
    fixed_json = DOCS_DIR / "ontology_fixed.json"
    if fixed_json.exists():
        fixed_json.unlink()
    opt_dir = DOCS_DIR / "培训材料md-优化"
    if opt_dir.exists():
        import shutil
        shutil.rmtree(opt_dir)

    # 直接 import 并调用 auto_pipeline 的 phase 函数
    sys.path.insert(0, str(SCRIPT_DIR))
    from auto_pipeline import (
        phase2_rebuild_ontology,
        phase3_fix_ontology,
        phase4_optimize,
    )

    if not phase2_rebuild_ontology():
        return False
    if not phase3_fix_ontology():
        return False
    if not phase4_optimize():
        return False

    return True


# ═══════════════════════════════════════════
# Main
# ═══════════════════════════════════════════

def main():
    log(f"🚀 auto_pipeline_v2 启动")
    log(f"   金标文件: FAQ 88问 + 4个访谈整理")
    log(f"   总计: 42 个 .md")

    steps = [
        ("Step A: 增强本体", stepA_build_enhanced_ontology),
        ("Step B: 增强ASR修复", stepB_refix_asr),
        ("Step C: 全管道重建", stepC_full_pipeline),
    ]

    for name, func in steps:
        step(name)
        try:
            if not func():
                log(f"❌ {name} 失败")
                sys.exit(1)
        except Exception as e:
            log(f"💥 {name} 异常: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    log(f"\n{'='*50}")
    log("✅ 全流程完成")
    log(f"  本体: {SUBJECT_FIXED}")
    log(f"  优化: {DOCS_DIR / '培训材料md-优化'}/")
    log(f"{'='*50}")
    sys.exit(0)


if __name__ == "__main__":
    main()
