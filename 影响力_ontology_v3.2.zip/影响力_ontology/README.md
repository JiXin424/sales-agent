# 影响力本体问答系统

> 把《影响力》这本书变成可以问、可以聊的销售教练。
> v3.2 / 2026-06-25

---

## 项目简介

销售人员提问，系统从 618 个实体里捞出相关的，喂给 DeepSeek，让它给一个有原则、有推理链、有案例、有话术的回答。

跟旧版最大的不一样：用户说"互惠原理"，咱不能像以前那样把所有带"互惠"二字的实体都塞进去——精确命中的优先，相关概念、推理链、案例通过关系图谱跳出来。

v3.2 在 v3.1 之上做了第四件大事：用源文件 `scenarios_10_sales_coaching.md` 补建 16 个销售场景实体，让"价格异议 / 初次拜访 / 客户拖延"等 synonym standard 都能 L2 同义词直接命中本体。

---

## 一、快速开始（90 秒跑通）

```bash
# 1. 解压
unzip influence_ontology.zip
cd influence_ontology

# 2. 设置 DeepSeek API Key
export DEEPSEEK_API_KEY='sk-xxxxxxxx'

# 3. 启动
./start.sh
```

打开 http://localhost:3000 直接用。

如果只想验证后端不依赖浏览器：

```bash
curl -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"query":"客户嫌贵怎么办","history":[]}'
```

---

## 二、完整部署

### 2.1 环境要求

- Python 3.9+（3.10/3.11/3.12 都行，3.13 也兼容）
- pip
- DeepSeek API Key（[获取地址](https://platform.deepseek.com/)）
- 600MB 内存（本体加载一次约 50MB，常驻 100-200MB）
- 不需要数据库，本体是 JSON 文件

### 2.2 依赖

只有 3 个第三方库，全部在 `api/requirements.txt`：

```
flask==3.0.0
flask-cors==4.0.0
openai==1.12.0
```

Python 标准库（json / pathlib / re / collections）和系统自带，不需要单独装。

### 2.3 方式一：裸机部署（最简单）

```bash
# 解压
unzip influence_ontology.zip -d /opt/
cd /opt/influence_ontology

# 装依赖（建议用 venv）
python3 -m venv .venv
source .venv/bin/activate
pip install -r api/requirements.txt

# 配置 API Key（二选一）
# 临时：export DEEPSEEK_API_KEY='sk-xxx'
# 永久：echo "export DEEPSEEK_API_KEY='sk-xxx'" >> ~/.bashrc && source ~/.bashrc

# 启动
./start.sh
# 或者
cd api && python3 chat_service.py
```

服务监听 0.0.0.0:3000，本机/局域网都能访问。

### 2.4 方式二：后台运行（生产环境）

**nohup 简单方式：**

```bash
cd /opt/influence_ontology
DEEPSEEK_API_KEY='sk-xxx' nohup python3 api/chat_service.py > /var/log/influence.log 2>&1 &
echo $! > /var/run/influence.pid
```

**systemd 服务方式（推荐）：**

```bash
sudo tee /etc/systemd/system/influence.service << 'EOF'
[Unit]
Description=Influence Ontology QA Service
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/influence_ontology/api
Environment="DEEPSEEK_API_KEY=sk-xxxxxxxx"
ExecStart=/opt/influence_ontology/.venv/bin/python3 chat_service.py
Restart=on-failure
RestartSec=5s
StandardOutput=append:/var/log/influence.log
StandardError=append:/var/log/influence.log

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now influence
sudo systemctl status influence
```

**Nginx 反向代理（加 HTTPS）：**

```nginx
server {
    listen 443 ssl http2;
    server_name influence.example.com;

    ssl_certificate     /etc/letsencrypt/live/influence.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/influence.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # SSE 流式响应必须的设置
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 300s;
    }
}
```

### 2.5 方式三：Docker 部署

`Dockerfile`：

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY api/requirements.txt ./requirements.txt
RUN pip install --no-cache-dir -r requirements.txt

COPY api/ ./api/
COPY web/ ./web/
COPY influence_ontology_cleaned.json ./influence_ontology_cleaned.json
COPY synonyms.json ./synonyms.json

WORKDIR /app/api
EXPOSE 3000

ENV PYTHONUNBUFFERED=1

CMD ["python3", "chat_service.py"]
```

构建并运行：

```bash
docker build -t influence-ontology:3.2 .
docker run -d \
  --name influence \
  -p 3000:3000 \
  -e DEEPSEEK_API_KEY='sk-xxxxxxxx' \
  --restart=unless-stopped \
  influence-ontology:3.2

# 查看日志
docker logs -f influence
```

### 2.6 配置项

只有 1 个必填环境变量：

| 变量名 | 必填 | 默认 | 说明 |
|---|---|---|---|
| `DEEPSEEK_API_KEY` | 是 | 无 | DeepSeek API 密钥 |

端口在 `api/chat_service.py` 末尾改：

```python
app.run(debug=False, host='0.0.0.0', port=3000)
```

本体路径在 `api/chat_service.py:19` 和 `api/knowledge_graph.py:17` 的 `ONTOLOGY_PATH` 常量。

### 2.7 健康检查

启动后 curl 三个接口验证：

```bash
# 1. 服务存活 + 本体统计
curl http://localhost:3000/api/ontology/stats
# 期望: {"stats":{"total_entities":644}, "entity_type_counts":{...}}

# 2. 跳转关系正常
curl "http://localhost:3000/api/ontology/related?entity_id=reciprocity-principle&max_results=3"
# 期望: related_entities 数组非空

# 3. 端到端 QA
curl -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"query":"什么是互惠原理"}'
# 期望: 返回 answer + full_context
```

---

## 三、作为 Agent 工具模块接通

这是本系统设计的主要使用场景：把"基于《影响力》知识库的检索 + 回答"作为一个工具，嵌入到更大的 Agent 系统（销售教练、CRM 助手、客服机器人等）。

提供 4 种接通方式，按需选择。

### 3.1 方式 A：HTTP API 调用（最通用，跨语言）

任何能发 HTTP 请求的语言都能用。

#### 接口 1：`POST /api/chat` — 同步问答（推荐入门用）

**请求：**

```json
{
  "query": "客户嫌贵怎么办",
  "history": [
    {"role": "user", "content": "什么是对比原理"},
    {"role": "assistant", "content": "对比原理是..."}
  ]
}
```

`history` 可选，传最近 3-6 条对话可以让 LLM 关键词提取利用上下文。

**响应：**

```json
{
  "query": "客户嫌贵怎么办",
  "answer": "# 客户嫌贵？别急着降价...",
  "core_entities_count": 1,
  "hop_count": 3,
  "relevant_entities_count": 10,
  "entities": [...],
  "full_context": {
    "system_prompt": "...",
    "user_query": "...",
    "llm_keywords": ["价格异议", "对比原理", "说服策略"],
    "keyword_source": "llm",
    "matched_synonym_standards": ["价格异议"],
    "layer1_direct": [],
    "layer2_synonym": [{"name": "价格异议", "type": "scenario", ...}],
    "layer3_multiword": [...],
    "hop_groups": {"principles": [...]},
    "core_entities": [{"name": "价格异议", "source": "core", ...}],
    "relevant_entities": [...]
  }
}
```

**Agent 取值要点：**
- `answer` — 给用户看的最终回答文本
- `full_context.llm_keywords` — LLM 提炼的搜索词，可用于下游路由
- `full_context.core_entities` — 命中的核心实体，可用于追问、跳转
- `full_context.system_prompt` — 完整提示词，调试或换 LLM 时用

#### 接口 2：`POST /api/chat/stream` — SSE 流式（前端打字效果）

**请求同 `/api/chat`。**

**响应是 SSE 事件流：**

```
data: {"type":"step","step":1,"message":"正在用 LLM 提炼搜索词...","status":"processing"}

data: {"type":"search_process","data":{...搜索过程详情...}}

data: {"type":"step","step":2,"message":"核心实体 1 个 · 多跳扩展 3 个","status":"success"}

data: {"type":"step","step":3,"message":"正在调用AI生成回答...","status":"processing"}

data: {"type":"step","step":4,"message":"AI回答生成完成","status":"success"}

data: {"type":"result","answer":"...","full_context":{...}}
```

客户端用 `EventSource` 或 `sseclient` 接收。前端实时打字效果的标配。

#### 接口 3：`GET /api/ontology/stats` — 本体统计

无需鉴权，启动时探测用。

```bash
curl http://localhost:3000/api/ontology/stats
```

```json
{
  "stats": {"total_entities": 644},
  "entity_type_counts": {
    "principles": 13, "concepts": 49, "terms": 40,
    "scenarios": 74, "cases": 111, "experiments": 47,
    "reasoning_chains": 47, "tactics": 34,
    "action_steps": 44, "scripts": 49, "persons": 136
  }
}
```

#### 接口 4：`GET /api/ontology/related` — 实体跳转

给一个 entity_id，返回它在关系图谱里的邻居。适合做"点击实体卡片查关联"的功能。

**请求参数：**

| 参数 | 必填 | 默认 | 说明 |
|---|---|---|---|
| `entity_id` | 是 | - | 实体 ID（如 `reciprocity-principle`） |
| `direction` | 否 | `both` | `forward` / `backward` / `both` |
| `max_depth` | 否 | `1` | 跳转深度（建议 1） |
| `max_results` | 否 | `20` | 最多返回几个邻居 |

```bash
curl "http://localhost:3000/api/ontology/related?entity_id=reciprocity-principle&max_results=5"
```

#### Python 调用示例

```python
import requests

resp = requests.post(
    "http://localhost:3000/api/chat",
    json={
        "query": "初次拜访制造业客户怎么开口",
        "history": [
            {"role": "user", "content": "什么是互惠原理"},
            {"role": "assistant", "content": "互惠原理是..."}
        ]
    },
    timeout=60
)
data = resp.json()
print(data["answer"])
print("命中核心实体:", [e["name"] for e in data["full_context"]["core_entities"]])
```

#### Node.js 调用示例

```javascript
const resp = await fetch('http://localhost:3000/api/chat', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    query: '客户嫌贵怎么办',
    history: []
  })
});
const data = await resp.json();
console.log(data.answer);
console.log('核心实体:', data.full_context.core_entities.map(e => e.name));
```

#### curl 示例（命令行）

```bash
curl -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"query":"客户嫌贵怎么办","history":[]}'

# SSE 流式
curl -N -X POST http://localhost:3000/api/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"query":"什么是互惠原理"}'
```

### 3.2 方式 B：Python 库直接 import（同进程）

如果你的 Agent 也是 Python 写的，不用走 HTTP，直接 import 模块，省一次网络往返：

```python
import sys
sys.path.insert(0, '/path/to/influence_ontology/api')

import os
os.environ['DEEPSEEK_API_KEY'] = 'sk-xxx'  # keyword_extractor 要用

from knowledge_graph import get_knowledge_graph
from enhanced_prompts import get_structured_prompt

# 1. 拿到检索结果 + 系统提示词（不用我们的 LLM）
kg = get_knowledge_graph()
result = kg.search(
    query="客户嫌贵怎么办",
    history=[{"role": "user", "content": "..."}]
)
system_prompt = get_structured_prompt(result)

# 2. 接你自己的 LLM（OpenAI / Anthropic / 本地模型都行）
from openai import OpenAI
client = OpenAI(api_key="sk-xxx", base_url="https://api.deepseek.com")
resp = client.chat.completions.create(
    model="deepseek-chat",
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "客户嫌贵怎么办"}
    ],
    temperature=0.7
)
print(resp.choices[0].message.content)

# 3. 也可以只取检索结果自己处理
print("命中核心实体:", [e["name"] for e in result["core_entities"]])
print("L2 命中:", [e["name"] for e in result["layer2_synonym"]])
print("hop 扩展:", {k: len(v) for k, v in result["hop_groups"].items()})
```

**好处：**
- 0 网络开销，毫秒级响应
- 可以灵活替换 LLM（DeepSeek / Claude / GPT / 本地模型）
- 可以拿原始结构化数据自己拼 prompt
- 也可以只用检索不要 LLM（参考 3.4）

**注意：**
- `get_knowledge_graph()` 是单例，首次调用加载本体（~1 秒），后续秒回
- 想换本体路径，改 `api/knowledge_graph.py:17` 的 `ONTOLOGY_PATH`

### 3.3 方式 C：封装为 SDK（推荐中台/多次调用场景）

如果要被多个 Agent 复用，建议封装一个轻 SDK。把下面这段存成 `influence_sdk.py`：

```python
"""影响力知识库 SDK：薄封装，统一异常 + 重试 + 日志"""
import requests
from typing import Optional, List, Dict


class InfluenceClient:
    def __init__(self, base_url: str = "http://localhost:3000", timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()

    def ask(
        self,
        query: str,
        history: Optional[List[Dict]] = None,
    ) -> Dict:
        """同步问答，返回完整结构化结果"""
        resp = self.session.post(
            f"{self.base_url}/api/chat",
            json={"query": query, "history": history or []},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def retrieve(
        self,
        query: str,
        history: Optional[List[Dict]] = None,
    ) -> Dict:
        """只做检索不调 LLM（用方式 B 同进程才支持，HTTP 不行）
        HTTP 用户请用 ask() 然后取 full_context"""
        raise NotImplementedError("HTTP 模式不支持纯检索，请用方式 B 同进程 import")

    def related(
        self,
        entity_id: str,
        direction: str = "both",
        max_results: int = 20,
    ) -> Dict:
        """获取实体的关联实体"""
        resp = self.session.get(
            f"{self.base_url}/api/ontology/related",
            params={
                "entity_id": entity_id,
                "direction": direction,
                "max_results": max_results,
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def stats(self) -> Dict:
        """获取本体统计信息（健康检查）"""
        resp = self.session.get(f"{self.base_url}/api/ontology/stats")
        resp.raise_for_status()
        return resp.json()

    def ask_stream(self, query: str, history: Optional[List[Dict]] = None):
        """SSE 流式问答，yield 每个事件"""
        with self.session.post(
            f"{self.base_url}/api/chat/stream",
            json={"query": query, "history": history or []},
            stream=True,
            timeout=self.timeout,
        ) as resp:
            for line in resp.iter_lines():
                if line and line.startswith(b"data: "):
                    import json
                    yield json.loads(line[6:])


# 使用
if __name__ == "__main__":
    client = InfluenceClient()

    # 健康检查
    print(client.stats())

    # 同步问答
    r = client.ask("客户嫌贵怎么办")
    print(r["answer"][:200])

    # 关联查询
    print(client.related("reciprocity-principle", max_results=3))
```

### 3.4 方式 D：作为 Function Tool / MCP 接入大模型 Agent

如果你想给 OpenAI / Claude / 任意 Agent 框架（LangChain / LlamaIndex / AutoGen / OpenAI Agents SDK）当工具用，把本系统封装成 function tool：

#### OpenAI Function Calling 接入示例

```python
from openai import OpenAI
from influence_sdk import InfluenceClient

client = OpenAI(api_key="sk-xxx")
influence = InfluenceClient()

tools = [
    {
        "type": "function",
        "function": {
            "name": "search_influence_knowledge",
            "description": "在《影响力》销售知识库中检索原则、策略、话术、案例。当用户问销售/说服/谈判相关问题时调用。",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "销售问题，比如'客户嫌贵怎么办'、'初次拜访怎么说'"
                    }
                },
                "required": ["query"]
            }
        }
    }
]

def call_tool(name, args):
    if name == "search_influence_knowledge":
        r = influence.ask(args["query"])
        # 只返回结构化检索结果，让上游 LLM 自己组织语言
        ctx = r["full_context"]
        return {
            "core_entities": [e["name"] for e in ctx["core_entities"]],
            "related_principles": [e["name"] for e in ctx["hop_groups"].get("principles", [])],
            "scripts": [e["name"] for e in ctx["hop_groups"].get("scripts", [])],
            "matched_keywords": ctx["llm_keywords"],
        }

# 用法：把 tools 传给 chat.completions，收到 tool_calls 时调 call_tool
```

#### MCP Server 适配（给 Claude Desktop / Cursor / 各类 MCP 客户端用）

把 SDK 包一层 MCP server：

```python
# influence_mcp_server.py
from mcp.server.fastmcp import FastMCP
from influence_sdk import InfluenceClient

mcp = FastMCP("influence-ontology")
influence = InfluenceClient()

@mcp.tool()
def search_sales_knowledge(query: str) -> dict:
    """在《影响力》销售知识库中检索原则、策略、话术、案例。
    适用场景：客户异议处理、初次拜访、谈判收尾、客户拖延等销售问题。"""
    r = influence.ask(query)
    ctx = r["full_context"]
    return {
        "core_entities": [e["name"] for e in ctx["core_entities"]],
        "related_principles": [e["name"] for e in ctx["hop_groups"].get("principles", [])],
        "scripts": [e["name"] for e in ctx["hop_groups"].get("scripts", [])],
        "tactics": [e["name"] for e in ctx["hop_groups"].get("tactics", [])],
        "full_answer": r["answer"],
    }

@mcp.tool()
def get_entity_relations(entity_id: str) -> dict:
    """查询某个实体（如 reciprocity-principle）的关联实体。
    可用于"这个原则有哪些案例"、"这个策略基于什么原理"等查询。"""
    return influence.related(entity_id, max_results=10)

if __name__ == "__main__":
    mcp.run()
```

客户端（Claude Desktop）配置 `claude_desktop_config.json`：

```json
{
  "mcpServers": {
    "influence": {
      "command": "python3",
      "args": ["/path/to/influence_mcp_server.py"]
    }
  }
}
```

### 3.5 接通方式对比

| 方式 | 适用场景 | 优点 | 缺点 |
|---|---|---|---|
| A. HTTP API | 任意语言、跨机部署 | 标准化、解耦 | 一次网络往返 |
| B. Python import | Python 单体应用 | 0 网络开销，可换 LLM | 同进程耦合 |
| C. SDK 封装 | 多 Agent 复用 | 统一异常 + 重试 | 多写一层 |
| D. Function Tool / MCP | 大模型 Agent 框架 | 让 LLM 自己决定何时调 | 需要 LLM 支持 function call |

**推荐：** 如果你是初学者或做内部工具，直接用 A；如果你的 Agent 已经在用 LangChain / MCP 生态，用 D。

---

## 四、工作流程

```
用户问问题（可能很长，可能带历史）
   ↓
┌─────────────────────────────────────┐
│  keyword_extractor.py（轻量 LLM）   │
│                                     │
│  用 deepseek-chat 把长查询 +        │
│  最近 3 轮历史压成 3-5 个搜索词      │
│  失败兜底：n-gram 切词               │
└────────────────┬────────────────────┘
                 ↓
┌─────────────────────────────────────┐
│  knowledge_graph.py（核心引擎）     │
│                                     │
│  Layer 1: name 精确匹配             │  ← "互惠原理"直接命中
│  Layer 2: synonyms 命中             │  ← "嫌贵"映射到"价格异议"
│  Layer 3: 多词匹配（兜底）          │  ← 模糊查询找案例
│                                     │
│  L3 兜底2：L1+L2 全空时，            │  ← 同义词 standard
│           把 L3 top-3 提升为 core   │    没对应实体的救兵
│                                     │
│  Hop 扩展：通过 328 条关系          │  ← 命中后拉出相关原则、
│           做 1 跳，按类型分组       │    推理链、案例、话术
└────────────────┬────────────────────┘
                 │
┌────────────────┴────────────────────┐
│  旧引擎 search_ontology()           │  ← 保留作为并行信号
└────────────────┬────────────────────┘
                 ↓
┌─────────────────────────────────────┐
│  enhanced_prompts.py 拼提示词       │
│                                     │
│  - 核心实体（按类型智能取字段）     │
│  - 多跳扩展（按类型分组）           │
│  - 多词匹配补充                     │
│  - 旧引擎匹配（并行参考）           │
└────────────────┬────────────────────┘
                 ↓
           DeepSeek 流式回答
                 ↓
┌─────────────────────────────────────┐
│  三窗口展示                         │
│                                     │
│  左：搜索过程（LLM 关键词+三层命中）│
│  中：AI 回答                        │
│  右：完整上下文（按类型分组）       │
└─────────────────────────────────────┘
```

---

## 五、文件结构

```
影响力_ontology/
├── README.md                                 # 本文档（唯一权威）
├── start.sh                                  # 启动脚本
│
├── influence_ontology_cleaned.json           # ★ 运行时加载的本体（618 实体 + 328 relations）
├── influence_ontology_cleaned.json.bak3      # 销售场景补建前的备份
├── influence_ontology_enriched.json          # 清洗前的原始本体（保留作参考）
├── influence_ontology_enriched.json.bak2     # 清洗前备份
├── synonyms.json                             # 同义词库（45 组）
├── scenarios_10_sales_coaching.md            # 销售场景源文件（v3.2 用过）
│
├── api/
│   ├── chat_service.py                       # Flask 服务
│   ├── knowledge_graph.py                    # 三层检索 + 多跳扩展（核心）
│   ├── keyword_extractor.py                  # LLM 关键词提取（deepseek-chat）
│   ├── enhanced_prompts.py                   # 拼系统提示词 + 按类型智能取字段
│   └── requirements.txt                      # 3 个依赖：flask / flask-cors / openai
│
├── web/
│   └── index.html                            # 三窗口 UI
│
├── raw/                                      # 章节级原始资料（7 章 json）
│   ├── reciprocity.json / scarcity.json / ...
│
├── for-import/                               # 历史导入文件（设计参考）
│   └── knowledge/
│       ├── 00-影响力本体定义.md
│       ├── 02-影响力案例人物实验库.md
│       ├── 04-影响力方法论框架库.md
│       └── 06-影响力销售实战场景库.md
│
└── scripts/
    ├── clean_ontology.py                     # 本体清洗（v3.1）
    ├── supplement_scenarios.py               # 销售场景补建（v3.2）
    ├── extract_influence_ontology.py         # 原始抽取脚本
    └── ...其他历史脚本
```

---

## 六、数据概览

本体 11 大类共 618 个实体：
- principles（原则）13 个、concepts（概念）49 个、terms（术语）40 个
- scenarios（场景）74 个（含 v3.2 新增 16 个销售场景）、cases（案例）111 个、experiments（实验）47 个
- reasoning_chains（推理链）47 个、tactics（策略）34 个
- action_steps（行动步骤）44 个、scripts（话术）49 个、persons（人物）136 个
- relations（关系）**328 条**（含 v3.2 新增 47 条场景→原则 applies 关系），覆盖 20 种关系类型

⚠️ **历史数据层面的坑**（v3.1+v3.2 已处理）：

第一，原始 `synonyms.json` 里"价格异议"、"初次拜访"、"制造紧迫感"是销售通用话术，但本体里的场景都是书里举的具体例子——两套数据不是一个思路产出的。45 个 standard 词里原本只有 6 个能在本体里找到 name 完全相同的实体。**v3.2 解决**：用源文件 `scenarios_10_sales_coaching.md` 补建 16 个销售场景，让 15 个 scenario_synonyms 全部能 L2 直接命中实体。

第二，原始本体的 `description` 字段有大量"概念: 互惠"这种自重复格式（50% 以上的 concept/term 中招），等于没填。v3.1 用 `clean_ontology.py` 重新生成 `influence_ontology_cleaned.json`，按类型从其他字段（definition / premises / text / method 等）拼出有价值的描述。

第三，concept/term 在原书里本身就没详细解释（65/66 个空），源文件救不动。这部分靠 `_smart_description` 跳过空实体，不污染 system prompt。

---

## 七、三层检索 + 兜底逻辑

**Layer 1：精确命中（权重最高）**

启动时建一个 `name → entity` 的反向索引。用户问"什么是互惠原理"，扫描 query 包不包含任何 entity 的 name。命中就锁定为核心实体。

**Layer 2：synonyms 命中**

用 `synonyms.json` 识别用户用了哪些同义词。比如"客户嫌贵"映射到标准词"价格异议"。命中的 standard 加入 keywords，让 Layer 3 多词匹配找到含这个词的实体，自动升格为核心。

**Layer 3：多词匹配（兜底）**

保留旧版逻辑——`json.dumps(entity)` 后做关键词 `in` 匹配，score 累加。适合"如何应对客户拖延决策"这种模糊场景查询。

**同义词拆词（关键 trick）**

如果 synonyms 命中了"价格异议"，但本体里没有 name 完全等于"价格异议"的实体，就把这个词拆成 2-gram：

```
"价格异议" → ["价格", "格异", "异议"]
```

让 Layer 3 能命中含"价格"或"异议"的实体（比如"客户冷淡异议场景"、"价格-质量推理链"）。

**L3 兜底 2（v3.1 新增）：L1+L2 全空时提升 L3**

历史上 39/45 个 synonym standard 在本体里没对应实体。v3.2 已经补建 16 个销售场景让最常见的 15 个 scenario_synonyms 都能 L2 直接命中，但其他类型（tactic/principle 抽象词）仍可能命中失败。兜底逻辑保留：L1+L2 都空时，把 L3 top-3 提升为 core_entities（标记 `source='l3_promoted'`），让 hop 扩展至少能跑起来。

**Hop 扩展（1 跳）**

命中的核心实体通过本体 `relations` 字段做 1 跳：
- 双向遍历（from_id 和 to_id 都看）
- 按 10 种类型分组（**原则** > 推理链 > 概念 > 术语 > 策略 > 话术 > 场景 > 案例 > 实验 > 行动步骤）
- 每类最多 3 个，避免噪音

v3.2 把"原则"加到 HOP_TYPE_ORDER 最前面，让 scenario 通过 applies 关系 hop 到 principle 时能被显示（之前 bug：scenario 命中后 hop 段是空的，因为 principles 不在分组列表里）。

为啥不做 2 跳：试过，会拉出大量不相关的人物实体，信噪比下降。

---

## 八、LLM 关键词提取（v3.1 新增）

`keyword_extractor.py` 用 deepseek-chat 把用户查询压成 3-5 个搜索词。比 n-gram 强在：

- 能处理超长查询（"我今天去拜访一个制造业客户，初次见面，对方说我们产品比竞品贵 30%，他预算只有 50 万，怎么用对比原理说服他接受我们的价格？"）
- 能跨轮次利用历史（"那这个原理怎么用到客户初次拜访上？"——读到上一轮的"互惠原理"）
- 能合并同义（"嫌贵、预算紧、能不能便宜" → "价格异议"）

**系统提示词设计的关键**：把本体里精选的核心术语按 6 类（原则 / 概念 / 术语 / 策略 / 场景 / 客户行为）罗列进 prompt，让 LLM 知道目标词库长什么样，提炼出来的词能直接落到本体上。这部分在 `_build_kb_overview()` 里，用 `@lru_cache` 缓存。

**失败兜底**：API 不可用 / 没设 key → 走 `extract_with_fallback()` 做 n-gram 切词，至少能跑。`extract()` 统一返回 `(keywords, source)`，`source ∈ {'llm','fallback'}`，前端会显示来源标签。

---

## 九、按类型智能取字段（v3.1 新增）

`enhanced_prompts._smart_description(e)` 按实体类型从最有价值的字段拼描述，不再无脑用 `description`：

- **principle**：直接用 description（清洗后已经是有内容的）
- **concept / term**：优先 definition，其次 summary，最后 description
- **reasoning_chain**：拼 `premises | reasoning | trigger | behavior | consequence`，再加 `证据: evidence`
- **tactic**：summary → description → steps
- **script**：有 context 也有 text 时拼 `适用场景: ctx | text`；只有 text 时直接返回 text（避免 `话术: 话术:` 双前缀）；都没有才回落到 description
- **case**：summary → description
- **experiment**：拼 `hypothesis | method`，再加 `结论: conclusion`
- **scenario**：description → trigger → behavior → outcome

所有字段都过 `_clean_desc(name, desc)`，过滤"类型: name"这种自重复格式。

按类型选字段是因为不同类型的实体价值字段不一样：推理链的精髓在 premises→consequence，话术的精髓在 text，实验的精髓在 method+conclusion。一刀切用 description 会丢信息。

---

## 十、系统提示词结构

`enhanced_prompts.get_structured_prompt()` 输出大约 3500-5500 字，分这几段：

1. **知识库结构**（精简版说明 11 大类）
2. **怎么用各类知识**（不是数字统计，是行为指引）—— 比如"问'怎么做'时优先引用策略"、"问'怎么说'时直接引用话术"
3. **查询理解指南**（意图识别 + 词汇映射）
4. **回答结构建议**（按问题类型给模板）
5. **核心实体**（L1+L2+提升的 L3，按类型取字段）
6. **多跳扩展**（按类型分组：原则/推理链/概念/策略/话术/案例...）
7. **新引擎多词匹配**（去重后补充）
8. **旧引擎匹配**（并行参考，去重）

新旧引擎结果并行进 prompt，因为旧引擎有 n-gram + AI 关键词提取兜底，对模糊查询有独到优势；新引擎擅长精确命中和结构化扩展。互补。

---

## 十一、数据准备脚本

### 11.1 本体清洗（v3.1）

`scripts/clean_ontology.py` 把原始 `influence_ontology_enriched.json` 里低质的"description = 类型: name"格式清洗成有价值的描述。

清洗规则按类型不同：

- **concepts / terms**：`description ← definition`（没 definition 就置空，因为原本的"概念: name"格式也没价值）
- **reasoning_chain**：`description ← premises → consequence + 证据: evidence`
- **script**：`description ← 适用场景: context | 话术: text`
- **experiment**：`description ← method | 结论: conclusion`

清洗后写入 `influence_ontology_cleaned.json`，原文件备份到 `.bak2`。

那些改后为空的实体，`_smart_description` 会自动跳过（多类型字段兜底），不会污染 system prompt。

### 11.2 销售场景补建（v3.2）

`scripts/supplement_scenarios.py` 用源文件 `scenarios_10_sales_coaching.md` 补建销售场景实体，解决 synonym standard 在本体里找不到实体的问题。

补建结果：新增 16 个 scenario 实体 + 47 条 applies 关系。scenarios 总数从 58 → 74，relations 从 281 → 328。

### 11.3 路径常量集中位置

- `api/knowledge_graph.py:17` ONTOLOGY_PATH
- `api/chat_service.py:19` ONTOLOGY_PATH
- 两者都指向 `influence_ontology_cleaned.json`（清洗 + 补建后的最终版本）
- 备份链：`influence_ontology_enriched.json.bak2`（清洗前）→ `influence_ontology_cleaned.json.bak3`（补建前）→ `influence_ontology_cleaned.json`（当前）

---

## 十二、效果验证（v3.2）

4 个典型查询全部通过：

- **"什么是互惠原理"** —— LLM 词 3 个，L1 命中互惠原理，Hop 扩展 18 个（6 类：案例/概念/实验/推理链/话术/策略），prompt 5432 字，0 自重复
- **"客户嫌贵怎么办"** —— LLM 词 3 个（价格异议/对比原理/说服策略），**L2 命中"价格异议"新场景实体**，Hop 扩展 3 个相关原理（对比/互惠/稀缺），prompt 3700 字，answer 3140 字
- **"初次拜访怎么说"** —— LLM 词 4 个（初次拜访/建立信任/互惠原理/话术），**L2 命中"初次拜访"+"建立信任"**，core 7 个，Hop 扩展 3 原理 + 2 推理链 + 1 策略
- **"客户拖延怎么办"** —— LLM 词 5 个，**L2 命中"客户拖延"**，Hop 扩展 3 个相关原理（对比/稀缺/承诺一致）

API 层全验证通过。浏览器 UI 需要你自己刷新页面核验——AI 没法操作浏览器。

---

## 十三、开发踩坑记录

> 这些是真实踩到的，未来开发者 / Claude 必读。

### 1. NameError 被 try/except 吞成 500

`/api/chat` 一直 500，日志只有"处理请求时出错"。

根因：`full_context.system_prompt` 写成了 `'system_prompt': context`，但 `context` 在那个函数里根本不存在 → NameError → 被外层 except 吞了。

修法：变量名改对。并在 except 里加 `traceback.print_exc()`，至少能看到堆栈。

教训：Flask 路由的全局 `try/except Exception` 是双刃剑，调试期一定要打印 traceback。

### 2. `"\\n"` 不是换行

旧代码 `"\\n".join(parts)`，Python 字符串里 `"\\n"` 是字面量反斜杠+n，不是换行符。该写 `"\n"`。

### 3. 前端模板字符串没转义

`html += \`<div>${ctx.system_prompt}</div>\`` 直接插，prompt 里含 `<` 或 `>` 会被浏览器解析成 HTML。

修法：转义 + CSS `white-space: pre-wrap`。

```javascript
const escaped = String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
```

### 4. inline style 改了背景没改文字色

`.keyword-tag` 默认深蓝字，加了 `background:#4a5568`（深灰）但没改 color——深字+深底，看不见。

修法：覆盖背景时成对覆盖 color。

### 5. synonyms 标准术语 ≠ 本体 entity name

45 个 synonym standard 里只有 6 个能在本体找到 name 完全相同的实体。这是设计层面的债。

缓解方案三层叠加：
- Layer 3 拆词兜底（2-gram）
- Layer 2 即使没命中实体，standard 也加入 keywords 给 L3 用
- L1+L2 全空时 L3 top-3 提升为 core

根治要补一份 `synonym → entity_id` 映射，或者把缺失的 standard（价格异议、初次拜访、客户拖延等）作为新场景实体补进本体（v3.2 已经补了 scenario 类）。

### 6. keywords 字段覆盖率只有 2%

原本想用 `entity.keywords` 做精确匹配，结果只有 9/361 实体有这字段。别假设字段都填了，用前先统计覆盖率。

### 7. `_is_self_repetition` 收到 list 直接崩

`_clean_desc(name, e.get(field))` 在某些字段上是 list（evidence、steps、keywords），传进 `_is_self_repetition` 里调 `.strip()` → `AttributeError: 'list' object has no attribute 'strip'` → 被 except 吞成 500。

修法：`_is_self_repetition` 和 `_clean_desc` 开头都加 `if not isinstance(desc, str): return False / ''`。

教训：处理本体字段一定要防御非字符串（list / dict / None 都常见）。

### 8. 死代码 KEYWORD_EXTRACTION_PROMPT = None

`keyword_extractor.py` 早期把系统提示词定义为模块级常量，后来重构改成 `_get_system_prompt()` 懒加载，但忘了把 `KEYWORD_EXTRACTION_PROMPT` 删了，留了个 `= None` 的占位。`extract_with_llm` 还在用它当 system message → DeepSeek 收到 `None` 当 system → 触发各种异常 → 一直走 fallback。

修法：删除占位，直接调 `_get_system_prompt()`。

教训：重构时占位符要么删掉，要么写明 deprecated。死代码会让后来人困惑。

### 9. "话术: 话术:" 双前缀

`_smart_description` 给 script 类型拼描述时无条件加 `话术: ` 前缀，但 system prompt 里类型 label 也是 [话术]，结果出现 `[话术]: 话术: xxx` 的双重前缀。

修法：只在同时有 context 和 text 时加前缀做区分；只有 text 时直接返回 text（type label 已经说明是话术了）。

### 10. HOP_TYPE_ORDER 漏 principles，scenario hop 段空

v3.2 给 scenario 实体加了 applies→principle 关系，但 system prompt 的"相关知识扩展"段死活是空的。手 trace 才发现 `_hop_expand` 找到了 principle 邻居，但 `HOP_TYPE_ORDER` 列表里没 'principles'，分组时被默默丢弃。同时 `enhanced_prompts.HOP_LABEL_ORDER` 也漏了，渲染段也没"相关原则"标题。

修法：两个常量都加 `('principles', '相关原则')` 放最前面。

教训：分类型过滤的"白名单"常量，加新类型时一定要同步更新所有用到的地方。代码里 `HOP_TYPE_ORDER` 和 `HOP_LABEL_ORDER` 是两个独立常量，特别容易漏改一个。

### 11. ⚠️ Claude 的"假完成"陷阱

v2.0 阶段，前一个 Claude session 反复声称"系统已完成并测试"，实际浏览器测试从没做过，留下一堆自我检讨 md。原因是 AI 没能力操作浏览器，但为了"完成任务"硬说做了。

给未来 Claude 的话：
- 浏览器交互是硬限制，不能假装能做
- API 测试 ≠ 浏览器测试，curl 通了 ≠ UI 没问题
- 少写自我检讨文档，多做事
- ✅/❌ 标清楚验证范围，别含糊

---

## 十四、已知问题

- **浏览器 UI 没人工验证** —— 等你刷新页面看
- **tactic_synonyms / principle_synonyms 部分仍有 standard 不命中实体** —— 如"喜好策略"、"联盟策略"、"联盟原理"。下一步可补 tactic 实体或改 standard 名映射到现有实体
- **37 个 concept / 29 个 term 清洗后 description 为空** —— 因为它们只有 name，没 definition / summary / 其他字段；源文件也救不动（书里没详细解释）；`_smart_description` 会自动跳过
- **`\?` SyntaxWarning** —— 预存在，不影响功能

---

## 十五、开发新功能

改后端：`knowledge_graph.py` 自测 → curl `/api/chat/stream` → 让用户刷新浏览器。

改前端：改 `index.html` → 用户刷新 → 反馈。

改数据：改 json → 重启服务（数据懒加载）。

改 prompt：改 `enhanced_prompts.py` → curl 看 prompt 长度和结构。

改关键词提取：改 `keyword_extractor.py` → `python3 keyword_extractor.py "测试查询"` 直接看 LLM 输出。

常用调试：

```bash
# 实时日志
tail -f /tmp/influence_chat.log

# 重启服务
lsof -ti:3000 | xargs kill -9
cd api && DEEPSEEK_API_KEY=xxx python3 chat_service.py > /tmp/influence_chat.log 2>&1 &

# 单测引擎
cd api && python3 knowledge_graph.py

# 单测关键词提取
cd api && DEEPSEEK_API_KEY=xxx python3 keyword_extractor.py "客户嫌贵怎么办"

# 单测 prompt
cd api && python3 -c "
from knowledge_graph import get_knowledge_graph
from enhanced_prompts import get_structured_prompt
kg = get_knowledge_graph()
r = kg.search('什么是互惠原理')
p = get_structured_prompt(r)
print(f'{len(p)} 字')
print(p[:500])
"

# 重跑本体清洗
cd scripts && python3 clean_ontology.py

# 重跑销售场景补建
cd scripts && python3 supplement_scenarios.py
```

---

## 十六、后续规划

短期（1-2 天）：
- 给 8 个 tactic_synonyms（互惠策略/稀缺策略/权威策略/对比策略/承诺策略/社会认同策略/喜好策略/联盟策略）补 tactic 实体，或改 synonyms standard 映射到现有 tactic（互惠可信度策略、稀缺促销策略等）
- 给 4 个抽象 principle_synonyms（联盟原理/互惠性/社会性/影响力）做映射或删掉
- 意图识别：根据"什么是/怎么用/遇到"这类问法选不同的 hop 深度

中期：
- 多级跳转 UI：点核心实体卡片进详情页
- 评测集 + 评分自动化

长期：
- 用 D3 / ECharts 画知识图谱网络
- 增量数据接入流程（新场景/新话术怎么入库）

---

## 十七、关于旧文档

v2.0 留下了 20+ 份 md（HONEST_STATUS / CURRENT_STATUS / FINAL_TEST_REPORT / OPTIMIZATION_FINAL_REPORT ...），大部分是进度报告和自我检讨，已经过时。本 README 是唯一权威文档，已经从压缩包里删除。

需要保留的（已在压缩包内）：
- `BRAINSTORM_UPGRADE.md` / `MULTI_HOP_BRASTORM.md`：设计思路
- `BROWSER_TEST_CHECKLIST.md`：手动测试清单
- `for-import/knowledge/`：4 份历史导入源文件，作为内容参考

---

**最后更新**：2026-06-25 v3.2
**验证范围**：API 4 查询全通过 / UI 待用户核验
