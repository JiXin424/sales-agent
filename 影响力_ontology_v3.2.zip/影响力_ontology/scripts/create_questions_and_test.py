#!/usr/bin/env python3
"""为10个销售场景各设计3个问题，并在影响力本体系统上测试，生成帮助度报告。"""

import json
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# 10个场景的30个问题
SCENARIO_QUESTIONS = {
    1: {
        "title": "大客户初次拜访",
        "questions": [
            "第一次拜访客户时，客户时间紧张且有戒备心理，如何快速建立信任并让客户愿意深入交流？",
            "客户说「你们这类销售我见多了」，如何应对这种常见的拒绝并反转对话？",
            "如何将模糊的「再联系」转化为明确的下一步承诺，避免客户拖延？",
        ]
    },
    2: {
        "title": "价格异议处理",
        "questions": [
            "客户说「比竞品贵30%」，如何在不降价的前提下让客户理解价值差异？",
            "如何在价格谈判中改变客户的参照系，从「比谁便宜」转向「值多少钱」？",
            "客户要求折扣但我想维护价格体系，如何用拒绝—后撤术处理？",
        ]
    },
    3: {
        "title": "多方决策人梳理",
        "questions": [
            "客户内部决策链复杂（采购/IT/业务/财务），如何识别真正的决策者并避免在错误的联系人上浪费时间？",
            "中间联系人不愿意引荐决策者，如何通过向上管理让他成为内部盟友？",
            "多方决策时，如何让不同角色的决策者都感受到价值并获得他们的支持？",
        ]
    },
    4: {
        "title": "替换在用竞品",
        "questions": [
            "客户已有稳定运行的竞品系统且满意度较高，如何找到切入点并让其考虑替换？",
            "客户对现有供应商有长期合作关系和信任基础，如何不攻击对手的前提下发现其未被满足的需求？",
            "如何用低成本试点降低客户的换供应商风险感知？",
        ]
    },
    5: {
        "title": "招标书响应策略",
        "questions": [
            "客户发了RFP（招标书），参数明显偏向竞品，如何差异化响应避免陷入参数比拼？",
            "如何在技术评分落后时，通过商务条款和风险评估扭转局面？",
            "招标过程中客户说「你们价格最高」，如何用锚定效应重新定义价格坐标系？",
        ]
    },
    6: {
        "title": "培养内部支持者",
        "questions": [
            "客户内部有一个人认可我们的方案，但影响力不够，如何将其升级为内部倡导者？",
            "如何让内部支持者在关键决策会议上主动为我们的方案发声？",
            "支持者担心向上管理失败会影响自己的职业发展，如何降低他的风险感知？",
        ]
    },
    7: {
        "title": "商务谈判收尾",
        "questions": [
            "签约前客户突然提出额外的保修、培训要求，如何在维护利润的前提下处理？",
            "客户要求「先试用再付款」，如何用条件交换降低风险同时保障现金流？",
            "谈判陷入僵局，客户说「不满足这个条件就不签」，如何破局？",
        ]
    },
    8: {
        "title": "唤醒沉睡客户",
        "questions": [
            "客户搁置项目半年没动静，如何重新激活并让其将项目提升为优先级？",
            "客户说「预算被砍了，项目暂时搁置」，如何用时间窗口制造紧迫感？",
            "长期跟进后客户仍然拖延，如何放大拖延成本推动决策？",
        ]
    },
    9: {
        "title": "存量客户扩Scope",
        "questions": [
            "老客户只用基础模块，如何将其扩展到数据中台、AI预测等高级模块？",
            "客户说「现有功能够用」，如何让其意识到未使用功能的隐性价值？",
            "客户总部压降本指标，如何在不降价的前提下推动增购？",
        ]
    },
    10: {
        "title": "丢单后挽回关系",
        "questions": [
            "客户选择了竞品，如何在丢单后维护关系并为下一次机会埋伏笔？",
            "客户说「你们服务太差」而流失，如何承认问题并证明改进措施有效？",
            "丢单后客户拒绝沟通，如何通过提供价值重新建立连接？",
        ]
    },
}

def generate_questions_md():
    """生成scenarios_10_sales_coaching.md文件（兼容test_sales_scenarios.py格式）"""
    output_path = BASE_DIR / "scenarios_10_sales_coaching.md"
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("# 10个销售教练场景\n\n")
        for num, data in SCENARIO_QUESTIONS.items():
            f.write(f"## 场景 {num}：{data['title']}\n")
            f.write("**背景**：基于影响力原则的销售教练场景\n")
            for i, q in enumerate(data['questions'], 1):
                f.write(f"{i}. {q}\n")
            f.write("\n")

    print(f"Generated: {output_path}")
    return output_path

def run_test_script():
    """运行test_sales_scenarios.py进行测试"""
    test_script = BASE_DIR / "scripts" / "test_sales_scenarios.py"

    if not test_script.exists():
        print(f"Error: Test script not found at {test_script}")
        return None

    print(f"Running test script: {test_script}")
    result = subprocess.run(
        ['python3', str(test_script)],
        capture_output=True,
        text=True,
        cwd=str(BASE_DIR)
    )

    print("STDOUT:", result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)

    return result.returncode == 0

def main():
    print("=" * 60)
    print("步骤1：生成10个场景的30个问题文件")
    print("=" * 60)
    md_path = generate_questions_md()

    print("\\n" + "=" * 60)
    print("步骤2：运行影响力本体系统测试")
    print("=" * 60)
    success = run_test_script()

    if success:
        print("\\n" + "=" * 60)
        print("步骤3：查看生成的报告")
        print("=" * 60)

        report_md = BASE_DIR / "scenario_test_report.md"
        report_json = BASE_DIR / "scenario_test_report.json"

        if report_md.exists():
            print(f"✅ Markdown报告: {report_md}")
        if report_json.exists():
            print(f"✅ JSON报告: {report_json}")
    else:
        print("\\n❌ 测试失败，请检查错误信息")

if __name__ == "__main__":
    main()
