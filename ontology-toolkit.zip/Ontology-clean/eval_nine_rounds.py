"""9轮滚动评测脚本 — 3套x30题，每套3轮滚动优化

评测架构：
- Set 1 (R1-R3): 基础认知 — 公司/产品/规格/竞品/资质/政策
- Set 2 (R4-R6): 复杂推理 — 竞品对比/场景匹配/方案推荐
- Set 3 (R7-R9): 实战应用 — 异议处理/话术推荐/政策驱动销售

每轮流程：发30题 → 收集回答 → 自动评分 → 分析 → 优化 → 下一轮
"""

import asyncio
import json
import os
import sys
import time
from datetime import datetime

import httpx

API = "http://localhost:8001/api/v1/chat/"
BUILD_CTX = "http://localhost:8001/api/v1/documents/build-context"
RESULTS_DIR = "/Users/fred/Documents/cc_Projects/Taishan/new-software/Ontology/app/eval_results"

# ============================================================
# 3 套题目
# ============================================================

SET1_BASIC = [
    # 公司基础 (Q1-Q5)
    {"q": "九峰医疗是做什么的？", "intent": "entity_info", "keys": ["九峰", "2015", "基层", "AI", "影像"], "min_score": 3},
    {"q": "九峰医疗的核心产品有哪些？", "intent": "entity_info", "keys": ["肺结核", "AI", "评估软件", "监测预警"], "min_score": 3},
    {"q": "九峰医疗成立时间？总部在哪？", "intent": "entity_info", "keys": ["2015", "江西", "南昌"], "min_score": 2},
    {"q": "九峰医疗有哪些资质认证？", "intent": "entity_info", "keys": ["ISO13485", "三类证", "等保"], "min_score": 3},
    {"q": "九峰医疗获得过什么重要奖项？", "intent": "entity_info", "keys": ["斯坦福", "冠军", "WHO"], "min_score": 2},
    # 产品规格 (Q6-Q10)
    {"q": "肺结核AI评估软件的技术参数是什么？", "intent": "entity_info", "keys": ["敏感度", "特异性", "94", "秒"], "min_score": 3},
    {"q": "九峰智能辅助工作站的配置是怎样的？", "intent": "entity_info", "keys": ["GPU", "CPU", "工作站"], "min_score": 2},
    {"q": "九峰的移动体检车有什么特点？", "intent": "entity_info", "keys": ["5G", "DR", "移动", "体检车"], "min_score": 3},
    {"q": "九峰AI产品的检测速度是多少？", "intent": "entity_info", "keys": ["秒", "5", "处理速度"], "min_score": 2},
    {"q": "肺结核AI辅助评估软件的型号是什么？", "intent": "entity_info", "keys": ["JF", "CXR"], "min_score": 1},
    # 竞品认知 (Q11-Q15)
    {"q": "九峰的主要竞争对手有哪些？", "intent": "entity_info", "keys": ["智影", "推想", "掌引"], "min_score": 2},
    {"q": "智影医疗的主打产品是什么？", "intent": "entity_info", "keys": ["智影", "I-Sight", "AI"], "min_score": 2},
    {"q": "推想科技的业务覆盖范围有多大？", "intent": "entity_info", "keys": ["推想", "省", "国家"], "min_score": 2},
    {"q": "九峰和智影在资质上有什么区别？", "intent": "comparison", "keys": ["三类证", "二类证", "智影"], "min_score": 2},
    {"q": "掌引医疗提供什么解决方案？", "intent": "entity_info", "keys": ["掌引", "影像", "诊断"], "min_score": 2},
    # 资质合规 (Q16-Q20)
    {"q": "三类医疗器械注册证意味着什么？", "intent": "entity_info", "keys": ["三类", "最高", "严格", "注册"], "min_score": 2},
    {"q": "九峰持有的是几类证？为什么重要？", "intent": "entity_info", "keys": ["三类", "唯一", "肺部", "AI"], "min_score": 3},
    {"q": "监管机构A三类注册证的申请难度有多大？", "intent": "entity_info", "keys": ["临床", "试验", "数据"], "min_score": 2},
    {"q": "九峰AI产品通过了哪些国际认证？", "intent": "entity_info", "keys": ["ISO13485", "CE"], "min_score": 2},
    {"q": "公安部三级等保对客户有什么意义？", "intent": "entity_info", "keys": ["等保", "数据", "安全"], "min_score": 2},
    # 政策法规 (Q21-Q25)
    {"q": "结核病防治管理办法规定了哪些重点人群需要筛查？", "intent": "entity_info", "keys": ["七类", "重点人群", "筛查"], "min_score": 2},
    {"q": "2025年基本公共卫生服务补贴标准是多少？", "intent": "entity_info", "keys": ["99", "元", "补贴"], "min_score": 2},
    {"q": "高校入学为什么要做胸片检查？", "intent": "entity_info", "keys": ["学校", "胸片", "结核", "必检"], "min_score": 2},
    {"q": "无结核社区政策对九峰有什么影响？", "intent": "scenario", "keys": ["无结核", "社区", "筛查"], "min_score": 2},
    {"q": "国家结核病防治规划的最新目标是什么？", "intent": "entity_info", "keys": ["规划", "2030", "防治"], "min_score": 2},
    # 客户与场景 (Q26-Q30)
    {"q": "九峰的主要客户群体有哪些？", "intent": "entity_info", "keys": ["基层", "医院", "疾控", "高校"], "min_score": 2},
    {"q": "高校新生结核病筛查的业务流程是怎样的？", "intent": "scenario", "keys": ["筛查", "DR", "AI"], "min_score": 2},
    {"q": "65岁以上老年人体检筛查的预算来源是什么？", "intent": "entity_info", "keys": ["基本公共卫生", "99", "补贴"], "min_score": 2},
    {"q": "九峰服务的乡镇卫生院有多少家？", "intent": "entity_info", "keys": ["千", "乡镇", "基层"], "min_score": 1},
    {"q": "医共体影像中心方案解决什么痛点？", "intent": "scenario", "keys": ["放射科", "基层", "远程"], "min_score": 2},
]

SET2_REASONING = [
    # 竞品对比 (Q1-Q10)
    {"q": "九峰和智影在肺结核筛查领域的核心差异是什么？", "intent": "comparison", "keys": ["三类证", "二类证", "准确率", "产品"], "min_score": 3},
    {"q": "九峰对比推想的优势在哪里？", "intent": "comparison", "keys": ["三类证", "基层", "筛查", "专注"], "min_score": 3},
    {"q": "智影AI的敏感度是多少？和九峰比如何？", "intent": "comparison", "keys": ["敏感度", "94", "98"], "min_score": 2},
    {"q": "在招标场景中，九峰的三类证能带来什么优势？", "intent": "comparison", "keys": ["三类证", "招标", "合规", "门槛"], "min_score": 2},
    {"q": "健乃喜的结核病检测方法和九峰有什么不同？", "intent": "comparison", "keys": ["试剂", "影像", "AI"], "min_score": 2},
    {"q": "从产品线完整性看，九峰和智影谁更全面？", "intent": "comparison", "keys": ["DR", "CT", "体检车", "工作站"], "min_score": 2},
    {"q": "九峰的移动DR体检车和智影的方案有什么区别？", "intent": "comparison", "keys": ["C类驾照", "5G", "AI", "体检车"], "min_score": 2},
    {"q": "国内AI影像厂商中，持有肺结核三类证的有哪些？", "intent": "comparison", "keys": ["九峰", "唯一", "三类证"], "min_score": 3},
    {"q": "九峰产品的定价和竞品相比如何？", "intent": "comparison", "keys": ["定价", "万", "服务费"], "min_score": 2},
    {"q": "为什么说九峰在基层筛查领域有先发优势？", "intent": "comparison", "keys": ["基层", "400万", "千家"], "min_score": 2},
    # 场景匹配 (Q11-Q20)
    {"q": "一个县级疾控中心要做结核病筛查，九峰能提供什么方案？", "intent": "scenario", "keys": ["移动", "体检车", "AI", "筛查"], "min_score": 3},
    {"q": "高校要做10万人新生筛查，怎么规划？", "intent": "scenario", "keys": ["筛查", "流程", "AI", "DR"], "min_score": 2},
    {"q": "基层卫生院没有放射科医生，九峰怎么解决这个问题？", "intent": "scenario", "keys": ["AI", "远程", "自动", "诊断"], "min_score": 3},
    {"q": "九峰的防筛诊治管康全流程包括哪些环节？", "intent": "scenario", "keys": ["预防", "筛查", "诊断", "治疗", "管理", "康复"], "min_score": 3},
    {"q": "移动体检车方案适合哪些场景？", "intent": "scenario", "keys": ["学校", "社区", "农村", "养老院"], "min_score": 2},
    {"q": "医共体影像中心方案的技术架构是怎样的？", "intent": "scenario", "keys": ["云", "边缘", "终端", "远程"], "min_score": 2},
    {"q": "如何利用65岁以上老年人体检政策推动销售？", "intent": "prep", "keys": ["99元", "补贴", "老年人", "体检"], "min_score": 3},
    {"q": "136个重点县的结核病防治需求如何转化为销售机会？", "intent": "scenario", "keys": ["重点县", "筛查", "政策"], "min_score": 2},
    {"q": "九峰如何帮助客户算经济账？", "intent": "scenario", "keys": ["40.45", "1:94", "效益", "投入产出"], "min_score": 2},
    {"q": "南昌航空大学的筛查案例有哪些关键数据？", "intent": "entity_info", "keys": ["4830", "南昌航空", "筛查"], "min_score": 2},
    # 方案推荐 (Q21-Q30)
    {"q": "一个三甲医院要建设AI影像诊断中心，推荐什么方案？", "intent": "prep", "keys": ["工作站", "AI", "影像"], "min_score": 2},
    {"q": "省级代理商适合推广九峰的哪些产品？", "intent": "prep", "keys": ["代理商", "体检车", "工作站", "筛查"], "min_score": 2},
    {"q": "预算20万左右的基层医院适合什么方案？", "intent": "prep", "keys": ["工作站", "基层", "20万", "30万"], "min_score": 2},
    {"q": "九峰的定价模式有哪些选择？", "intent": "entity_info", "keys": ["放置", "租赁", "软件", "服务费"], "min_score": 3},
    {"q": "代理商画像中，省级代理和区域代理有什么区别？", "intent": "comparison", "keys": ["省级", "区域", "代理", "资源"], "min_score": 2},
    {"q": "九峰的交付服务流程是怎样的？", "intent": "scenario", "keys": ["交付", "安装", "培训", "验收"], "min_score": 2},
    {"q": "九峰体检车筛查的作业流程规范是什么？", "intent": "scenario", "keys": ["流程", "筛查", "DR", "AI"], "min_score": 2},
    {"q": "九峰的监测预警系统能做什么？", "intent": "entity_info", "keys": ["传染病", "监测", "预警", "呼吸"], "min_score": 2},
    {"q": "九峰在西藏的成功案例说明了什么？", "intent": "scenario", "keys": ["西藏", "高海拔", "移动", "筛查"], "min_score": 2},
    {"q": "如何用九峰的解决方案帮助卫健委完成考核指标？", "intent": "prep", "keys": ["卫健委", "考核", "筛查", "指标"], "min_score": 2},
]

SET3_APPLICATION = [
    # 异议处理 (Q1-Q10)
    {"q": "客户说'九峰品牌没听说过'，怎么回应？", "intent": "objection", "keys": ["斯坦福", "冠军", "WHO", "三类证"], "min_score": 2},
    {"q": "客户说'太贵了，预算不够'，怎么应对？", "intent": "objection", "keys": ["99元", "补贴", "经济账", "40.45"], "min_score": 3},
    {"q": "客户说'我们已经有放射科了，不需要AI'，怎么说服？", "intent": "objection", "keys": ["效率", "第三只眼", "漏诊", "辅助"], "min_score": 2},
    {"q": "客户担心AI诊断不准，出事了谁负责？", "intent": "objection", "keys": ["三类证", "监管机构A", "辅助", "医生"], "min_score": 3},
    {"q": "客户说'智影的方案更便宜'，怎么回应？", "intent": "objection", "keys": ["三类证", "二类证", "合规", "资质"], "min_score": 3},
    {"q": "客户说'上级没有明确要求用AI'，怎么引导？", "intent": "objection", "keys": ["政策", "指南", "专家共识", "推荐"], "min_score": 2},
    {"q": "客户说'先等等看，明年再说'，怎么促单？", "intent": "objection", "keys": ["政策窗口", "补贴", "99元", "时机"], "min_score": 2},
    {"q": "客户说'我们对数据安全有顾虑'，怎么消除？", "intent": "objection", "keys": ["等保", "三级", "ISO27001", "安全"], "min_score": 2},
    {"q": "客户说'别的医院用过吗？效果怎么样？'", "intent": "objection", "keys": ["案例", "南昌航空", "西藏", "400万"], "min_score": 2},
    {"q": "客户说'我们人手不够，操作不了'，怎么解决？", "intent": "objection", "keys": ["培训", "自动", "简单", "交付"], "min_score": 2},
    # 销售话术 (Q11-Q20)
    {"q": "给卫健委主任做九峰方案汇报，重点讲什么？", "intent": "prep", "keys": ["合规", "政策", "筛查", "考核"], "min_score": 3},
    {"q": "代理商要向医院推销九峰产品，核心卖点是什么？", "intent": "prep", "keys": ["三类证", "唯一", "基层", "成熟"], "min_score": 3},
    {"q": "面对检验科主任，应该用什么话术？", "intent": "prep", "keys": ["效率", "准确率", "敏感度", "辅助"], "min_score": 2},
    {"q": "九峰的独特价值用一句话怎么概括？", "intent": "entity_info", "keys": ["三类证", "唯一", "基层", "AI"], "min_score": 2},
    {"q": "如何用'在有鱼的地方打鱼'这个策略指导销售？", "intent": "scenario", "keys": ["有鱼", "预算", "痛点", "需求"], "min_score": 2},
    {"q": "给代理商讲九峰的盈利模式，怎么说？", "intent": "prep", "keys": ["代理", "利润", "服务费", "合作"], "min_score": 2},
    {"q": "如何用中华预防医学会的专家共识增强说服力？", "intent": "prep", "keys": ["专家共识", "预防医学会", "AI", "推荐"], "min_score": 2},
    {"q": "拜访基层卫生院院长的准备工作清单？", "intent": "prep", "keys": ["政策", "案例", "方案", "预算"], "min_score": 2},
    {"q": "如何用结核病防治成本效益数据说服领导投资？", "intent": "prep", "keys": ["40.45", "效益", "成本", "投入产出"], "min_score": 3},
    {"q": "向高校领导推销新生筛查方案的切入点是什么？", "intent": "prep", "keys": ["政策", "必检", "胸片", "学校"], "min_score": 2},
    # 政策驱动 (Q21-Q30)
    {"q": "2025年基本公卫政策中哪些条款对九峰有利？", "intent": "entity_info", "keys": ["99元", "老年人", "体检", "筛查"], "min_score": 3},
    {"q": "结核病防治管理办法中七类重点人群分别是谁？", "intent": "entity_info", "keys": ["七类", "密切接触", "学生", "老年人", "糖尿病"], "min_score": 2},
    {"q": "WHO推荐CAD技术用于结核病筛查意味着什么？", "intent": "scenario", "keys": ["WHO", "CAD", "推荐", "权威"], "min_score": 2},
    {"q": "如何利用'无结核社区'创建活动拓展业务？", "intent": "scenario", "keys": ["无结核", "社区", "创建", "筛查"], "min_score": 2},
    {"q": "学校结核病防控指南要求入学必须做胸片检查的法律依据是什么？", "intent": "entity_info", "keys": ["学校", "指南", "2020", "胸片"], "min_score": 2},
    {"q": "九峰产品如何帮助地方完成结核病防治考核指标？", "intent": "scenario", "keys": ["考核", "筛查率", "发现率", "指标"], "min_score": 2},
    {"q": "结核病防治规划2024-2030的关键目标是什么？", "intent": "entity_info", "keys": ["2030", "规划", "发病率", "目标"], "min_score": 2},
    {"q": "如何用政策文件来推动预算审批？", "intent": "scenario", "keys": ["红头文件", "政策", "预算", "补贴"], "min_score": 2},
    {"q": "广西玉林结核病防治的经验数据对销售有什么帮助？", "intent": "scenario", "keys": ["40.45", "效益", "广西", "玉林"], "min_score": 2},
    {"q": "如果卫健委问'为什么选择九峰而不是其他厂商'，怎么回答？", "intent": "objection", "keys": ["三类证", "唯一", "基层经验", "案例"], "min_score": 3},
]

SETS = [
    ("基础认知", SET1_BASIC),
    ("复杂推理", SET2_REASONING),
    ("实战应用", SET3_APPLICATION),
]


# ============================================================
# 评分逻辑
# ============================================================

def score_answer(answer: str, keys: list[str], min_score: int) -> dict:
    """基于关键词命中率评分 (0-5)"""
    if not answer or "一般性问题" in answer or "销售知识助手" in answer:
        return {"score": 0, "hits": [], "misses": keys, "reason": "未回答", "hit_rate": 0, "passed": False}

    hits = [k for k in keys if k in answer]
    misses = [k for k in keys if k not in answer]
    hit_rate = len(hits) / len(keys) if keys else 0

    if hit_rate >= 0.8:
        score = 5
    elif hit_rate >= 0.6:
        score = 4
    elif hit_rate >= 0.4:
        score = 3
    elif hit_rate >= 0.2:
        score = 2
    elif len(answer) > 20:
        score = 1
    else:
        score = 0

    passed = score >= min_score
    return {"score": score, "hits": hits, "misses": misses, "hit_rate": hit_rate, "passed": passed}


async def score_answer_llm(question: str, answer: str, keys: list[str]) -> dict:
    """LLM语义评分 (0-5)：判断回答是否覆盖了关键信息点"""
    if not answer or "一般性问题" in answer or "销售知识助手" in answer:
        return {"score": 0, "hits": [], "misses": keys, "hit_rate": 0, "passed": False}

    import json as _json
    from openai import AsyncOpenAI
    from backend.config import DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL, DEEPSEEK_MODEL_FLASH

    client = AsyncOpenAI(api_key=DEEPSEEK_API_KEY, base_url=DEEPSEEK_BASE_URL)
    prompt = f"""判断以下回答是否覆盖了关键信息点。评分标准：
- 回答中是否包含与每个关键点语义等价的信息（同义词、变体、具体数值也算命中）
- 不要只看精确匹配，要看语义覆盖

问题：{question}
关键信息点：{keys}
回答：{answer[:500]}

输出JSON：
{{"covered_keys": ["命中的关键点"], "missed_keys": ["未覆盖的关键点"], "coverage_rate": 0.6, "score": 3, "reason": "简要说明"}}"""

    try:
        resp = await client.chat.completions.create(
            model=DEEPSEEK_MODEL_FLASH,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300,
            response_format={"type": "json_object"},
        )
        result = _json.loads(resp.choices[0].message.content)
        return {
            "score": result.get("score", 0),
            "hits": result.get("covered_keys", []),
            "misses": result.get("missed_keys", []),
            "hit_rate": result.get("coverage_rate", 0),
            "passed": result.get("score", 0) >= 3,
        }
    except Exception as e:
        # 回退到关键词评分
        return score_answer(answer, keys, 3)


# ============================================================
# 主流程
# ============================================================

async def ask_question(client: httpx.AsyncClient, question: str) -> dict:
    """发送问题到 API"""
    try:
        resp = await client.post(API, json={"question": question}, timeout=180, follow_redirects=True)
        return resp.json()
    except Exception as e:
        return {"answer": f"API错误: {e}", "intent": "error", "entities": [], "confidence": 0}


async def run_round(client: httpx.AsyncClient, set_name: str, set_idx: int, round_num: int, questions: list[dict], use_llm_score: bool = False) -> dict:
    """执行一轮评测（3并发）"""
    print(f"\n{'='*60}")
    print(f"Set {set_idx+1} [{set_name}] — Round {round_num}")
    print(f"{'='*60}")

    start_time = time.time()

    # 并发发送所有问题
    sem = asyncio.Semaphore(3)
    async def ask_with_sem(q):
        async with sem:
            return await ask_question(client, q["q"])

    responses = await asyncio.gather(*[ask_with_sem(q) for q in questions])

    results = []
    total_score = 0
    max_score = 0
    pass_count = 0
    intent_correct = 0

    for i, (q, resp) in enumerate(zip(questions, responses)):
        q_num = i + 1
        answer = resp.get("answer", "")
        detected_intent = resp.get("intent", "")
        confidence = resp.get("confidence", 0)

        scoring = score_answer(answer, q["keys"], q["min_score"])
        if use_llm_score:
            llm_scoring = await score_answer_llm(q["q"], answer, q["keys"])
            # LLM评分优先，但保留关键词hits用于展示
            scoring["hits"] = llm_scoring.get("hits", scoring["hits"])
            scoring["misses"] = llm_scoring.get("misses", scoring["misses"])
        total_score += scoring["score"]
        max_score += 5
        if scoring["passed"]:
            pass_count += 1
        if detected_intent == q["intent"]:
            intent_correct += 1

        results.append({
            "num": q_num,
            "question": q["q"],
            "expected_intent": q["intent"],
            "detected_intent": detected_intent,
            "intent_match": detected_intent == q["intent"],
            "answer": answer[:500],
            "confidence": confidence,
            "score": scoring["score"],
            "min_score": q["min_score"],
            "passed": scoring["passed"],
            "hits": scoring["hits"],
            "misses": scoring["misses"],
            "hit_rate": scoring.get("hit_rate", 0),
        })

        status = "✅" if scoring["passed"] else "❌"
        print(f"  Q{q_num:02d} [{scoring['score']}/5] {status} ({detected_intent}) {q['q'][:30]}... — misses: {scoring['misses']}")

    elapsed = round(time.time() - start_time, 1)

    summary = {
        "set": set_name,
        "set_idx": set_idx,
        "round": round_num,
        "timestamp": datetime.now().isoformat(),
        "elapsed_seconds": elapsed,
        "total_score": total_score,
        "max_score": max_score,
        "score_pct": round(total_score / max_score * 100, 1) if max_score else 0,
        "pass_count": pass_count,
        "pass_rate": round(pass_count / len(questions) * 100, 1),
        "intent_accuracy": round(intent_correct / len(questions) * 100, 1),
        "avg_confidence": round(sum(r["confidence"] for r in results) / len(results), 2),
        "results": results,
        "weak_questions": [r for r in results if r["score"] <= 2],
    }

    print(f"\n  📊 总分: {total_score}/{max_score} ({summary['score_pct']}%)")
    print(f"  📊 通过率: {pass_count}/{len(questions)} ({summary['pass_rate']}%)")
    print(f"  📊 意图准确率: {summary['intent_accuracy']}%")
    print(f"  📊 弱题数: {len(summary['weak_questions'])}")
    print(f"  ⏱️  耗时: {elapsed}s ({round(elapsed/len(questions), 1)}s/题)")

    return summary


def analyze_and_plan(round_result: dict, round_num: int) -> str:
    """分析轮次结果，生成改进计划"""
    weak = round_result["weak_questions"]
    if not weak:
        return "无明显弱项，保持当前状态。"

    # 分析弱题模式
    intent_issues = {}
    miss_keywords = {}
    for w in weak:
        intent = w["detected_intent"]
        if intent != w["expected_intent"]:
            intent_issues[intent] = intent_issues.get(intent, 0) + 1
        for m in w["misses"]:
            miss_keywords[m] = miss_keywords.get(m, 0) + 1

    plan_lines = [f"Round {round_num} 改进计划:"]
    plan_lines.append(f"  弱题数: {len(weak)}/30")
    plan_lines.append(f"  高频缺失关键词: {sorted(miss_keywords.items(), key=lambda x:-x[1])[:10]}")

    if intent_issues:
        plan_lines.append(f"  意图识别偏差: {intent_issues}")

    # 建议改进方向
    plan_lines.append("  改进方向:")
    if round_result["score_pct"] < 50:
        plan_lines.append("    - 检查推理引擎的实体查找策略")
        plan_lines.append("    - 增强 response prompt 的回答深度")
    if round_result["intent_accuracy"] < 80:
        plan_lines.append("    - 优化意图分类 prompt 的 few-shot 示例")
    plan_lines.append("    - 针对高频缺失关键词检查知识库覆盖度")

    plan = "\n".join(plan_lines)
    print(f"\n{plan}")
    return plan


async def main():
    use_llm_score = "--llm-score" in sys.argv

    os.makedirs(RESULTS_DIR, exist_ok=True)
    all_rounds = []

    async with httpx.AsyncClient() as client:
        for set_idx, (set_name, questions) in enumerate(SETS):
            for round_in_set in range(3):
                round_num = set_idx * 3 + round_in_set + 1

                # 执行评测
                result = await run_round(client, set_name, set_idx, round_num, questions, use_llm_score=use_llm_score)
                all_rounds.append(result)

                # 保存单轮结果
                result_file = os.path.join(RESULTS_DIR, f"round_{round_num}.json")
                with open(result_file, "w", encoding="utf-8") as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)

                # 分析和计划
                plan = analyze_and_plan(result, round_num)
                result["improvement_plan"] = plan

                # 每轮结束后重建背景知识
                if round_num < 9:
                    print(f"\n  🔄 重建背景知识...")
                    try:
                        resp = await client.post(BUILD_CTX, timeout=60)
                        print(f"  📍 {resp.json()}")
                    except Exception as e:
                        print(f"  ⚠️ 重建失败: {e}")

                print(f"\n  ⏳ 等待5秒进入下一轮...\n")
                await asyncio.sleep(5)

    # 汇总报告
    print(f"\n{'='*60}")
    print("九轮滚动评测汇总")
    print(f"{'='*60}")

    report = {
        "timestamp": datetime.now().isoformat(),
        "rounds_summary": [],
        "sets_comparison": [],
    }

    for r in all_rounds:
        report["rounds_summary"].append({
            "round": r["round"],
            "set": r["set"],
            "score_pct": r["score_pct"],
            "pass_rate": r["pass_rate"],
            "intent_accuracy": r["intent_accuracy"],
            "weak_count": len(r["weak_questions"]),
        })
        print(f"  R{r['round']} [{r['set'][:4]}] 分数:{r['score_pct']}% 通过:{r['pass_rate']}% 意图:{r['intent_accuracy']}% 弱题:{len(r['weak_questions'])}")

    # Set 对比
    for set_idx in range(3):
        set_rounds = [r for r in all_rounds if r["set_idx"] == set_idx]
        trend = [r["score_pct"] for r in set_rounds]
        report["sets_comparison"].append({
            "set": set_rounds[0]["set"],
            "rounds": [r["round"] for r in set_rounds],
            "scores": trend,
            "improvement": trend[-1] - trend[0] if len(trend) > 1 else 0,
        })

    report_file = os.path.join(RESULTS_DIR, "full_report.json")
    with open(report_file, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print(f"\n完整报告已保存: {report_file}")
    return report


if __name__ == "__main__":
    asyncio.run(main())
