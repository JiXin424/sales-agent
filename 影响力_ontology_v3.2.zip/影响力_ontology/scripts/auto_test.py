#!/usr/bin/env python3
"""自动化验证脚本 - 模拟浏览器测试"""

import requests
import json
import sys

BASE_URL = "http://localhost:3000"

def test_1_page_load():
    """测试1：页面加载"""
    print("\n🧪 测试1：页面加载")
    try:
        response = requests.get(BASE_URL, timeout=5)
        if response.status_code == 200 and 'html' in response.text:
            print("   ✅ 页面可访问")
            return True
        else:
            print(f"   ❌ 页面加载失败: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ 连接失败: {str(e)}")
        return False

def test_2_api_stats():
    """测试2：API统计"""
    print("\n🧪 测试2：本体统计API")
    try:
        response = requests.get(f"{BASE_URL}/api/ontology/stats", timeout=5)
        data = response.json()

        total = data['stats']['total_entities']
        scenarios = data['entity_type_counts'].get('scenarios', 0)
        scripts = data['entity_type_counts'].get('scripts', 0)

        print(f"   实体总数: {total}")
        print(f"   场景数: {scenarios}")
        print(f"   话术数: {scripts}")

        if total == 602 and scenarios == 58 and scripts == 49:
            print("   ✅ 本体数据正确")
            return True
        else:
            print("   ❌ 本体数据不完整")
            return False
    except Exception as e:
        print(f"   ❌ API请求失败: {str(e)}")
        return False

def test_3_stream_chat_synonym():
    """测试3：流式聊天（同义词）"""
    print("\n🧪 测试3：同义词功能 - '客户嫌贵怎么办'")
    try:
        response = requests.post(
            f"{BASE_URL}/api/chat/stream",
            json={"query": "客户嫌贵怎么办"},
            stream=True,
            timeout=30
        )

        keywords_found = False
        price_related_found = False

        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8')
                if 'data:' in line and 'search_process' in line:
                    data = json.loads(line.split('data: ')[1].strip())
                    keywords = data['data']['keywords_extracted']
                    print(f"   关键词: {keywords}")

                    if '价格异议' in keywords:
                        keywords_found = True
                        print("   ✅ 同义词映射成功（嫌贵→价格异议）")

        return keywords_found
    except Exception as e:
        print(f"   ❌ 测试失败: {str(e)}")
        return False

def test_4_stream_chat_new_scenario():
    """测试4：流式聊天（新场景）"""
    print("\n🧪 测试4：新场景搜索 - '陌生电话怎么打'")
    try:
        response = requests.post(
            f"{BASE_URL}/api/chat/stream",
            json={"query": "陌生电话怎么打"},
            stream=True,
            timeout=30
        )

        new_scenario_found = False

        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8')
                if 'data:' in line and 'search_process' in line:
                    data = json.loads(line.split('data: ')[1].strip())
                    top_results = data['data']['top_results']
                    print(f"   匹配数: {data['data']['matched_entities']}")

                    for result in top_results[:3]:
                        name = result['name']
                        if '陌生电话' in name or '转介绍' in name:
                            new_scenario_found = True
                            print(f"   ✅ 找到新话术: {name}")

        return new_scenario_found
    except Exception as e:
        print(f"   ❌ 测试失败: {str(e)}")
        return False

def test_5_related_entities():
    """测试5：相关实体API"""
    print("\n🧪 测试5：相关实体API - 互惠原理")
    try:
        response = requests.get(
            f"{BASE_URL}/api/ontology/related",
            params={"entity_id": "reciprocity-principle", "direction": "both", "max_results": "10"},
            timeout=5
        )

        data = response.json()
        count = data['related_count']
        print(f"   相关实体数: {count}")

        if count >= 5:
            print("   ✅ 相关实体API正常")
            return True
        else:
            print("   ❌ 相关实体数量不足")
            return False
    except Exception as e:
        print(f"   ❌ API请求失败: {str(e)}")
        return False

def test_6_scenario_to_script():
    """测试6：场景-话术关系"""
    print("\n🧪 测试6：场景-话术关系 - ToB陌生电话场景")
    try:
        response = requests.get(
            f"{BASE_URL}/api/ontology/related",
            params={"entity_id": "scenario-cold-call-to-b2b", "direction": "forward", "max_results": "5"},
            timeout=5
        )

        data = response.json()
        count = data['related_count']
        print(f"   关联话术数: {count}")

        if count >= 2:
            print("   ✅ 场景-话术关系正常")
            return True
        else:
            print("   ❌ 场景-话术关系缺失")
            return False
    except Exception as e:
        print(f"   ❌ API请求失败: {str(e)}")
        return False

def main():
    print("=" * 60)
    print("影响力本体系统 - 自动化验证")
    print("=" * 60)

    tests = [
        ("页面加载", test_1_page_load),
        ("本体统计", test_2_api_stats),
        ("同义词功能", test_3_stream_chat_synonym),
        ("新场景搜索", test_4_stream_chat_new_scenario),
        ("相关实体API", test_5_related_entities),
        ("场景-话术关系", test_6_scenario_to_script),
    ]

    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"   ❌ 测试异常: {str(e)}")
            results.append((name, False))

    # 总结
    print("\n" + "=" * 60)
    print("测试总结")
    print("=" * 60)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for name, result in results:
        status = "✅" if result else "❌"
        print(f"{status} {name}")

    print(f"\n通过率: {passed}/{total} ({passed/total*100:.1f}%)")

    if passed == total:
        print("\n🎉 所有测试通过！")
        print("\n⚠️  但这仅验证了API功能")
        print("📋 仍需在浏览器中验证：")
        print("   1. 三窗口布局是否正确显示")
        print("   2. 相关知识卡片是否显示")
        print("   3. 点击跳转是否工作")
        print("   4. AI回答Markdown渲染是否正常")
        return 0
    else:
        print(f"\n❌ {total - passed} 个测试失败")
        return 1

if __name__ == '__main__':
    exit(main())
