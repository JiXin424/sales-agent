#!/usr/bin/env python3
"""
md_optimizer — Markdown 向量化检索优化批处理工具（流式输出版）

用法：
    python md_optimizer.py <文件.md|文件夹路径> [选项]

输出规则：
    - 单文件：  源文件名-优化.md
    - 文件夹：  原文件夹名-优化/ （子文件夹名和 md 文件名都加"-优化"）

示例：
    python md_optimizer.py ./docs --model deepseek-chat
    python md_optimizer.py ./article.md --base-url https://api.deepseek.com
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import random
import re
import sqlite3
import ssl
import sys
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


# ──────────────────────────────────────────────────────────────
# 默认配置
# ──────────────────────────────────────────────────────────────

_SCRIPT_DIR = Path(__file__).parent.resolve()
DEFAULT_PROMPT_PATH = str(_SCRIPT_DIR / "MAX向量化检索优化提示词.md")
DEFAULT_SUBJECT_PATH = str(_SCRIPT_DIR / "主体文件.md")
DEFAULT_MODEL = "deepseek-v4-pro"
DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MAX_WORKERS = 4
DEFAULT_TIMEOUT = 120

# ANSI 颜色码
COLOR_GRAY = "\033[90m"
COLOR_GREEN = "\033[32m"
COLOR_RESET = "\033[0m"


# ──────────────────────────────────────────────────────────────
# 日志系统：TeeStdout（同时输出到终端 + 文件，文件过滤 ANSI）
# ──────────────────────────────────────────────────────────────

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


class TeeStdout:
    """将 stdout 同时输出到终端和日志文件，日志中自动去除 ANSI 颜色码。
    支持开关控制：content 生成阶段可关闭日志写入，避免日志过大。"""

    def __init__(self, log_path: Path):
        self.terminal = sys.stdout
        # 以追加模式打开，避免覆盖之前写入的 header
        self.log_file = open(log_path, "a", encoding="utf-8")
        self.log_path = log_path
        self._log_enabled = True

    def write(self, message: str) -> None:
        self.terminal.write(message)
        if self._log_enabled:
            self.log_file.write(_ANSI_RE.sub("", message))
            self.log_file.flush()

    def flush(self) -> None:
        self.terminal.flush()
        self.log_file.flush()

    def close(self) -> None:
        self.log_file.close()

    def isatty(self) -> bool:
        return self.terminal.isatty()

    def enable_log(self, enabled: bool = True) -> None:
        """控制是否将输出写入日志文件。"""
        self._log_enabled = enabled


def setup_logging() -> Path:
    """创建 log 目录和日志文件，返回日志路径。"""
    log_dir = _SCRIPT_DIR / "log"
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"md_optimizer_{timestamp}.log"
    return log_path


def setup_database() -> Path:
    """创建 SQLite 数据库（如不存在则建表），返回 db 路径。"""
    db_path = _SCRIPT_DIR / "md_optimizer.db"
    conn = sqlite3.connect(str(db_path))
    cur = conn.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_time TEXT,
            command TEXT,
            python_version TEXT,
            platform TEXT,
            model TEXT,
            workers INTEGER,
            timeout INTEGER,
            input_path TEXT,
            prompt_path TEXT,
            subject_path TEXT,
            dry_run BOOLEAN,
            total_time REAL,
            success_count INTEGER,
            failed_count INTEGER,
            total_count INTEGER,
            total_in_bytes INTEGER,
            total_out_bytes INTEGER,
            avg_time REAL,
            congestion_level INTEGER,
            total_prompt_tokens INTEGER,
            total_completion_tokens INTEGER,
            total_cache_hit INTEGER,
            total_cache_miss INTEGER
        );
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER,
            file_path TEXT,
            status TEXT,
            elapsed_time REAL,
            in_bytes INTEGER,
            out_bytes INTEGER,
            prompt_tokens INTEGER,
            completion_tokens INTEGER,
            cache_hit INTEGER,
            cache_miss INTEGER,
            error_message TEXT,
            FOREIGN KEY (run_id) REFERENCES runs(id)
        );
    """)
    conn.commit()
    conn.close()
    return db_path


def save_run_to_db(db_path: Path, args: argparse.Namespace, start_time: float) -> int:
    """将本次运行数据保存到 SQLite，返回 run_id。"""
    elapsed = time.time() - start_time
    files = _run_stats.get("files", [])
    success = sum(1 for f in files if f["status"] == "success")
    failed = sum(1 for f in files if f["status"] == "failed")
    total = len(files)
    total_in = sum(f.get("in_bytes", 0) for f in files)
    total_out = sum(f.get("out_bytes", 0) for f in files if f["status"] == "success")
    avg_time = sum(f.get("time", 0) for f in files) / max(total, 1)
    total_prompt = sum(f.get("prompt_tokens", 0) for f in files)
    total_completion = sum(f.get("completion_tokens", 0) for f in files)
    total_cache_hit = sum(f.get("cache_hit", 0) for f in files)
    total_cache_miss = sum(f.get("cache_miss", 0) for f in files)

    conn = sqlite3.connect(str(db_path))
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO runs (
            run_time, command, python_version, platform, model, workers, timeout,
            input_path, prompt_path, subject_path, dry_run,
            total_time, success_count, failed_count, total_count,
            total_in_bytes, total_out_bytes, avg_time, congestion_level,
            total_prompt_tokens, total_completion_tokens, total_cache_hit, total_cache_miss
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        datetime.now().isoformat(),
        ' '.join(sys.argv),
        sys.version.split()[0],
        f"{platform.system()} {platform.release()}",
        args.model, args.workers, args.timeout,
        args.input, args.prompt, args.subject, args.dry_run,
        elapsed, success, failed, total,
        total_in, total_out, avg_time, _congestion._level,
        total_prompt, total_completion, total_cache_hit, total_cache_miss
    ))
    run_id = cur.lastrowid

    for item in files:
        cur.execute("""
            INSERT INTO files (
                run_id, file_path, status, elapsed_time, in_bytes, out_bytes,
                prompt_tokens, completion_tokens, cache_hit, cache_miss, error_message
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            run_id,
            item.get("file", ""),
            item.get("status", ""),
            item.get("time", 0),
            item.get("in_bytes", 0),
            item.get("out_bytes", 0),
            item.get("prompt_tokens", 0) or 0,
            item.get("completion_tokens", 0) or 0,
            item.get("cache_hit", 0) or 0,
            item.get("cache_miss", 0) or 0,
            item.get("error", "")
        ))

    conn.commit()
    conn.close()
    return run_id


def write_log_header(log_path: Path, args: argparse.Namespace) -> None:
    """极简日志头：只写命令行和关键参数。"""
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {' '.join(sys.argv)}\n")
        f.write(f"  model={args.model}, workers={args.workers}, dry_run={args.dry_run}\n\n")


def write_log_footer(log_path: Path, start_time: float, db_path: Path) -> None:
    """极简日志尾：只保留关键摘要，详细数据已入库。"""
    elapsed = time.time() - start_time
    files = _run_stats.get("files", [])
    success = sum(1 for f in files if f["status"] == "success")
    failed = sum(1 for f in files if f["status"] == "failed")
    total = len(files)
    total_prompt = sum(f.get("prompt_tokens", 0) for f in files)
    total_completion = sum(f.get("completion_tokens", 0) for f in files)
    total_cache_hit = sum(f.get("cache_hit", 0) for f in files)

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f"\n[{datetime.now().strftime('%H:%M:%S')}] ")
        f.write(f"完成 {success}/{total}")
        if failed:
            f.write(f" (失败 {failed})")
        f.write(f" | 耗时 {elapsed:.0f}s")
        if total_prompt:
            f.write(f" | Tokens {total_prompt}+{total_completion}")
            if total_cache_hit:
                f.write(f" (hit {total_cache_hit})")
        f.write(f" | 库 {db_path.name}\n")


# 全局运行统计
_run_stats: dict = {
    "start_time": 0.0,
    "log_path": None,
    "files": [],
    "errors": [],
    "success": 0,
    "failed": 0,
    "total": 0,
}


# ──────────────────────────────────────────────────────────────
# 拥挤重试策略（全局状态）
# ──────────────────────────────────────────────────────────────

class CongestionController:
    """
    全局拥堵控制器。

    当 API 返回 429/503/529 时，提升拥堵级别并增加后续请求延迟。
    成功请求后逐步降级。
    """

    def __init__(self):
        self._level = 0  # 0-3
        self._lock = threading.Lock()
        self._last_hit = 0.0

    # 拥堵级别 → 全局额外延迟（秒）
    _delays = {0: 0.0, 1: 1.0, 2: 3.0, 3: 6.0}
    _max_level = 3

    def hit(self):
        """遇到拥挤错误时调用，提升级别。"""
        with self._lock:
            self._level = min(self._level + 1, self._max_level)
            self._last_hit = time.time()
            delay = self._delays[self._level]
        print(f"    ⚠️  API 拥挤，拥堵级别 → {self._level}（全局延迟 {delay}s）")
        return delay

    def release(self):
        """成功请求后调用，尝试降级。每 3 次成功降 1 级。"""
        with self._lock:
            if self._level > 0 and time.time() - self._last_hit > 10:
                self._level -= 1

    def wait(self):
        """发起请求前调用，根据当前拥堵级别休眠。"""
        delay = self._delays[self._level]
        if delay > 0:
            time.sleep(delay)


_congestion = CongestionController()


# ──────────────────────────────────────────────────────────────
# LLM 客户端（零外部依赖，仅用 urllib）
# ──────────────────────────────────────────────────────────────

class LLMError(RuntimeError):
    pass


def _resolve_ssl_ctx() -> Optional[ssl.SSLContext]:
    """返回合适的 SSLContext，处理 macOS 证书问题。"""
    try:
        import certifi  # type: ignore
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    try:
        return ssl.create_default_context()
    except Exception:
        pass
    return None


def _http_post_stream(
    url: str,
    body: dict,
    headers: dict,
    timeout: int,
) -> object:
    """发送流式 POST 请求，返回 response 对象（可迭代读取 SSE）。"""
    req = Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json", **headers},
    )

    ctx = _resolve_ssl_ctx()
    kwargs: dict = {"timeout": timeout}
    if ctx is not None:
        kwargs["context"] = ctx

    try:
        return urlopen(req, **kwargs)
    except URLError as e:
        err_str = str(e)
        if "CERTIFICATE_VERIFY_FAILED" not in err_str and "SSL" not in err_str:
            raise
        print("    ⚠️  SSL 证书验证失败，尝试不验证证书模式...")
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        kwargs["context"] = ctx
        return urlopen(req, **kwargs)


def _parse_sse_line(line: bytes) -> Optional[dict]:
    """解析 SSE 数据行，返回 JSON dict 或 None。"""
    text = line.decode("utf-8", errors="replace").strip()
    if text.startswith("data: "):
        payload = text[6:]
        if payload == "[DONE]":
            return None
        try:
            return json.loads(payload)
        except json.JSONDecodeError:
            return None
    return None


class OpenAIClient:
    """OpenAI-compatible chat completions client with streaming."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        url = base_url.rstrip("/")
        if url.endswith("/chat/completions"):
            self.url = url
        elif not url.endswith("/v1"):
            self.url = f"{url}/v1/chat/completions"
        else:
            self.url = f"{url}/chat/completions"

    def chat_stream(
        self,
        system: str,
        user: str,
        temperature: float = 0.3,
        extra_body: Optional[dict] = None,
    ) -> str:
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if extra_body:
            body.update(extra_body)
        headers = {"Authorization": f"Bearer {self.api_key}"}

        resp = _http_post_stream(self.url, body, headers, self.timeout)

        if resp.getcode() != 200:
            raise LLMError(f"HTTP {resp.getcode()} from {self.url}")

        reasoning_parts: list[str] = []
        content_parts: list[str] = []
        in_reasoning = False
        in_content = False
        content_started = False
        self.last_usage: Optional[dict] = None

        print(f"    {COLOR_GRAY}💭 思考中...", end="", flush=True)

        for raw_line in resp:
            chunk = _parse_sse_line(raw_line)
            if chunk is None:
                continue

            # 捕获 usage（choices 为空时）
            usage = chunk.get("usage")
            if usage:
                self.last_usage = usage
                continue

            choices = chunk.get("choices") or []
            if not choices:
                continue
            delta = choices[0].get("delta") or {}

            rc = delta.get("reasoning_content")
            if rc:
                if not in_reasoning:
                    print(f"{COLOR_RESET}\n    {COLOR_GRAY}💭 ", end="", flush=True)
                    in_reasoning = True
                print(rc, end="", flush=True)
                reasoning_parts.append(rc)

            c = delta.get("content")
            if c:
                if not content_started:
                    # 开始生成正文时关闭日志写入（避免日志过大），保留思考过程
                    if hasattr(sys.stdout, "enable_log"):
                        sys.stdout.enable_log(False)
                    content_started = True
                if in_reasoning and not in_content:
                    print(f"{COLOR_RESET}\n    {COLOR_GREEN}✍️  ", end="", flush=True)
                    in_content = True
                elif not in_content:
                    print(f"{COLOR_RESET}\n    {COLOR_GREEN}✍️  ", end="", flush=True)
                    in_content = True
                print(c, end="", flush=True)
                content_parts.append(c)

        print(COLOR_RESET)
        # 恢复日志写入
        if hasattr(sys.stdout, "enable_log"):
            sys.stdout.enable_log(True)
        return "".join(content_parts)


# ──────────────────────────────────────────────────────────────
# 核心逻辑
# ──────────────────────────────────────────────────────────────

def load_subject_context(subject_path: Path) -> str:
    """读取主体公司信息文件。"""
    if not subject_path.exists():
        return ""
    try:
        content = subject_path.read_text(encoding="utf-8")
        # 过滤掉未填写的占位符行
        lines = [ln for ln in content.splitlines() if "（请填写）" not in ln and "请根据" not in ln]
        return "\n".join(lines).strip()
    except Exception:
        return ""


def build_prompts(
    raw_system: str,
    md_content: str,
    src_name: str = "",
    subject_context: str = "",
) -> tuple[str, str]:
    """
    v3 构建 system + user prompt：
    - 强化 YAML front matter 输出（策略 9 严格执行）
    - 强制 ≥10 个 FAQ（策略 5 严格执行）
    - 注入本体上下文（v2 创新点）
    - 注入检索锚点（策略 7）
    """
    system = (
        raw_system
        + "\n\n---\n\n## v3 强化指令（必须严格执行）\n\n"
        "用户将提交一篇 Markdown 文档原文。请输出 MAX 级优化后的完整文档。\n\n"
        "### 输出格式（铁律，违反即失败）\n"
        "1. **必须以标准 YAML front matter 开头**，用 `---` 包围，严格遵守以下 schema：\n"
        "```\n"
        "---\n"
        "文档类型：[知识库/产品文档/竞品分析/客户案例/销售话术/方法论/法规文件/学术研究]\n"
        "核心主题：[3-5 个关键词，逗号分隔]\n"
        "相关概念：[15-20 个同义词/别名/搜索词，逗号分隔]\n"
        "目标受众：[具体角色列表]\n"
        "术语映射:\n"
        "  - 主名称: [名称]\n"
        "  - 英文名: [名称]\n"
        "  - 别名: [别名1, 别名2]\n"
        "  - 简称: [简称]\n"
        "---\n"
        "```\n"
        "2. **YAML 后立即是 `> 快速定位：` 摘要**（2-3 句话，含产品名/核心概念/解决的问题）\n"
        "3. **`> 用户常搜：`** 列出 3-5 个口语化查询\n"
        "4. **正文必须包含 `## 常见问题（FAQ）` 章节**，至少 10 个 FAQ，按主题分类（关于产品价值/关于案例与效果/关于实施与使用/关于公司背景 等），每个答案 ≤120 字\n"
        "5. **结尾附 `## 检索锚点辅助`**，列出 8-12 个用户口语化表达\n"
        "6. 输出完整 Markdown 文档，不要外层 ```markdown 代码块标记\n"
        "7. 不要用对话式开头（如\"好的\"、\"以下是\"），直接从 YAML 开始\n\n"
        "### 内容要求\n"
        "- 严格遵循上述 MAX 13 项优化策略\n"
        "- 原文信息零丢失（策略 11、12）\n"
        "- 关键词密度达标（策略 10）\n"
        "- 术语一致性（策略 3）\n"
        "- 主语显性化、语义自包含（策略 1、2）\n\n"
        "### FAQ 红线（策略 5.4）\n"
        "- 禁止编造原文未提及的数字/客户/案例\n"
        "- 答案 ≤120 字，超长拆分为 2 个 FAQ\n"
        "- 每个问题用括号标注用户可能的口语化问法\n"
    )

    if subject_context:
        system += (
            "\n\n---\n\n## 项目本体（已自动构建，作为权威背景）\n\n"
            + subject_context
            + "\n\n**本体使用指令**：\n"
            "- 优化时严格基于以上本体，实体名称用本体的主名（不要自创别名）\n"
            "- 涉及本体中的实体时，统一使用本体内的命名（如本体里有\"九峰医疗\"，不要写\"九峰公司\"）\n"
            "- YAML front matter 的术语映射必须与本体一致\n"
            "- FAQ 中涉及到本体里的关系（如 produces/certified_for），答案要符合本体描述\n"
        )

    user = f"--- 原文开始 ---\n\n{md_content}\n\n--- 原文结束 ---\n\n请按 v3 强化指令输出 MAX 优化文档，必须以 YAML front matter 开头。"
    return system, user


def call_llm(
    client: OpenAIClient,
    system_prompt: str,
    md_content: str,
    src_name: str = "",
    subject_context: str = "",
    retries: int = 2,
    extra_body: Optional[dict] = None,
) -> tuple[str, Optional[dict]]:
    """调用 LLM，带拥挤感知重试。返回 (result_text, usage_dict)。"""
    system, user = build_prompts(system_prompt, md_content, src_name, subject_context)
    last_error = None
    max_retries = retries + 3  # 基础重试 + 拥挤额外重试

    for attempt in range(max_retries + 1):
        # 全局拥堵等待
        _congestion.wait()

        try:
            result = client.chat_stream(system, user, extra_body=extra_body)
            _congestion.release()  # 成功，尝试降级
            usage = getattr(client, "last_usage", None)
            if usage:
                pt = usage.get("prompt_tokens", 0)
                ct = usage.get("completion_tokens", 0)
                # DeepSeek 硬盘缓存字段
                cache_hit = usage.get("prompt_cache_hit_tokens", 0)
                cache_miss = usage.get("prompt_cache_miss_tokens", 0)
                # DashScope/通用字段
                if not cache_hit and not cache_miss:
                    cache_hit = usage.get("prompt_tokens_details", {}).get("cached_tokens", 0)
                    cache_miss = usage.get("prompt_tokens_details", {}).get("cache_creation_input_tokens", 0)
                cache_info = ""
                if cache_hit:
                    cache_info += f", cache_hit={cache_hit}"
                if cache_miss:
                    cache_info += f", cache_miss={cache_miss}"
                print(f"    📊 Tokens: prompt={pt}, completion={ct}{cache_info}")
            return result, usage
        except LLMError as e:
            err_msg = str(e)
            last_error = e

            # 判断是否为拥挤类错误
            is_congestion = any(code in err_msg for code in ["429", "503", "529", "Overloaded"])

            if is_congestion:
                _congestion.hit()
                # 指数退避 + 随机抖动
                backoff = min(2 ** attempt + random.random(), 30)
                print(f"    ⏳ 拥挤退避：等待 {backoff:.1f}s 后重试 ({attempt + 1}/{max_retries + 1})")
                time.sleep(backoff)
                continue

            # 非拥挤错误，用基础重试
            if attempt < retries:
                wait = 2 ** attempt
                print(f"    ⚠️  调用失败，{wait}s 后重试: {e}")
                time.sleep(wait)
            else:
                break

    raise last_error


def strip_markdown_fence(text: str) -> str:
    """去除外层 ```markdown ... ``` 包装。"""
    text = text.strip()
    m = re.match(r"^```(?:markdown)?\s*\n?", text, re.IGNORECASE)
    if m:
        text = text[m.end():]
    m = re.search(r"\n?```\s*$", text)
    if m:
        text = text[:m.start()]
    return text.strip()


def get_output_name(src_path: Path, is_dir_mode: bool) -> str:
    name = src_path.name
    stem = src_path.stem
    suffix = src_path.suffix

    if suffix.lower() == ".md":
        return f"{stem}-优化{suffix}"
    else:
        return f"{name}-优化"


def process_single_file(
    client: OpenAIClient,
    system_prompt: str,
    src_file: Path,
    out_file: Path,
    subject_context: str = "",
    dry_run: bool = False,
    extra_body: Optional[dict] = None,
) -> bool:
    """处理单个 md 文件，返回是否成功。记录耗时和统计信息。"""
    try:
        content = src_file.read_text(encoding="utf-8")
    except Exception as e:
        print(f"  ❌ 读取失败 [{src_file}]: {e}")
        _run_stats["errors"].append({"file": str(src_file), "error": f"读取失败: {e}"})
        return False

    file_start = time.time()
    in_size = len(content.encode("utf-8"))
    print(f"  📝 处理: {src_file} ({in_size} bytes)")

    if dry_run:
        print(f"    ⏹️  dry-run，跳过 LLM 调用")
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(content, encoding="utf-8")
        _run_stats["files"].append({
            "file": str(src_file),
            "status": "success",
            "time": time.time() - file_start,
            "in_bytes": in_size,
            "out_bytes": in_size,  # dry-run: 输出=输入
        })
        return True

    try:
        optimized, usage = call_llm(
            client, system_prompt, content,
            src_name=src_file.stem,
            subject_context=subject_context,
            extra_body=extra_body,
        )
        optimized = strip_markdown_fence(optimized)
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(optimized, encoding="utf-8")
        elapsed = time.time() - file_start
        out_size = len(optimized.encode("utf-8"))
        print(f"    ✅ 已保存: {out_file} ({elapsed:.1f}s, {out_size} bytes)")
        file_stat = {
            "file": str(src_file),
            "status": "success",
            "time": elapsed,
            "in_bytes": in_size,
            "out_bytes": out_size,
        }
        if usage:
            file_stat["prompt_tokens"] = usage.get("prompt_tokens", 0)
            file_stat["completion_tokens"] = usage.get("completion_tokens", 0)
            # DeepSeek 硬盘缓存
            file_stat["cache_hit"] = usage.get("prompt_cache_hit_tokens", 0)
            file_stat["cache_miss"] = usage.get("prompt_cache_miss_tokens", 0)
            # DashScope/通用缓存
            if not file_stat["cache_hit"] and not file_stat["cache_miss"]:
                details = usage.get("prompt_tokens_details", {})
                file_stat["cache_hit"] = details.get("cached_tokens", 0)
                file_stat["cache_miss"] = details.get("cache_creation_input_tokens", 0)
        _run_stats["files"].append(file_stat)
        return True
    except Exception as e:
        elapsed = time.time() - file_start
        err_msg = f"{type(e).__name__}: {e}"
        print(f"    ❌ 处理失败 ({elapsed:.1f}s): {e}")
        _run_stats["errors"].append({"file": str(src_file), "error": err_msg, "time": elapsed})
        _run_stats["files"].append({
            "file": str(src_file),
            "status": "failed",
            "time": elapsed,
            "in_bytes": in_size,
            "error": err_msg,
        })
        return False


def process_directory(
    client: OpenAIClient,
    system_prompt: str,
    src_dir: Path,
    out_dir: Path,
    subject_context: str = "",
    dry_run: bool = False,
    max_workers: int = DEFAULT_MAX_WORKERS,
    extra_body: Optional[dict] = None,
) -> tuple[int, int]:
    tasks: list[tuple[Path, Path]] = []

    for root, dirs, files in os.walk(src_dir):
        root_path = Path(root)
        rel = root_path.relative_to(src_dir)

        out_root = out_dir
        for part in rel.parts:
            out_root = out_root / f"{part}-优化"

        for fname in files:
            if not fname.lower().endswith(".md"):
                continue
            src_file = root_path / fname
            out_name = f"{src_file.stem}-优化{src_file.suffix}"
            out_file = out_root / out_name
            tasks.append((src_file, out_file))

    total = len(tasks)
    if total == 0:
        print("  ⚠️  未找到任何 .md 文件")
        return 0, 0

    print(f"  📁 发现 {total} 个 .md 文件，开始处理（并发={max_workers}）...")

    success = 0
    failed = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_file = {
            executor.submit(
                process_single_file, client, system_prompt, src, out,
                subject_context, dry_run, extra_body
            ): (src, out)
            for src, out in tasks
        }
        for future in as_completed(future_to_file):
            if future.result():
                success += 1
            else:
                failed += 1

    return success, failed


# ──────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────

def resolve_api_key(args) -> str:
    """固定使用 DeepSeek API key。"""
    return "DEEPSEEK_API_KEY_PLACEHOLDER"


def resolve_base_url(args) -> str:
    if args.base_url:
        return args.base_url
    model = args.model.lower()
    if "deepseek" in model:
        return "https://api.deepseek.com"
    if "qwen" in model or "dashscope" in model:
        return "https://dashscope.aliyuncs.com/compatible-mode/v1"
    if "openai" in model or "gpt" in model:
        return "https://api.openai.com"
    return DEFAULT_BASE_URL


def main():
    parser = argparse.ArgumentParser(
        description="Markdown 向量化检索优化批处理工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
输出规则：
  单文件  → 源文件名-优化.md
  文件夹  → 原文件夹名-优化/ （子文件夹名和 md 文件名都加"-优化"）

示例：
  python md_optimizer.py ./docs
  python md_optimizer.py ./article.md --model gpt-4o
  python md_optimizer.py ./docs --dry-run --workers 8
        """,
    )
    parser.add_argument("input", help="输入的 .md 文件或文件夹路径")
    parser.add_argument(
        "-p", "--prompt", default=DEFAULT_PROMPT_PATH,
        help=f"系统提示词文件路径（默认：{DEFAULT_PROMPT_PATH}）"
    )
    parser.add_argument(
        "-s", "--subject", default=DEFAULT_SUBJECT_PATH,
        help=f"主体公司信息文件路径（默认：{DEFAULT_SUBJECT_PATH}）"
    )
    parser.add_argument("-m", "--model", default=DEFAULT_MODEL, help=f"模型名称（默认：{DEFAULT_MODEL}）")
    parser.add_argument("--api-key", help="API Key")
    parser.add_argument("--base-url", help="API Base URL")
    parser.add_argument("-w", "--workers", type=int, default=DEFAULT_MAX_WORKERS, help=f"并发数（默认：{DEFAULT_MAX_WORKERS}）")
    parser.add_argument("-t", "--timeout", type=int, default=DEFAULT_TIMEOUT, help=f"API 超时秒数（默认：{DEFAULT_TIMEOUT}）")
    parser.add_argument("--dry-run", action="store_true", help="空跑模式：不调用 LLM，仅复制文件结构")
    parser.add_argument("--no-fail-fast", action="store_true", help="遇到错误继续处理其他文件")
    parser.add_argument(
        "--ontology-types", default="general",
        choices=["general", "sales"],
        help="自动构建本体的类型预设（仅当未指定 --subject 时生效，默认：general）"
    )
    parser.add_argument(
        "--ontology-output", default=None,
        help="保存自动生成的本体主体文件路径（默认不保存，仅注入 system prompt）"
    )
    parser.add_argument(
        "--no-auto-subject", action="store_true",
        help="禁用自动本体构建（仅用现有主体文件）"
    )

    args = parser.parse_args()

    # ── 初始化日志系统 ──
    log_path = setup_logging()
    db_path = setup_database()

    # 先写入 header（直接写文件，不经过 tee），避免和 tee 并发写冲突
    write_log_header(log_path, args)

    # 设置 tee（追加模式），接管 stdout
    tee = TeeStdout(log_path)
    sys.stdout = tee
    print(f"📝 日志: {log_path}")
    print(f"🗄️  数据库: {db_path}")

    # 重置全局统计
    _run_stats.clear()
    _run_stats.update({"start_time": time.time(), "files": [], "errors": []})

    # ── 默认开启最大思考强度 ──
    extra_body: Optional[dict] = {
        "thinking": {"type": "enabled"},
        "reasoning_effort": "max",
    }
    print("🧠 已开启最大思考强度")

    try:
        # ── 校验输入 ──
        src_path = Path(args.input).resolve()
        if not src_path.exists():
            print(f"❌ 路径不存在: {src_path}")
            sys.exit(1)

        # ── 读取系统提示词 ──
        prompt_path = Path(args.prompt)
        if not prompt_path.exists():
            print(f"❌ 提示词文件不存在: {prompt_path}")
            sys.exit(1)
        system_prompt = prompt_path.read_text(encoding="utf-8")
        print(f"✅ 已加载提示词: {prompt_path}")

        # ── 读取主体公司信息 ──
        # 优先级：手动 --subject > auto-subject（自动构建本体）> 跳过
        subject_path = Path(args.subject)
        subject_context = ""
        if subject_path.exists():
            # 手动主体文件存在，优先使用
            subject_context = load_subject_context(subject_path)
            if subject_context:
                print(f"✅ 已加载主体公司信息: {subject_path}")
            else:
                print(f"⚠️  主体文件为空或未填写: {subject_path}")
        elif not args.no_auto_subject and not args.dry_run:
            # 默认行为：自动构建本体作为主体文件
            # 需先初始化 LLM 客户端，再回到这里
            subject_context = None  # 标记待构建
        else:
            print(f"⚠️  主体文件不存在: {subject_path}（且 --no-auto-subject 已禁用自动构建）")

        # ── 初始化 LLM 客户端 ──
        api_key = resolve_api_key(args)
        if not api_key and not args.dry_run:
            print("❌ 未找到 API Key")
            sys.exit(1)

        base_url = resolve_base_url(args)
        if not args.dry_run:
            client = OpenAIClient(
                api_key=api_key,
                base_url=base_url,
                model=args.model,
                timeout=args.timeout,
            )
            print(f"✅ LLM 配置: {args.model} @ {base_url}")
        else:
            client = None
            print("⏹️  dry-run 模式，跳过 LLM 初始化")

        # ── 自动构建本体（如果主体文件未指定） ──
        if subject_context is None:
            # 需要先初始化 client 才能调用 build_ontology
            if not args.dry_run and client is not None:
                from ontology_extractor import load_type_config
                from build_ontology import build_ontology_from_path

                print(f"\n🔬 未指定主体文件，自动构建本体 (--ontology-types={args.ontology_types})")
                type_config = load_type_config(args.ontology_types)
                # 关闭最大思考强度（抽取任务不需要）
                saved_extra_body = extra_body
                extra_body = None

                onto = build_ontology_from_path(
                    src_path=src_path,
                    client=client,
                    type_config=type_config,
                    max_workers=args.workers,
                    dry_run=False,
                )
                subject_context = onto["subject_markdown"]
                stats = onto["stats"]
                print(f"✅ 本体构建完成：{stats['merged_objects']} 实体 / "
                      f"{stats['merged_links']} 关系 / {stats['elapsed_seconds']:.0f}s")

                # 可选保存
                if args.ontology_output:
                    out_p = Path(args.ontology_output)
                    out_p.parent.mkdir(parents=True, exist_ok=True)
                    out_p.write_text(subject_context, encoding="utf-8")
                    print(f"💾 主体文件已保存: {out_p}")

                # 恢复 extra_body
                extra_body = saved_extra_body
                print()
            else:
                subject_context = ""

        # ── 执行处理 ──
        if src_path.is_file():
            if not src_path.name.lower().endswith(".md"):
                print(f"❌ 输入文件不是 .md: {src_path}")
                sys.exit(1)
            out_name = get_output_name(src_path, is_dir_mode=False)
            out_path = src_path.parent / out_name
            print(f"\n📄 单文件模式: {src_path} → {out_path}")
            ok = process_single_file(
                client, system_prompt, src_path, out_path,
                subject_context=subject_context, dry_run=args.dry_run, extra_body=extra_body
            )
            retcode = 0 if ok else 1
        else:
            out_dir_name = get_output_name(src_path, is_dir_mode=True)
            out_dir = src_path.parent / out_dir_name
            print(f"\n📁 文件夹模式: {src_path} → {out_dir}")
            success, failed = process_directory(
                client, system_prompt, src_path, out_dir,
                subject_context=subject_context,
                dry_run=args.dry_run,
                max_workers=args.workers,
                extra_body=extra_body,
            )
            print(f"\n📊 处理完成: 成功 {success} / 失败 {failed} / 总计 {success + failed}")
            retcode = 0 if failed == 0 else 1
    finally:
        # ── 保存到数据库 + 写入极简日志尾部 ──
        run_id = save_run_to_db(db_path, args, _run_stats["start_time"])
        write_log_footer(log_path, _run_stats["start_time"], db_path)
        tee.close()
        sys.stdout = tee.terminal
        print(f"🗄️  已入库 run_id={run_id} | 库: {db_path}")

    sys.exit(retcode)


if __name__ == "__main__":
    main()
