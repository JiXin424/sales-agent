#!/usr/bin/env python3
"""验证 influence_ontology.json 的一致性和完整性。"""

import json
import os
from collections import Counter

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JSON_PATH = os.path.join(BASE_DIR, "influence_ontology.json")
REPORT_PATH = os.path.join(BASE_DIR, "验证报告.md")

ENTITY_KEYS = [
    "principles", "concepts", "terms", "cases", "experiments",
    "persons", "reasoning_chains", "tactics", "action_steps",
    "scripts", "scenarios"
]


def main():
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    lines = ["# 《影响力》Ontology 验证报告", ""]
    lines.append("## 1. 基础统计")
    lines.append("")
    for key in ENTITY_KEYS:
        lines.append(f"- {key}: {len(data.get(key, []))}")
    lines.append(f"- relations: {len(data.get('relations', []))}")
    lines.append("")

    # Collect all valid ids
    all_ids = set()
    id_sources = {}
    for key in ENTITY_KEYS:
        for item in data.get(key, []):
            item_id = item.get("id")
            if item_id:
                all_ids.add(item_id)
                id_sources[item_id] = key

    # Check relations
    lines.append("## 2. 关系引用检查")
    lines.append("")
    broken = []
    rel_types = Counter()
    for r in data.get("relations", []):
        rel_types[r.get("relation_type", "UNKNOWN")] += 1
        fid = r.get("from_id")
        tid = r.get("to_id")
        if isinstance(fid, list):
            fid = tuple(fid)
        if isinstance(tid, list):
            tid = tuple(tid)
        if fid not in all_ids:
            broken.append(("from_id", fid, r))
        if tid not in all_ids:
            broken.append(("to_id", tid, r))

    if broken:
        lines.append(f"- 发现 {len(broken)} 条关系引用了不存在的 id")
        for kind, bad_id, r in broken[:20]:
            lines.append(f"  - {kind}=`{bad_id}` in relation `{r.get('relation_type')}`")
    else:
        lines.append("- 所有关系引用均有效")
    lines.append("")

    lines.append("## 3. 关系类型分布")
    lines.append("")
    for rt, cnt in rel_types.most_common():
        lines.append(f"- {rt}: {cnt}")
    lines.append("")

    # Check principles coverage
    lines.append("## 4. 核心原则覆盖检查")
    lines.append("")
    core_principles = ["互惠", "承诺", "一致", "社会认同", "喜好", "权威", "稀缺"]
    principle_names = [p.get("name", "") for p in data.get("principles", [])]
    for cp in core_principles:
        matched = [n for n in principle_names if cp in n]
        if matched:
            lines.append(f"- ✅ {cp}: {matched}")
        else:
            lines.append(f"- ❌ {cp}: 未找到")
    lines.append("")

    # Check empty fields
    lines.append("## 5. 空字段检查")
    lines.append("")
    for key in ENTITY_KEYS:
        empty_counts = Counter()
        total = 0
        for item in data.get(key, []):
            total += 1
            for k, v in item.items():
                if not v:
                    empty_counts[k] += 1
        if empty_counts:
            lines.append(f"### {key}")
            for field, cnt in empty_counts.most_common(5):
                lines.append(f"- {field}: {cnt}/{total} 为空")
    lines.append("")

    # Sample entities
    lines.append("## 6. 抽样检查")
    lines.append("")
    for key in ["principles", "cases", "experiments", "tactics"]:
        items = data.get(key, [])
        if items:
            sample = items[0]
            lines.append(f"### {key} 样例: {sample.get('name', sample.get('id', ''))}")
            for k, v in sample.items():
                if k in ("id", "name"):
                    continue
                if isinstance(v, list):
                    v_str = "; ".join(str(x) for x in v[:5])
                    if len(v) > 5:
                        v_str += f" ... (+{len(v)-5})"
                else:
                    v_str = str(v)[:200]
                lines.append(f"- **{k}**: {v_str}")
            lines.append("")

    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"Saved {REPORT_PATH}")


if __name__ == "__main__":
    main()
