"""异议处理 — 基于产品知识处理客户异议"""

import json
import logging

from sqlalchemy.ext.asyncio import AsyncSession

from backend.reasoning.intent import classify_intent
from backend.reasoning.engine import ReasoningEngine
from backend.llm import chat_pro

logger = logging.getLogger(__name__)

OBJECTION_PROMPT = """你是资深销售教练，帮销售人员处理客户异议。

基于以下产品知识：
{context}

已知信息：
- 实体：{entities}
- 关系：{relations}

客户异议：{objection}

请生成异议处理方案：
1. 理解客户真实顾虑
2. 提供应对策略（2-3种）
3. 给出话术参考
4. 提供支撑证据

输出 JSON：
{{"response": "异议处理建议", "tactics": [{{"name": "策略名", "script": "话术", "evidence": "支撑证据"}}], "fallback": "如果上述策略无效的备选方案"}}"""


async def handle_objection(objection: str, session: AsyncSession) -> dict:
    """处理客户异议"""
    # 1. 意图分析
    intent_result = await classify_intent(objection)

    # 2. 收集上下文
    engine = ReasoningEngine(session)
    context_data = await engine.reason(objection, intent_result)

    entities = json.dumps(
        [{"name": e["name"], "type": e["type"], "properties": e.get("properties", {})}
         for e in context_data.get("entities", [])],
        ensure_ascii=False,
    )
    relations = json.dumps(context_data.get("relations", []), ensure_ascii=False)

    # 3. 生成异议处理
    prompt = OBJECTION_PROMPT.format(
        context="九峰医疗产品知识库",
        entities=entities,
        relations=relations,
        objection=objection,
    )

    result_text = await chat_pro(
        messages=[{"role": "user", "content": prompt}],
        max_tokens=3000,
        response_format={"type": "json_object"},
    )

    try:
        result = json.loads(result_text)
    except json.JSONDecodeError:
        result = {"response": result_text, "tactics": [], "fallback": ""}

    return {
        "response": result.get("response", ""),
        "tactics": result.get("tactics", []),
        "fallback": result.get("fallback", ""),
    }
