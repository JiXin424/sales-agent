"""AFC2md 文档解析封装"""

import asyncio
import os
import subprocess
import sys

AFC2MD_DIR = "/Users/fred/Documents/cc_Projects/Taishan/api-software/AFC2md"

EXT_SCRIPT_MAP = {
    ".docx": "docx2md.py",
    ".pdf": "docx2md.py",
    ".doc": "doc97tomd.py",
    ".xlsx": "xlsx2md.py",
    ".png": "img2md.py",
    ".jpg": "img2md.py",
    ".jpeg": "img2md.py",
}


def get_supported_extensions() -> set[str]:
    return set(EXT_SCRIPT_MAP.keys())


async def parse_document(file_path: str) -> str:
    """将文档转为 Markdown，返回 Markdown 内容。

    AFC2md 将输出保存在源文件旁边（同目录，.md 后缀）。
    .md / .txt 文件直接读取，无需转换。
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext in (".md", ".txt"):
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()

    script = EXT_SCRIPT_MAP.get(ext)

    if not script:
        raise ValueError(f"不支持的文件格式: {ext}")

    script_path = os.path.join(AFC2MD_DIR, script)
    if not os.path.exists(script_path):
        raise FileNotFoundError(f"AFC2md 脚本不存在: {script_path}")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    # 调用 AFC2md
    proc = await asyncio.create_subprocess_exec(
        sys.executable, script_path, file_path,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=AFC2MD_DIR,
    )
    stdout, stderr = await proc.communicate()

    if proc.returncode != 0:
        raise RuntimeError(f"AFC2md 转换失败: {stderr.decode()[:500]}")

    # AFC2md 将 .md 保存在源文件旁边
    md_path = os.path.splitext(file_path)[0] + ".md"
    if not os.path.exists(md_path):
        raise FileNotFoundError(f"AFC2md 未生成输出文件: {md_path}")

    with open(md_path, "r", encoding="utf-8") as f:
        return f.read()
