"""测试本体 CRUD 操作"""

import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 先导入 models 确保表定义加载
from backend.ontology.models import Base, ObjectType, Object, LinkType, Link, Document


@pytest.mark.asyncio
async def test_create_object_type(db_session):
    """测试创建实体类型"""
    ot = ObjectType(name="Company", description="公司/组织")
    db_session.add(ot)
    await db_session.commit()

    result = await db_session.get(ObjectType, ot.id)
    assert result is not None
    assert result.name == "Company"


@pytest.mark.asyncio
async def test_create_object(db_session):
    """测试创建实体"""
    ot = ObjectType(name="Company", description="公司")
    db_session.add(ot)
    await db_session.flush()

    obj = Object(type_id=ot.id, name="九峰医疗", properties={"founded": "2015"})
    db_session.add(obj)
    await db_session.commit()

    result = await db_session.get(Object, obj.id)
    assert result is not None
    assert result.name == "九峰医疗"
    assert result.properties["founded"] == "2015"


@pytest.mark.asyncio
async def test_create_link(db_session):
    """测试创建关系"""
    ot1 = ObjectType(name="Company", description="公司")
    ot2 = ObjectType(name="Product", description="产品")
    db_session.add_all([ot1, ot2])
    await db_session.flush()

    obj1 = Object(type_id=ot1.id, name="九峰医疗")
    obj2 = Object(type_id=ot2.id, name="肺结核AI软件")
    db_session.add_all([obj1, obj2])
    await db_session.flush()

    lt = LinkType(name="produces", description="生产")
    db_session.add(lt)
    await db_session.flush()

    link = Link(type_id=lt.id, source_id=obj1.id, target_id=obj2.id)
    db_session.add(link)
    await db_session.commit()

    result = await db_session.get(Link, link.id)
    assert result is not None
    assert result.source_id == obj1.id
    assert result.target_id == obj2.id


@pytest.mark.asyncio
async def test_create_document(db_session):
    """测试创建文档记录"""
    doc = Document(filename="test.docx", file_type="docx", md_content="# Test", status="completed")
    db_session.add(doc)
    await db_session.commit()

    result = await db_session.get(Document, doc.id)
    assert result is not None
    assert result.filename == "test.docx"
    assert result.status == "completed"
