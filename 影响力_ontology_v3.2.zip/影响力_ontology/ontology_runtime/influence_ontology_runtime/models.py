"""Pydantic 模型定义《影响力》知识本体的 11 类实体和关系。"""

from __future__ import annotations

import re
from typing import Any, List, Optional, Union

from pydantic import BaseModel, Field, field_validator


class Principle(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    chapter: Optional[Union[str, int]] = None
    core_mechanism: Optional[str] = None
    social_function: Optional[str] = None
    keywords: Optional[Union[str, List[str]]] = None


class Concept(BaseModel):
    id: str
    name: str
    en_name: Optional[str] = None
    definition: Optional[str] = None
    related_principles: Optional[Union[str, List[str]]] = None
    source: Optional[str] = None

    @field_validator("related_principles", mode="before")
    @classmethod
    def _normalize_list(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, str):
            return [v]
        return v


class Term(BaseModel):
    id: str
    name: str
    en_name: Optional[str] = None
    definition: Optional[str] = None


class Case(BaseModel):
    id: str
    name: str
    chapter: Optional[Union[str, int]] = None
    summary: Optional[str] = None
    characters: Optional[Union[str, List[str]]] = None
    principle: Optional[Union[str, List[str]]] = None
    trigger: Optional[str] = None
    behavior: Optional[str] = None
    outcome: Optional[str] = None
    source_text: Optional[str] = None

    @field_validator("characters", "principle", mode="before")
    @classmethod
    def _normalize_list(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, str):
            return [v]
        return v


class Experiment(BaseModel):
    id: str
    name: str
    researcher: Optional[str] = None
    chapter: Optional[Union[str, int]] = None
    hypothesis: Optional[str] = None
    method: Optional[str] = None
    result: Optional[str] = None
    conclusion: Optional[str] = None
    principle: Optional[Union[str, List[str]]] = None

    @field_validator("principle", mode="before")
    @classmethod
    def _normalize_list(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, str):
            return [v]
        return v


class Person(BaseModel):
    id: str
    name: str
    en_name: Optional[str] = None
    role: Optional[str] = None
    affiliation: Optional[str] = None


class ReasoningChain(BaseModel):
    id: str
    name: str
    principle_id: Optional[Union[str, List[str]]] = None
    premises: Optional[Union[str, List[str]]] = None
    trigger: Optional[str] = None
    behavior: Optional[str] = None
    consequence: Optional[str] = None
    evidence: Optional[str] = None
    confidence: Optional[Union[str, float]] = None

    @field_validator("principle_id", "premises", mode="before")
    @classmethod
    def _normalize_list(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, str):
            return [v]
        return v


class Tactic(BaseModel):
    id: str
    name: str
    en_name: Optional[str] = None
    principle_id: Optional[Union[str, List[str]]] = None
    scenario: Optional[str] = None
    steps: Optional[Union[str, List[str]]] = None
    expected_result: Optional[str] = None
    risk: Optional[str] = None
    example: Optional[str] = None
    description: Optional[str] = None

    @field_validator("principle_id", mode="before")
    @classmethod
    def _normalize_principle_id(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, str):
            return [v]
        return v

    @field_validator("steps", mode="before")
    @classmethod
    def _normalize_steps(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, list):
            return v
        if isinstance(v, str):
            # 尝试按 "1. " 或 "第一步" 等拆分
            parts = re.split(r"\s*(?:\d+\.\s+|\n)", v.strip())
            parts = [p.strip() for p in parts if p.strip()]
            return parts if parts else [v]
        return v


class ActionStep(BaseModel):
    id: str
    tactic_id: Optional[str] = None
    order: Optional[int] = None
    action: Optional[str] = None
    script_template: Optional[str] = None
    note: Optional[str] = None
    name: Optional[str] = None


class Script(BaseModel):
    id: str
    name: str
    context: Optional[str] = None
    text: Optional[str] = None
    principle_id: Optional[Union[str, List[str]]] = None
    source_case: Optional[str] = None
    content: Optional[Union[str, List[str]]] = None

    @field_validator("principle_id", mode="before")
    @classmethod
    def _normalize_list(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, str):
            return [v]
        return v


class Scenario(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    applicable_tactics: Optional[Union[str, List[str]]] = None

    @field_validator("applicable_tactics", mode="before")
    @classmethod
    def _normalize_list(cls, v: Any) -> Optional[List[str]]:
        if v is None:
            return None
        if isinstance(v, str):
            return [v]
        return v


class Relation(BaseModel):
    id: Optional[str] = None
    relation_type: str
    from_id: Union[str, List[str]]
    to_id: Union[str, List[str]]
    description: Optional[str] = None

    @field_validator("from_id", "to_id", mode="before")
    @classmethod
    def _normalize_id(cls, v: Any) -> Optional[str]:
        if isinstance(v, list):
            return v[0] if v else None
        return v


class Ontology(BaseModel):
    """根模型，对应 influence_ontology.json 的顶层结构。"""

    principles: List[Principle] = Field(default_factory=list)
    concepts: List[Concept] = Field(default_factory=list)
    terms: List[Term] = Field(default_factory=list)
    cases: List[Case] = Field(default_factory=list)
    experiments: List[Experiment] = Field(default_factory=list)
    persons: List[Person] = Field(default_factory=list)
    reasoning_chains: List[ReasoningChain] = Field(default_factory=list)
    tactics: List[Tactic] = Field(default_factory=list)
    action_steps: List[ActionStep] = Field(default_factory=list)
    scripts: List[Script] = Field(default_factory=list)
    scenarios: List[Scenario] = Field(default_factory=list)
    relations: List[Relation] = Field(default_factory=list)

    def all_entities(self) -> List[Any]:
        """返回所有实体的扁平列表。"""
        return (
            self.principles
            + self.concepts
            + self.terms
            + self.cases
            + self.experiments
            + self.persons
            + self.reasoning_chains
            + self.tactics
            + self.action_steps
            + self.scripts
            + self.scenarios
        )

    def entity_type_map(self) -> dict[str, str]:
        """id -> 实体类型名 的映射。"""
        mapping = {}
        type_attr = {
            "principles": "principle",
            "concepts": "concept",
            "terms": "term",
            "cases": "case",
            "experiments": "experiment",
            "persons": "person",
            "reasoning_chains": "reasoning_chain",
            "tactics": "tactic",
            "action_steps": "action_step",
            "scripts": "script",
            "scenarios": "scenario",
        }
        for attr, type_name in type_attr.items():
            for entity in getattr(self, attr):
                mapping[entity.id] = type_name
        return mapping

    def stats(self) -> dict[str, int]:
        return {
            "principles": len(self.principles),
            "concepts": len(self.concepts),
            "terms": len(self.terms),
            "cases": len(self.cases),
            "experiments": len(self.experiments),
            "persons": len(self.persons),
            "reasoning_chains": len(self.reasoning_chains),
            "tactics": len(self.tactics),
            "action_steps": len(self.action_steps),
            "scripts": len(self.scripts),
            "scenarios": len(self.scenarios),
            "relations": len(self.relations),
        }
