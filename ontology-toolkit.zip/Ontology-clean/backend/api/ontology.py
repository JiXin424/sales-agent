"""本体数据 API — 图数据查询端点"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.db import async_session
from backend.ontology.models import Object, Link, ObjectType, LinkType
from backend.ontology.graph import OntologyGraph

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/ontology", tags=["ontology"])


async def get_session():
    async with async_session() as session:
        yield session


@router.get("/graph")
async def get_graph(session: AsyncSession = Depends(get_session)):
    """返回完整图数据，格式适配 AntV G6"""
    graph = OntologyGraph()
    await graph.build_from_db(session)

    nodes = [
        {"id": n, "data": data}
        for n, data in graph.graph.nodes(data=True)
    ]
    edges = [
        {"source": u, "target": v, "data": data}
        for u, v, data in graph.graph.edges(data=True)
    ]

    return {"nodes": nodes, "edges": edges}


@router.get("/objects")
async def list_objects(
    type: str | None = Query(None, description="按实体类型过滤"),
    session: AsyncSession = Depends(get_session),
):
    """列出实体，支持按类型过滤"""
    stmt = select(Object).options(selectinload(Object.type))

    if type:
        stmt = stmt.join(ObjectType).where(ObjectType.name == type)

    result = await session.execute(stmt)
    objects = result.scalars().all()

    return {
        "objects": [
            {
                "id": obj.id,
                "name": obj.name,
                "type": obj.type.name if obj.type else None,
                "properties": obj.properties,
                "created_at": obj.created_at.isoformat() if obj.created_at else None,
            }
            for obj in objects
        ]
    }


@router.get("/objects/{object_id}")
async def get_object(object_id: int, session: AsyncSession = Depends(get_session)):
    """查询单个实体及其关系"""
    stmt = (
        select(Object)
        .options(
            selectinload(Object.type),
            selectinload(Object.source_links).selectinload(Link.type),
            selectinload(Object.source_links).selectinload(Link.target),
            selectinload(Object.target_links).selectinload(Link.type),
            selectinload(Object.target_links).selectinload(Link.source),
        )
        .where(Object.id == object_id)
    )
    result = await session.execute(stmt)
    obj = result.scalar_one_or_none()

    if not obj:
        raise HTTPException(status_code=404, detail="实体不存在")

    outgoing = [
        {
            "id": link.id,
            "type": link.type.name if link.type else None,
            "target_id": link.target_id,
            "target_name": link.target.name if link.target else None,
        }
        for link in obj.source_links
    ]

    incoming = [
        {
            "id": link.id,
            "type": link.type.name if link.type else None,
            "source_id": link.source_id,
            "source_name": link.source.name if link.source else None,
        }
        for link in obj.target_links
    ]

    return {
        "id": obj.id,
        "name": obj.name,
        "type": obj.type.name if obj.type else None,
        "properties": obj.properties,
        "created_at": obj.created_at.isoformat() if obj.created_at else None,
        "relations": {"outgoing": outgoing, "incoming": incoming},
    }


@router.get("/stats")
async def get_ontology_stats(session: AsyncSession = Depends(get_session)):
    """实体和关系统计"""
    # 实体按类型统计
    obj_stats = await session.execute(
        select(ObjectType.name, func.count(Object.id))
        .join(Object, Object.type_id == ObjectType.id, isouter=True)
        .group_by(ObjectType.name)
    )
    entity_counts = {name: count for name, count in obj_stats.all()}

    # 关系按类型统计
    link_stats = await session.execute(
        select(LinkType.name, func.count(Link.id))
        .join(Link, Link.type_id == LinkType.id, isouter=True)
        .group_by(LinkType.name)
    )
    relation_counts = {name: count for name, count in link_stats.all()}

    # 总数
    total_objects = await session.execute(select(func.count(Object.id)))
    total_links = await session.execute(select(func.count(Link.id)))

    return {
        "total_objects": total_objects.scalar() or 0,
        "total_links": total_links.scalar() or 0,
        "entity_counts_by_type": entity_counts,
        "relation_counts_by_type": relation_counts,
    }
