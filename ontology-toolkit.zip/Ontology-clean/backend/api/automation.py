"""自动化API — 评测对比、历史、流水线触发"""

import json
import os
from glob import glob

from fastapi import APIRouter, HTTPException

from tools.eval_compare import compare_results, format_diff_report

router = APIRouter(prefix="/api/v1/automation", tags=["automation"])

EVAL_RESULTS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "eval_results",
)


def _load_report(path: str) -> dict | None:
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _find_reports() -> list[dict]:
    """找到所有 full_report*.json 文件，按时间排序"""
    pattern = os.path.join(EVAL_RESULTS_DIR, "full_report*.json")
    files = sorted(glob(pattern), key=os.path.getmtime)
    reports = []
    for f in files:
        data = _load_report(f)
        if data:
            data["_file"] = os.path.basename(f)
            reports.append(data)
    return reports


@router.get("/compare")
async def compare_eval_results():
    """对比最近两次评测结果"""
    reports = _find_reports()
    if len(reports) < 2:
        raise HTTPException(status_code=404, detail="至少需要2次评测记录")

    old, new = reports[-2], reports[-1]
    diff = compare_results(old, new)
    report_text = format_diff_report(diff, old.get("_file", "?"), new.get("_file", "?"))

    return {
        "old_file": old.get("_file"),
        "new_file": new.get("_file"),
        "diff": diff,
        "report": report_text,
    }


@router.get("/eval-history")
async def eval_history():
    """评测历史列表"""
    reports = _find_reports()
    history = []
    for r in reports:
        avg_score = 0
        if r.get("rounds_summary"):
            avg_score = round(
                sum(s["score_pct"] for s in r["rounds_summary"]) / len(r["rounds_summary"]), 1
            )
        history.append({
            "file": r.get("_file"),
            "timestamp": r.get("timestamp"),
            "avg_score": avg_score,
            "rounds": len(r.get("rounds_summary", [])),
        })
    return {"history": history}
