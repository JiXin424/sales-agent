#!/usr/bin/env python3
"""影响力本体问答系统 - 后端服务"""

import json
import os
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import openai

from enhanced_prompts import get_enhanced_system_prompt

# 初始化Flask应用
app = Flask(__name__)
CORS(app)

# 配置
BASE_DIR = Path(__file__).resolve().parent.parent
ONTOLOGY_PATH = BASE_DIR / "influence_ontology_cleaned.json"  # 清洗后版本：去自重复、definition 兜底
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_BASE_URL = "https://api.deepseek.com"

# 加载本体数据
def load_ontology():
    """加载影响力本体数据"""
    with open(ONTOLOGY_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)

# 全局变量存储本体数据
ontology_data = None

def get_ontology():
    """获取本体数据（懒加载）"""
    global ontology_data
    if ontology_data is None:
        ontology_data = load_ontology()
    return ontology_data

def enrich_entity_description(entity):
    """为实体补全description字段"""
    # 如果已有description且非空，直接返回
    if entity.get('description'):
        return entity

    entity_type = entity.get('type', '')
    desc = ''

    # 根据entity_type生成description
    if entity_type == 'case':
        # 案例：优先使用summary
        desc = entity.get('summary', '')
        if not desc:
            desc = f"{entity.get('name', '')}案例 - 体现了{entity.get('principle', '')}原理"

    elif entity_type == 'experiment':
        # 实验：使用summary
        desc = entity.get('summary', '')
        if not desc:
            desc = f"关于{entity.get('name', '')}的心理学实验，验证了{entity.get('principle', '')}原理"

    elif entity_type == 'reasoning_chain':
        # 推理链：组合premises和consequence
        premises = entity.get('premises', '')
        consequence = entity.get('consequence', '')
        if premises and consequence:
            desc = f"推理：{premises} → {consequence}"
        else:
            desc = entity.get('name', '')

    elif entity_type == 'tactic':
        # 策略：使用summary
        desc = entity.get('summary', '')
        if not desc:
            desc = entity.get('name', '')

    elif entity_type == 'script':
        # 话术：使用text
        text = entity.get('text', '')
        if text:
            # 限制长度
            desc = text if len(text) <= 100 else text[:100] + '...'
        else:
            desc = f"话术：{entity.get('name', '')}"

    elif entity_type == 'principle':
        # 原则：使用description或summary
        desc = entity.get('summary', entity.get('description', entity.get('name', '')))

    elif entity_type == 'scenario':
        # 场景：使用summary
        desc = entity.get('summary', '')
        if not desc:
            desc = f"场景：{entity.get('name', '')}"

    else:
        # 默认使用name
        desc = entity.get('name', entity.get('id', ''))

    entity['description'] = desc
    return entity

def extract_keywords_with_deepseek(query):
    """使用DeepSeek智能提取关键词"""
    try:
        client = openai.OpenAI(
            api_key=DEEPSEEK_API_KEY,
            base_url=DEEPSEEK_BASE_URL
        )

        prompt = f"""从以下销售问题中提取3-5个最关键的关键词，用于在影响力知识库中搜索相关内容。

问题：{query}

要求：
1. 提取影响力原则名称（如：互惠原理、稀缺原理、对比原理、承诺一致）
2. 提取具体销售场景（如：价格异议、初次拜访、客户拖延、建立信任）
3. 提取关键行为动词（如：应对、建立、推进、制造）
4. 只返回JSON格式，不要其他内容

返回格式：{{"keywords": ["关键词1", "关键词2", "关键词3", ...]}}
"""

        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=100
        )

        result_text = response.choices[0].message.content.strip()

        # 尝试解析JSON
        try:
            result = json.loads(result_text)
            keywords = result.get('keywords', [])
            if keywords:
                print(f"[DEBUG] AI提取关键词: {keywords}")
                return keywords
        except json.JSONDecodeError:
            print(f"[DEBUG] AI返回非JSON: {result_text}")

        # 如果AI提取失败，回退到规则提取
        return None

    except Exception as e:
        print(f"[DEBUG] AI关键词提取失败: {str(e)}")
        return None

def load_synonyms():
    """加载同义词库"""
    synonyms_path = BASE_DIR / "synonyms.json"
    try:
        with open(synonyms_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def extract_keywords_hybrid(query):
    """混合关键词提取策略：规则 + 同义词 + AI"""
    import re

    # 1. 规则匹配（快速）
    query_clean = re.sub(r'[，。？！；：""''（）、\.\?\!\;\:\(\)]', '', query)

    # 加载同义词库
    synonyms = load_synonyms()

    # 收集所有标准术语和同义词
    all_terms = []

    # 原则术语 + 同义词
    for principle, syn_list in synonyms.get('principle_synonyms', {}).items():
        all_terms.append(principle)
        all_terms.extend(syn_list)

    # 场景术语 + 同义词
    for scenario, syn_list in synonyms.get('scenario_synonyms', {}).items():
        all_terms.append(scenario)
        all_terms.extend(syn_list)

    # 行为动词 + 同义词
    for behavior, syn_list in synonyms.get('behavior_synonyms', {}).items():
        all_terms.append(behavior)
        all_terms.extend(syn_list)

    # 策略术语 + 同义词
    for tactic, syn_list in synonyms.get('tactic_synonyms', {}).items():
        all_terms.append(tactic)
        all_terms.extend(syn_list)

    keywords = []

    # 匹配所有术语
    matched_terms = set()
    for term in all_terms:
        if term in query_clean:
            # 记录匹配的术语，用于后续映射到标准术语
            matched_terms.add(term)

    # 将匹配到的同义词映射回标准术语
    for category_name, category_dict in synonyms.items():
        for standard_term, syn_list in category_dict.items():
            # 检查标准术语是否匹配
            if standard_term in matched_terms:
                keywords.append(standard_term)
                continue

            # 检查同义词是否匹配
            for syn in syn_list:
                if syn in matched_terms:
                    keywords.append(standard_term)
                    break

    # 2. 如果关键词不足，调用AI补充
    if len(keywords) < 3 and DEEPSEEK_API_KEY:
        ai_keywords = extract_keywords_with_deepseek(query)
        if ai_keywords:
            keywords.extend(ai_keywords)

    # 3. 如果仍然不足，使用n-gram作为补充
    if len(keywords) < 2:
        stop_words = {'的', '了', '是', '我', '有', '和', '就', '不', '人', '都', '一', '个', '在', '你', '会', '着', '吗', '呢', '吧', '啊', '这', '那', '什么', '怎么', '如何', '怎样', '客户', '问题'}

        for length in range(4, 1, -1):  # 4字、3字、2字
            for i in range(len(query_clean) - length + 1):
                word = query_clean[i:i+length]
                if word not in stop_words and word not in keywords:
                    keywords.append(word)
                    if len(keywords) >= 5:  # 限制数量
                        break
            else:
                continue  # 只在内层循环正常结束时继续
            break  # 外层循环也中断

    return list(set(keywords))  # 去重

def search_ontology(query, top_k=5):
    """在本体中搜索相关内容"""
    ontology = get_ontology()

    # 清理查询（移除标点）
    import re
    query_clean = re.sub(r'[，。？！；：""''（）、\.\?\!\;\:\(\)]', '', query)

    # 使用混合策略提取关键词
    keywords = extract_keywords_hybrid(query)

    print(f"[DEBUG] Query: {query}")
    print(f"[DEBUG] Keywords extracted: {keywords}")

    # 收集所有实体（从各个字段中）
    all_entities = []
    entity_types = ['principles', 'concepts', 'terms', 'cases', 'experiments', 'persons',
                   'reasoning_chains', 'tactics', 'action_steps', 'scripts', 'scenarios']

    for entity_type in entity_types:
        if entity_type in ontology:
            for entity in ontology[entity_type]:
                entity_copy = entity.copy()  # 复制实体，不修改原始数据
                entity_copy['type'] = entity_type.rstrip('s')
                # 补全description
                entity_copy = enrich_entity_description(entity_copy)
                all_entities.append(entity_copy)

    # 搜索相关实体
    results = []
    matched_keywords = {}  # 记录每个实体匹配到的关键词

    for entity in all_entities:
        # 简单的关键词匹配
        entity_text = json.dumps(entity, ensure_ascii=False).lower()
        score = sum(1 for kw in keywords if kw in entity_text)

        if score > 0:
            # 找出匹配的关键词
            matched = [kw for kw in keywords if kw in entity_text]
            results.append({
                'entity': entity,
                'score': score,
                'matched_keywords': matched
            })

    # 按相关性排序
    results.sort(key=lambda x: x['score'], reverse=True)
    final_results = [r['entity'] for r in results[:top_k]]

    # 构建搜索过程信息
    search_process = {
        'query': query,
        'query_clean': query_clean,
        'keywords_extracted': keywords,
        'total_entities': len(all_entities),
        'matched_entities': len(results),
        'top_results': [
            {
                'entity': r['entity'],
                'score': r['score'],
                'matched_keywords': r['matched_keywords'],
                'type': r['entity'].get('type', 'unknown'),
                'name': r['entity'].get('name', r['entity'].get('id', '')),
                'description': r['entity'].get('description', '')[:100] + '...' if len(r['entity'].get('description', '')) > 100 else r['entity'].get('description', '')
            }
            for r in results[:top_k]
        ]
    }

    return final_results, search_process

@app.route('/')
def index():
    """返回主页"""
    return send_from_directory(BASE_DIR / 'web', 'index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    """聊天接口"""
    data = request.json
    query = data.get('query', '').strip()
    history = data.get('history', [])

    if not query:
        return jsonify({'error': '请输入问题'}), 400

    if not DEEPSEEK_API_KEY:
        return jsonify({'error': 'DEEPSEEK_API_KEY环境变量未设置'}), 500

    try:
        # 1a. 新引擎：三层检索 + 多跳扩展
        from knowledge_graph import get_knowledge_graph
        kg = get_knowledge_graph()
        kg_result = kg.search(query, history=history)

        # 1b. 兼容引擎：保留旧 search_ontology 作为并行信号
        relevant_entities, search_process = search_ontology(query, top_k=10)

        # 2. 构建结构化系统提示词：核心实体 + 多跳扩展 + 多词匹配 + 兼容引擎匹配
        from enhanced_prompts import get_structured_prompt
        system_prompt = get_structured_prompt(kg_result, legacy_entities=relevant_entities[:8])

        # 3. 调用DeepSeek API
        client = openai.OpenAI(
            api_key=DEEPSEEK_API_KEY,
            base_url=DEEPSEEK_BASE_URL
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query}
        ]

        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=messages,
            temperature=0.7,
            max_tokens=2000
        )

        answer = response.choices[0].message.content

        # 4. 准备完整的上下文信息（用于前端展示）
        full_context = {
            'system_prompt': system_prompt,
            'user_query': query,
            'llm_keywords': kg_result.get('llm_keywords', []),
            'keyword_source': kg_result.get('keyword_source', 'unknown'),
            'matched_synonym_standards': kg_result.get('matched_synonym_standards', []),
            'layer1_direct': kg_result.get('layer1_direct', []),
            'layer2_synonym': kg_result.get('layer2_synonym', []),
            'layer3_multiword': kg_result.get('layer3_multiword', [])[:5],
            'hop_groups': kg_result.get('hop_groups', {}),
            'core_entities': kg_result.get('core_entities', []),
            'relevant_entities': [
                {
                    'type': e.get('type'),
                    'name': e.get('name', e.get('id', '')),
                    'description': e.get('description', '')
                }
                for e in relevant_entities[:5]
            ]
        }

        # 5. 返回结果
        return jsonify({
            'query': query,
            'answer': answer,
            'relevant_entities_count': len(relevant_entities),
            'core_entities_count': len(kg_result.get('core_entities', [])),
            'hop_count': sum(len(v) for v in kg_result.get('hop_groups', {}).values()),
            'entities': [
                {
                    'id': e.get('id'),
                    'type': e.get('type'),
                    'name': e.get('name', e.get('id'))
                }
                for e in relevant_entities[:3]
            ],
            'full_context': full_context
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'处理请求时出错: {str(e)}'}), 500

@app.route('/api/chat/stream', methods=['POST'])
def chat_stream():
    """流式聊天接口 - 实时显示搜索过程"""
    from flask import Response
    import json

    data = request.json
    query = data.get('query', '').strip()
    history = data.get('history', [])

    if not query:
        return jsonify({'error': '请输入问题'}), 400

    if not DEEPSEEK_API_KEY:
        return jsonify({'error': 'DEEPSEEK_API_KEY环境变量未设置'}), 500

    def generate():
        try:
            # 步骤1: 开始搜索
            yield f"data: {json.dumps({'type': 'step', 'step': 1, 'message': '正在用 LLM 提炼搜索词...', 'status': 'processing'}, ensure_ascii=False)}\n\n"

            # 步骤2a: 新引擎 - 三层检索 + 多跳扩展
            from knowledge_graph import get_knowledge_graph
            kg = get_knowledge_graph()
            kg_result = kg.search(query, history=history)

            # 步骤2b: 兼容引擎 - 保留旧 search_ontology 作为并行信号
            relevant_entities, search_process = search_ontology(query, top_k=10)

            # 步骤3: 显示搜索过程（合并新旧引擎信息）
            merged_process = dict(search_process)
            merged_process['new_engine'] = {
                'llm_keywords': kg_result.get('llm_keywords', []),
                'keyword_source': kg_result.get('keyword_source', 'unknown'),
                'matched_synonym_standards': kg_result.get('matched_synonym_standards', []),
                'layer1_direct_count': len(kg_result.get('layer1_direct', [])),
                'layer2_synonym_count': len(kg_result.get('layer2_synonym', [])),
                'layer3_multiword_count': len(kg_result.get('layer3_multiword', [])),
                'hop_group_counts': {k: len(v) for k, v in kg_result.get('hop_groups', {}).items()},
                'layer1_direct': kg_result.get('layer1_direct', []),
                'layer2_synonym': kg_result.get('layer2_synonym', []),
                'hop_groups': kg_result.get('hop_groups', {}),
            }
            yield f"data: {json.dumps({'type': 'search_process', 'data': merged_process}, ensure_ascii=False)}\n\n"

            # 步骤4: 显示匹配到的实体
            core_count = len(kg_result.get('core_entities', []))
            hop_count = sum(len(v) for v in kg_result.get('hop_groups', {}).values())
            yield f"data: {json.dumps({'type': 'step', 'step': 2, 'message': f'核心实体 {core_count} 个 · 多跳扩展 {hop_count} 个 · 兼容引擎 {len(relevant_entities)} 个', 'status': 'success'}, ensure_ascii=False)}\n\n"

            # 步骤5: 构建结构化系统提示词（核心实体 + 多跳扩展 + 多词匹配 + 兼容引擎并行）
            from enhanced_prompts import get_structured_prompt
            context = get_structured_prompt(kg_result, legacy_entities=relevant_entities[:8])

            # 步骤6: 调用DeepSeek API
            yield f"data: {json.dumps({'type': 'step', 'step': 3, 'message': '正在调用AI生成回答...', 'status': 'processing'}, ensure_ascii=False)}\n\n"

            client = openai.OpenAI(
                api_key=DEEPSEEK_API_KEY,
                base_url=DEEPSEEK_BASE_URL
            )

            messages = [
                {"role": "system", "content": context},
                {"role": "user", "content": query}
            ]

            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                temperature=0.7,
                max_tokens=2000
            )

            answer = response.choices[0].message.content

            # 步骤7: 返回最终结果
            yield f"data: {json.dumps({'type': 'step', 'step': 4, 'message': 'AI回答生成完成', 'status': 'success'}, ensure_ascii=False)}\n\n"

            final_context = {
                'system_prompt': context,
                'user_query': query,
                'llm_keywords': kg_result.get('llm_keywords', []),
                'keyword_source': kg_result.get('keyword_source', 'unknown'),
                'matched_synonym_standards': kg_result.get('matched_synonym_standards', []),
                'layer1_direct': kg_result.get('layer1_direct', []),
                'layer2_synonym': kg_result.get('layer2_synonym', []),
                'layer3_multiword': kg_result.get('layer3_multiword', [])[:5],
                'hop_groups': kg_result.get('hop_groups', {}),
                'core_entities': kg_result.get('core_entities', []),
                'relevant_entities': [
                    {
                        'type': e.get('type'),
                        'name': e.get('name', e.get('id', '')),
                        'description': e.get('description', '')
                    }
                    for e in relevant_entities[:5]
                ]
            }

            yield f"data: {json.dumps({'type': 'result', 'answer': answer, 'full_context': final_context}, ensure_ascii=False)}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)}, ensure_ascii=False)}\n\n"

    return Response(generate(), mimetype='text/event-stream')

def find_entity_by_id(entity_id: str):
    """根据ID查找实体"""
    ontology = get_ontology()

    # 在各个类型中查找
    entity_types = ['principles', 'concepts', 'terms', 'cases', 'experiments', 'persons',
                   'reasoning_chains', 'tactics', 'action_steps', 'scripts', 'scenarios']

    for entity_type in entity_types:
        if entity_type in ontology:
            for entity in ontology[entity_type]:
                if entity.get('id') == entity_id:
                    # 添加type字段
                    entity['type'] = entity_type.rstrip('s')
                    return entity

    return None

@app.route('/api/ontology/related', methods=['GET'])
def get_related_entities():
    """获取相关实体（多级跳转API）"""
    entity_id = request.args.get('entity_id', '').strip()
    direction = request.args.get('direction', 'both')  # forward, backward, both
    max_depth = int(request.args.get('max_depth', '1'))
    max_results = int(request.args.get('max_results', '20'))

    if not entity_id:
        return jsonify({'error': '请提供entity_id参数'}), 400

    ontology = get_ontology()
    relations = ontology.get('relations', [])

    # 查找相关关系
    related = []
    visited = {entity_id}  # 避免循环

    for rel in relations:
        rel_entity = None
        rel_direction = None

        # 正向关系: from_id == entity_id
        if direction in ['forward', 'both'] and rel['from_id'] == entity_id:
            rel_entity = find_entity_by_id(rel['to_id'])
            rel_direction = 'forward'

        # 反向关系: to_id == entity_id
        elif direction in ['backward', 'both'] and rel['to_id'] == entity_id:
            rel_entity = find_entity_by_id(rel['from_id'])
            rel_direction = 'backward'

        if rel_entity and rel_entity.get('id') not in visited:
            visited.add(rel_entity['id'])

            # 补全description
            rel_entity = enrich_entity_description(rel_entity)

            related.append({
                'entity': {
                    'id': rel_entity.get('id'),
                    'type': rel_entity.get('type'),
                    'name': rel_entity.get('name', rel_entity.get('id')),
                    'description': rel_entity.get('description', '')[:200] + '...' if len(rel_entity.get('description', '')) > 200 else rel_entity.get('description', '')
                },
                'relation_type': rel['relation_type'],
                'direction': rel_direction,
                'relation_description': rel.get('description', '')
            })

    # 限制结果数量
    related = related[:max_results]

    return jsonify({
        'entity_id': entity_id,
        'direction': direction,
        'related_count': len(related),
        'related_entities': related
    })

@app.route('/api/ontology/stats', methods=['GET'])
def get_stats():
    """获取本体统计信息"""
    ontology = get_ontology()

    # 统计各类型实体数量
    entity_type_counts = {}
    entity_types = ['principles', 'concepts', 'terms', 'cases', 'experiments', 'persons',
                   'reasoning_chains', 'tactics', 'action_steps', 'scripts', 'scenarios']

    for entity_type in entity_types:
        if entity_type in ontology:
            entity_type_counts[entity_type] = len(ontology[entity_type])

    # 计算总数
    total_count = sum(entity_type_counts.values())

    return jsonify({
        'stats': {'total_entities': total_count},
        'entity_type_counts': entity_type_counts
    })

if __name__ == '__main__':
    print("启动影响力本体问答系统...")
    print(f"本体数据路径: {ONTOLOGY_PATH}")
    print(f"API Key: {'已设置' if DEEPSEEK_API_KEY else '未设置'}")
    print("访问地址: http://localhost:3000")
    app.run(debug=False, host='0.0.0.0', port=3000)
