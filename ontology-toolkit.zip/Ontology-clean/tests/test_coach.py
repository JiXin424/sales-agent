"""Sprint 3 测试：销售教练模块"""

import pytest


# === Prep (拜访准备) Tests ===

@pytest.mark.asyncio
async def test_prep_with_company(db_session):
    """测试生成拜访准备方案"""
    from backend.ontology.crud import ensure_default_types, create_object, create_link
    from backend.coach.prep import generate_prep_plan

    await ensure_default_types(db_session)
    await create_object(db_session, "Company", "测试公司", {"行业": "医疗", "规模": "中型"})
    await create_object(db_session, "Product", "测试产品", {"特点": "AI驱动"})
    await create_object(db_session, "Scenario", "基层筛查", {})
    await db_session.commit()
    await create_link(db_session, "测试公司", "测试产品", "produces")
    await create_link(db_session, "测试产品", "基层筛查", "targets")
    await db_session.commit()

    result = await generate_prep_plan("帮我准备拜访基层医院的材料", db_session)
    assert result["plan"]
    assert len(result["plan"]) > 50
    assert "evidence" in result


# === Objection (异议处理) Tests ===

@pytest.mark.asyncio
async def test_objection_handling(db_session):
    """测试异议处理"""
    from backend.ontology.crud import ensure_default_types, create_object
    from backend.coach.objection import handle_objection

    await ensure_default_types(db_session)
    await create_object(db_session, "Product", "测试产品", {"价格": "50万", "ROI": "1年回本"})
    await create_object(db_session, "Certification", "三类证", {})
    await db_session.commit()

    result = await handle_objection("客户说你们的系统太贵了", db_session)
    assert result["response"]
    assert len(result["response"]) > 30
    assert "tactics" in result


# === Comparison (竞品对比) Tests ===

@pytest.mark.asyncio
async def test_comparison(db_session):
    """测试竞品对比"""
    from backend.ontology.crud import ensure_default_types, create_object, create_link
    from backend.coach.comparison import generate_comparison

    await ensure_default_types(db_session)
    await create_object(db_session, "Product", "我们的产品", {"特点": "AI驱动", "价格": "50万"})
    await create_object(db_session, "Competitor", "竞品A", {"特点": "传统方法", "价格": "30万"})
    await db_session.commit()
    await create_link(db_session, "我们的产品", "竞品A", "competes_with")
    await db_session.commit()

    result = await generate_comparison("我们的产品和竞品A比怎么样？", db_session)
    assert result["analysis"]
    assert len(result["analysis"]) > 50


# === Coach API Tests ===

def test_coach_router_exists():
    """测试 coach router 已注册"""
    from backend.api.coach import router
    assert router is not None
