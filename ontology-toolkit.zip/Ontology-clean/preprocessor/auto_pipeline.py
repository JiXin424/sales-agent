#!/usr/bin/env python3
"""
auto_pipeline — 全自动管道脚本

流程：
  Phase 1: 修复 ASR 转写错别字（7 个视频文件）
  Phase 2: 重建本体（build_ontology.py，使用修复后文件）
  Phase 3: 修复本体输出中的实体重复/错别字问题
  Phase 4: 执行文档优化（md_optimizer.py）
  Phase 5: 最终验证报告
"""

import os
import sys
import subprocess
import json
import time
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent.resolve()
DOCS_DIR = SCRIPT_DIR.parent / "docs" / "ProductX材料第一批"
ASR_DIR = DOCS_DIR / "培训材料md" / "视频培训材料"
TRAINING_MD_DIR = DOCS_DIR / "培训材料md"
SUBJECT_FILE = DOCS_DIR / "主体文件.md"
ONTOLOGY_JSON = DOCS_DIR / "ontology.json"
SUBJECT_FILE_V2 = DOCS_DIR / "主体文件_v2.md"
SUBJECT_FILE_FIXED = DOCS_DIR / "主体文件_fixed.md"
ONTOLOGY_JSON_V2 = DOCS_DIR / "ontology_v2.json"
OPTIMIZED_DIR = DOCS_DIR / "培训材料md_优化"

MODEL = "deepseek-v4-pro"
API_KEY = "DEEPSEEK_API_KEY_PLACEHOLDER"
BASE_URL = "https://api.deepseek.com"

sys.path.insert(0, str(SCRIPT_DIR))
from md_optimizer import OpenAIClient


def log(msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)
    # Also write to pipeline log
    with open(DOCS_DIR / "_pipeline.log", "a") as f:
        f.write(f"[{ts}] {msg}\n")


# ═══════════════════════════════════════════════
# Phase 1: Fix ASR
# ═══════════════════════════════════════════════

ASR_FIX_PROMPT = """你是医学术语校正专家。以下文本来自语音识别(ASR)转写，包含大量同音字/错别字。

核心规则：
1. 只修正语音识别错误，不改变原意、不添加内容、不删除内容
2. 所有数字、百分比、日期、时间、剂量、生存率等数值必须原封不动保留
3. 修正方向：同音/近音字→正确医学术语
4. 产品名标准化：ProductX(商品名®)、竞品E、竞品C(竞品C)等
5. 输出格式与原Markdown完全一致

请直接输出修正后的全文，不要加任何说明。"""


def phase1_fix_asr():
    """修复 7 个 ASR 视频转写文件"""
    log("=" * 50)
    log("Phase 1: 修复 ASR 转写错别字")
    log("=" * 50)

    # 断点：检查是否已完成
    bak_count = len(list(ASR_DIR.glob("*.asr_orig.bak")))
    if bak_count >= 7:
        log(f"Phase 1 已完成（{bak_count} 备份），跳过")
        return True

    files = sorted(ASR_DIR.glob("*.md"))
    # 跳过已修复的
    pending = [f for f in files if not f.with_name(f"{f.stem}.fixed.md").exists()]
    if not pending:
        log("所有文件已修复，跳过")
        return True

    client = OpenAIClient(api_key=API_KEY, base_url=BASE_URL, model=MODEL)
    ok = 0
    for f in pending:
        log(f"  修复: {f.name}")
        content = f.read_text(encoding="utf-8")
        try:
            result = client.chat_stream(
                system="你是专业的医学语音转写校正助手。",
                user=f"{ASR_FIX_PROMPT}\n\n---\n\n{content}",
                temperature=0.1,
                extra_body={"max_tokens": 16000, "reasoning_effort": "medium"},
            )
            out = f.with_name(f"{f.stem}.fixed.md")
            out.write_text(result, encoding="utf-8")
            ok += 1
            log(f"    ✅ {len(content)}→{len(result)} chars")
        except Exception as e:
            log(f"    ❌ {e}")
            return False

    # 替换原始文件
    for f in files:
        fixed = f.with_name(f"{f.stem}.fixed.md")
        if fixed.exists():
            bak = f.with_suffix(".asr_orig.bak")
            if not bak.exists():
                f.rename(bak)
            fixed.rename(f)

    log(f"Phase 1 完成: {ok}/{len(pending)} 修复")
    return True


# ═══════════════════════════════════════════════
# Phase 2: Rebuild ontology
# ═══════════════════════════════════════════════

def phase2_rebuild_ontology():
    """用修复后的文件重新构建本体"""
    log("=" * 50)
    log("Phase 2: 重建本体")
    log("=" * 50)

    # 断点：检查是否已完成
    if SUBJECT_FILE_V2.exists() and ONTOLOGY_JSON_V2.exists():
        log(f"Phase 2 已完成，跳过 ({SUBJECT_FILE_V2}, {ONTOLOGY_JSON_V2})")
        return True

    cmd = [
        sys.executable, str(SCRIPT_DIR / "build_ontology.py"),
        str(TRAINING_MD_DIR),
        "--types", "sales",
        "--workers", "6",
        "--batch-size", "5",
        "--max-doc-chars", "4000",
        "-o", str(SUBJECT_FILE_V2),
        "--dump-json", str(ONTOLOGY_JSON_V2),
    ]
    log(f"  执行: {' '.join(cmd)}")
    proc = subprocess.run(cmd, cwd=str(SCRIPT_DIR), capture_output=False,
                          text=True, timeout=1800)
    if proc.returncode != 0:
        log(f"❌ build_ontology 失败 (code={proc.returncode})")
        return False

    log(f"Phase 2 完成: {SUBJECT_FILE_V2} + {ONTOLOGY_JSON_V2}")
    return True


# ═══════════════════════════════════════════════
# Phase 3: Fix ontology (dedup entities, fix ASR errors)
# ═══════════════════════════════════════════════

def phase3_fix_ontology():
    """规则去重：同类型+同名标准化后合并实体"""
    log("=" * 50)
    log("Phase 3: 本体实体去重（规则）")
    log("=" * 50)

    if SUBJECT_FILE_FIXED.exists() and (DOCS_DIR / "ontology_fixed.json").exists():
        log("Phase 3 已完成，跳过")
        return True

    if not ONTOLOGY_JSON_V2.exists():
        log(f"❌ 本体 JSON 不存在: {ONTOLOGY_JSON_V2}")
        return False

    with open(ONTOLOGY_JSON_V2) as f:
        ontology = json.load(f)

    objects = ontology.get("objects", [])
    links = ontology.get("links", [])
    log(f"  原始: {len(objects)} 实体, {len(links)} 关系")

    # 标准化名称：去括号全角→半角、去®
    def norm(name: str) -> str:
        return name.replace("（", "(").replace("）", ")").replace("®", "").strip()

    # 同 type + 标准化名称 → 合并
    merged = {}
    dropped = 0
    for obj in objects:
        key = (obj["type"], norm(obj["name"]))
        if key in merged:
            existing = merged[key]
            if len(obj["name"]) > len(existing["name"]):
                existing["name"] = obj["name"]
            for k, v in obj.get("properties", {}).items():
                if k not in existing.get("properties", {}):
                    existing["properties"][k] = v
            dropped += 1
        else:
            merged[key] = dict(obj)

    fixed_objects = list(merged.values())
    log(f"  去重后: {len(fixed_objects)} 实体 (合并 {dropped} 个)")

    # 更新关系引用
    name_map = {}
    for obj in objects:
        key = (obj["type"], norm(obj["name"]))
        if key in merged and obj["name"] != merged[key]["name"]:
            name_map[obj["name"]] = merged[key]["name"]

    fixed_links = []
    for link in links:
        s, t = link.get("source", ""), link.get("target", "")
        link2 = dict(link)
        if s in name_map:
            link2["source"] = name_map[s]
        if t in name_map:
            link2["target"] = name_map[t]
        fixed_links.append(link2)

    # 写输出
    fixed_json = {
        "stats": {**ontology.get("stats", {}),
                  "original_objects": len(objects), "fixed_objects": len(fixed_objects),
                  "merged_duplicates": dropped,
                  "phase3_fixed_at": datetime.now().isoformat()},
        "objects": fixed_objects,
        "links": fixed_links,
    }
    with open(DOCS_DIR / "ontology_fixed.json", "w") as f:
        json.dump(fixed_json, f, ensure_ascii=False, indent=2)

    # 生成简化主体文件
    lines = ["# 销售知识本体背景知识（修复版）", "",
             f"> Phase 3 规则去重 | {datetime.now().strftime('%Y-%m-%d %H:%M')}", "",
             f"## 实体 ({len(fixed_objects)})", ""]
    by_type = {}
    for obj in fixed_objects:
        t = obj.get("type", "Other")
        by_type.setdefault(t, []).append(obj)
    for t, objs in sorted(by_type.items()):
        lines.append(f"### {t} ({len(objs)})")
        for o in objs[:30]:
            props = o.get("properties", {})
            ps = ", ".join(f"{k}: {v}" for k, v in sorted(props.items())[:5])
            lines.append(f"- **{o['name']}**" + (f" — {ps}" if ps else ""))
        if len(objs) > 30:
            lines.append(f"  ... 共 {len(objs)} 个")
        lines.append("")
    lines.append(f"## 关系 ({len(fixed_links)} 条)")
    for link in fixed_links[:50]:
        lines.append(f"- {link.get('source','?')} —[{link.get('type','?')}]→ {link.get('target','?')}")
    if len(fixed_links) > 50:
        lines.append(f"  ... 共 {len(fixed_links)} 条")

    with open(SUBJECT_FILE_FIXED, "w") as f:
        f.write("\n".join(lines))

    log(f"Phase 3 完成: {SUBJECT_FILE_FIXED}")
    return True


# ═══════════════════════════════════════════════
# Phase 4: Run md_optimizer
# ═══════════════════════════════════════════════

def phase4_optimize():
    """执行 Step 3 文档优化"""
    log("=" * 50)
    log("Phase 4: 文档优化 (md_optimizer)")
    log("=" * 50)

    subject = SUBJECT_FILE_FIXED if SUBJECT_FILE_FIXED.exists() else SUBJECT_FILE_V2
    if not subject.exists():
        log(f"❌ 主体文件不存在: {subject}")
        return False

    cmd = [
        sys.executable, str(SCRIPT_DIR / "md_optimizer.py"),
        str(TRAINING_MD_DIR),
        "--model", MODEL,
        "--workers", "10",
        "--subject", str(subject),
        "--prompt", str(SCRIPT_DIR / "MAX-v3-prompt.md"),
    ]
    # md_optimizer 不接受 --output-dir 参数，它会在输入目录旁创建 _优化 目录
    # 我们可以用 PYTHON 环境来捕捉输出目录

    log(f"  执行: {' '.join(cmd)}")
    proc = subprocess.run(cmd, cwd=str(SCRIPT_DIR), capture_output=False,
                          text=True, timeout=1200)
    if proc.returncode != 0:
        log(f"❌ md_optimizer 失败 (code={proc.returncode})")
        return False

    log("Phase 4 完成")
    return True


# ═══════════════════════════════════════════════
# Phase 5: Report
# ═══════════════════════════════════════════════

def phase5_report():
    log("=" * 50)
    log("Phase 5: 最终报告")
    log("=" * 50)

    if SUBJECT_FILE_FIXED.exists():
        log(f"✅ 主体文件(修复版): {SUBJECT_FILE_FIXED}")
    elif SUBJECT_FILE_V2.exists():
        log(f"✅ 主体文件(V2): {SUBJECT_FILE_V2}")

    fixed_json = DOCS_DIR / "ontology_fixed.json"
    if fixed_json.exists():
        with open(fixed_json) as f:
            data = json.load(f)
        s = data.get("stats", {})
        log(f"  原始实体: {s.get('original_objects', '?')} → 修复后: {s.get('fixed_objects', '?')}")
        log(f"  原始关系: {s.get('original_links', '?')} → 修复后: {s.get('fixed_links', '?')}")

    # Check optimized output
    for cand in [DOCS_DIR / "培训材料md_优化", DOCS_DIR.parent / "培训材料md_优化",
                 TRAINING_MD_DIR.parent / "培训材料md_优化"]:
        if cand.is_dir():
            opt_files = list(cand.glob("*.md"))
            if opt_files:
                log(f"  优化输出: {cand} ({len(opt_files)} files)")
                break

    log(f"\n{'='*50}")
    log("全管道完成！")
    log(f"{'='*50}")
    return True


# ═══════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════

def main():
    os.makedirs(DOCS_DIR, exist_ok=True)
    log("🚀 auto_pipeline 启动")

    phases = [
        ("Phase 1: ASR修复", phase1_fix_asr),
        ("Phase 2: 重建本体", phase2_rebuild_ontology),
        ("Phase 3: 本体修复", phase3_fix_ontology),
        ("Phase 4: 文档优化", phase4_optimize),
        ("Phase 5: 最终报告", phase5_report),
    ]

    for name, func in phases:
        log(f"\n{'='*50}")
        log(f"开始 {name}")
        try:
            ok = func()
            if not ok:
                log(f"❌ {name} 失败，管道中止")
                sys.exit(1)
        except Exception as e:
            log(f"💥 {name} 异常: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    sys.exit(0)


if __name__ == "__main__":
    main()
