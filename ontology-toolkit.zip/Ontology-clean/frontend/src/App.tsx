import { useState } from 'react';
import { HashRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import {
  MessageOutlined,
  AimOutlined,
  ShareAltOutlined,
  FolderOpenOutlined,
  DashboardOutlined,
  WarningOutlined,
} from '@ant-design/icons';
import ChatPage from './pages/ChatPage';
import CoachPage from './pages/CoachPage';
import GraphPage from './pages/GraphPage';
import DocumentsPage from './pages/DocumentsPage';
import DashboardPage from './pages/DashboardPage';
import ConflictsPage from './pages/ConflictsPage';
import './App.css';

const { Sider, Content } = Layout;

const NAV_ITEMS = [
  { key: '/', icon: <MessageOutlined />, label: '对话' },
  { key: '/coach', icon: <AimOutlined />, label: '教练' },
  { key: '/graph', icon: <ShareAltOutlined />, label: '图谱' },
  { key: '/docs', icon: <FolderOpenOutlined />, label: '文档' },
  { key: '/dashboard', icon: <DashboardOutlined />, label: '看板' },
  { key: '/conflicts', icon: <WarningOutlined />, label: '冲突' },
];

function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        width={220}
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        style={{ borderRight: '1px solid #30363d' }}
      >
        <div
          style={{
            height: 48,
            margin: 12,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: collapsed ? 14 : 16,
            fontWeight: 600,
            color: '#e6edf3',
            borderBottom: '1px solid #30363d',
            paddingBottom: 12,
          }}
        >
          {collapsed ? 'OC' : '本体销售教练'}
        </div>
        <Menu
          mode="inline"
          selectedKeys={[location.pathname]}
          items={NAV_ITEMS.map((item) => ({
            key: item.key,
            icon: item.icon,
            label: item.label,
            onClick: () => navigate(item.key),
          }))}
        />
      </Sider>
      <Layout>
        <Content
          style={{
            padding: 24,
            overflow: 'auto',
            background: '#0d1117',
          }}
        >
          <Routes>
            <Route path="/" element={<ChatPage />} />
            <Route path="/coach" element={<CoachPage />} />
            <Route path="/graph" element={<GraphPage />} />
            <Route path="/docs" element={<DocumentsPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/conflicts" element={<ConflictsPage />} />
          </Routes>
        </Content>
      </Layout>
    </Layout>
  );
}

function App() {
  return (
    <HashRouter>
      <AppLayout />
    </HashRouter>
  );
}

export default App;
