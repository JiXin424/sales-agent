"""FastAPI 入口"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import text

from backend.db import engine
from backend.ontology.models import Base
from backend.api.documents import router as documents_router
from backend.api.chat import router as chat_router
from backend.api.chat_stream import router as chat_stream_router
from backend.api.coach import router as coach_router
from backend.api.feedback import router as feedback_router
from backend.api.ontology import router as ontology_router
from backend.api.stats import router as stats_router
from backend.api.conflicts import router as conflicts_router
from backend.api.automation import router as automation_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动时创建表
    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


app = FastAPI(
    title="Ontology Sales Copilot",
    description="基于本体论的 AI 销售教练",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(documents_router)
app.include_router(chat_router)
app.include_router(chat_stream_router)
app.include_router(coach_router)
app.include_router(feedback_router)
app.include_router(ontology_router)
app.include_router(stats_router)
app.include_router(conflicts_router)
app.include_router(automation_router)


@app.get("/health")
async def health():
    return {"status": "ok"}
